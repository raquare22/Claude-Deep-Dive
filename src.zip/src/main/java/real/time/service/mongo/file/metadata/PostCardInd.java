package real.time.service.mongo.file.metadata;


import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PostCardInd {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PostCardInd.class);
	
	@Value("${OCM.postCardInd}")
	private Boolean ocmPostCardInd;
	
	@Value("${CAP.postCardInd}")
	private Boolean capPostCardInd;
	
	Map<String, Boolean> postCardIndMap = new HashMap<String, Boolean>();
	
	public void createMap() {
		postCardIndMap.put("OCM", ocmPostCardInd);
		postCardIndMap.put("CAP", capPostCardInd);
		
	}
	
	public Boolean getPostCardInd(String clientName) {
		createMap();
		Boolean postCardInd = true; 
		try {
			postCardInd = postCardIndMap.get(clientName);
		}
		catch (Exception e) {
			LOGGER.error("PostCardInd --> no postCardInd found for client: {}, defaulting as true", clientName);
			return true;
		}
		return postCardInd;
	}

}
