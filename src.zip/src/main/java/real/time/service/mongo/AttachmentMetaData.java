package real.time.service.mongo;



import real.time.service.revision.AttachmentRevision;
import real.time.service.mongo.processors.MetaData;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document(collection = "attachment")
public class AttachmentMetaData extends MetaData {
    private static final long serialVersionUID = 1L;

    private String adapterId;
    private String adapterTypeId;
    private String adapterName;
    private String contentType;
    private Date expires;
    private String externalId;
    private long fileSize;
    private String fileName;
    private String fsId;
    boolean isAsync;
    private String stAdapterDocId;
    private String sourceSystemName;
    private Date sourceSystemDateCreated;
    private int spaceId;
    private String cloudSpaceId;
    private String attachmentId;
    
    public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public String getCloudSpaceId() {
		return cloudSpaceId;
	}

	public void setCloudSpaceId(String cloudSpaceId) {
		this.cloudSpaceId = cloudSpaceId;
	}

	public AttachmentMetaData() {
        super();
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public boolean isAsync() {
        return isAsync;
    }

    public void setAsync(boolean isAsync) {
        this.isAsync = isAsync;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Date getExpires() {
        return expires == null ? null : (Date) expires.clone();

    }

    public void setExpires(Date expires) {
        this.expires = expires == null ? null : (Date) expires.clone();
    }

    public String getAdapterId() {
        return adapterId;
    }

    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    public String getAdapterName() {
        return adapterName;
    }

    public void setAdapterName(String adapterName) {
        this.adapterName = adapterName;

    }

    public String getFsId() {
        return fsId;
    }

    public void setFsId(String fsId) {
        this.fsId = fsId;
    }

    public String getStAdapterDocId() {
        return stAdapterDocId;
    }

    public void setStAdapterDocId(String stAdapterDocId) {
        this.stAdapterDocId = stAdapterDocId;
    }

    public String getAdapterTypeId() {
        return adapterTypeId;
    }

    public void setAdapterTypeId(String adapterTypeId) {
        this.adapterTypeId = adapterTypeId;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public Date getSourceSystemDateCreated() {
        return sourceSystemDateCreated == null ? null : (Date) sourceSystemDateCreated.clone();
    }

    public void setSourceSystemDateCreated(Date sourceSystemDateCreated) {
        this.sourceSystemDateCreated = sourceSystemDateCreated == null ? null : (Date) sourceSystemDateCreated.clone();
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(Integer spaceId) {
            this.spaceId = spaceId==null ? 0 : spaceId;
    }

    @Override
    public List<AttachmentRevision> getRevisions() {
        return revisions;
    }

}