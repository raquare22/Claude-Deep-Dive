package real.time.service.mongo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Date;
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentAttachmentMetaData  implements Serializable {

    private static final long serialVersionUID = 1L;

	@JsonProperty("id")
	private String fsId;
	
	@JsonProperty("attachmentId")
	private String attachmentId;
	
	@JsonIgnore
	private int index;
	
	@JsonProperty("fileName")
	private String fileName;
	
	@JsonProperty("fileSize")
	private long fileSize;
	
	@JsonProperty("contentType")
	private String contentType;
	
	@JsonIgnore
	private Date expires;
	
	private Date createdOn;
	
	private Date modifiedOn;
	
	private String createdBy;
	
	private String modifiedBy;
	
	private String virusScanStatus;
	
	private String cloudStorageProvider;
	
	@JsonProperty("status")
	private String status;
	
	@JsonProperty("external_id")
	private String externalId;
	
	@JsonProperty("error_message")
	private String errorMessage;
	
	@JsonProperty("spaceId")
	private String spaceId;
	
	private String url;

	private boolean sentToDocVault;
	
	public String getVirusScanStatus() {
		return virusScanStatus;
	}
	public void setVirusScanStatus(String virusScanStatus) {
		this.virusScanStatus = virusScanStatus;
	}
	public String getCloudStorageProvider() {
		return cloudStorageProvider;
	}
	public void setCloudStorageProvider(String cloudStorageProvider) {
		this.cloudStorageProvider = cloudStorageProvider;
	}
	public String getSpaceId() {
		return spaceId;
	}
	public String getAttachmentId() {
		return attachmentId;
	}
	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
    public String getName() {
        return fileName;
    }
    public void setName(String name) {
        this.fileName = name;
    }
    public Date getExpires() {
    	return expires==null?null:(Date)expires.clone();
    }
    public void setExpires(Date expires) {
    	this.expires = expires==null?null:(Date)expires.clone();
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
	public String getFsId() {
		return fsId;
	}
	public void setFsId(String fsId) {
		this.fsId = fsId;
	}
	public String getExternalId() {
		return externalId;
	}
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
		
	public boolean isSentToDocVault() {
        return sentToDocVault;
    }
    public void setSentToDocVault(boolean sentToDocVault) {
        this.sentToDocVault = sentToDocVault;
    }
    @Override
    public String toString() {
        return "DocumentAttachmentMetaData [fsId=" + fsId + ", index=" + index + ", fileName=" + fileName + ", expires=" + expires
                + ", status=" + status + ", externalId=" + externalId + ", errorMessage=" + errorMessage + ", sentToDocVault="
                + sentToDocVault + "]";
    }


}
