package real.time.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import org.springframework.context.annotation.Bean;

import real.time.service.ness.KafkaConfig;
import real.time.service.ness.RealTimeNessConfig;

@EnableAutoConfiguration
@SpringBootApplication
public class RealTimeServiceApplication {
	private static final Logger LOGGER = LogManager.getLogger(RealTimeServiceApplication.class);

	protected static boolean shutdown = false;

	public static void main(String[] args) {
		SpringApplication application =new SpringApplication(RealTimeServiceApplication.class);
		application.addListeners(new RealTimeServiceApplicationContextListener());
		application.run(args);
		if(KafkaConfig.enableNess) {
			RealTimeNessConfig.startup();
		}
		
	}
	
	@Bean
    public JavaMailSender javaMailSender() {
        return new JavaMailSenderImpl();
    }

	 @Bean
	 public ObjectMapper objectMapper() {
	    	
	    	 ObjectMapper mapper = new ObjectMapper();
	    	 mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
	    	 mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	    	 
	        return mapper;
	}
	
	@Bean
	public WebClient.Builder webClientBuilder() {
	    return WebClient.builder();
	}
	public static synchronized void shutdown() {
	  if(KafkaConfig.enableNess) {
		LOGGER.warn("SHUTDOWN: shutdown={}", shutdown);
		if (shutdown) {
			LOGGER.warn("SHUTDOWN: COMPLETE; Already performeds");
			return;
		}

		shutdown = true;
		RealTimeNessConfig.shutdown();
	 }
   }
}
