package real.time.service.java.delegate.docvault;

import java.util.concurrent.TimeUnit;

public class RetryOnExceptionHandler {

  public static final int DEFAULT_RETRIES = 4;
  public static final long DEFAULT_TIME_TO_WAIT_MS = 250L;

  private int numRetries;
  private long timeToWaitMS;
  private boolean isRetry;

  public RetryOnExceptionHandler(Number numRetries, Number timeToWaitMS) {
      this.numRetries = numRetries != null ? numRetries.intValue() : DEFAULT_RETRIES;
      this.timeToWaitMS = timeToWaitMS != null ? timeToWaitMS.longValue() : DEFAULT_TIME_TO_WAIT_MS;
      this.isRetry = false;
  }

  public RetryOnExceptionHandler() {
      this(DEFAULT_RETRIES, DEFAULT_TIME_TO_WAIT_MS);
      this.isRetry = false;
  }

  public boolean shouldRetry() {
      return (numRetries >= 0);
  }

  public void waitUntilNextTry() {
      try {
          TimeUnit.MILLISECONDS.sleep(timeToWaitMS);
      } catch (InterruptedException iex) {
          Thread.currentThread().interrupt();
      }
  }

  public void exceptionOccurred() throws OutOfRetriesException  {
      numRetries--;
      this.isRetry = true;
      if (!shouldRetry()) {
          throw new OutOfRetriesException("Exceeded " + numRetries + " retries");
      }
      waitUntilNextTry();
  }

  public int getNumRetries() {
      return numRetries;
  }

  public void setNumRetries(int numRetries) {
      this.numRetries = numRetries;
  }

  public long getTimeToWaitMS() {
      return timeToWaitMS;
  }

  public void setTimeToWaitMS(long timeToWaitMS) {
      this.timeToWaitMS = timeToWaitMS;
  }

	public boolean isRetry() {
		return isRetry;
	}
	
	public void setRetry(boolean isRetry) {
		this.isRetry = isRetry;
	}
  
  
  

}

