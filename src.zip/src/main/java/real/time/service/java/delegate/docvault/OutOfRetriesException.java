package real.time.service.java.delegate.docvault;


public class OutOfRetriesException extends Exception {
    private static final long serialVersionUID = 1L;

    public OutOfRetriesException() {
        super();
    }

    public OutOfRetriesException(String message) {
        super(message);
    }
    
    

}
