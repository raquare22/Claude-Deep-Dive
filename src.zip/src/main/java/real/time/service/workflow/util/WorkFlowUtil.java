package real.time.service.workflow.util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.json.JSONException;

import real.time.service.document.util.DocumentResponse;
import real.time.service.util.Parser;

import real.time.service.workflow.constants.Workflow;

public class WorkFlowUtil {
	
	private static final String MISSING_OR_INVALID_DATA = "Missing or invalid data: ";
	
	public static void updateEDeliveryError(Document metaData, String field) {
        String eDeliveryError = metaData.getString(Workflow.E_DELIVERY_ERROR);
        String errorMessage = MISSING_OR_INVALID_DATA + field;
        if (StringUtils.isBlank(eDeliveryError)) {
            metaData.put(Workflow.E_DELIVERY_ERROR, errorMessage);
        } else {
            if (!eDeliveryError.contains(errorMessage)) {
                metaData.put(Workflow.E_DELIVERY_ERROR, eDeliveryError + "|" + errorMessage);
            }
        }
    }
	
	
    public static DocumentResponse readDocumentResponseFromJsonFile(String fileName) throws IOException, JSONException {
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            String documentAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            return Parser.parseJsonWithDateFormat(documentAsJsonString,
                    DocumentResponse.class, sdf);
        }
    }
    
    public static DocumentResponse readDocumentResponseFromJsonString(String jsonString) throws IOException, JSONException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return Parser.parseJsonWithDateFormat(jsonString,
                DocumentResponse.class, sdf);
    }

}
