package real.time.service.oauth;

import java.util.Optional;


public interface OauthManagerUtil {
    String getOauthToken(String tokenType, String clientId, String clientSecret, String grantType, String oauthUrl, boolean getNewToken, String scope);

    OauthTokenExtended refreshToken(OauthTokenExtended tokenExtended) throws InterruptedException;

    Optional<OauthTokenExtended> getOauthTokenExtended(String appId, String appSecret, String url, String grantType, String scope);
}


