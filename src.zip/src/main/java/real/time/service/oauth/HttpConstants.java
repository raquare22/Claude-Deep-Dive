package real.time.service.oauth;


public class HttpConstants {
	private HttpConstants(){
	//not called
	}
	public static final int	   OAUTH_POST_RETRIES_VALUE = 3;
	public static final long   OAUTH_POST_RETRIES_SLEEP_TIME_VALUE = 3000;
	public static final int    LONG_FILE_TIMEOUT_SETTING = 3600000;
	public static final int    TIMEOUT_SETTING = 120000;
    public static final String CONTENT_TYPE_MULTIPART_FORM_DATA = "multipart/form-data";
    public static final String UTF_8 = "UTF-8";
    public static final String X_TRANSACTION_ID_HEADER = "X-Transaction-Id";
    public static final String PATH = "/v2/oauth2/token.json";
    public static final String HEADER_ACCEPT = "Accept";
    public static final String FORM_PARAM_CLIENT_ID = "client_id";
    public static final String FORM_PARAM_CLIENT_SECRET = "client_secret";
	public static final String FORM_PARAM_GRANT_TYPE = "grant_type";
	public static final String FORM_VALUE_AUTHORIZATION_CODE = "authorization_code";
	public static final String RESPONSE_BODY = "responseBody";
	public static final String STATUS_CODE = "statusCode";
	public static final String HTTPS_PROTOCOL = "https";
    public static final String FORM_PARAM_SCOPE = "scope";
}


