package real.time.service.oauth;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "token")
public class Token {

    @JsonProperty("grant_type")
    private String grantType;

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("refresh_token")
    private String refreshToken;

    @JsonProperty("token_type")
    private String tokenType;

    @JsonProperty("expires_in")
    private int expiresIn;

    @JsonProperty("client_id")
    private String clientId;

    @JsonProperty("client_secret")

    private String clientSecret;

    /**
     * @return the grant_type
     */
    public String getGrantType() {
        return grantType;
    }

    /**
     * @param grantType
     *            the grant_type to set
     */
    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    /**
     * @return the access_token
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * @param accessToken
     *            the access_token to set
     */
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * @return the refresh_token
     */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * @param refreshToken
     *            the refresh_token to set
     */
    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    /**
     * @return the token_type
     */
    public String getTokenType() {
        return tokenType;
    }

    /**
     * @param tokenType
     *            the token_type to set
     */
    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    /**
     * @return the expires_in
     */
    public int getExpiresIn() {
        return expiresIn;
    }

    /**
     * @param expiresIn
     *            the expires_in to set
     */
    public void setExpiresIn(int expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientIdentifier) {
        this.clientId = clientIdentifier;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }


}

