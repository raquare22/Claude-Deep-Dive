package real.time.service.oauth;

import real.time.service.config.ConfigData;
import real.time.service.oauth.HttpConstants;
import real.time.service.oauth.OauthTokenExtended;
import real.time.service.oauth.Token;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Optional;

@Component
public class AuthorizationOauthProvider {
	
	@Value("${OAUTH_POST_RETRIES}")
	private String oauthPostRetries;
	
	@Value("${OAUTH_POST_RETRIES_SLEEP_TIME}")
	private String oauthPostRetriesSleepTime;
	
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthorizationOauthProvider.class);
    private int postRetries;
    private long threadSleepTime;

    @Autowired
    private RestTemplate restTemplate;

    public Optional<Token> getOauth2Token(String url, OauthTokenExtended oauthTokenExtended) throws InterruptedException {
        setVariables();
        var count = 0;
        var response = postOauthToken(oauthTokenExtended, url);
        while (count < postRetries && response.getStatusCode().value() >= HttpStatus.INTERNAL_SERVER_ERROR.value()) {
            ++count;
            synchronized (this) {
                this.wait(threadSleepTime);
            }
            response = postOauthToken(oauthTokenExtended, url);
        }
        if (response.getStatusCode() == HttpStatus.OK) {
            return Optional.of(response.getBody());
        } else {
            LOGGER.error("Failed postOauthToken response status: {}, appIdentifier: {}", response.getStatusCode(), oauthTokenExtended.getApplicationId());
            return Optional.empty();
        }
    }

    private ResponseEntity<Token> postOauthToken(OauthTokenExtended oauthTokenExtended, String url) {
        var headers = new HttpHeaders();
        headers.set(HttpConstants.HEADER_ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        var uri = UriComponentsBuilder.fromUriString(url).build().encode().toUri();

        var reqPayload = new LinkedMultiValueMap<String, String>();
        reqPayload.add(HttpConstants.FORM_PARAM_CLIENT_ID, oauthTokenExtended.getApplicationId());
        reqPayload.add(HttpConstants.FORM_PARAM_CLIENT_SECRET, oauthTokenExtended.getPassword());
        reqPayload.add(HttpConstants.FORM_PARAM_GRANT_TYPE, (StringUtils.isEmpty(oauthTokenExtended.getGrantType())) ?
                HttpConstants.FORM_VALUE_AUTHORIZATION_CODE : oauthTokenExtended.getGrantType());
        if (oauthTokenExtended.getScope() != null && !oauthTokenExtended.getScope().isEmpty()) {
            reqPayload.add(HttpConstants.FORM_PARAM_SCOPE, oauthTokenExtended.getScope());
        }
        var request = new HttpEntity<MultiValueMap<String, String>>(reqPayload, headers);
        return restTemplate.exchange(uri, HttpMethod.POST, request, Token.class);
    }

    private void setVariables() {
        if (postRetries <= 0) {
            /*postRetries = Optional.ofNullable(ConfigData.getOrDefaultStringWithActiveProfile(OAUTH_POST_RETRIES))
                    .filter(StringUtils::isNumeric)
                    .map(Integer::parseInt)
                    .orElse(HttpConstants.OAUTH_POST_RETRIES_VALUE);*/
        	postRetries = Optional.ofNullable((oauthPostRetries))
                    .filter(StringUtils::isNumeric)
                    .map(Integer::parseInt)
                    .orElse(HttpConstants.OAUTH_POST_RETRIES_VALUE);
        }
        if (threadSleepTime <= 0) {
        	 threadSleepTime = Optional.ofNullable((oauthPostRetriesSleepTime))
                     .filter(StringUtils::isNumeric)
                     .map(Long::parseLong)
                     .orElse(HttpConstants.OAUTH_POST_RETRIES_SLEEP_TIME_VALUE);
           /* threadSleepTime = Optional.ofNullable(ConfigData.getOrDefaultStringWithActiveProfile(OAUTH_POST_RETRIES_SLEEP_TIME))
                    .filter(StringUtils::isNumeric)
                    .map(Long::parseLong)
                    .orElse(HttpConstants.OAUTH_POST_RETRIES_SLEEP_TIME_VALUE);*/
        }
    }

}
