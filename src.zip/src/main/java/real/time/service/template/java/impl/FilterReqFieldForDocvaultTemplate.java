package real.time.service.template.java.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import real.time.service.document.util.Attachment;
import real.time.service.document.util.DocumentResponse;
import real.time.service.template.Templates;
import real.time.service.template.TemplateHandler;
import real.time.service.workflow.util.WorkFlowUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilterReqFieldForDocvaultTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(FilterReqFieldForDocvaultTemplate.class);
    private static final String PIPE_DELIMITER = "|";
    private static final String PATIENT_ACCOUNT_NUMBER = "patientAccountNumber";

    ObjectMapper mapper = new ObjectMapper();

    public String filterDuplicates(String inputString) {
        String joinedInputString = "";

        try {
            if (!StringUtils.isEmpty(inputString)) {
                joinedInputString = (Arrays.asList(Arrays.stream(inputString.split("\\|"))
                        .filter(x -> !StringUtils.isBlank(x)).toArray(String[]::new)).stream()
                        .collect(Collectors.toSet())).stream()
                        .collect(Collectors.joining(PIPE_DELIMITER, PIPE_DELIMITER, PIPE_DELIMITER));
            }
        } catch (Exception e) {
            LOGGER.error("getting exception to filter duplicates {} {} ", inputString, ExceptionUtils.getStackTrace(e));
            joinedInputString = "";
        }

        return joinedInputString;
    }
    
	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT);
		
		LOGGER.debug("string template loaded, st={}", st);
		
		DocumentResponse document = (DocumentResponse) pojo;
		Attachment[] attachment = document.getAttachments();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        mapper.setDateFormat(df);
        
        String attachments;
        try {
			attachments = mapper.writeValueAsString(attachment);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
        
        String createApplication = (String) document.getMetadata().get("createApplication");
        Map<String, String> metadataMap = new HashMap<>();
        

        switch (createApplication) {
            case "OCM":
                metadataMap.put("memberId", (String) document.getMetadata().get("memberId"));
                metadataMap.put("physicianName", (String) document.getMetadata().get("physicianName"));
                metadataMap.put("memberName", (String) document.getMetadata().get("memberName"));
                metadataMap.put("notificationId", (String) document.getMetadata().get("notificationNumber"));
                metadataMap.put("notificationLetterId", (String) document.getMetadata().get("NotificationLetterID"));
                
                String dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && !dateOfService.isEmpty()) {
                    metadataMap.put("dateOfService", dateOfService);
                }
                break;
            case "CAP":
                metadataMap.put("physicianName", (String) document.getMetadata().get("physicianName"));
                metadataMap.put("claimNumber", filterDuplicates((String) document.getMetadata().get("multClaimNumber")) );
                metadataMap.put("memberId", filterDuplicates((String) document.getMetadata().get("multMemberId")) );

        }
        metadataMap.put("source", "PRUN");
		if (document.getMetadata().get("createdDate") != null
				&& document.getMetadata().get("createdDate").toString().length() != 24) {
			metadataMap.put("sourceCreatedDate", df.format(new Date()));
		} else {
			metadataMap.put("sourceCreatedDate", (String) document.getMetadata().get("createdDate"));
		}
        
		LOGGER.debug("document={}", document);

        return st.add("document", document)
                .add("map", metadataMap)
                .add("attachments", attachments)
                .render();
	}

    @Override
    public String convertWithTemplate(String jsonString) {
        DocumentResponse document;
        try {
            document = WorkFlowUtil.readDocumentResponseFromJsonString(jsonString);
        } catch (IOException e) {
        	throw new RuntimeException(e);
        }
        
        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        
        DocumentResponse document;
        try {
            document = WorkFlowUtil.readDocumentResponseFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
    }

    private String convertDateToGMTFormat(String dateStr){
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        format.setTimeZone(TimeZone.getTimeZone("GMT"));
        DateFormat format2 = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
        format2.setTimeZone(TimeZone.getTimeZone("GMT"));
        try {
            Date date = format.parse(dateStr);
            return format2.format(date);
        } catch (ParseException e) {
            LOGGER.error("convertDateToGMTFormat -- Unable to parse dateCreated string {}", dateStr);
            return null;
        }
    }
}
