package real.time.service.template;

public enum Templates {
	/**
	 * template method name should be same. For eg: checkWritePRAResponse,
	 * mergedMetaDataTemplate are present as method in allTemplates.stg
	 */
	ELGS_METADATA_VALIDATION_REQUEST("elgsMetadataValidationRequest"),
	FDS_CLOUD_SEARCH_TERMS("fdsCloudSearchTerms"),
  	FILTER_REQ_FIELD_FOR_DOCVAULT("filterReqFieldForDocvault");

	private final String template;

	Templates(String template) {
		this.template = template;
	}

	public String getTemplate() {
		return this.template;
	}
}
