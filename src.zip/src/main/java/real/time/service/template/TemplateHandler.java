package real.time.service.template;


public abstract class TemplateHandler {
    protected final TemplateLoader templateLoader;

    protected TemplateHandler() {
        this.templateLoader = TemplateLoader.getInstance();
    }

    public abstract String convertWithTemplate(String jsonString);

    public abstract String convertWithTemplateFromFilePath(String filePath);
    
    public abstract String convertWithTemplate(Object pojo);
}
