package real.time.service.template.java.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;

import real.time.service.mongo.DocumentMetaData;
import real.time.service.template.TemplateHandler;
import real.time.service.template.Templates;

public class ElgsMetadataValidationRequestTemplate extends TemplateHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ElgsMetadataValidationRequestTemplate.class);
	
	
	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.ELGS_METADATA_VALIDATION_REQUEST);
		
		Map<String, Object> map = (Map<String, Object>) pojo;
		
		DocumentMetaData document = (DocumentMetaData) map.get("document");
		org.bson.Document metadata = (org.bson.Document) map.get("metadata");
		List<String> errorList = (List<String>) map.get("errorList");
		String fdsCloudSpaceId = (String) map.get("fdsCloudSpaceId");
		String fdsCloudDocumentId = (String) map.get("fdsCloudDocumentId");

		
		String errorListStr = new Gson().toJson(errorList);
		
		return st.add("errorList", errorListStr).add("document", document)
				.add("metadata", metadata)
                .add("fdsCloudSpaceId", fdsCloudSpaceId)
                .add("fdsCloudDocumentId", fdsCloudDocumentId)
                .render();
	}

    @Override
    public String convertWithTemplate(String jsonString) {
        return null;
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        
        return null;
    }

}
