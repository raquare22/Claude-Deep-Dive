package real.time.service.template;

import real.time.service.template.java.impl.ElgsMetadataValidationRequestTemplate;
import real.time.service.template.java.impl.FDSCloudSearchTermsTemplate;
import real.time.service.template.java.impl.FilterReqFieldForDocvaultTemplate;
import org.eclipse.collections.impl.map.mutable.UnifiedMap;

import java.util.Map;

public final class TemplateFactory {
	private static final Map<String, TemplateHandler> TEMPLATE_HANDLERS = new UnifiedMap<>();

	/**
	 * Register your templates here. extend TemplateHandler class to override your
	 * own implementation. add that impl in the map
	 */
	static {
	    TEMPLATE_HANDLERS.put(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate(), new FilterReqFieldForDocvaultTemplate());
	    TEMPLATE_HANDLERS.put(Templates.ELGS_METADATA_VALIDATION_REQUEST.getTemplate(), new ElgsMetadataValidationRequestTemplate());
	    TEMPLATE_HANDLERS.put(Templates.FDS_CLOUD_SEARCH_TERMS.getTemplate(), new FDSCloudSearchTermsTemplate());
	}

	private TemplateFactory() {
		throw new AssertionError("Cannot instantiate");
	}

	public static TemplateHandler getInstance(String templates) {
		return TEMPLATE_HANDLERS.get(templates);
	}
}
