package real.time.service.template.java.impl;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import real.time.service.template.TemplateHandler;
import real.time.service.template.Templates;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class FDSCloudSearchTermsTemplate extends TemplateHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FDSCloudSearchTermsTemplate.class);
	private static final String PIPE_DELIMITER = "|";
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.FDS_CLOUD_SEARCH_TERMS);
		
		LOGGER.info("string template loaded, st={}", st);
		
		org.bson.Document metadata = (org.bson.Document) pojo;
		
		Map<String, String> searchTermsMap = createSearchTermsMap(metadata);
		
		return st.add("map", searchTermsMap).render();
	}
	
	@Override
    public String convertWithTemplate(String jsonString) {
		return null;
		
	}
	
	@Override
    public String convertWithTemplateFromFilePath(String filePath) {
		return null;
	}
	
	
	public String getSearchTermsString(org.bson.Document metadata, String cid) {
		Map<String, String> searchTermsMap = createSearchTermsMap(metadata);
		String str = "";		
		try {
			str = mapper.writeValueAsString(searchTermsMap);
		} catch (JsonProcessingException e) {
			LOGGER.error("FDSCloudSearchTermsTemplate error converting map to json string, cid={}, e={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));;
		}
		return str;
	}
	
	public String filterDuplicates(String inputString, String cid) {
        String joinedInputString = "";

        try {
            if (!StringUtils.isEmpty(inputString)) {
                joinedInputString = (Arrays.asList(Arrays.stream(inputString.split("\\|"))
                        .filter(x -> !StringUtils.isBlank(x)).toArray(String[]::new)).stream()
                        .collect(Collectors.toSet())).stream()
                        .collect(Collectors.joining(PIPE_DELIMITER, PIPE_DELIMITER, PIPE_DELIMITER));
            }
        } catch (Exception e) {
            LOGGER.error("getting exception to filter duplicates cid={}, {} {} ", Encode.forJava(cid), inputString, ExceptionUtils.getStackTrace(e));
            joinedInputString = "";
        }

        return joinedInputString;
    }
	
	public Map<String, String> createSearchTermsMap(org.bson.Document metadata) {
		String createApplication = metadata.getString("createApplication");
		
		Map<String, String> searchTermsMap = new HashMap<>();
		
		String createdDate = metadata.getString("createdDate");
		searchTermsMap.put("createdDate", createdDate);
		searchTermsMap.put("expiryDate", metadata.getString("expiryDate"));
		searchTermsMap.put("category", metadata.getString("category"));
		searchTermsMap.put("subCategory", metadata.getString("subCategory"));
		searchTermsMap.put("filePath", metadata.getString("filePath"));
		searchTermsMap.put("emailAlertReq", metadata.getString("emailAlertReq"));
		searchTermsMap.put("tin", metadata.getString("tin"));
		searchTermsMap.put("mpin", metadata.getString("mpin"));
		
		switch (createApplication) {
			case "CAP":
	            searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("physicianName", metadata.getString("providerName"));
	            searchTermsMap.put("memberId", metadata.getString("multMemberId"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            searchTermsMap.put("claimNumber", metadata.getString("claimNumber"));
	            String dateOfService = (String) metadata.getString("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                	searchTermsMap.put("dateOfService", metadata.getString("dateOfService"));
                }	            
	            break;
	        default:
	        	break;
	    }
		
		return searchTermsMap;
	}

}
