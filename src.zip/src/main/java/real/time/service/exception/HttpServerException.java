package real.time.service.exception;

import org.springframework.http.HttpStatusCode;

public class HttpServerException extends RuntimeException {

	private final HttpStatusCode status;

	public HttpServerException(String message, HttpStatusCode status2) {
		super(message);
		this.status = status2;
	}

	
	public HttpStatusCode getStatus() { return status; }
}
