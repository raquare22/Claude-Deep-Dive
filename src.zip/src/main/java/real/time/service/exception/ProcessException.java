package real.time.service.exception;

public class ProcessException extends PrunException {


	public ProcessException() {
		super(ErrorCode.PROCESS);
	}

	public ProcessException(String message, Throwable cause) {
		super(message, cause, ErrorCode.PROCESS);
	}

	public ProcessException(String message) {
		super(message, ErrorCode.PROCESS);
	}

	public ProcessException(Throwable cause) {
		super(cause, ErrorCode.PROCESS);
	}
}