package real.time.service.provider.pojo;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class TaxId {

    @JsonProperty("tax_id_nbr")
    private String taxIdNbr;
    @JsonProperty("tax_id_typ_cd")
    private String taxIdTypCd;
    @JsonProperty("tin_eff_dt")
    private Date tinEffDt;
    @JsonProperty("tin_canc_dt")
    private Date tinCancDt;
    @JsonProperty("tax_eff_dt")
    private Date taxEffDt;
    @JsonProperty("tax_canc_dt")
    private Date taxCancDt;
    @JsonProperty("corp_ownr_prov_id")
    private String corpOwnrProvId;
    @JsonProperty("corp_owner_lst_nm")
    private String corpOwnerLstNm;
    @JsonProperty("corp_owner_fst_nm")
    private String corpOwnerFstNm;
    @JsonProperty("corp_owner_mdl_nm")
    private String corpOwnerMdlNm;
    @JsonProperty("corp_owner_nm_sufx_cd")
    private String corpOwnerNmSufxCd;
    @JsonProperty("pay_typ_cd")
    private String payTypCd;
    @JsonProperty("payee_prov_id")
    private String payeeProvId;
    @JsonProperty("payee_prov_lst_nm")
    private String payeeProvLstNm;
    @JsonProperty("payee_prov_fst_nm")
    private String payeeProvFstNm;
    @JsonProperty("payee_prov_mdl_nm")
    private String payeeProvMdlNm;
    @JsonProperty("payee_prov_nm_sufx_cd")
    private String payeeProvNmSufxCd;

    public void setTaxIdNbr(String taxIdNbr) {
        this.taxIdNbr = taxIdNbr;
    }
    public String getTaxIdNbr() {
        return taxIdNbr;
    }

    public void setTaxIdTypCd(String taxIdTypCd) {
        this.taxIdTypCd = taxIdTypCd;
    }
    public String getTaxIdTypCd() {
        return taxIdTypCd;
    }

    public void setTinEffDt(Date tinEffDt) {
        this.tinEffDt = tinEffDt==null?null:(Date) tinEffDt.clone();
    }
    public Date getTinEffDt() {
        return tinEffDt==null?null:(Date) tinEffDt.clone();
    }

    public void setTinCancDt(Date tinCancDt) {
        this.tinCancDt = tinCancDt==null?null:(Date) tinCancDt.clone();
    }
    public Date getTinCancDt() {
        return tinCancDt==null?null:(Date) tinCancDt.clone();
    }

    public void setTaxEffDt(Date taxEffDt) {
        this.taxEffDt = taxEffDt==null?null:(Date) taxEffDt.clone();
    }
    public Date getTaxEffDt() {
        return taxEffDt==null?null:(Date) taxEffDt.clone();
    }

    public void setTaxCancDt(Date taxCancDt) {
        this.taxCancDt = taxCancDt==null?null:(Date) taxCancDt.clone();
    }
    public Date getTaxCancDt() {
        return taxCancDt==null?null:(Date) taxCancDt.clone();
    }

    public void setCorpOwnrProvId(String corpOwnrProvId) {
        this.corpOwnrProvId = corpOwnrProvId;
    }
    public String getCorpOwnrProvId() {
        return corpOwnrProvId;
    }

    public void setCorpOwnerLstNm(String corpOwnerLstNm) {
        this.corpOwnerLstNm = corpOwnerLstNm;
    }
    public String getCorpOwnerLstNm() {
        return corpOwnerLstNm;
    }

    public void setCorpOwnerFstNm(String corpOwnerFstNm) {
        this.corpOwnerFstNm = corpOwnerFstNm;
    }
    public String getCorpOwnerFstNm() {
        return corpOwnerFstNm;
    }

    public void setCorpOwnerMdlNm(String corpOwnerMdlNm) {
        this.corpOwnerMdlNm = corpOwnerMdlNm;
    }
    public String getCorpOwnerMdlNm() {
        return corpOwnerMdlNm;
    }

    public void setCorpOwnerNmSufxCd(String corpOwnerNmSufxCd) {
        this.corpOwnerNmSufxCd = corpOwnerNmSufxCd;
    }
    public String getCorpOwnerNmSufxCd() {
        return corpOwnerNmSufxCd;
    }

    public void setPayTypCd(String payTypCd) {
        this.payTypCd = payTypCd;
    }
    public String getPayTypCd() {
        return payTypCd;
    }

    public void setPayeeProvId(String payeeProvId) {
        this.payeeProvId = payeeProvId;
    }
    public String getPayeeProvId() {
        return payeeProvId;
    }

    public void setPayeeProvLstNm(String payeeProvLstNm) {
        this.payeeProvLstNm = payeeProvLstNm;
    }
    public String getPayeeProvLstNm() {
        return payeeProvLstNm;
    }

    public void setPayeeProvFstNm(String payeeProvFstNm) {
        this.payeeProvFstNm = payeeProvFstNm;
    }
    public String getPayeeProvFstNm() {
        return payeeProvFstNm;
    }

    public void setPayeeProvMdlNm(String payeeProvMdlNm) {
        this.payeeProvMdlNm = payeeProvMdlNm;
    }
    public String getPayeeProvMdlNm() {
        return payeeProvMdlNm;
    }

    public void setPayeeProvNmSufxCd(String payeeProvNmSufxCd) {
        this.payeeProvNmSufxCd = payeeProvNmSufxCd;
    }
    public String getPayeeProvNmSufxCd() {
        return payeeProvNmSufxCd;
    }

}