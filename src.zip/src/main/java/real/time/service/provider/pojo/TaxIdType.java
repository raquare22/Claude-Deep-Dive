package real.time.service.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for taxIdType complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="taxIdType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="taxId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="taxIdType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tpsmInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tpsmDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "taxIdType", propOrder = {
        "taxId",
        "taxIdType",
        "corpMPIN",
        "tpsmInd",
        "tpsmDesc"
})

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class TaxIdType {

    protected String taxId;
    protected String taxIdType;
    protected String tpsmInd;
    protected String tpsmDesc;
    protected String corpMPIN;

    /**
     * Gets the value of the taxId property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTaxId() {
        return taxId;
    }

    /**
     * Sets the value of the taxId property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTaxId(String value) {
        this.taxId = value;
    }

    /**
     * Gets the value of the taxIdType property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTaxIdType() {
        return taxIdType;
    }

    /**
     * Sets the value of the taxIdType property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTaxIdType(String value) {
        this.taxIdType = value;
    }

    /**
     * Gets the value of the tpsmInd property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTpsmInd() {
        return tpsmInd;
    }

    /**
     * Sets the value of the tpsmInd property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTpsmInd(String value) {
        this.tpsmInd = value;
    }

    /**
     * Gets the value of the tpsmDesc property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTpsmDesc() {
        return tpsmDesc;
    }

    /**
     * Sets the value of the tpsmDesc property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public String getcorpMPIN() {
        return corpMPIN;
    }

    /**
     * Sets the value of the corpMPIN property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setcorpMPIN(String value) {
        this.corpMPIN = value;
    }

    /**
     * Gets the value of the corpMPIN property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public void setTpsmDesc(String value) {
        this.tpsmDesc = value;
    }

}
