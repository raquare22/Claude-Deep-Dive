package real.time.service.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class AddressData {

    @JsonProperty("adr_id")
    private String adrId;
    @JsonProperty("adr_typ_cd")
    private String adrTypCd;
    private List<List<Address>> address;
    private List<List<Phone>> phone;

    public void setAdrId(String adrId) {
        this.adrId = adrId;
    }
    public String getAdrId() {
        return adrId;
    }

    public void setAdrTypCd(String adrTypCd) {
        this.adrTypCd = adrTypCd;
    }
    public String getAdrTypCd() {
        return adrTypCd;
    }

    public void setAddress(List<List<Address>> address) {
        this.address = new ArrayList<>(address);
    }
    public List<List<Address>> getAddress() {
        return new ArrayList<> (address);
    }

    public void setPhone(List<List<Phone>> phone) {
        this.phone = new ArrayList<>(phone);
    }
    public List<List<Phone>> getPhone() {
        return new ArrayList<>(phone);
    }

}
