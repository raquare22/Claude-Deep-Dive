package real.time.service.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class PhysicianFacility {
    private SvcResponse svcResponse;

    public SvcResponse getSvcResponse() {
        return svcResponse;
    }

    public void setSvcResponse(SvcResponse svcResponse) {
        this.svcResponse = svcResponse;
    }

}

