package real.time.service.provider.pojo;

public class Request {
    private final RequestBody requestBody;
    private final RequestHeader requestHeader;

    private Request(RequestBuilder builder) {
        requestBody = builder.requestBody;
        requestHeader = builder.requestHeader;
    }

    public static class RequestBuilder {
        private RequestBody requestBody;
        private RequestHeader requestHeader;

        public RequestBuilder setRequestBody(RequestBody requestBody) {
            this.requestBody = requestBody;
            return this;
        }

        public RequestBuilder setRequestHeader(RequestHeader requestHeader) {
            this.requestHeader = requestHeader;
            return this;
        }

        public Request build() {
            return new Request(this);
        }
    }
    public RequestBody getRequestBody() {
        return requestBody;
    }
    public RequestHeader getRequestHeader() {
        return requestHeader;
    }

    @Override
    public String toString() {
        return String.format("Request [requestBody=%s, requestHeader=%s]", requestBody, requestHeader);
    }
}
