package real.time.service.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Specialty {

    @JsonProperty("spcl_typ_cd")
    private String spclTypCd;
    @JsonProperty("spcl_pri_cd")
    private String spclPriCd;
    @JsonProperty("spcl_eff_dt")
    private Date spclEffDt;
    @JsonProperty("spcl_canc_dt")
    private Date spclCancDt;
    @JsonProperty("spcl_typ_shrt_desc")
    private String spclTypShrtDesc;
    @JsonProperty("spcl_typ_full_desc")
    private String spclTypFullDesc;

    public void setSpclTypCd(String spclTypCd) {
        this.spclTypCd = spclTypCd;
    }
    public String getSpclTypCd() {
        return spclTypCd;
    }

    public void setSpclPriCd(String spclPriCd) {
        this.spclPriCd = spclPriCd;
    }
    public String getSpclPriCd() {
        return spclPriCd;
    }

    public void setSpclEffDt(Date spclEffDt) {
        this.spclEffDt = spclEffDt==null?null:(Date) spclEffDt.clone();
    }
    public Date getSpclEffDt() {
        return spclEffDt==null?null:(Date) spclEffDt.clone();
    }

    public void setSpclCancDt(Date spclCancDt) {
        this.spclCancDt = spclCancDt==null?null:(Date) spclCancDt.clone();
    }
    public Date getSpclCancDt() {
        return spclCancDt==null?null:(Date) spclCancDt.clone();
    }

    public void setSpclTypShrtDesc(String spclTypShrtDesc) {
        this.spclTypShrtDesc = spclTypShrtDesc;
    }
    public String getSpclTypShrtDesc() {
        return spclTypShrtDesc;
    }

    public void setSpclTypFullDesc(String spclTypFullDesc) {
        this.spclTypFullDesc = spclTypFullDesc;
    }
    public String getSpclTypFullDesc() {
        return spclTypFullDesc;
    }

}
