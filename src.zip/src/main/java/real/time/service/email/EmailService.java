package real.time.service.email;

import java.util.Map;

public interface EmailService {
	
	public boolean sendEmail(String emailSender, String emailReceiver, String emailSubject, String message);

}
