package real.time.service.email;

import java.io.File;
import java.util.List;
import jakarta.mail.internet.MimeMessage;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import jakarta.mail.MessagingException;

public class EmailSender {
	private static final Logger logger = LoggerFactory.getLogger(EmailSender.class);

	private EmailSender() {
		throw new IllegalStateException("Utility class");
	};
	
	public static void sendMail(String from, String[] to, String subject, String msg, JavaMailSender mailSender) throws Exception {
		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(from);
			message.setTo(to);
			message.setSubject(subject);
			message.setText(msg);

			mailSender.send(message);
			logger.debug("Email was successfully sent");
		} catch (MailException e) {
			logger.error("Not able to send email {}", ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	public static void sendMail(String from, String to, String subject, String msg, JavaMailSender mailSender) throws Exception {
		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(from);
			message.setTo(to);
			message.setSubject(subject);
			message.setText(msg);

			mailSender.send(message);
			logger.debug("Email was successfully sent to FDS and SSMO");
		} catch (MailException e) {
			logger.error("Not able to send email to FDS and SSMO {}", ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	public static void sendMailWithAttachments(String from, String to, String subject, String msg, List<File> attachments, JavaMailSender mailSender) throws Exception {

		try {
			MimeMessage mimeMessage = mailSender.createMimeMessage();
			MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
			message.setFrom(from);
			message.setTo(to);
			message.setSubject(subject);
			message.setText(msg,true);
			if(attachments!=null && !attachments.isEmpty()){
				for(File att  : attachments){
					message.addAttachment(att.getName(),att);
				}

			}

			mailSender.send(mimeMessage);
			logger.debug("Email was successfully sent");
		} catch (MailException  | MessagingException e) {
			logger.error("Not able to send email {}", ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}
}
