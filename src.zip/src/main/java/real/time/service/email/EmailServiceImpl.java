package real.time.service.email;

import real.time.service.email.EmailSender;
import real.time.service.workflow.constants.Workflow;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;

import java.net.Inet4Address;
import java.util.Arrays;
import java.util.Map;

@Service("emailService")
public class EmailServiceImpl implements EmailService {
	
	@Value("${ELR_SMTP_RELAY_HOST}")
	private String elrSMTPRelayOSEHost;
	

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	JavaMailSender javaMailSender;


	public EmailServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	/**
	 * Below Method will be used for sending mails with error/exception details.
	 * 
	 * @param errorMap
	 * @return void
	 */

	@Override
	public boolean sendEmail(String emailSender, String emailReceiver, String emailSubject, String message) {
		boolean mailSent = false;
		LOGGER.debug("EmailServiceImpl-->sendEmail-->ENTER");
		
		try {
				String emailMessage = getEmailMessage(message);
				
				if (javaMailSender instanceof JavaMailSenderImpl) {
					JavaMailSenderImpl javaMailSenderImpl = (JavaMailSenderImpl) javaMailSender;
					javaMailSenderImpl.setHost(elrSMTPRelayOSEHost);
				}
				
				if (emailReceiver.contains("{")) {
					// if multiple receiver emails, parse the string into an array
					String[] emailReceiverArr = parseEmailReceiver(emailReceiver);
					LOGGER.debug("parseEmailReceiver arr={}", Arrays.toString(emailReceiverArr));
					EmailSender.sendMail(emailSender, emailReceiverArr, emailSubject, emailMessage, javaMailSender);
				} else {
					EmailSender.sendMail(emailSender, emailReceiver, emailSubject, emailMessage, javaMailSender);
				}
				
				
				mailSent = true;
			

		} catch (Exception e) {
			LOGGER.error("sendEmail Error while sending out Email {}={} {}",
					"message", message,
					ExceptionUtils.getStackTrace(e));
			mailSent = false;
		}
		LOGGER.debug("EmailServiceImpl-->sendEmail-->EXIT");
		return mailSent;
	}
	
	private String getEmailMessage(String message) {
		StringBuilder sb = new StringBuilder();
		if (StringUtils.isNotEmpty(message)) {
			sb.append(message);
			sb.append("\n");
		}
		return sb.toString();
	}
	
	protected String[] parseEmailReceiver(String emailReceiver) {
		return emailReceiver.substring(emailReceiver.indexOf("{")+1, emailReceiver.indexOf("}")).split("\\s*;\\s*");
	}

}
