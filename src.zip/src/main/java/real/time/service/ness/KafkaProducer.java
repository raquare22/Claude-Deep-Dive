package real.time.service.ness;

import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;

public class KafkaProducer {
    protected NessKafkaAsyncProducer nessKafkaAsyncProducer = null;
    private static boolean setUp = KafkaConfig.enableNess;

    public static void setUpOff() {
        setUp = false;
    }

    public static boolean getSetUp() {
        return setUp;
    }

    public NessKafkaAsyncProducer getNewNessKafkaAsyncProducer()
    {

        nessKafkaAsyncProducer = getKafkaProducer();
        return nessKafkaAsyncProducer;

    }

    protected NessKafkaAsyncProducer getKafkaProducer() {
        NessKafkaAsyncProducer.NessKafkaAsyncProducerBuilder kafkaProducerBuilder =
                new NessKafkaAsyncProducer.NessKafkaAsyncProducerBuilder()
                        .setKafkaBrokerList(KafkaConfig.brokerlist)
                        .setKafkaTopic(KafkaConfig.kafkatopic)
                        .setKafkaKeyPassword(KafkaConfig.kafkaKeypass)
                        .setKafkaKeystoreLocation(KafkaConfig.kafkaKeyStorepath)
                        .setKafkaKeystorePassword(KafkaConfig.kafkaKeystorepass)
                        .setKafkaClientId(KafkaConfig.kafkaclientId)
                        .setKafkaProtocol(KafkaConfig.Kafkaprotocol);

        return kafkaProducerBuilder.buildNessAsyncProducer();
    }
}
