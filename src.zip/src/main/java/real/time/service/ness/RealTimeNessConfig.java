package real.time.service.ness;

import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.kafka.clients.producer.Callback;
import com.optum.eis.event.model.logClass;
import com.optum.eis.event.model.outcome;
import com.optum.eis.event.model.severity;
import com.optum.eis.kraken.core.NessLog;
import com.optum.eis.kraken.core.constants.RequiredFieldsConstants;
import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;


public class RealTimeNessConfig {
    private static final Logger LOGGER = LogManager.getLogger(RealTimeNessConfig.class);

    protected static final Properties requiredFields = getDefaultProperties();

    protected static KafkaProducer kafkaProducer;

    protected static NessKafkaAsyncProducer kafkaAsyncProducer;
    protected static boolean shutdown = false;

    public static Properties getDefaultProperties() {
        Properties requiredFields = new Properties();
        // Setting required fields for the NessLog

        requiredFields.put(RequiredFieldsConstants.APPLICATION_ASK_ID, KafkaConfig.appAskid);
        requiredFields.put(RequiredFieldsConstants.APPLICATION_NAME, KafkaConfig.appname);
        requiredFields.put(RequiredFieldsConstants.DEVICE_VENDOR, KafkaConfig.devicevendor);
        requiredFields.put(RequiredFieldsConstants.DEVICE_PRODUCT, KafkaConfig.deviceproduct);


        kafkaProducer=new KafkaProducer();
        kafkaAsyncProducer = kafkaProducer.getNewNessKafkaAsyncProducer();
        return requiredFields;
    }



    protected static NessLog.NessLogBuilder getNessLogBuilder() {
        return new NessLog.NessLogBuilder()
                .setRequiredFields(requiredFields)
                .setReceivedTime(System.currentTimeMillis())
                .setSeverity(severity.INFO)
                .setLogClass(logClass.SECURITY_AUDIT)
                .setTags(KafkaConfig.tag);
    }

    public static void startup() {
        NessLog nessLog = getNessLogBuilder().setMsg("SystemStart:SUCCESS").buildLog();
        LOGGER.info("{}", nessLog.getLog());
        publishLog(nessLog);
    }

    public static void shutdown() {
        NessLog nessLog = getNessLogBuilder().setMsg("SystemStop:SUCCESS").buildLog();
        LOGGER.info("{}", nessLog.getLog());
        publishLog(nessLog);
        shutdown = true;
        LOGGER.warn("SHUTDOWN: true");

        if (kafkaAsyncProducer != null) {
            LOGGER.warn("Closing the kafkaAsyncProducer");
            kafkaAsyncProducer.closeNessAsyncProducer();

        }
    }

    public static void createNessLogEvent(String message) {

		try {

			  createNessLogEvent( message, true);

			}catch (Exception e) {

				LOGGER.error("Error to post NESS Log  {}",
						ExceptionUtils.getStackTrace(e));
			}
    }

    public static void createNessLogEvent(String message, boolean success)
    {

        NessLog.NessLogBuilder logBuilder = getNessLogBuilder().setMsg("Message received: " + message);

        if (success) {
            logBuilder.setOutcome(outcome.SUCCESS);
        } else {
            logBuilder.setOutcome(outcome.FAILURE);
        }

        NessLog nessLog = logBuilder.buildLog();
        LOGGER.debug("{}", nessLog.getLog());
        publishLog(nessLog);
    }

    protected static void publishLog(NessLog nessLog ) {
        if (shutdown) {
            LOGGER.warn("SHUTDOWN: return");
            return;
        }

        if (kafkaAsyncProducer != null) {
            kafkaAsyncProducer.publishNessLogsAsync(nessLog);
        }
    }
}
