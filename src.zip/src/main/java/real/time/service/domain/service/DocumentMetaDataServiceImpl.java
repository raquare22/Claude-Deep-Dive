package real.time.service.domain.service;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import real.time.service.model.MultiPutResponse;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.util.DocumentUtil;

import java.util.ArrayList;
import java.util.List;

@Service
public class DocumentMetaDataServiceImpl  implements DocumentMetaDataService {
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	static final Logger logger = LoggerFactory.getLogger(DocumentMetaDataServiceImpl.class);
	
	private static final String DOCUMENT_COLLECTION = "document";
	private static final String ID = "id";


	@Override
	public DocumentMetaData saveDocumentMetaData(DocumentMetaData doc) {
		logger.debug("Entering saveDocumentMetaData");
		MongoOperations op = mongoTemplate;
		
		DocumentMetaData updatedDoc = null;
		
		String id = doc.getId();
		if (id == null || id.isEmpty()) {
			// document doesn't exist, insert
			updatedDoc = op.insert(doc, DOCUMENT_COLLECTION);
			return updatedDoc;
		} else {
			// check document already exists in collection
			DocumentMetaData document = mongoTemplate.findOne(query(where(ID).is(id)), DocumentMetaData.class, DOCUMENT_COLLECTION);
			if (document != null) {
				mongoTemplate.save(doc, DOCUMENT_COLLECTION);
				return doc;
			} else {
				updatedDoc = op.insert(doc, DOCUMENT_COLLECTION);
				return updatedDoc;
			}
		}
	}

	@Override
	public MultiPutResponse updateMultiDocuments(List<String> docIds, DocumentMetaData document) {
		List<String> updated = new ArrayList<>();
		List<String> notUpdated = new ArrayList<>();
		for (String id : docIds) {
			var updatedDoc = updateDocumentMetaData(document, id);
			if (updatedDoc != null) {
				updated.add(updatedDoc.getId());
			} else {
				notUpdated.add(id);
			}
		}
		return new MultiPutResponse(updated, notUpdated);
	}

	@Override
	public DocumentMetaData updateDocumentMetaData(DocumentMetaData doc, String id) {
		logger.debug("Entering updateDocumentMetaData");
		DocumentMetaData document = mongoTemplate.findOne(query(where(ID).is(id)), DocumentMetaData.class, DOCUMENT_COLLECTION);
		if (document != null) {
			DocumentUtil.updateDocumentMetaDataRevisions(document);
			DocumentUtil.updateDateModified(document);
			Document md = document.getMetadata();
			if (md == null) {
				Document metadata = new Document();
				doc.getMetadata().forEach((key, value) -> {
					metadata.append(key, value);
				});
				document.setMetadata(metadata);
			} else {
				doc.getMetadata().forEach((key, value) -> {
					md.append(key, value);
				});
			}
			mongoTemplate.save(document, DOCUMENT_COLLECTION);
		}
		return document;
	}

}
