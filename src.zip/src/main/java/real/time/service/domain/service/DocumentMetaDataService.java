package real.time.service.domain.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import real.time.service.model.MultiPutResponse;
import real.time.service.mongo.DocumentMetaData;


import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

public interface DocumentMetaDataService {

    DocumentMetaData saveDocumentMetaData(DocumentMetaData metadata);

    MultiPutResponse updateMultiDocuments(List<String> docIds, DocumentMetaData document);

    DocumentMetaData updateDocumentMetaData(DocumentMetaData metadata, String id);

}
