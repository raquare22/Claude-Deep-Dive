package real.time.service.domain.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

//import com.optum.fds.paperless.util.SanitizeUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import real.time.service.EhCache;
import real.time.service.exception.ProcessException;
import real.time.service.java.delegate.docvault.OutOfRetriesException;
import real.time.service.java.delegate.docvault.RetryOnExceptionHandler;
import real.time.service.model.Doc360UploadResponse;
import real.time.service.mongo.FDSCloudDocument;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.util.RestTemplateChunkClient;
import real.time.service.util.RestTemplateClient;
import real.time.service.util.WebClientSync;


@Service("FileStoreService")
public class FilestoreServiceImpl implements FilestoreService {
	private static final Logger LOGGER = LoggerFactory.getLogger(FilestoreServiceImpl.class);
	
	@Autowired
	private EhCache ehcache;
	
	@Autowired
	private OauthManagerUtil oauthManagerUtil;
	

	@Autowired
	private RestTemplateClient restTemplateClient;

	@Autowired
	private RestTemplateChunkClient restTemplateChunkClient;

	@Autowired
	private WebClientSync webClientSync;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${FDSRetrySleepTimeMS}")
	private Long timeToWaitMS;
	
	@Value("${FDSDocumentsUrl}")
	protected String fdsDocumentsUrl;

	@Value("${FDSOauthUrl}")
	protected String fdsOauthUrl;
	
	@Value("${FDSCloudAppId}")
	protected String fdsCloudAppId;
	
	@Value("${FDSCloudAppSecret}")
	protected String fdsCloudAppSecret;

	@Value("${Doc360DocumentsUrl}")
	protected String doc360DocumentsUrl;

	@Value("${Doc360OauthUrl}")
	protected String doc360OauthUrl;

	@Value("${Doc360AppId}")
	protected String doc360AppId;

	@Value("${Doc360AppSecret}")
	protected String doc360AppSecret;

	@Value("${Doc360Scope}")
	protected String doc360Scope;

	@Value("${Doc360RetryCount:3}")
	protected int doc360RetryCount;

	@Value("${Doc360RetrySleepMS:500}")
	protected long doc360RetrySleepMS;
	
	@Value("${FileStoreMinSizeToChunk:6000000}")
	protected int fileStoreMinSizeToChunk;
	
	@Value("${FileStoreUseWebClient:true}")
	protected boolean fileStoreUseWebClient;

	protected static final String GRANT_TYPE = "client_credentials";
	protected static int totalCnt = 0;
	protected static int totalChunkCnt = 0;
	protected static long largestChunkSize = 0L;
	private static AtomicInteger totalOutstandingRequests = new AtomicInteger(0);

	protected static boolean shutdown = false;
	private static final String SHUTTING_DOWN = "Filestore is shutting down";
	private static final String DOC360_TOKEN_CACHE_KEY = "tokenDoc360Prun";
	private static final String DOC360_PROVIDER = "doc360";
	private static final String DOC360_DOCUMENT_TYPE_QUERY_PARAM = "document-type";
	// Allow 5 seconds in shutdown for processing to finish
	private static Long maxShutdownLoop = 100L;

	public static synchronized void shutdown() {
		LOGGER.warn("SHUTDOWN: shutdown={}, maxShutdownLoop={}", shutdown, maxShutdownLoop);
		if (shutdown) {
			LOGGER.warn("SHUTDOWN: COMPLETE; Already performed; shutdown={},", shutdown);
			return;
		}

		try {
			shutdown = true;
			long i = 0;
			int totalOutstandingRequestsInt = totalOutstandingRequests.get();
			while (totalOutstandingRequestsInt > 0 && ++i <= maxShutdownLoop) {
				sleep(50, "SHUTDOWN: sleeping; totalOutstandingRequests=" + totalOutstandingRequestsInt);
				totalOutstandingRequestsInt = totalOutstandingRequests.get();
			}
			LOGGER.warn("SHUTDOWN: COMPLETE; shutdown={}", shutdown);
			logStats();
			WebClientSync.logStats();
		} catch (Exception e) {
			LOGGER.error("SHUTDOWN: {}", ExceptionUtils.getStackTrace(e));
		}
	}
	
	@Override
	public ResponseEntity<FDSCloudDocument> postDocumentToFDSCloudWithAttachmentRetry(String document, String searchTerms, String filePath, String fdsCloudSpaceId, String cid) {
		ResponseEntity<FDSCloudDocument> response = null;
		
		try {
			Path path = Paths.get(filePath);
			Map<String, String> pathParams = new HashMap<>();
			pathParams.put("spaceId", fdsCloudSpaceId);
			
			URI uri = UriComponentsBuilder.fromUriString(fdsDocumentsUrl).buildAndExpand(pathParams).toUri();
			
			
			totalStats();
			var length = path.toFile().length();
			if (length >= fileStoreMinSizeToChunk) {
				chunkStats(filePath, length);
			}
			
			LOGGER.info("PRE: fdsCloud file={}, length={}, CID={}, totalOutstandingRequests={}", Encode.forJava(filePath),Encode.forJava(String.valueOf(length)), Encode.forJava(cid), Encode.forJava(String.valueOf(totalOutstandingRequests)));
			
			if (fileStoreUseWebClient) {
				response = webClientSync.sendMultiPartDataWithRetry(fdsDocumentsUrl, uri, path.toFile(), document, searchTerms, cid);
			}
			
			LOGGER.info("POST: fdsCloud file={}, length={}, CID={}, totalCnt={}, totalChunkCnt={}, largestChunkSize={}",
					Encode.forJava(filePath), Encode.forJava(String.valueOf(length)), Encode.forJava(cid), Encode.forJava(String.valueOf(totalCnt)), Encode.forJava(String.valueOf(totalChunkCnt)), Encode.forJava(String.valueOf(largestChunkSize)));

			
		} catch (Exception e) {
			LOGGER.error("POST: CID={}, filePath={}; {}: {}",Encode.forJava(cid), Encode.forJava(String.valueOf(filePath)), Encode.forJava(e.getClass().getSimpleName()), e.getMessage());
			totalOutstandingRequests.decrementAndGet();
		}
		
		totalOutstandingRequests.decrementAndGet();
		return response;
	}

	@Override
	public ResponseEntity<FDSCloudDocument> postDocumentToFDSCloudWithAttachment(String document, String searchTerms, String filePath, String fdsCloudSpaceId, String cid) throws IOException, ProcessException {
		if (shutdown) {
			throw new ProcessException(SHUTTING_DOWN + "; fdsCloudSpaceId=" + fdsCloudSpaceId + ", filePath=" + filePath);
		}

		if (isNullOrEmpty(fdsCloudAppId) || isNullOrEmpty(fdsCloudAppSecret)) {
			LOGGER.warn("postDocumentToFDSWithAttachment -- appId or appSecret is null or empty for spaceId, CID={}", Encode.forJava(cid));
		}
		ResponseEntity<FDSCloudDocument> response = null;

		Path path = Paths.get(filePath);
		try {
			Resource resource = new UrlResource(Encode.forJava(String.valueOf(path.toUri())));
            String token = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", fdsCloudAppId, fdsCloudAppSecret, GRANT_TYPE, fdsOauthUrl, true, null);

			Map<String, String> pathParams = new HashMap<>();
			pathParams.put("spaceId", fdsCloudSpaceId);

			MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
			requestMap.add("metadata", document);
			requestMap.add("searchTerms", searchTerms);
			requestMap.add("file", resource);

			URI uri = UriComponentsBuilder.fromUriString(fdsDocumentsUrl).buildAndExpand(pathParams).toUri();

			HttpHeaders headers = new HttpHeaders();
			headers.set("fds-authorization", token);
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(requestMap, headers);

			totalStats();
			var length = path.toFile().length();
			if (length >= fileStoreMinSizeToChunk) {
				chunkStats(filePath, length);
			}
			LOGGER.info("PRE: fdsCloud file={}, length={}, totalOutstandingRequests={}, CID={}", Encode.forJava(filePath), Encode.forJava(String.valueOf(length)), Encode.forJava(String.valueOf(totalOutstandingRequests)), Encode.forJava(cid));
			if (fileStoreUseWebClient) {
				response = webClientSync.sendMultiPartData(uri, token, path.toFile(), document, searchTerms, cid);
			} else if (length < fileStoreMinSizeToChunk) {
				response = restTemplateClient.putExchangeWithRetry(uri, HttpMethod.POST, requestEntity);
			} else {
				response = restTemplateChunkClient.putExchangeWithRetry(uri, HttpMethod.POST, requestEntity);
			}
			LOGGER.info("POST: fdsCloud file={}, length={}, totalCnt={}, totalChunkCnt={}, largestChunkSize={}, CID={}", Encode.forJava(filePath), Encode.forJava(String.valueOf(length)), Encode.forJava(String.valueOf(totalCnt)), Encode.forJava(String.valueOf(totalChunkCnt)), Encode.forJava(String.valueOf(largestChunkSize)), Encode.forJava(cid));
		} catch (Exception e) {
			LOGGER.error("POST: filePath={}; {}: {}, CID={}", Encode.forJava(String.valueOf(filePath)), Encode.forJava(e.getClass().getSimpleName()), e.getMessage(), Encode.forJava(cid));
			totalOutstandingRequests.decrementAndGet();
			throw e;
		}
		LOGGER.info("fds cloud response={}, CID={}", Encode.forJava(response.toString()), Encode.forJava(cid));
		totalOutstandingRequests.decrementAndGet();
		return response;
	}

	@Override
	public ResponseEntity<Doc360UploadResponse> postDocumentToDoc360WithAttachmentRetry(String document, String filePath, String docClass, String cid) {
		if (shutdown) {
			LOGGER.warn("postDocumentToDoc360WithAttachmentRetry aborted because service is shutting down, CID={}", Encode.forJava(cid));
			return ResponseEntity.status(503).body(buildDoc360ErrorResponse(503, "Filestore is shutting down"));
		}

		if (!isPdfFile(filePath)) {
			LOGGER.warn("provider={} invalid file type for upload CID={} filePath={}", DOC360_PROVIDER, Encode.forJava(cid), Encode.forJava(String.valueOf(filePath)));
			return ResponseEntity.status(415).body(buildDoc360ErrorResponse(415, "Only PDF files are supported for Doc360 uploads"));
		}

		String endpointWithQuery = doc360DocumentsUrl;
		if (!isNullOrEmpty(docClass)) {
			endpointWithQuery = UriComponentsBuilder.fromUriString(doc360DocumentsUrl)
					.queryParam(DOC360_DOCUMENT_TYPE_QUERY_PARAM, docClass)
					.build()
					.toUriString();
		}

		final Resource resource;
		try {
			resource = new UrlResource(Paths.get(filePath).toUri());
		} catch (Exception e) {
			LOGGER.error("provider={} unable to create file resource for upload CID={} filePath={} err={}",
					DOC360_PROVIDER, Encode.forJava(cid), Encode.forJava(String.valueOf(filePath)), ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(500).body(buildDoc360ErrorResponse(500, "Unable to create file resource"));
		}

		MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
		requestMap.add("metadata", document);
		requestMap.add("file", resource);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		headers.setAccept(java.util.Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(requestMap, headers);

		String token = oauthManagerUtil.getOauthToken(DOC360_TOKEN_CACHE_KEY, doc360AppId, doc360AppSecret, GRANT_TYPE, doc360OauthUrl, false, doc360Scope);
		String accessToken = isNullOrEmpty(token) ? "" : "Bearer " + token;

		RetryOnExceptionHandler retryHandler = new RetryOnExceptionHandler(doc360RetryCount, doc360RetrySleepMS);

		try {
			while (retryHandler.shouldRetry()) {
				long startTime = System.nanoTime();
				try {
					headers.set("Authorization", accessToken);
					ResponseEntity<Doc360UploadResponse> response = postDocumentToDoc360(endpointWithQuery, requestEntity);
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.info("provider={} request=uploadDocument CID={} filePath={} docClass={} HTTPStatus={} TotalLatency={}",
							DOC360_PROVIDER, Encode.forJava(cid), Encode.forJava(filePath), Encode.forJava(docClass), response.getStatusCode().value(), latency);
					return response;
				} catch (HttpClientErrorException.Unauthorized e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.error("provider={} unauthorized CID={} HTTPStatus={} TotalLatency={} responseBody={} err={}",
							DOC360_PROVIDER, Encode.forJava(cid), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e));
					// refresh token and retry
					String newToken = oauthManagerUtil.getOauthToken(DOC360_TOKEN_CACHE_KEY, doc360AppId, doc360AppSecret, GRANT_TYPE, doc360OauthUrl, true, doc360Scope);
					accessToken = isNullOrEmpty(newToken) ? "" : "Bearer " + newToken;
					retryHandler.exceptionOccurred();
				} catch (HttpServerErrorException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.error("provider={} server error CID={} HTTPStatus={} TotalLatency={} responseBody={} err={}",
							DOC360_PROVIDER, Encode.forJava(cid), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e));
					if (!isRetryableDoc360Status(e.getStatusCode().value())) {
						return ResponseEntity.status(e.getStatusCode()).body(buildDoc360ErrorResponse(e.getStatusCode().value(), "Doc360 server error"));
					}
					retryHandler.exceptionOccurred();
				} catch (HttpClientErrorException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.error("provider={} client error CID={} HTTPStatus={} TotalLatency={} responseBody={} err={}",
							DOC360_PROVIDER, Encode.forJava(cid), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e));
					if (!isRetryableDoc360Status(e.getStatusCode().value())) {
						return ResponseEntity.status(e.getStatusCode()).body(buildDoc360ErrorResponse(e.getStatusCode().value(), "Doc360 client error"));
					}
					retryHandler.exceptionOccurred();
				} catch (RestClientException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.error("provider={} rest client error CID={} TotalLatency={} err={}",
							DOC360_PROVIDER, Encode.forJava(cid), latency, ExceptionUtils.getStackTrace(e));
					retryHandler.exceptionOccurred();
				}
			}
		} catch (OutOfRetriesException ex) {
			LOGGER.error("provider={} exhausted retries CID={} err={}", DOC360_PROVIDER, Encode.forJava(cid), ExceptionUtils.getStackTrace(ex));
			return ResponseEntity.status(500).body(buildDoc360ErrorResponse(500, "Doc360 call failed after retries"));
		}

		return ResponseEntity.status(500).body(buildDoc360ErrorResponse(500, "Doc360 upload failed"));
	}

	protected ResponseEntity<Doc360UploadResponse> postDocumentToDoc360(String endpointWithQuery, HttpEntity<MultiValueMap<String, Object>> requestEntity) {
		return restTemplate.postForEntity(endpointWithQuery, requestEntity, Doc360UploadResponse.class);
	}

	private Doc360UploadResponse buildDoc360ErrorResponse(Integer statusCode, String message) {
		Doc360UploadResponse response = new Doc360UploadResponse();
		response.setMessageMap(java.util.Collections.singletonMap("message", message));
		response.setStatus(statusCode);
		return response;
	}


	private boolean isRetryableDoc360Status(int statusCode) {
		return statusCode == 401 || statusCode == 404 || statusCode == 502 || statusCode == 503 || statusCode == 504;
	}

	private boolean isPdfFile(String filePath) {
		if (isNullOrEmpty(filePath)) {
			return false;
		}

		Path path;
		try {
			path = Paths.get(filePath);
		} catch (Exception e) {
			return false;
		}

		if (!Files.isRegularFile(path)) {
			return false;
		}

		String fileName = path.getFileName() == null ? "" : path.getFileName().toString().toLowerCase(Locale.ROOT);
		if (!fileName.endsWith(".pdf")) {
			return false;
		}

		try (InputStream in = Files.newInputStream(path)) {
			byte[] header = new byte[4];
			if (in.read(header) < 4) {
				return false;
			}
			return "%PDF".equals(new String(header, StandardCharsets.US_ASCII));
		} catch (IOException e) {
			LOGGER.warn("provider={} unable to read file for PDF validation filePath={} err={}", DOC360_PROVIDER, Encode.forJava(String.valueOf(filePath)), Encode.forJava(e.getMessage()));
			return false;
		}
	}


	protected static void sleep(long milliseconds, String description) {
		try {
			LOGGER.warn("sleeping {} ms: {}", milliseconds, description);
			TimeUnit.MILLISECONDS.sleep(milliseconds);
		} catch (InterruptedException e) {
			LOGGER.error("SLEEP: INTERRUPT; threadId={}", Thread.currentThread().getId());
			Thread.currentThread().interrupt();
		}
	}

	protected static void totalStats() {
		++totalCnt;
		totalOutstandingRequests.incrementAndGet();
	}

	protected static void chunkStats(String filePath, long length) {
		// fileStoreUseWebClient: These stats only reflect files >= fileStoreMinSizeToChunk
		++totalChunkCnt;
		if (length > largestChunkSize) {
			LOGGER.warn("STATS: largestChunkSize change; length={}, prevLargestChunkSize={}, filePath={}", Encode.forJava(String.valueOf(length)), Encode.forJava(String.valueOf(largestChunkSize)), Encode.forJava(String.valueOf(filePath)));
			largestChunkSize = length;
		}
	}

	protected static void logStats() {
		LOGGER.warn("STATS: totalCnt={}, totalChunkCnt={}, largestChunkSize={}, totalOutstandingRequests={}", totalCnt, totalChunkCnt, largestChunkSize, totalOutstandingRequests.get());
	}

	private boolean isNullOrEmpty(String str) {
		return str == null || str.isEmpty();
	}

	public boolean validateResponseStatusCode(int statusCode) {
		return statusCode == 500 || statusCode == 502 || statusCode == 503 || statusCode == 504;
	}
}
