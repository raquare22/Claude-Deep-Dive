package real.time.service.domain.service;

import java.io.IOException;

import org.springframework.http.ResponseEntity;

import real.time.service.exception.ProcessException;
import real.time.service.model.Doc360UploadResponse;
import real.time.service.mongo.FDSCloudDocument;

public interface FilestoreService {

	public ResponseEntity<FDSCloudDocument> postDocumentToFDSCloudWithAttachmentRetry(String document, String searchTerms, String filePath, String fdsCloudSpaceId, String cid);
	
	public ResponseEntity<FDSCloudDocument> postDocumentToFDSCloudWithAttachment(String document, String searchTerms, String filePath, String spaceId, String cid) throws IOException, ProcessException;

	public ResponseEntity<Doc360UploadResponse> postDocumentToDoc360WithAttachmentRetry(String document, String filePath, String docClass, String cid);
}
