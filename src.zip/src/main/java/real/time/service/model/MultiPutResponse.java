package real.time.service.model;

import java.util.List;

public class MultiPutResponse {

    List<String> updated;

    List<String> notUpdated;

    public MultiPutResponse(List<String> updated, List<String> notUpdated) {
        this.updated = updated;
        this.notUpdated = notUpdated;
    }

    public List<String> getUpdated() {
        return updated;
    }

    public void setUpdated(List<String> updated) {
        this.updated = updated;
    }

    public List<String> getNotUpdated() {
        return notUpdated;
    }

    public void setNotUpdated(List<String> notUpdated) {
        this.notUpdated = notUpdated;
    }

}
