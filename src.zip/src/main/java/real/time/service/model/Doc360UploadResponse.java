package real.time.service.model;

import java.util.Map;

public class Doc360UploadResponse {

    private String globalDocId;
    private String indexName;
    private String receivedDate;
    private Integer status;
    private Map<String, Object> messageMap;

    public String getGlobalDocId() {
        return globalDocId;
    }

    public void setGlobalDocId(String globalDocId) {
        this.globalDocId = globalDocId;
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public String getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Map<String, Object> getMessageMap() {
        return messageMap;
    }

    public void setMessageMap(Map<String, Object> messageMap) {
        this.messageMap = messageMap;
    }
}
