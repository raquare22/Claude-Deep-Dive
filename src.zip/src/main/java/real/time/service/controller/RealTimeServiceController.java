package real.time.service.controller;

import java.io.InputStream;
import java.io.IOException;

import java.time.Duration;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.pdfbox.io.RandomAccessRead;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import real.time.service.config.ConfigData;
import real.time.service.domain.service.DocumentMetaDataService;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.ness.KafkaProducer;

import real.time.service.mongo.processors.MetaDataStatus;
import real.time.service.ness.RealTimeNessConfig;
import real.time.service.util.GenericResponse;
import real.time.service.util.ProcessDocumentUtil;
import real.time.service.util.SanitizeUtil;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.io.RandomAccessReadBuffer;

@Component
@RestController
@RequestMapping("/api/services")
public class RealTimeServiceController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RealTimeServiceController.class);
	private static final List<String> ALLOWED_FILE_TYPES = Arrays.asList("application/pdf");
	private static final String INVALID_REQUEST = "Invalid request";
	private static final String REQUEST = ", request: ";
	private static final String EMPTY_REQUEST_BODY = "Null or empty request body";
	private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
	private final Bucket fileUploadRequestBucket;
	private final Bucket processDocumentRequestBucket;	 
	 
		@Autowired
		public RealTimeServiceController(@Value("${fileUploadRateLimit}")long fileUploadRateLimit, 
				                         @Value("${processDocumentRateLimit}")long processDocumentRateLimit) {
			
			Bandwidth uploadLimit = Bandwidth.classic(fileUploadRateLimit, Refill.greedy(fileUploadRateLimit, Duration.ofMinutes(1)));
			Bandwidth documentLimit = Bandwidth.classic(processDocumentRateLimit, Refill.greedy(processDocumentRateLimit, Duration.ofMinutes(1)));
			
			this.fileUploadRequestBucket = Bucket.builder()
		             .addLimit(uploadLimit)
		             .build();
		         
		    this.processDocumentRequestBucket = Bucket.builder()
		             .addLimit(documentLimit)
		             .build();		
		}
	
	@Autowired
    private ProcessDocumentUtil processDocumentUtil;

	@Autowired
	private ConfigData config;

	@Autowired
	private DocumentMetaDataService documentMetaDataService;

    @Autowired
    private ObjectMapper objectMapper;


	@PostMapping(value = "/process/file/{spaceId}", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE } )
	public ResponseEntity<Map<String, Object>> processFileUpload(@RequestHeader HttpHeaders headers, @RequestPart("file") MultipartFile file, @RequestPart("metadata") String metadata, @PathVariable String spaceId, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) {
		if (fileUploadRequestBucket.tryConsume(1)) {

			Map<String, Object> responseMap = new HashMap<>();
			String headersStr = headers == null || headers.isEmpty() ? "null" : headers.toString();
			try {

				if (file == null || metadata == null || metadata.isEmpty() || spaceId == null || spaceId.isEmpty() || isInvalidSpaceId(spaceId)) {
					LOGGER.error("Unable to process request, file, metadata or spaceId is null or invalid, CID:{}", Encode.forJava(optumCidExt));
					responseMap = new HashMap<>();
					responseMap.put("error", "Null or invalid request");
					return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
				}

				// Strong PDF validation and filename sanitization to mitigate malicious uploads
				if (!isValidAndSafePdf(file)) {
					responseMap = new HashMap<>();
					responseMap.put("error", "Invalid file type");
					return new ResponseEntity<>(responseMap, HttpStatus.UNSUPPORTED_MEDIA_TYPE);
				}

				String requestStr = "/process/file/" + spaceId + " , headers: " + headersStr + REQUEST + metadata;
				logNess(requestStr);

				String fileName = file.getOriginalFilename();

				org.bson.Document metadataJson = org.bson.Document.parse(metadata);
				Integer spaceIdInt = Integer.parseInt(spaceId);

				if (metadataJson == null || metadataJson.isEmpty()) {
					LOGGER.error("Null or invalid request, metadata is not valid JSON, fileName={}, spaceId={}, CID:{}", Encode.forJava(fileName),
							Encode.forJava(spaceId), Encode.forJava(optumCidExt));
					responseMap = new HashMap<>();
					responseMap.put("error", "Metadata must be in json format");
					return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
				}

				// verify PDF content once more using PDFBox
				if (!isValidFileContent(file.getInputStream())) {
					LOGGER.error("sendFile -- Invalid pdf content: {}, CID={}", Encode.forJava(fileName), Encode.forJava(optumCidExt));
					responseMap = new HashMap<>();
					responseMap.put("error", "Invalid pdf content");
					return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
				}

				responseMap = processDocumentUtil.processFileUpload(fileName, file, metadataJson, spaceIdInt, Encode.forJava(optumCidExt));

				if (responseMap.get("documentStatus").equals(MetaDataStatus.SEVERE_ERROR)) {
					LOGGER.info("processFileUpload -- document in SEVERE_ERROR, fileName={}, spaceId={}, CID:{}", Encode.forJava(fileName),
							Encode.forJava(spaceId), Encode.forJava(optumCidExt));
					return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
				}

				if (responseMap.get("documentStatus").equals(MetaDataStatus.FATAL_ERROR) || responseMap.get("documentStatus").equals(MetaDataStatus.STORAGE_ERROR)) {
					LOGGER.info("processFileUpload -- document in FATAL_ERROR or STORAGE_ERROR, fileName={}, spaceId={}, CID:{}", Encode.forJava(fileName),
							Encode.forJava(spaceId), Encode.forJava(optumCidExt));
					return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
				}
				LOGGER.info("processFileUpload -- document uploaded successfully, fileName={}, spaceId={}, CID:{}", SanitizeUtil.sanitizeAlphaString(fileName),
						SanitizeUtil.sanitizeIntegerString(spaceId), Encode.forJava(optumCidExt));
				return new ResponseEntity<>(responseMap, HttpStatus.CREATED);

			} catch (Exception e) {
				LOGGER.error("Error processing the document, HTTPStatus={}, apiPath=/process/file/{}, error={}, CID:{}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(spaceId), ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt));
				responseMap = new HashMap<>();
				responseMap.put("error", "Internal server error");

				String errorLog = "Error executing POST request /process/file/" + spaceId + " message: " + e.getMessage() + ", headers: " + headersStr;
				logNess(errorLog);

				return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			LOGGER.info("Too many requests made. Wait for 1 minute and try again.");
			return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
		}
	}
	
	private boolean isInvalidSpaceId(String spaceId) {
		try { 
	        Integer.parseInt(spaceId); 
	    } catch(NumberFormatException e) { 
	        return true; 
	    } catch(NullPointerException e) {
	        return true;
	    }
	    return false;
	}
	
	@PostMapping(value = "/process/document", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> processDocument (@RequestHeader HttpHeaders headers, @RequestBody String requestBody, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) {
      if(processDocumentRequestBucket.tryConsume(1)) {
    		
		LOGGER.info("Entering processDocument request");
    	Map<String, Object> responseMap = new HashMap<>();
    	String headersStr = headers == null || headers.isEmpty() ? "null" : headers.toString();
    	
    	try {
			// Validate request body
			if (StringUtils.isEmpty(requestBody)) {
				responseMap.put("error", "Request body is empty");
				LOGGER.error("Unable to process request, request body is empty, HTTPStatus={}, CID:{}", HttpStatus.BAD_REQUEST, Encode.forJava(optumCidExt));
				return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
			}

			Map<String, String> requestMap = objectMapper.readValue(requestBody, HashMap.class);
			
			// check required fields
			if (validateDocumentRequest(requestMap)) {
				responseMap.put("error", "Missing required variable");
				LOGGER.error("Unable to process request, missing required variable, HTTPStatus={}, Request:{}, CID:{}", HttpStatus.BAD_REQUEST, SanitizeUtil.sanitizeString(requestBody), Encode.forJava(optumCidExt));
				return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
			}
			
			String requestStr="/process/document , headers: " + headersStr + REQUEST + requestBody;
			logNess(requestStr);
			
			responseMap = processDocumentUtil.processDocument(requestMap, Encode.forJava(optumCidExt));
        
			if (responseMap == null || responseMap.isEmpty()) {
				LOGGER.error("Error processing the document, HTTPStatus={}, apiPath=/process/document, error={Invalid FDS Document Id/SpaceId}, CID:{}", HttpStatus.BAD_REQUEST, Encode.forJava(optumCidExt));
				responseMap = new HashMap<>();
				responseMap.put("error", "Invalid FDS Document Id/SpaceId");
	            return new ResponseEntity<>(responseMap,HttpStatus.BAD_REQUEST);
			}

			LOGGER.info("processDocument --> document uploaded successfully, Request:{}, CID:{}", SanitizeUtil.sanitizeString(requestBody), Encode.forJava(optumCidExt));
	    	return new ResponseEntity<>(responseMap, HttpStatus.OK);
			
		} catch (JsonProcessingException e) {
			LOGGER.error("Error parsing JSON request body, HTTPStatus={}, apiPath=/process/document, error={}, CID:{}", HttpStatus.BAD_REQUEST, ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt));
			responseMap.put("error", "Invalid JSON format");
			return new ResponseEntity<>(responseMap, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			LOGGER.error("Error processing the document, HTTPStatus={}, apiPath=/process/document, error={}, CID:{}", HttpStatus.INTERNAL_SERVER_ERROR, ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt));
			responseMap = new HashMap<>();
			responseMap.put("error", "Internal server error");
			
			String errorLog = "Error executing POST request /process/document message: "+e.getMessage() + ", headers: " + headersStr.toString();
			logNess(errorLog);
			
            return new ResponseEntity<>(responseMap,HttpStatus.INTERNAL_SERVER_ERROR);
		}  
      } else {
    	  LOGGER.info("Too many requests made. Wait for 1 minute and try again.");
          return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
      }
    }

	@PostMapping(value = "/process/bounceEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> insertDocumentForBouncedEmail(@RequestHeader HttpHeaders headers, @RequestBody String jsonStr, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) {
		if(processDocumentRequestBucket.tryConsume(1)) {
			String headersStr = headers == null || headers.isEmpty() ? "null" : headers.toString();

			if (StringUtils.isEmpty(jsonStr)) {
				LOGGER.info("apiPath=/run/bounceEmail, 400 BAD REQUEST invalid json, CID:{}", Encode.forJava(optumCidExt));
				return new ResponseEntity<>(
						GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
						HttpStatus.BAD_REQUEST);
			}
			LOGGER.info("insertDocumentForBouncedEmail apiPath=/run/bounceEmail, requestBody={}, CID:{}", Encode.forJava(jsonStr), Encode.forJava(optumCidExt));
			try {
				String requestStr="/process/bounceEmail , headers: " + headersStr + REQUEST + Encode.forJava(jsonStr);
				logNess(requestStr);
				var documentMetaData = objectMapper.readValue(jsonStr, DocumentMetaData.class);
				appendDefaultValues(documentMetaData);
				documentMetaDataService.saveDocumentMetaData(documentMetaData);
				LOGGER.info("insertDocumentForBouncedEmail apiPath=/run/bounceEmail, bounce email doc inserted docId={}, CID:{}", documentMetaData.getId(), Encode.forJava(optumCidExt));
				return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(),
						"DocumentMetaData inserted with id = " + documentMetaData.getId()));
			} catch (Exception ex) {
				String errorLog = "Error executing POST request /process/bounceEmail , headers: " + headersStr+ REQUEST + Encode.forJava(jsonStr) +", message: "+ex.getMessage();
				logNess(errorLog);
				LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/bounceEmail, jsonstr={}, error={}, CID:{}", HttpStatus.INTERNAL_SERVER_ERROR,
						Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex), Encode.forJava(optumCidExt));
				return new ResponseEntity<>(
						GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		else {
			LOGGER.info("Too many requests made. Wait for 1 minute and try again, CID:{}", Encode.forJava(optumCidExt));
			return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
		}
	}

	private void appendDefaultValues(DocumentMetaData documentMetaData) {
		documentMetaData.setTransactionId(UUID.randomUUID().toString());
		documentMetaData.setStatus(MetaDataStatus.AVAILABLE);
		if (documentMetaData.getSpaceId() == 0) {
			throw new NullPointerException("spaceId cannot be null");
		}
		var clientId = config.getCredentials(documentMetaData.getSpaceId()).get("clientId").toString();
		var appIdentifier = config.getCredentials(documentMetaData.getSpaceId()).get("appIdentifier").toString();

		documentMetaData.setClientId(Integer.parseInt(clientId));
		documentMetaData.setAppIdentifier(appIdentifier);
	}


	@PutMapping(value = "/document/multi", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> putMultiDocument(@RequestBody Map<String, Object> requestMap, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) {
		long startTime = System.nanoTime();
		if (MapUtils.isEmpty(requestMap)) {
			LOGGER.warn("Error updating multi documents, invalid request, CID:{}, HTTPStatus={}", Encode.forJava(optumCidExt), HttpStatus.BAD_REQUEST);
			return new ResponseEntity<>(GenericResponse.from("400", "Error during putMultiDocument: " + INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
		}

		List<String> documentIds = null;
		DocumentMetaData documentMetaData = null;
		String docIdStr = "";
		String docMetaDataStr = "";
		try {
			documentIds = (List<String>) requestMap.get("documentIds");
			documentMetaData = objectMapper.convertValue(requestMap.get("document"), DocumentMetaData.class);

            if (documentIds == null || documentIds.isEmpty() || documentMetaData == null) {
                LOGGER.warn("Error updating multi documents, documentIds or documentMetaData is null or empty, CID:{}, HTTPStatus={}", Encode.forJava(optumCidExt), HttpStatus.BAD_REQUEST);
                return new ResponseEntity<>(GenericResponse.from("400", "Error during putMultiDocument: " + INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
            }

			docIdStr = (documentIds == null || documentIds.isEmpty())  ? "" : documentIds.toString();
			docMetaDataStr = (documentMetaData == null) ? "" : documentMetaData.toString();

			LOGGER.info("Updating multi documents CID={} docIds={}, documentMetadata={}", Encode.forJava(optumCidExt),
					Encode.forJava(docIdStr), Encode.forJava(docMetaDataStr));

			var response = documentMetaDataService.updateMultiDocuments(documentIds, documentMetaData);

			long latency = (System.nanoTime() - startTime) / 1000000;
			LOGGER.info("Success updating multi documents CID:{}, HTTPStatus={}, docIds={}, latency={}, response={}", Encode.forJava(optumCidExt), HttpStatus.OK, Encode.forJava(docIdStr), latency, response);
			return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), response));
		} catch (Exception e) {
			docIdStr = (documentIds == null || documentIds.isEmpty())  ? "" : documentIds.toString();
			docMetaDataStr = (documentMetaData == null) ? "" : documentMetaData.toString();
			long latency = (System.nanoTime() - startTime) / 1000000;

			if (e.getMessage() != null && e.getMessage().contains("JWT signature verification")) {
				LOGGER.error("@StargateJWTFilter Class - Error validating JWT: JWT signature verification failed. CID:{}, docIds={}, latency={}",Encode.forJava(optumCidExt),
					Encode.forJava(docIdStr), latency);
				return new ResponseEntity(GenericResponse.from("401", "JWT signature verification failed", e.getMessage()), HttpStatus.UNAUTHORIZED);
			}
			LOGGER.error("Error updating multi documents CID:{}, docIds={}, documentmetaData={}, latency={}, error={}",Encode.forJava(optumCidExt),
					Encode.forJava(docIdStr), Encode.forJava(docMetaDataStr), latency, ExceptionUtils.getStackTrace(e));
			return new ResponseEntity(GenericResponse.from("500", "Error during putMultiDocument: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private boolean validateDocumentRequest(Map<String, String> request) {
    	return request == null || 
    			StringUtils.isEmpty(request.get("fdsCloudDocumentId")) || StringUtils.isEmpty(request.get("fdsCloudSpaceId"));
    }
	
	private void logNess(String msg) {
		if (KafkaProducer.getSetUp()) {
			RealTimeNessConfig.createNessLogEvent(msg);
			
		}
	}
	
	public boolean isValidFileType(String fileType) {
	    return ALLOWED_FILE_TYPES.contains(fileType);
	}
	
	public boolean isValidFileContent(InputStream inputStream) {
		try (RandomAccessReadBuffer rarBuffer = new RandomAccessReadBuffer(inputStream);
	           PDDocument document = Loader.loadPDF(rarBuffer)) {
			   return (document != null);
        } catch (IOException e) {
        	LOGGER.error("Exception while reading pdf content:{}",ExceptionUtils.getStackTrace(e));
            return false;
        }
	}


	private boolean isValidAndSafePdf(MultipartFile file) {
		if (file == null) return false;

		try {
			long size = file.getSize();
			if (size <= 0) {
				LOGGER.warn("Rejected file due to size: {} bytes", size);
				return false;
			}

			String original = file.getOriginalFilename();
			if (original == null) {
				LOGGER.warn("Rejected file with null filename");
				return false;
			}

			String filename = java.nio.file.Paths.get(original).getFileName().toString();
			if (filename.contains("..") || filename.contains("/") || filename.contains("\\")) {
				LOGGER.warn("Rejected file with path traversal in filename: {}", Encode.forJava(original));
				return false;
			}

			if (!filename.toLowerCase().endsWith(".pdf")) {
				LOGGER.warn("Rejected file due to extension not .pdf: {}", Encode.forJava(filename));
				return false;
			}

			// Check magic bytes (PDF header)
			try (java.io.InputStream is = file.getInputStream()) {
				byte[] header = new byte[4];
				int read = is.read(header);
				if (read < 4) {
					LOGGER.warn("Rejected file: header too short");
					return false;
				}
				String magic = new String(header, 0, 4, java.nio.charset.StandardCharsets.US_ASCII);
				if (!magic.startsWith("%PDF")) {
					LOGGER.warn("Rejected file: missing %PDF header");
					return false;
				}
			}

			try (org.apache.pdfbox.pdmodel.PDDocument doc = Loader.loadPDF(new RandomAccessReadBuffer(file.getInputStream()))) {
				if (doc == null) {
					LOGGER.warn("Rejected file: PDFBox returned null document");
					return false;
				}
			}

			return true;
		} catch (Exception e) {
			LOGGER.warn("PDF validation failed: {}", e.getMessage());
			return false;
		}
	}
}
