package real.time.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import javax.ws.rs.core.UriBuilderException;
import java.net.URI;
import java.net.URISyntaxException;

public final class SanitizeUtil {
    private static final String AUTHORIZATION = "Authorization";
    protected static final String REGEX_REPLACEMENT_CHARACTER = "\\$";
	public static final String REPLACEMENT_CHARACTER = "$";
    
    public static String sanitizeString(String input) {
        if (input != null && !input.isEmpty()) {
            try {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode jsonNode = mapper.readTree(input);
                return jsonNode.toString();
            } catch (JsonSyntaxException | JsonProcessingException e) {
                //return input.replaceAll("[^a-zA-Z0-9_-]", "");
                return "Sanitize Failure";
            }
        }
        return "";
    }



    public static HttpEntity<?> sanitizeHttpEntityHeaderRmAuth(HttpEntity<?> requestEntity) {
        requestEntity = new HttpEntity<>(requestEntity.getHeaders());
        HttpHeaders httpHeaders = requestEntity.getHeaders();
        httpHeaders.remove(AUTHORIZATION);
        if (requestEntity.getHeaders().getContentType() != null) {
            httpHeaders.setContentType(new MediaType(sanitizeString(requestEntity.getHeaders().getContentType().toString())));
        }
        return requestEntity;
    }

    public static String sanitizeResponseEntityBody(ResponseEntity<?> response) {
        return response != null && response.getBody() != null ? sanitizeString(response.getBody().toString()) : null;
    }

    public static boolean sanitizeNumericString(String input){
        try {
            return input != null && input.matches("[0-9]+");
        } catch (NumberFormatException e) {
            return false;
        }
    }
    public static String sanitizeFilePath(String input){
        if (input == null) {
            return null;
        }
        return input.replaceAll("[@!$%^&:*?\"<>|]", "_");

    }
    
    public static String sanitizeToString(String str){
        return str == null ? null : str.replaceAll("\\v", "");
    }

    public static String sanitizeIntegerString(String str) {
        return str == null ? null : str.replaceAll("[^0-9]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaString(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaNumericString(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z0-9]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaNumericStringWithHyphen(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z0-9-]", REGEX_REPLACEMENT_CHARACTER);
    }
    public static String sanitizeURL(String url) throws UriBuilderException, URISyntaxException {
        String sanitizedURL = "";
        var awsUri = new URI(url);
        //rebuilding the uri
        sanitizedURL = awsUri.getScheme() + "://" + awsUri.getHost() + awsUri.getPath();
        if (awsUri.getQuery() != null) {
            sanitizedURL += "?" + awsUri.getQuery();
        }
        if (awsUri.getFragment() != null) {
            sanitizedURL += "#" + awsUri.getFragment();
        }
        return sanitizedURL;
    }
}
