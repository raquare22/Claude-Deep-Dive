package real.time.service.util;

import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import real.time.service.mongo.FDSCloudDocument;

@Service
public class RestTemplateChunkClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(RestTemplateChunkClient.class);
	protected static int totalFailureCnt = 0;

	@Autowired
	@Qualifier("RestTemplateChunk")
	private RestTemplate restTemplate;

    @Retryable(value = { RestClientException.class }, maxAttempts = 3, backoff = @Backoff(delay = 1000, multiplier = 2, maxDelay = 10000))
    public ResponseEntity<FDSCloudDocument> putExchangeWithRetry(URI uri, HttpMethod method,  HttpEntity<?> request) throws RestClientException{
        return restTemplate.exchange(uri, method, request, FDSCloudDocument.class);
    }

    @Recover
    public void recover(RetryException e) {
        incrementAndGetTotalFailureCnt();
        LOGGER.error("Retry maximum reached: totalFailureCnt={}; {}", totalFailureCnt, e.getMessage());
    }

    protected static int incrementAndGetTotalFailureCnt() {
		return ++totalFailureCnt;
	}

}