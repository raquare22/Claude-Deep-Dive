package real.time.service.util;

import java.net.URI;
import java.net.URISyntaxException;

import jakarta.ws.rs.core.UriBuilderException;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import real.time.service.java.delegate.docvault.OutOfRetriesException;
import real.time.service.java.delegate.docvault.RetryOnExceptionHandler;
import real.time.service.mongo.DocumentAttachmentMetaData;
import real.time.service.mongo.FDSCloudDocument;

@Component
public class RetryUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RetryUtil.class);

	
	public ResponseEntity<byte[]> retryGetAttachment(URI awsUri, RestTemplate restTemplate) throws InterruptedException, URISyntaxException {
		
		int count = 0;
		int retryInterval = 3000;
		int retryCount = 3;
		
		// get new token for retry
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

		
		LOGGER.info("retryGetAttachment request headers:{}, searchUrl:{}, interval:{}, retryCount:{} ", headers, awsUri
				,retryInterval, retryCount );

		while (count < retryCount) {
			try {
				synchronized (this) {
					this.wait(retryInterval);
				}
				String sanitizedURL = "";
				try{
					sanitizedURL = SanitizeUtil.sanitizeURL(awsUri.toString());
				}catch (UriBuilderException e){
					LOGGER.error("getAttachment Invoking Retry Mechanism, err={}", ExceptionUtils.getStackTrace(e));
					String errorMessage = "Error Building URL";
					byte[] errorBytes = errorMessage.getBytes();
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorBytes);
				}
				return restTemplate.exchange(sanitizedURL, HttpMethod.GET, attachmentEntity, byte[].class);
			} catch (HttpServerErrorException e) {
				if (HttpUtils.validateStatusCode(e.getStatusCode())) {
					LOGGER.error("retryGetAttachment Provider Search - Invoking Retry Mechanism Again: {} ", count);
					if (count == (retryCount - 1)) {
						LOGGER.error("retryGetAttachment HTTP 5xx Error after {} retries, err = {}", count, ExceptionUtils.getStackTrace(e));
						throw e;
					}
				} else {
					throw e;
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw e;
			} catch (Exception e) {
				LOGGER.error("retryGetAttachment Error while Provider Search{}", ExceptionUtils.getStackTrace(e));
				throw e;
			} finally {
				count++;
			}
		}
		return null;
	}
	
	public ResponseEntity<DocumentAttachmentMetaData> retryFDSCloudCall(URI awsUri, String newAccessToken, RestTemplate restTemplate, String fdsCloudGetDocumentUrl) throws InterruptedException {
		
		int count = 0;
		int retryInterval = 500;
		int retryCount = 3;
		
		// get new token for retry
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", newAccessToken);
		HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);
		
		LOGGER.info("retryFDSCloudCall request searchUrl:{}, interval:{}, retryCount:{} ", awsUri
				,retryInterval, retryCount );

		while (count < retryCount) {
			try {
				synchronized (this) {
					this.wait(retryInterval);
				}
				return restTemplate.exchange(awsUri, HttpMethod.GET, attachmentEntity, DocumentAttachmentMetaData.class);
			} catch (HttpServerErrorException e) {
				if (HttpUtils.validateStatusCode(e.getStatusCode())) {
					LOGGER.error("retryFDSCloudCall Provider Search - Invoking Retry Mechanism Again: {} ", count);
					if (count == (retryCount - 1)) {
						LOGGER.error("retryFDSCloudCall HTTP 5xx Error after {} retries, err = {}", count, ExceptionUtils.getStackTrace(e));
						throw e;
					}
				} else {
					throw e;
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw e;
			} catch (Exception e) {
				LOGGER.error("retryGetAttachment Error while Provider Search{}", ExceptionUtils.getStackTrace(e));
				throw e;
			} finally {
				count++;
			}
		}
		return null;
	}
		
	public ResponseEntity<FDSCloudDocument> retryFDSCloudGetCall(String uri, String newAccessToken, RestTemplate restTemplate, String fdsCloudGetDocumentUrl, String cid) throws InterruptedException, URISyntaxException {
		
		var numRetries = 3;
		var timeToWaitMS = 500L;
		
		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		
		// get new token for retry
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", newAccessToken);
		HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

		ResponseEntity<FDSCloudDocument> response = null;
		
		long startTime = System.nanoTime();
		
		
		while (retryHandler.shouldRetry()) {
			try {
				try {
					response = restTemplate.exchange(uri, HttpMethod.GET, attachmentEntity, FDSCloudDocument.class);
					
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					LOGGER.info("getFDSCloudSearchTerms CID={} Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
							Encode.forJava(cid), fdsCloudGetDocumentUrl, HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
					break;
				} catch (HttpStatusCodeException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
				
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						
						LOGGER.error("retryFDSCloudGetCall HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, CID={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(cid), fdsCloudGetDocumentUrl, HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("retryFDSCloudGetCall HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, CID={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(cid), fdsCloudGetDocumentUrl, HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						ResponseEntity<FDSCloudDocument> errorResponse = new ResponseEntity<FDSCloudDocument>(null, headers, e.getStatusCode().value());
						return errorResponse;
					}
				}
			} catch (OutOfRetriesException e) {

				LOGGER.error("retryFDSCloudGetCall HttpStatusCodeException 3 retries exhausted Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, err={}, CID={}", 
						fdsCloudGetDocumentUrl, HttpMethod.GET.toString(), ExceptionUtils.getStackTrace(e), Encode.forJava(cid) );
				ResponseEntity<FDSCloudDocument> errorResponse = new ResponseEntity<FDSCloudDocument>(HttpStatus.INTERNAL_SERVER_ERROR);
				return errorResponse;
			}
		}

		
		return response;
	}
	

}