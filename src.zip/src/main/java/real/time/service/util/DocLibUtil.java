package real.time.service.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import real.time.service.EhCache;
import real.time.service.document.response.util.DocumentResponseUtil;
import real.time.service.java.delegate.docvault.OutOfRetriesException;
import real.time.service.java.delegate.docvault.RetryOnExceptionHandler;
import real.time.service.mongo.AttachmentMetaData;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.template.TemplateFactory;
import real.time.service.workflow.constants.Workflow;

@Service("DocLibUtil")
public class DocLibUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceUtil.class);
	
	static final String DOCLIB_DUPLICATE_ENTRY_RESPONSE = "fileId already exists";
	static final String UNABLE_TO_PROCESS_REQUEST = "we are unable to process your request at this time";
	static final String DUPLICATE_ENTRY_RESPONSE = "Duplicate entry";
	protected Integer numRetries = 3;
	protected Long timeToWaitMS = 250L;
	
	
	@Value("${DocLibOauthUrl}")
    private String docLibOauthUrl;
	
	@Value("${DocLibClientId}")
    private String docLibClientId;
	
	@Value("${DocLibClientSecret}")
    private String docLibClientSecret;
	
	@Value("${DocLibPostUrl}")
    private String docLibPostUrl;
	
	
	@Autowired
	private OauthManagerUtil oauthManagerUtil;
	
	@Autowired
	private RestTemplate restTemplate;

		
	
	
	private final DateFormat df;

	
	private DocLibUtil() {
		super();
		df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));
        
    }
	

public boolean isResponseSuccess(String responseBody, String cid) {
	boolean isSuccess = false;
	try {
		Map<String, Object> responseMap = new ObjectMapper().readValue(responseBody, HashMap.class);
		Map metadata = (Map) responseMap.get("metadata");
		int count = Integer.parseInt(metadata.get(Workflow.COMMON_SUCCESS).toString());
		isSuccess = (count > 0);
	} catch (JsonProcessingException e) {
		LOGGER.error("Error to parse response object, CID={}, err={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
	} catch (NumberFormatException e) {
		LOGGER.error("Error to parse response object success count, CID={}, err= {}",Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
	}
	return isSuccess;
}


	public DocumentMetaData runDocLibProcess(DocumentMetaData document, String cid) {
		String jsonToDocLib = null;

		try {
			String token = oauthManagerUtil.getOauthToken("tokenStargate", docLibClientId, docLibClientSecret, "client_credentials", docLibOauthUrl, false, null);
			var accessToken = "Bearer " + token;

			var attachments = new ArrayList<AttachmentMetaData>();
			var attachmentMetaData = new AttachmentMetaData();

			attachmentMetaData.setFsId(document.getDocumentAttachments().get(0).getFsId());
			attachmentMetaData.setFileName(document.getDocumentAttachments().get(0).getName());
			attachmentMetaData.setDateCreated(document.getDateCreated());
			attachmentMetaData.setSpaceId(document.getSpaceId());
			attachmentMetaData.setCloudSpaceId(document.getDocumentAttachments().get(0).getSpaceId());
			attachmentMetaData.setAttachmentId(document.getDocumentAttachments().get(0).getAttachmentId());
			attachmentMetaData.setFileSize(document.getDocumentAttachments().get(0).getFileSize());
			attachmentMetaData.setContentType(document.getDocumentAttachments().get(0).getContentType());
			attachments.add(attachmentMetaData);

			var documentJsonStr = DocumentResponseUtil.buildDocumentResponseInJson(document, attachments);

			documentJsonStr = TemplateFactory.getInstance("filterReqFieldForDocvault").convertWithTemplate(documentJsonStr);

			jsonToDocLib = List.of(documentJsonStr).toString();

			if (jsonToDocLib.charAt(0) == '[' && jsonToDocLib.charAt(jsonToDocLib.length() - 1) == ']') {
				jsonToDocLib = jsonToDocLib.substring(1, jsonToDocLib.length() - 1);
			}

			ResponseEntity<String> response = null;

			response = postDocumentToDocLibWithRetry(docLibPostUrl, accessToken, jsonToDocLib, document.getId(), Encode.forJava(cid));

			int responseStatus = response.getStatusCode().value();

			String localUploadTime = df.format(new Date());

			if (responseStatus == 200) {
				if (!ObjectUtils.defaultIfNull(response.getBody(), StringUtils.EMPTY).contains(UNABLE_TO_PROCESS_REQUEST) && isResponseSuccess(response.getBody(), cid)) {
					LOGGER.info("getting success response and response body and payload {}, CID={}", jsonToDocLib, Encode.forJava(cid));
					document.getMetadata().put(Workflow.METADATA_DOCLIB_API_RESPONSE, true);
					document.getMetadata().put(Workflow.METADATA_DOCLIB_UPLOAD_DATE, localUploadTime);
					document.getMetadata().put(Workflow.METADATA_DOCSENTTO_FIELD, Workflow.METADATA_DOCSENTTO_DOCLIB);
				} else {
					LOGGER.error("getting error response and response body and payload {}, CID={}", jsonToDocLib, Encode.forJava(cid));
					document.getMetadata().put(Workflow.METADATA_DOCLIB_API_RESPONSE, false);
				}

			} else {

				if (ObjectUtils.defaultIfNull(response.getBody(), StringUtils.EMPTY).contains(DUPLICATE_ENTRY_RESPONSE) || ObjectUtils.defaultIfNull(response.getBody(), StringUtils.EMPTY).contains(DOCLIB_DUPLICATE_ENTRY_RESPONSE)) {
					LOGGER.info("getting duplicate entry response and response body and payload {}, CID={}", jsonToDocLib, Encode.forJava(cid));

					document.getMetadata().put(Workflow.METADATA_DOCLIB_API_RESPONSE, true);
					document.getMetadata().put(Workflow.METADATA_DOCLIB_UPLOAD_DATE, localUploadTime);
					document.getMetadata().put(Workflow.METADATA_DOCSENTTO_FIELD, Workflow.METADATA_DOCSENTTO_DOCLIB);

				} else {
					LOGGER.error("getting error response and response body and payload {}, CID={}", jsonToDocLib, Encode.forJava(cid));
					document.getMetadata().put(Workflow.METADATA_DOCLIB_API_RESPONSE, false);
				}
			}

			return document;

		} catch (Exception e) {
			LOGGER.error("Exception sending document to DocLib documentId={}, e={}, CID={}", document.getId(), ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			return null;
		}
	}

	ResponseEntity<String> postDocumentToDocLibWithRetry(String endpoint, String accessToken, String jsonToDocLib, String docId, String cid) throws OutOfRetriesException {
		ResponseEntity<String> response = null;

		var numRetries = 3;
		var timeToWaitMS = 500L;

		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		String msg;
		while (retryHandler.shouldRetry()) {
			try {
				try {
					if (retryHandler.isRetry()) {
						String newToken = oauthManagerUtil.getOauthToken("tokenStargate", docLibClientId, docLibClientSecret, "client_credentials", docLibOauthUrl, true, null);
						String newAccessToken = "Bearer " + newToken;
						LOGGER.info("postDocumentToDocLibWithRetry retrying doclib call with new token, CID={}", Encode.forJava(cid));
						response = postDocumentToDocLib(endpoint, newAccessToken, jsonToDocLib);
					} else {
						response = postDocumentToDocLib(endpoint, accessToken, jsonToDocLib);
					}
					break;
				} catch (HttpClientErrorException.Unauthorized e) {
					LOGGER.error("HttpClientErrorException Unauthorized for documentId={}, responseBody={}, statusCode={}, CID={}", docId, e.getResponseBodyAsString(), e.getStatusCode(), Encode.forJava(cid));
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				} catch (HttpClientErrorException e) {
					LOGGER.error("HttpClientErrorException for documentId={}, responseBody={}, statusCode={}, CID={}", docId, e.getResponseBodyAsString(), e.getStatusCode(), Encode.forJava(cid));
					return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
				} catch (HttpServerErrorException e) {
					if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
						LOGGER.error("HttpServerErrorException for documentId={}, responseBody={}, statusCode={}, CID={}", docId, e.getResponseBodyAsString(), e.getStatusCode(), Encode.forJava(cid));
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("{} exception for documentId={}, responseBody={}, statusCode={}, CID={}", e.getClass().getSimpleName(), docId, e.getResponseBodyAsString(), e.getStatusCode(), Encode.forJava(cid));
						return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
					}
				} catch (RestClientException e) {
					LOGGER.error("RestClientException for documentId {} and exception {}, CID={}", docId, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
					retryHandler.exceptionOccurred();
				}
			} catch (OutOfRetriesException e) {
				msg = String.format(
						"RestClientException to endpoint %s and exhausted %s retries with retry time %s millis, CID=%s",
						endpoint, retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS(), Encode.forJava(cid));
				LOGGER.error(msg);
				throw new OutOfRetriesException(msg);
			}
		}
		return response;
	}
	
	ResponseEntity<String> postDocumentToDocLib(String endpoint, String accessToken, String document)
			throws RestClientException {
		var headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("accept", "application/json");
		headers.set("Authorization", accessToken);
		HttpEntity<String> request = new HttpEntity<>(document, headers);
		return restTemplate.postForEntity(endpoint, request, String.class);
	}

}
