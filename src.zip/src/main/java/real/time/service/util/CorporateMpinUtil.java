package real.time.service.util;

import java.io.IOException;
import java.util.Optional;


import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.JsonSyntaxException;
import real.time.service.EhCache;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.oauth.OauthTokenExtended;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.provider.pojo.*;
import real.time.service.workflow.constants.Workflow;
import real.time.service.workflow.util.WorkFlowUtil;

@Component
public class CorporateMpinUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CorporateMpinUtil.class);
	
	private static final String PADDING_0 = "0";
	
	@Autowired
	private EhCache ehcache;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private OauthManagerUtil oauthManagerUtil;
	
	
	@Value("${PESAppId}")
    private String pesAppId;
	
	@Value("${PesAppSecret}")
    private String pesAppSecret;
	
	@Value("${PesAuthUrl}")
    private String pesAuthUrl;
	
	@Value("${ProvSearchURL}")
    private String provSearchUrl;
	
	@Value("${PESAttributeSet}")
    private String pesAttributeSet;
	
	@Value("${PESCount}")
    private String pesCount;
	
	@Value("${PESAppName}")
    private String pesAppName;

	public void retrieveCorporateMpin(String tin, DocumentMetaData document, String cid) {
		
		var metadata = document.getMetadata();
		String corporateMpin = ehcache.getCorpMpinCache(formatTin(tin));
		
		if (StringUtils.isEmpty(corporateMpin)) {
			LOGGER.debug("Invoking Corporate MPIN retrieve service for tin");
			corporateMpin = getMpinFromSvcs(tin, cid);
			ehcache.putCorpMpinCache(tin, corporateMpin);
		}
		
		
		if (StringUtils.isNotEmpty(corporateMpin)) {
			corporateMpin = StringUtils.leftPad(corporateMpin, 9, PADDING_0);
			metadata.put(Workflow.PROV_CORP_MPIN, corporateMpin);
		} else {
			WorkFlowUtil.updateEDeliveryError(metadata, Workflow.PROV_CORP_MPIN);
			
		}
	}
	
	public String getMpinFromSvcs(String tin, String cid) {
		LOGGER.debug("Invoking Corporate MPIN retrieve service for tin");
		var request = createRequest(tin, cid);
		try {
			return getProviderCorpMpin(request.getRequestBody(), request.getRequestHeader(), cid);
		} catch (Exception e) {
			LOGGER.error("getMpinFromSvcs Error in retrieveing corporate mpin err={}, cid={}",
					ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			return null;
		}
	}
	
	
	private Request createRequest(String tin, String cid) {

		String accessToken = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId, pesAppSecret, "client_credentials", pesAuthUrl, false, null);

		var requestHeader = new RequestHeader.RequestHeaderBuilder().setToken(accessToken).build();

		var requestBody = new RequestBody.RequestBodyBuilder()
				.setAppName(pesAppName)
				.setAttributeSet(pesAttributeSet)
				.setCount(pesCount).setTaxIdNumber(tin).build();

		return new Request.RequestBuilder().setRequestBody(requestBody).setRequestHeader(requestHeader).build();
	}
	
	public String formatTin(String tin) {
		String trimmedTin = tin.trim();
		return trimmedTin.length() == 14 ? trimmedTin.substring(0, 9) : trimmedTin;
	}
	
	
	
	
	
	public final Object searchProvider(RequestBody requestBody, RequestHeader requestHeader, String cid) throws Exception {
		Object providerInfo = null;

		var searchParams = new LinkedMultiValueMap<String, String>();
		searchParams.add("tax-id-nbr", requestBody.getTaxIdNumber());
		searchParams.add("app-nm", requestBody.getAppName());
		searchParams.add("attribute-set", requestBody.getAttributeSet());
		searchParams.add("count", requestBody.getCount());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set("authorization", "Bearer " + requestHeader.getToken());
		headers.set("timestamp", requestHeader.getTimeStamp());
		headers.set("scope", requestHeader.getScope());
		headers.set("actor", requestHeader.getActor());
		headers.set("correlation_id", requestHeader.getCorrelationId());
		try {
			ResponseEntity<String> response = HttpUtils.postExchange(headers, searchParams, provSearchUrl, String.class,
					null);


			if (HttpUtils.validateStatusCode(response.getStatusCode())) {
				return retrySearchProvider(headers, searchParams, cid);
			}
			String responseBody = Optional.of(response).map(ResponseEntity::getBody)
					.orElseThrow(() -> new RestClientException("Message"));

			MediaType mediaType = Optional.of(response).map(ResponseEntity::getHeaders).map(HttpHeaders::getContentType)
					.orElseThrow(() -> new RestClientException("Message"));

			return parseResponseBody(responseBody, mediaType, cid);

		} catch (RestClientException e) {
			LOGGER.error("searchProvider Invoking Retry Mechanism headers, searchParams, CID={}, error={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
			providerInfo = retrySearchProvider(headers, searchParams, cid);

		} catch (IOException | JsonSyntaxException | NullPointerException e) {
			LOGGER.error("searchProvider Syntax exception CID={}, err={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));

			return null;

		} catch (Exception e) {
			LOGGER.error("searchProvider Error while Provider Search CID={}, err={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));

			throw e;
		}

		return providerInfo;
	}

	public String getProviderCorpMpin(RequestBody requestBody, RequestHeader requestHeader, String cid) throws Exception {

		Object providerInfo = searchProvider(requestBody, requestHeader, cid);

		return (providerInfo instanceof ProviderSearchResults)
				? getProviderCorpMpin((ProviderSearchResults) providerInfo)
				: getProviderCorpMpin((PhysicianFacility) providerInfo);
	}

	public String getProviderCorpMpin(PhysicianFacility providerInfo) {
		return Optional.ofNullable(providerInfo).map(PhysicianFacility::getSvcResponse)
				.map(SvcResponse::getPhysicianFacilityInformation)
				.map(PhysicianFacilityInformation::getTaxId).flatMap(x -> x.stream().findFirst())
				.map(TaxIdType::getcorpMPIN).orElse(null);

	}

	public String getProviderCorpMpin(ProviderSearchResults providerInfo) {

		return Optional.ofNullable(providerInfo).map(ProviderSearchResults::getRecords)
				.filter(CollectionUtils::isNotEmpty).flatMap(x -> x.stream().findFirst()).map(Records::getRosterdata)
				.map(Rosterdata::getTaxId).filter(CollectionUtils::isNotEmpty).flatMap(x -> x.stream().findFirst())
				.flatMap(x -> x.stream().findFirst()).map(TaxId::getCorpOwnrProvId).orElse(null);
	}
	

	public final Object retrySearchProvider(HttpHeaders headers, MultiValueMap<?, ?> searchParams, String cid) throws Exception {
		int count = 0;
		int retrieveCorpMPINCallRetryInterval = 500;
		int retryCount = 2;
		
		// get new token for retry
		String newToken = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId, pesAppSecret, "client_credentials", pesAuthUrl, true, null);
		headers.set("authorization", "Bearer " + newToken); 

		
		LOGGER.info("retrievecorpMPIN PES retry request headers, searchParams, searchUrl, CID={}, interval:{}, retryCount:{} ",
				Encode.forJava(cid)
				,retrieveCorpMPINCallRetryInterval, retryCount );
		//later chceck

		while (count < retryCount) {
			try {
				synchronized (this) {
					this.wait(retrieveCorpMPINCallRetryInterval);
				}
				ResponseEntity<String> response = HttpUtils.postExchange(headers, searchParams, provSearchUrl, String.class,
						restTemplate);

				String responseBody = Optional.of(response).map(ResponseEntity::getBody).orElse(null);
//				LOGGER.info("response:{}, body: {}", response , responseBody);
				MediaType mediaType = Optional.of(response).map(ResponseEntity::getHeaders)
						.map(HttpHeaders::getContentType).orElse(null);

				return parseResponseBody(responseBody, mediaType, cid);

			} catch (HttpServerErrorException e) {
				if (HttpUtils.validateStatusCode(e.getStatusCode())) {
					LOGGER.error("retrySearchProvider Provider Search - Invoking Retry Mechanism Again: {}, CID={} ", count, Encode.forJava(cid));
					if (count == (retryCount - 1)) {
						LOGGER.error("retrySearchProvider HTTP 5xx Error after {} retries - Provider Search, CID={}", count, Encode.forJava(cid));
						LOGGER.error("retrySearchProvider for CID={}, error={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
						throw e;
					}
				} else {
					throw e;
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw e;
			} catch (Exception e) {
				LOGGER.error("retrySearchProvider Error while Provider Search CID={}, error={}",Encode.forJava(cid),  ExceptionUtils.getStackTrace(e));
				throw e;
			} finally {
				count++;
			}
		}
		return null;
	}

	public Object parseResponseBody(String responseBody, MediaType mediaType, String cid) throws IOException {
		if (responseBody != null && mediaType != null) {
			if (mediaType.equals(MediaType.APPLICATION_XML)) {
				LOGGER.info("xml -> PhysicianFacility, response body: , CID={}, mediaType: {}",Encode.forJava(cid), mediaType);
				return Parser.parseXML(responseBody, PhysicianFacility.class);
			} else {
				LOGGER.info("json -> ProviderSearchResults, response body: , CID={}, mediaType: {}",Encode.forJava(cid), mediaType);
				return Parser.parseJson(responseBody, ProviderSearchResults.class, false);
			}
		}
		return null;
	}

}
