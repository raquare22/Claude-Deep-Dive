package real.time.service.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
//import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

public class HttpUtils {
    public static <T> ResponseEntity<T> postExchange( HttpHeaders headers,
                                                      MultiValueMap<?, ?> reqPayload,
                                                      String url,
                                                      Class<T> responseType,
                                                      RestTemplate restTemplate) throws RestClientException {

        URI uri = UriComponentsBuilder.fromUriString(url).build().encode().toUri();

        HttpEntity<?> requestEntity = new HttpEntity<>(reqPayload, headers);
        if(restTemplate == null){
            restTemplate = new RestTemplate();
        }
        return restTemplate.exchange(uri, HttpMethod.POST, requestEntity, responseType);
    }
    
	public static boolean validateStatusCode(HttpStatusCode httpStatusCode) {

		return HttpStatus.UNAUTHORIZED.equals(httpStatusCode) 
				|| HttpStatus.INTERNAL_SERVER_ERROR.equals(httpStatusCode)
				|| HttpStatus.BAD_GATEWAY.equals(httpStatusCode)
				|| HttpStatus.SERVICE_UNAVAILABLE.equals(httpStatusCode)
				|| HttpStatus.GATEWAY_TIMEOUT.equals(httpStatusCode);
	}
}

