package real.time.service.util;

import java.io.File;
import java.net.URI;
import java.util.Optional;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import real.time.service.EhCache;
import real.time.service.exception.HttpServerException;
import real.time.service.java.delegate.docvault.OutOfRetriesException;
import real.time.service.java.delegate.docvault.RetryOnExceptionHandler;
import real.time.service.mongo.FDSCloudDocument;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.oauth.OauthTokenExtended;
import io.netty.channel.ChannelOption;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

@Service("WebClientSync")
public class WebClientSync {
	private static final Logger LOGGER = LoggerFactory.getLogger(WebClientSync.class);

	protected static int totalHttpFailureCnt = 0;
	protected static int totalFailureCnt = 0;

	@Autowired
	private WebClient.Builder webClientBuilder;
	
	@Autowired
	private OauthManagerUtil oauthManagerUtil;

	@Autowired
	private EhCache ehCache;
	
	@Value("${FDSOauthUrl}")
	protected String fdsOauthUrl;
	
	@Value("${FDSCloudAppId}")
	protected String fdsCloudAppId;
	
	@Value("${FDSCloudAppSecret}")
	protected String fdsCloudAppSecret;

	private WebClient webClientSingleton = null;
    private static final String GRANT_TYPE = "client_credentials";

	ExchangeFilterFunction errorResponseFilter = ExchangeFilterFunction.ofResponseProcessor(WebClientSync::responseFilter);

	public static void logStats() {
		LOGGER.warn("STATS: totalHttpFailureCnt={}, totalFailureCnt={}", totalHttpFailureCnt, totalFailureCnt);
	}
	
	public ResponseEntity<FDSCloudDocument> sendMultiPartDataWithRetry(String fdsCloudPostDocumentsUrl, URI uri, File file, String document, 
			String searchTerms, String cid) throws OutOfRetriesException {
		
		var numRetries = 3;
		var timeToWaitMS = 250L;
		
		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		

        String oauthToken = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", fdsCloudAppId, fdsCloudAppSecret, GRANT_TYPE, fdsOauthUrl, false, null);

		ResponseEntity<FDSCloudDocument> response = null;
		
		long startTime = System.nanoTime();
		HttpHeaders headers = new HttpHeaders();
		while (retryHandler.shouldRetry()) {
			try {
				try {
					
					if (retryHandler.isRetry()) {
                        String newToken = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", fdsCloudAppId, fdsCloudAppSecret, GRANT_TYPE, fdsOauthUrl, true, null);
						response = getWebClient()
								.post().uri(uri).contentType(MediaType.MULTIPART_FORM_DATA)
								.header("fds-authorization", newToken)
								.body(BodyInserters.fromMultipartData(getMultiValueMap(file, document, searchTerms)))
								.retrieve()
//								.bodyToMono(FDSCloudDocument.class)
//								.retry(3)
					            .toEntity(FDSCloudDocument.class)
								.block();
						
					} else {
						response = getWebClient()
								.post().uri(uri).contentType(MediaType.MULTIPART_FORM_DATA)
								.header("fds-authorization", oauthToken)
								.body(BodyInserters.fromMultipartData(getMultiValueMap(file, document, searchTerms)))
								.retrieve()
//								.bodyToMono(FDSCloudDocument.class)
//								.retry(3)
					            .toEntity(FDSCloudDocument.class)
								.block();
					}
					
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					LOGGER.info("sendMultiPartDataWithRetry CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
							Encode.forJava(cid), fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), response.getStatusCode().value(), latency );
					break;
				} catch (HttpStatusCodeException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
				
					incrementAndGetTotalHttpFailureCnt();
					
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						
						LOGGER.error("sendMultiPartDataWithRetry HttpStatusCodeException Invoking Retry Mechanism CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(cid), fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("sendMultiPartDataWithRetry HttpStatusCodeException Invoking Retry Mechanism CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(cid), fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						ResponseEntity<FDSCloudDocument> errorResponse = new ResponseEntity<FDSCloudDocument>(null, headers, e.getStatusCode().value());
						return errorResponse;
					}
				} catch (WebClientResponseException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					incrementAndGetTotalHttpFailureCnt();
					
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						
						LOGGER.error("sendMultiPartDataWithRetry WebClientResponseException Invoking Retry Mechanism CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(cid), fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("sendMultiPartDataWithRetry WebClientResponseException Invoking Retry Mechanism CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(cid), fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						ResponseEntity<FDSCloudDocument> errorResponse = new ResponseEntity<FDSCloudDocument>(null, headers, e.getStatusCode().value());
						return errorResponse;
					}
				} catch (Exception e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.error("sendMultiPartDataWithRetry Exception CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, TotalLatency={}, err={}", 
							Encode.forJava(cid), fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), latency, ExceptionUtils.getStackTrace(e) );
					
					ResponseEntity<FDSCloudDocument> errorResponse = new ResponseEntity<FDSCloudDocument>(HttpStatus.INTERNAL_SERVER_ERROR);
					return errorResponse;
				}
			} catch (OutOfRetriesException e) {

				LOGGER.error("retryFDSCloudGetCall OutOfRetriesException 3 retries exhausted CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, err={}", 
						Encode.forJava(cid), fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), ExceptionUtils.getStackTrace(e) );
				ResponseEntity<FDSCloudDocument> errorResponse = new ResponseEntity<FDSCloudDocument>(HttpStatus.INTERNAL_SERVER_ERROR);
				return errorResponse;
			}
		}

		
		return response;
	}

	public ResponseEntity<FDSCloudDocument> sendMultiPartData(URI uri, String oauthToken, File file, String document, String searchTerms, String cid) {
		FDSCloudDocument response = null;
		try {
			response = getWebClient()
				.post().uri(uri).contentType(MediaType.MULTIPART_FORM_DATA)
				.header("fds-authorization", oauthToken)
				.body(BodyInserters.fromMultipartData(getMultiValueMap(file, document, searchTerms))).retrieve().bodyToMono(FDSCloudDocument.class)
				.retry(3)
				.block();
		} catch (HttpServerException e) {
			incrementAndGetTotalHttpFailureCnt();
			throw new HttpServerException("file=" + file + "; " + e.getMessage(), e.getStatus());
		} catch(Exception e) {
			incrementAndGetTotalFailureCnt();
			throw new HttpServerException("file=" + file + "; " + ExceptionUtils.getStackTrace(e), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LOGGER.info("OK: CID={}, response={}", Encode.forJava(cid), response);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}


	protected MultiValueMap<String, HttpEntity<?>> getMultiValueMap(File file, String document, String searchTerms) {
		MultipartBodyBuilder builder = new MultipartBodyBuilder();
		builder.part("file", new FileSystemResource(Encode.forJava(String.valueOf(file))));
		builder.part("metadata", document);
		builder.part("searchTerms", searchTerms);
		return builder.build();
	}

	protected final WebClient getWebClient() {
		if (webClientSingleton == null) {
			getNewWebClient();
		}
		return webClientSingleton;
	}

	protected final synchronized WebClient getNewWebClient() {
		if (webClientSingleton == null) {
			HttpClient httpClient = HttpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000); //default 30000
			webClientSingleton = webClientBuilder.clientConnector(new ReactorClientHttpConnector(httpClient))
//					.filter(errorResponseFilter)
					.build();
		}
		return webClientSingleton;
	}

	protected static Mono<ClientResponse> responseFilter(ClientResponse response) {
		HttpStatusCode status = response.statusCode();
		if (status.isError()) {
			String msg = "body=" + response.bodyToMono(String.class) + ", headers=" + response.headers().asHttpHeaders();
			LOGGER.error("FAILURE: status={}, msg={}", status, msg);
			return response.bodyToMono(String.class).flatMap(body -> Mono.error(new HttpServerException(msg, status)));
		}
		LOGGER.info("OK: status={}, body={}, headers={}", status, response.bodyToMono(String.class), response.headers().asHttpHeaders());
		return Mono.just(response);
	}

	protected static int incrementAndGetTotalHttpFailureCnt() {
		return ++totalHttpFailureCnt;
	}

	protected static int incrementAndGetTotalFailureCnt() {
		return ++totalFailureCnt;
	}
}