package real.time.service.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.UriBuilderException;
//import net.sf.ehcache.CacheException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import real.time.service.EhCache;
import real.time.service.email.EmailService;
import real.time.service.java.delegate.docvault.OutOfRetriesException;
import real.time.service.java.delegate.docvault.RetryOnExceptionHandler;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.mongo.FDSCloudDocument;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.oauth.OauthTokenExtended;
import real.time.service.template.TemplateFactory;

@Service("ServiceUtil")
public class ServiceUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceUtil.class);
	
	private ArrayList<HttpStatus> validStatus = new ArrayList<>(Arrays.asList(HttpStatus.OK, HttpStatus.CREATED));
	
	protected Integer numRetries = 3;
	protected Long timeToWaitMS = 250L;
	
	
	@Value("${FDSCloudOauthUrl}")
    private String fdsCloudOauthUrl;
	
	@Value("${FDSCloudClientId}")
    private String fdsCloudClientId;
	
	@Value("${FDSCloudClientSecret}")
    private String fdsCloudClientSecret;
	
	@Value("${FDSCloudGetDocumentUrl}")
    private String fdsCloudGetDocumentUrl;
	
	@Value("${FDSCloudGrantType}")
	private String fdsCloudGrantType;
	
	@Value("${ELGSOauthUrl}")
    private String elgsOauthUrl;
	
	@Value("${ELGSClientId}")
    private String elgsClientId;
	
	@Value("${ELGSClientSecret}")
    private String elgsClientSecret;
	
	@Value("${ELGSPostUrl}")
    private String elgsPostUrl;
	
	@Value("${emailSender}")
    private String emailSender;
	
	@Value("${ELGSEmailReceiver}")
    private String emailReceiver;
	
	@Value("${env}")
    private String env;
	
	@Autowired
	private OauthManagerUtil oauthManagerUtil;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private RetryUtil retryUtil;
	
	@Autowired
	private EmailService emailService;

	@Autowired
	private EhCache ehCache;
	
	
//	public ResponseEntity<GenericResponse> postExchangeGenericResponse(URI uri, HttpEntity<?> requestEntity){
//		LOGGER.info("uri={}, requestEntity={}", uri, requestEntity);
//		return new RestTemplate().exchange(uri, HttpMethod.POST, requestEntity, GenericResponse.class);
//	}
	
//	public ResponseEntity<GenericResponse> postRequestToSvcMultiPartForm(String url, MultiValueMap<String, Object> requestMap, String spaceId) {
//		LOGGER.info("postRequestToSvcMultipartForm -- Posting document request to service layer, apiUrl={}, requestMap={}, pathVariable={}", url, requestMap, spaceId);
//		
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("Accept", "*/*");
//		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
//		HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(requestMap, headers);
//		
//		URI uri = UriComponentsBuilder.fromUriString(url)
//				.buildAndExpand(spaceId)
//				.encode()
//			    .toUri();
//		
//		ResponseEntity<GenericResponse> responseEntity = null;
//		
//		try {
//			responseEntity = postExchangeGenericResponse(uri, request);
//			if (responseEntity == null) {
//				LOGGER.warn("Post task returned null: apiUrl={}, requestBody={}", url, request.getBody());
//				return new ResponseEntity<>(new GenericResponse("102", "Error during service call", "responseEntity == null"), HttpStatus.PROCESSING);
//			}
//
//			if (validStatus.contains(responseEntity.getStatusCode())) {
//				LOGGER.info("Post task successful: requestBody={}", request.getBody());
//				return responseEntity;
//			}
//			int retryCount = numRetries;
//			while ((! (validStatus.contains(responseEntity.getStatusCode()))) && (retryCount --> 0)) {
//				try {
//					synchronized(this) {
//						this.wait(timeToWaitMS);
//					}
//				} catch (InterruptedException e) {
//					Thread.currentThread().interrupt();
//				}
//				responseEntity = postExchangeGenericResponse(uri, request);
//				LOGGER.warn("Post task retry: requestBody={}, retryCount={}", request.getBody(), retryCount);
//			}
//			if (responseEntity.getStatusCode() != HttpStatus.OK || responseEntity.getStatusCode() != HttpStatus.CREATED) {
//				LOGGER.error("Post task failed with error code={}: requestBody={}", responseEntity.getStatusCode(), request.getBody());
//				return responseEntity;
//			}
//		} catch (Exception e) {
//			LOGGER.error("postExchange failed: apiUrl={}, postRequest={}; {}", url, requestMap, e.getMessage());
//			return new ResponseEntity<>(new GenericResponse("400", "Error during service call", e.getMessage()), HttpStatus.BAD_REQUEST);
//		}
//		return responseEntity;
//
//	}



	public void sendMetadataValidationNotificationELGS(List<Map<String, String>> errorList, DocumentMetaData document, org.bson.Document metadata, String fdsCloudSpaceId, String fdsCloudDocumentId, String cid) {
		LOGGER.info("Sending ELGS metadata validation notification fdsCloudDocumentId, CID={}", Encode.forJava(cid));

		Map<String, Object> requestMap = new HashMap<>();
		requestMap.put("metadata", metadata);
		requestMap.put("document", document);
		requestMap.put("fdsCloudDocumentId", fdsCloudDocumentId);
		requestMap.put("errorList", errorList);
		requestMap.put("fdsCloudSpaceId", fdsCloudSpaceId);

		String requestJson = TemplateFactory.getInstance("elgsMetadataValidationRequest").convertWithTemplate(requestMap);

		try {
			// get stargate token
			String token = oauthManagerUtil.getOauthToken("tokenStargateELGS", elgsClientId, elgsClientSecret, "client_credentials", elgsOauthUrl, false, null);
			ResponseEntity<String> response = postELGSWithRetry(token, requestJson, fdsCloudDocumentId, Encode.forJava(cid));


			LOGGER.info("ELGS metadata validation API HTTPStatus={}, CID={}", response.getStatusCode(), Encode.forJava(cid));

			int responseStatus = response.getStatusCode().value();

			if (responseStatus == 200) {
				LOGGER.info("Sent notification to ELGS for metadata validation, response, CID={}", Encode.forJava(cid));
			} else {
				LOGGER.info("Notification to ELGS metadata validation API failed, now sending email notification - fdsCloudDocumentId={}, response={}, CID={}",
						SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(fdsCloudDocumentId),
						SanitizeUtil.sanitizeResponseEntityBody(response), Encode.forJava(cid));
				sendEmailNotificationELGS(requestJson, fdsCloudDocumentId, Encode.forJava(cid));
			}
		} catch (Exception e) {
			LOGGER.error("Exception sending notification to ELGS fdsCloudDocId, e={}, CID={}", ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			sendEmailNotificationELGS(requestJson, fdsCloudDocumentId, Encode.forJava(cid));
		}
	}

	public void sendEmailNotificationELGS(String requestJson, String fdsCloudDocumentId, String cid) {
		LOGGER.info("Sending email notification to ELGS, fdsCloudDocId={}, requestJson={}, CID={}",
				SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(fdsCloudDocumentId), SanitizeUtil.sanitizeString(requestJson), Encode.forJava(cid));

		try {
			String emailSubject = "ELGS Metadata Validation API failure - " + env;
			emailService.sendEmail(emailSender, emailReceiver, emailSubject, requestJson);
			LOGGER.info("Email notification to ELGS successfully sent, fdsDocumentId={}, requestJson={}, emailReceiver={}, CID={}",
					SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(fdsCloudDocumentId), SanitizeUtil.sanitizeString(requestJson), emailReceiver, Encode.forJava(cid));
		} catch (Exception e) {
			LOGGER.error("Exception sending email notification to ELGS, requestJson={}, emailReceiver={}, fdsCloudDocId={}, CID={}", SanitizeUtil.sanitizeString(requestJson),
					emailReceiver, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(fdsCloudDocumentId), Encode.forJava(cid));
		}
	}


	public ResponseEntity<String> postELGSWithRetry(String accessToken, String requestJson, String docId, String cid) throws OutOfRetriesException {
		ResponseEntity<String> response = null;

		var numRetries = 3;
		var timeToWaitMS = 500L;

		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		String msg;
		while (retryHandler.shouldRetry()) {
			try {
				try {
					if (retryHandler.isRetry()) {
						String newToken = oauthManagerUtil.getOauthToken("tokenStargateELGS", elgsClientId, elgsClientSecret, "client_credentials", elgsOauthUrl, true, null);
						String newAccessToken = "Bearer " + newToken;
						LOGGER.info("postELGSWithRetry retrying elgs call with new token, CID={}", Encode.forJava(cid));
						response = postELGSRequest(newAccessToken, requestJson, Encode.forJava(cid));
					} else {
						response = postELGSRequest(accessToken, requestJson, Encode.forJava(cid));
					}
					break;
				} catch (HttpClientErrorException.Unauthorized e) {
					LOGGER.error("postELGSWithRetry HttpClientErrorException Unauthorized for documentId={}, responseBody={}, statusCode={}, CID={}", 
							SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId), e.getResponseBodyAsString(), e.getStatusCode(), Encode.forJava(cid));
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				}catch (HttpClientErrorException e) {
					LOGGER.error("postELGSWithRetry HttpClientErrorException for documentId={}, responseBody={}, statusCode={}, CID={}", 
							SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId), e.getResponseBodyAsString(), e.getStatusCode(), Encode.forJava(cid));
					//later check for codeQL for docId
					return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());					
				} catch (HttpServerErrorException e) {
					if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
						LOGGER.error("postELGSWithRetry HttpClientErrorException for documentId={}, responseBody={}, statusCode={}, CID={}", 
								SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId), 
								e.getResponseBodyAsString(), e.getStatusCode(), Encode.forJava(cid) );
						retryHandler.exceptionOccurred();
					}
					else {
						LOGGER.error("postELGSWithRetry HttpServerErrorException for documentId={}, responseBody={}, statusCode={}, CID={}", 
								SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId), e.getClass().getSimpleName(), e.getStatusCode(), Encode.forJava(cid));
						return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
					}
				} catch (RestClientException e) {
					LOGGER.error("postELGSWithRetry RestClientException for document and exception, CID={}, err={} ", Encode.forJava(cid),
							ExceptionUtils.getStackTrace(e));
					retryHandler.exceptionOccurred();
				}
			} catch (OutOfRetriesException e) {
				msg = String.format(
						"postELGSWithRetryRestClientException to endpoint %s and exhausted %s retries with retry time %s millis, CID=%s",
						elgsPostUrl, retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS(), Encode.forJava(cid));
				LOGGER.error(msg);
				throw new OutOfRetriesException(msg);
			}
		}
		return response;
	}
	
	public ResponseEntity<String> postELGSRequest(String token, String requestStr, String cid) {
		var headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("accept", "application/json");
		headers.set("Authorization", token);
		HttpEntity<String> request = new HttpEntity<>(requestStr, headers);
		LOGGER.info("ProcessDocumentUtil send to ELGS metadata validation api, url={}, requestJson={}, CID={}", elgsPostUrl, SanitizeUtil.sanitizeString(requestStr), Encode.forJava(cid));
		return restTemplate.postForEntity(elgsPostUrl, request, String.class);
	}
	
	
	public ResponseEntity<FDSCloudDocument> getFDSCloudSearchTerms(String fdsDocumentId, String fdsCloudSpaceId, String cid) throws InterruptedException, URISyntaxException {

		String token = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", fdsCloudClientId, fdsCloudClientSecret, fdsCloudGrantType, fdsCloudOauthUrl, false, null);
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", token);
		HttpEntity<?> entity = new HttpEntity<>(headers);
		
		
		Map<String, String> pathParams = new HashMap<>();
		pathParams.put("spaceId", fdsCloudSpaceId);
		pathParams.put("documentId", fdsDocumentId);
				
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(fdsCloudGetDocumentUrl);
		
		URI uri = uriBuilder.buildAndExpand(pathParams).encode().toUri();
				
		ResponseEntity<FDSCloudDocument> response = null;
		
		long startTime = System.nanoTime();
		
		try {
			
			response = restTemplate.exchange(Encode.forJava(uri.toString()), HttpMethod.GET, entity, FDSCloudDocument.class);
			
			long latency = (System.nanoTime() - startTime) / 1000000;
			LOGGER.info("getFDSCloudSearchTerms CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
					Encode.forJava(cid), fdsCloudGetDocumentUrl, HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
			
		} catch (HttpStatusCodeException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;
			if (e.getResponseBodyAsString().contains("Document not found")){
				
				LOGGER.warn("getFDSCloudSearchTerms HttpStatusCodeException document not found, CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}", 
						Encode.forJava(cid), fdsCloudGetDocumentUrl, HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString() );
				
				return response;
			} else {
				LOGGER.error("getFDSCloudSearchTerms HttpStatusCodeException Invoking Retry Mechanism, CID={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
						Encode.forJava(cid), fdsCloudGetDocumentUrl, HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
				
				String newAccessToken = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", fdsCloudClientId, fdsCloudClientSecret, fdsCloudGrantType, fdsCloudOauthUrl, true, null);
				response = retryUtil.retryFDSCloudGetCall(Encode.forJava(uri.toString()), newAccessToken, restTemplate, fdsCloudGetDocumentUrl, cid);
			}			
		} catch (UriBuilderException e){
			LOGGER.error("getFDSCloudSearchTerms error building URL , e={}, CID={}",  ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		}
		catch (Exception e) {
			LOGGER.error("getFDSCloudSearchTerms error sending FDSCloud get request, e={}, CID={}",  ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		}
		
		return response;		
	}
	
}
