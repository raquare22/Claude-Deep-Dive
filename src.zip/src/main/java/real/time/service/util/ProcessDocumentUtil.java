package real.time.service.util;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import real.time.service.config.ConfigData;
import real.time.service.domain.service.DocumentMetaDataService;
import real.time.service.domain.service.FilestoreService;
import real.time.service.exception.HttpServerException;
import real.time.service.model.Doc360UploadResponse;
import real.time.service.mongo.DocumentAttachmentMetaData;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.mongo.FDSCloudDocument;
import real.time.service.mongo.file.metadata.PostCardInd;
import real.time.service.mongo.processors.MetaDataStatus;
import real.time.service.pojo.ClientMetadata;
import real.time.service.pojo.ErrorMessage;
import real.time.service.template.java.impl.FDSCloudSearchTermsTemplate;
import real.time.service.workflow.constants.Workflow;
import real.time.service.workflow.util.WorkFlowUtil;

@Component
public class ProcessDocumentUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessDocumentUtil.class);
	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	protected String schemaFileBasePath = File.separator + "schemas" + File.separator;
	private static final String EXPIRY_DATE = "expiryDate";
	private static final String CREATED_DATE = "createdDate";
	private static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
	private static final String UPLOAD_PROVIDER_FDS = "FDS_CLOUD";
	private static final String UPLOAD_PROVIDER_DOC360 = "DOC360";
	private static final String UPLOAD_PROVIDER_METADATA_KEY = "uploadProvider";
	
	private static final Gson gson = new GsonBuilder().setDateFormat(DATE_FORMAT).create();
	
	@Value("${FDSRetentionPeriod}")
	protected Integer fDSRetentionPeriod;
	
	@Autowired
	private ConfigData config;
	
	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	private PostCardInd postCardInd;
	
	@Autowired
    private DocumentMetaDataService documentMetaDataService;
	
	@Autowired
    private FilestoreService filestoreService;
	
	
	@Autowired
	private CorporateMpinUtil corpMpinUtil;
	
	@Autowired
	private ServiceUtil serviceUtil;
	
	@Autowired
	private FilestoreUtil filestoreUtil;
	
	@Autowired
	private DocLibUtil docLibUtil;
	
	@Autowired
	FDSCloudSearchTermsTemplate fdsCloudSearchTermsTemplate;
	
	private final DateFormat df;

	
	private ProcessDocumentUtil() {
		super();
		df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));
        
    }

	public Map<String, Object> processDocument(Map<String, String> requestMap, String cid) throws URISyntaxException, InterruptedException, IOException {
		Map<String, Object> resultMap = new HashMap<>();

		try {
			String fdsCloudDocumentId = requestMap.get("fdsCloudDocumentId");
			String fdsCloudSpaceId = requestMap.get("fdsCloudSpaceId");

			DocumentMetaData newDoc = convertAndCreateDocument(fdsCloudDocumentId, fdsCloudSpaceId, resultMap, Encode.forJava(cid));
			if (newDoc == null || (newDoc != null && (newDoc.getMetadata() == null || newDoc.getMetadata().isEmpty()))) {
				LOGGER.error("Error converting FDSCloudDoc to document, invalid documentId or spaceId, CID={}", Encode.forJava(cid));
				return Collections.emptyMap();
			}

			resultMap.put("fdsCloudDocumentId", newDoc.getFdsDocumentId());

			if (newDoc.getStatus() != null && (newDoc.getStatus().equals(MetaDataStatus.FATAL_ERROR) || newDoc.getStatus().equals(MetaDataStatus.SEVERE_ERROR))) {
				LOGGER.warn("Document has FATAL_ERROR or SEVERE_ERROR, processing will not continue, fdsCloudDocId={}, prunDocumentId={}, resultMap={}, CID={}", Encode.forJava(newDoc.getFdsDocumentId()), Encode.forJava(newDoc.getId()), Encode.forJava(resultMap.toString()), Encode.forJava(cid));newDoc = documentMetaDataService.saveDocumentMetaData(newDoc);
				resultMap.put(Workflow.DOCUMENT_ID, newDoc.getId());
				return resultMap;
			}

			// required field rule
//			runRequiredFieldRuleProcess(newDoc, cid);
//			if (!((boolean) newDoc.getMetadata().get(Workflow.SEND_TO_DOCVAULT))) {
//				LOGGER.warn("processDocument --> document not eligible to send to DocLib, documentId={}, CID={}", newDoc.getId(), Encode.forJava(cid));
//				newDoc = documentMetaDataService.saveDocumentMetaData(newDoc);
//				resultMap.put(Workflow.DOCUMENT_ID, newDoc.getId());
//				return resultMap;
//			}

			// send Doc to DocLib
//			DocumentMetaData finalDoc = docLibUtil.runDocLibProcess(newDoc, Encode.forJava(cid));
//			if (finalDoc == null) {
//				LOGGER.error("Error sending document to DocLib, CID={}", Encode.forJava(cid));
//				return Collections.emptyMap();
//			}

			newDoc = documentMetaDataService.saveDocumentMetaData(newDoc);
			resultMap.put(Workflow.DOCUMENT_ID, newDoc.getId());

			// return response with DocLib upload date
			resultMap.put(Workflow.METADATA_DOCLIB_UPLOAD_DATE, newDoc.getMetadata().get(Workflow.METADATA_DOCLIB_UPLOAD_DATE));
			return resultMap;
		} catch (Exception e) {
			LOGGER.error("Exception during processDocument, CID={}", Encode.forJava(cid), e);
			throw new RuntimeException(INTERNAL_SERVER_ERROR, e); // Return 500 Internal Server Error
		}
	}
	
	public void runRequiredFieldRuleProcess(DocumentMetaData document, String cid) {

		org.bson.Document metadata = document.getMetadata();
		
		String tin = (String) metadata.get(Workflow.TIN);
		
		if (StringUtils.isEmpty(tin)) {
			WorkFlowUtil.updateEDeliveryError(metadata, Workflow.TIN);
			WorkFlowUtil.updateEDeliveryError(metadata, Workflow.PROV_CORP_MPIN);
		}

		if (!StringUtils.isEmpty(tin) && StringUtils.isEmpty((String) metadata.get(Workflow.PROV_CORP_MPIN)) ) {
			// retrieveCorporateMpin
			corpMpinUtil.retrieveCorporateMpin(tin, document, cid);
		}
		
		String corporateMpin = (String) metadata.get(Workflow.PROV_CORP_MPIN);
		
		
		if (metadata.get("emailAlertReq").equals("N")) {
			metadata.put(Workflow.SEND_TO_DOCVAULT, true);
			if (tin == null || tin.isEmpty() || corporateMpin == null || corporateMpin.isEmpty()) {
				metadata.put(Workflow.SEND_TO_DOCVAULT, false);
			}
		} else {
			metadata.put(Workflow.SEND_TO_DOCVAULT, true);
			if (tin == null || tin.isEmpty() || corporateMpin == null || corporateMpin.isEmpty()) {
				metadata.put(Workflow.SEND_TO_DOCVAULT, false);
			}
		}
		
	}


	public Map<String, Object> processFileUpload(String fileName, MultipartFile file, Document metadata, Integer spaceId, String optumCidExt) {
		LOGGER.info("processFileUpload -- start, file={}, metadata={}, spaceId={}, CID={}", SanitizeUtil.sanitizeAlphaString(fileName), metadata, spaceId, Encode.forJava(optumCidExt));
		
		Map<String, Object> responseMap = new HashMap<String, Object>();
		
		// Create document and validate metadata
		DocumentMetaData document = new DocumentMetaData();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		org.bson.Document convertedMetadata = convertAndValidateMetadata(document, metadata, spaceId, resultMap, optumCidExt);

		convertedMetadata.put("fileName", fileName);
		convertedMetadata.putAll(resultMap);

		document.setMetadata(convertedMetadata);

		// save file to ingest
		String ingestFilePath = filestoreUtil.saveFileToIngest(fileName, file, spaceId, Encode.forJava(optumCidExt));

		String uploadProvider = resolveUploadProvider(spaceId);
		if (document.getMetadata() != null) {
			document.getMetadata().put(UPLOAD_PROVIDER_METADATA_KEY, uploadProvider);
		}

		if (UPLOAD_PROVIDER_DOC360.equalsIgnoreCase(uploadProvider)) {
			ResponseEntity<Doc360UploadResponse> doc360Response = postDocumentToDoc360(ingestFilePath, spaceId, metadata, Encode.forJava(optumCidExt));
			updateDocumentWithDoc360Response(document, spaceId, doc360Response, Encode.forJava(optumCidExt));
		} else {
			ResponseEntity<FDSCloudDocument> fdsCloudDocumentResponse = postDocumentToFDSCloud(ingestFilePath, spaceId, metadata, Encode.forJava(optumCidExt));
			updateDocumentWithFDSCloudResponse(document, spaceId, fdsCloudDocumentResponse, Encode.forJava(optumCidExt));
		}

		// save document to Mongo
		DocumentMetaData savedDoc = documentMetaDataService.saveDocumentMetaData(document);

		responseMap.put("documentStatus", savedDoc.getStatus());
		responseMap.put("documentId", savedDoc.getId());
		if (UPLOAD_PROVIDER_DOC360.equalsIgnoreCase(uploadProvider)) {
			responseMap.put("doc360DocumentId", savedDoc.getDoc360DocumentId());
			responseMap.put("doc360DocClass", savedDoc.getDoc360DocClass());
		}
		responseMap.putAll(resultMap);

		LOGGER.info("processFileUpload -- end, file={}, metadata={}, spaceId={}, CID={}", SanitizeUtil.sanitizeAlphaString(fileName), metadata, spaceId, Encode.forJava(optumCidExt));

		return responseMap;
	}

	public ResponseEntity<Doc360UploadResponse> postDocumentToDoc360(String filePath, Integer spaceId, org.bson.Document metadata, String cid) {
		try {
			String documentString = mapper.writeValueAsString(metadata);
			String docClass = resolveDoc360DocClass(spaceId);
			return filestoreService.postDocumentToDoc360WithAttachmentRetry(documentString, filePath, docClass, cid);
		} catch (JsonProcessingException e) {
			LOGGER.error("postDocumentToDoc360 -- unable to convert metadata to JSON, metadata is invalid, CID={}", Encode.forJava(cid), e);
			Doc360UploadResponse body = new Doc360UploadResponse();
			body.setMessageMap(java.util.Collections.singletonMap("message", "Invalid JSON metadata"));
			body.setStatus(HttpStatus.BAD_REQUEST.value());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
		} catch (Exception e) {
			LOGGER.error("Exception during postDocumentToDoc360, CID={}", Encode.forJava(cid), e);
			Doc360UploadResponse body = new Doc360UploadResponse();
			body.setMessageMap(java.util.Collections.singletonMap("message", INTERNAL_SERVER_ERROR));
			body.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
		}
	}


	public ResponseEntity<FDSCloudDocument> postDocumentToFDSCloud(String filePath, Integer spaceId, org.bson.Document metadata, String cid) {
		try {
			String fdsCloudSpaceId = (String) config.getCredentials(spaceId).get("fdsCloudSpaceId");
			String documentString = mapper.writeValueAsString(metadata);

			String searchTermsString = fdsCloudSearchTermsTemplate.getSearchTermsString(metadata, cid);

			return filestoreService.postDocumentToFDSCloudWithAttachmentRetry(documentString, searchTermsString, filePath, fdsCloudSpaceId, cid);
		} catch (HttpServerException e) {
			LOGGER.error("Error executing POST request /documents/{}, status={}, {}, CID={}", Encode.forJava(String.valueOf(spaceId)), e.getStatus(), e.getMessage(), Encode.forJava(cid));
			return new ResponseEntity<>(new FDSCloudDocument(), e.getStatus());
		} catch (HttpServerErrorException e) {
			LOGGER.error("Error executing POST request /documents/{}, status={}, {}, CID={}", Encode.forJava(String.valueOf(spaceId)), e.getStatusCode(), e.getMessage(), Encode.forJava(cid));
			return new ResponseEntity<>(new FDSCloudDocument(), e.getStatusCode());
		} catch (HttpClientErrorException e) {
			LOGGER.error("Error executing POST request /documents/{}, filePath={}; {}: {}, CID={}", Encode.forJava(String.valueOf(spaceId)), Encode.forJava(filePath), e.getClass().getSimpleName(), e.getMessage(), Encode.forJava(cid));
			return new ResponseEntity<>(new FDSCloudDocument(), e.getStatusCode());
		} catch (JsonProcessingException e) {
			LOGGER.error("postDocumentToFDSCloud -- unable to convert metadata to string, metadata={}, CID={}", metadata, Encode.forJava(cid));
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new FDSCloudDocument());
		} catch (Exception e) {
			LOGGER.error("Exception during postDocumentToFDSCloud, CID={}", Encode.forJava(cid), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new FDSCloudDocument());
		}
	}
	
	
	public void updateDocumentWithFDSCloudResponse(DocumentMetaData document, Integer spaceId, ResponseEntity<FDSCloudDocument> response, String cid) {
		String fdsDocumentId = null;
		String fsId = null;
		if (document.getMetadata() != null) {
			document.getMetadata().put(UPLOAD_PROVIDER_METADATA_KEY, UPLOAD_PROVIDER_FDS);
		}
		if (response != null && response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
			LOGGER.info("FDS Cloud Response is 200 or 201, response={}, CID={}", response.getStatusCode(), Encode.forJava(cid));
			
			FDSCloudDocument fdsCloudDocResponse = (FDSCloudDocument) response.getBody();
			
			// set document
			
			if (fdsCloudDocResponse != null) {
				
				fdsDocumentId = (String) fdsCloudDocResponse.getDocumentId();
				
				List<DocumentAttachmentMetaData> attachments = fdsCloudDocResponse.getAttachments();
				fsId = attachments.get(0).getAttachmentId();
				document.setDocumentAttachments(attachments);
				document.setFsId(fsId);
				document.setFdsAttachmentId(fsId);
				document.setFdsDocumentId(fdsDocumentId);
				
				MetaDataStatus docStatus = document.getStatus();
				if (docStatus == null || (docStatus != null && docStatus.equals(MetaDataStatus.SEVERE_ERROR) && docStatus.equals(MetaDataStatus.FATAL_ERROR))) {
					document.setStatus(MetaDataStatus.AVAILABLE);
				}
				
				
			} else {
				LOGGER.error("FDS cloud response did not contain attachment information, response={}, CID={}", Encode.forJava(response.getStatusCode().toString()), Encode.forJava(cid));
				document.setStatus(MetaDataStatus.STORAGE_ERROR);
			}
			
		} else {
			LOGGER.error("Filestore service response is not 200, error CID={}", Encode.forJava(cid));
						
			document.setStatus(MetaDataStatus.STORAGE_ERROR);
			
		}
		
		addDefaultValues(document, spaceId, fdsDocumentId, fsId);
	}

	public void updateDocumentWithDoc360Response(DocumentMetaData document, Integer spaceId, ResponseEntity<Doc360UploadResponse> response, String cid) {
		if (document.getMetadata() != null) {
			document.getMetadata().put(UPLOAD_PROVIDER_METADATA_KEY, UPLOAD_PROVIDER_DOC360);
		}

		if (response != null && response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
			Doc360UploadResponse doc360Response = response.getBody();
			document.setDoc360DocumentId(doc360Response.getGlobalDocId());
			document.setDoc360DocClass(resolveDoc360DocClass(spaceId));

			MetaDataStatus docStatus = document.getStatus();
			if (docStatus == null || (!docStatus.equals(MetaDataStatus.SEVERE_ERROR) && !docStatus.equals(MetaDataStatus.FATAL_ERROR)
					&& !docStatus.equals(MetaDataStatus.STORAGE_ERROR))) {
				document.setStatus(MetaDataStatus.AVAILABLE);
			}
			LOGGER.info("Doc360 upload success, statusCode={}, doc360DocumentId={}, CID={}", response.getStatusCode().value(), Encode.forJava(document.getDoc360DocumentId()), Encode.forJava(cid));
		} else {
			LOGGER.error("Doc360 upload failed, statusCode={}, CID={}", response == null ? "null" : response.getStatusCode().value(), Encode.forJava(cid));
			document.setStatus(MetaDataStatus.STORAGE_ERROR);
		}

		addDefaultValues(document, spaceId, document.getFdsDocumentId(), document.getFsId());
	}

	private String resolveUploadProvider(Integer spaceId) {
		return config.getUploadProvider(spaceId);
	}

	private String resolveDoc360DocClass(Integer spaceId) {
		return config.getDoc360DocClass(spaceId);
	}

	
	public org.bson.Document convertAndValidateMetadata(DocumentMetaData document, org.bson.Document metadata, Integer spaceId, Map<String, Object> resultMap, String cid) {
		
		String clientName = config.getClientNameFromSpaceId(spaceId);
		
		Set<String> errorSet = new HashSet<>();

		String clientJson = gson.toJson(metadata);
		JSONObject clientJsonObj = new JSONObject( clientJson );

		LOGGER.debug("convertMetadata -- client json clientName={}, object={}", clientName, clientJsonObj);
		try {
			JSONTokener tokener = getClientSchema(clientName);
			if (tokener == null) {
				LOGGER.error("jsonSchema does not exist clientName={}, CID={}", clientName, Encode.forJava(cid));
				
				return null;
			}
			JSONObject jsonSchema = new JSONObject(tokener);
			
			SchemaLoader loader = SchemaLoader.builder().schemaJson(jsonSchema).build();
			Schema schema = loader.load().build();
			schema.validate(clientJsonObj);
		} catch (org.everit.json.schema.ValidationException e) {
			@SuppressWarnings("rawtypes")
			Class enumClass = getErrEnumFromClientName(clientName);
			for (String errMsg : e.getAllMessages()) {
				getErrors(errMsg, errorSet, enumClass);
			}
		}
		
		List<Map<String, String>> errorList = new ArrayList<>();
		for (String errorStr : errorSet) {
			Map<String, String> errorMap = new HashMap<>();
			String errorType = errorStr.toLowerCase().contains("severe") ? "Severe" : "Warning";
			errorMap.put("error", "Error");
			errorMap.put("type", errorType);
			errorMap.put("detail", errorStr);
			errorList.add(errorMap);
			
			if (errorType.equals("Severe")) {
				document.setStatus(MetaDataStatus.SEVERE_ERROR);
			}
		}
		
		
		ClientMetadata convertedMetadata = (ClientMetadata) mapper.convertValue(metadata, getClassFromClientName(clientName));
		convertedMetadata.setPostCardInd(postCardInd.getPostCardInd(clientName));
		String convertedMetadataJson = gson.toJson(convertedMetadata);
		org.bson.Document convertedMetadataObj = Document.parse(convertedMetadataJson);
		
		
		if (!errorList.isEmpty()) {
			resultMap.put("validationErrors", errorList);
		}
		
		return convertedMetadataObj;
	}
		
	
	public DocumentMetaData convertAndCreateDocument(String fdsCloudDocumentId, String fdsCloudSpaceId, Map<String, Object> resultMap, String cid) throws URISyntaxException, InterruptedException {

		DocumentMetaData document = new DocumentMetaData();


		try {
			// get search terms and attachment from FDSCloud
			ResponseEntity<FDSCloudDocument> response = serviceUtil.getFDSCloudSearchTerms(fdsCloudDocumentId, fdsCloudSpaceId, Encode.forJava(cid));

			Map<String, Object> metadataMap = extractMetadata(response);
			if (metadataMap == null || metadataMap.isEmpty()) {
				LOGGER.error("convertAndInsertDocument error getting search terms from FDSCloud, searchTerms are null, CID={}", Encode.forJava(cid));
				return null;
			}

			String fileName = "";

			org.bson.Document metadata = new org.bson.Document();
			metadata.putAll(metadataMap);
			document.setMetadata(metadata);
			String fdsAttachmentId = "";
			if (response != null && response.getBody() != null && response.getBody().getAttachments() != null) {
				List<DocumentAttachmentMetaData> attachmentsList = response.getBody().getAttachments();
				fdsAttachmentId = attachmentsList.get(0).getAttachmentId();
				fileName = attachmentsList.get(0).getName();
				document.setDocumentAttachments(attachmentsList);
			}

			metadata.put("fileName", fileName);

			// get client from fds cloud Space Id
			Map<String, Object> fdsCloudSpaceIdMap = config.getClientMapFromFdsCloudSPaceId(fdsCloudSpaceId);
			String clientName = (String) fdsCloudSpaceIdMap.get("clientName");
			Integer spaceId = (Integer) fdsCloudSpaceIdMap.get("spaceId");


			// map document metadata with string template
			org.bson.Document mappedMetadata = convertAndValidateMetadata(document, clientName, resultMap, fdsCloudSpaceId, fdsCloudDocumentId, Encode.forJava(cid));
			document.setMetadata(mappedMetadata);

			addDefaultValues(document, spaceId, fdsCloudDocumentId, fdsAttachmentId);

		} catch (Exception e) {
			LOGGER.error("Exception converting and creating document fdsCloudDocumentId ={}, e={}, CID={}", Encode.forJava(fdsCloudDocumentId), ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		}
		// insert doc to mongo
		return document;
    			
	}
	
	
	
	public void addDefaultValues(DocumentMetaData doc, Integer spaceId, String fdsDocumentId, String fdsAttachmentId) {
		// set created and expiry date
		org.bson.Document metadata = doc.getMetadata();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
		ZonedDateTime currentDate = ZonedDateTime.now(ZoneOffset.UTC);

		if (metadata.get(CREATED_DATE) == null || StringUtils.isEmpty(metadata.get(CREATED_DATE).toString())) {
			metadata.put(CREATED_DATE, currentDate.format(formatter));
		}
		
		if (metadata.get(EXPIRY_DATE) == null || StringUtils.isEmpty(metadata.get(EXPIRY_DATE).toString())) {
			ZonedDateTime expiryDate = currentDate.plusDays(fDSRetentionPeriod);
			metadata.put(EXPIRY_DATE, expiryDate.format(formatter));
		}
		
		doc.setTransactionId(UUID.randomUUID().toString());
		if (doc.getStatus() == null || (!doc.getStatus().equals(MetaDataStatus.FATAL_ERROR) && !doc.getStatus().equals(MetaDataStatus.STORAGE_ERROR) && !doc.getStatus().equals(MetaDataStatus.SEVERE_ERROR) )) {
			doc.setStatus(MetaDataStatus.AVAILABLE);
		}		
		var clientId = config.getCredentials(spaceId).get("clientId").toString();
		var appIdentifier = config.getCredentials(spaceId).get("appIdentifier").toString();
		doc.setSpaceId(spaceId);
		doc.setClientId(Integer.parseInt(clientId));
		doc.setAppIdentifier(appIdentifier);
		doc.setFdsDocumentId(fdsDocumentId);
		doc.setFsId(fdsAttachmentId);
		doc.setFdsAttachmentId(fdsAttachmentId);
		
	}

	public org.bson.Document convertAndValidateMetadata(DocumentMetaData document, String clientName, Map<String, Object> resultMap, String fdsCloudSpaceId, String fdsCloudDocumentId, String cid) {
		org.bson.Document map = document.getMetadata();
		Set<String> errorSet = new HashSet<>();

		String clientJson = gson.toJson(map);
		JSONObject clientJsonObj = new JSONObject( clientJson );

		LOGGER.debug("convertMetadata -- client json clientName={}, object={}", clientName, clientJsonObj);
		try {
			JSONTokener tokener = getClientSchema(clientName);
			if (tokener == null) {
				LOGGER.error("jsonSchema does not exist clientName={}, CID={}", clientName, Encode.forJava(cid));
				
				return null;
			}
			JSONObject jsonSchema = new JSONObject(tokener);
			
			SchemaLoader loader = SchemaLoader.builder().schemaJson(jsonSchema).build();
			Schema schema = loader.load().build();
			schema.validate(clientJsonObj);
		} catch (org.everit.json.schema.ValidationException e) {
			@SuppressWarnings("rawtypes")
			Class enumClass = getErrEnumFromClientName(clientName);
			for (String errMsg : e.getAllMessages()) {
				getErrors(errMsg, errorSet, enumClass);
			}
		}
		
		List<Map<String, String>> errorList = new ArrayList<>();
		for (String errorStr : errorSet) {
			Map<String, String> errorMap = new HashMap<>();
			String errorType = errorStr.toLowerCase().contains("severe") ? "Severe" : "Warning";
			errorMap.put("error", "Error");
			errorMap.put("type", errorType);
			errorMap.put("detail", errorStr);
			errorList.add(errorMap);
			
			if (errorType.equals("Severe")) {
				document.setStatus(MetaDataStatus.SEVERE_ERROR);
			}
		}
		
		
		ClientMetadata convertedMetadata = (ClientMetadata) mapper.convertValue(map, getClassFromClientName(clientName));
		convertedMetadata.setPostCardInd(postCardInd.getPostCardInd(clientName));
		String convertedMetadataJson = gson.toJson(convertedMetadata);
		org.bson.Document convertedMetadataObj = Document.parse(convertedMetadataJson);
		
		
		if (!errorList.isEmpty()) {
			resultMap.put("statusMessages", errorList);
			convertedMetadataObj.put("errorList", errorList);
			LOGGER.info("convertMetadata -- resultMap={}, CID={}", resultMap, Encode.forJava(cid));
			serviceUtil.sendMetadataValidationNotificationELGS(errorList, document, convertedMetadataObj, fdsCloudSpaceId, fdsCloudDocumentId, Encode.forJava(cid));
		}
		
		return convertedMetadataObj;
	}
	


	@SuppressWarnings("rawtypes")
	public void getErrors(String errMsg, Set<String> errors, Class enumClass) {
    	
    	ErrorMessage err = null;
    	String key = "";
    	// #: required key [SubCategory] not found
    	// #/DATEOFSERVICE: subject must not be valid against schema "enum":["00000000"]
    	// #/CreatingApp: expected minLength: 1, actual: 0
    	// #/isPrintSuppressed: blah is not a valid enum value
    	
    	if (errMsg.contains("[") && errMsg.contains("required key")) {
    		key = errMsg.substring(errMsg.indexOf("[")+1, errMsg.indexOf("]"));		
    	} else if (errMsg.contains("minLength") || errMsg.contains("enum")) {
    		key = errMsg.substring(errMsg.indexOf("#/")+2, errMsg.indexOf(":"));
    	}
    	
    	try {
        	err = (ErrorMessage) Enum.valueOf(enumClass, key.replaceAll("\\s",""));
    		LOGGER.debug("getErrors -- errorCode={}, errorMessage={}", err.getErrorCode(), err.getErrorMessage());
    		errors.add(err.getErrorMessage());
    	} catch (Exception e) {
    		LOGGER.info("No enum value for key={}", key);
    	}
     }
    
    @SuppressWarnings("rawtypes")
	public Class getClassFromClientName(String clientName) {
    	String className = "real.time.service.pojo." + clientName;
    	try {
        	return Class.forName(className);
    	} catch (ClassNotFoundException e) {
    		LOGGER.error("getClassFromClientName -- class not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
    		return null;
    	}    	
    }
    
    @SuppressWarnings("rawtypes")
	public Class getErrEnumFromClientName(String clientName) {
    	String enumName = "real.time.service.pojo." + clientName + "$ErrorMsg";
    	try {
    		return Class.forName(enumName);
		} catch (ClassNotFoundException e) {
    		LOGGER.error("getClassFromClientName -- ErrorMsg enum not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
    		return null;
		}
    }
    
    public JSONTokener getClientSchema(String clientName) {
    	return new JSONTokener(ProcessDocumentUtil.class.getResourceAsStream(schemaFileBasePath + clientName + "_client_schema.json"));
    }

	

	
	
	
	@SuppressWarnings("unchecked")
	private Map<String, Object> extractMetadata(ResponseEntity<FDSCloudDocument> response) {
		try {
			if (response != null && response.getBody() != null) {
				FDSCloudDocument responseDoc = response.getBody();
				String metadataStr = responseDoc.getMetadata();
				return mapper.readValue(metadataStr, HashMap.class);
			} else {
				LOGGER.error("extractMetadata FDSCloudResponse is null");
				return Collections.emptyMap();
			}
		} catch (Exception e) {
			LOGGER.error("extractMetadata error getting search terms from FDSCloud response with err={}", ExceptionUtils.getStackTrace(e));
			return Collections.emptyMap();
		}
		
	}

}
