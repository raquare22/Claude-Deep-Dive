package real.time.service.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

/**
 * Use existing instances to create ObjectReader or ObjectWriter for purposes, otherwise create a static instance.
 */
public final class Parser {
	private static final Logger LOGGER = LoggerFactory.getLogger(Parser.class);
    public static final int PRETTY_PRINT_INDENT_FACTOR = 1;
    public static final int PRINT_DEFAULT_IDENTATION = 0;
    public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    public static final ObjectMapper XML_MAPPER;
    public static final ObjectMapper DATE_FORMAT_MAPPER = OBJECT_MAPPER.copy();
    public static final ObjectMapper MIX_IN_MAPPER = OBJECT_MAPPER.copy();
    static {
        JacksonXmlModule module = new JacksonXmlModule();
        module.setDefaultUseWrapper(false);
        XML_MAPPER = new XmlMapper(module);
    }

    private Parser(){}

    public static <T> T parseXMLFile(File xmlFile, Class<T> clazz) throws IOException {
        String xml;
        try (InputStream xmlFileInputStream =  new BufferedInputStream(Files.newInputStream(xmlFile.toPath()))) {
            xml = inputStreamToString(xmlFileInputStream);
        }
        return parseXML(xml, clazz);
    }

    public static <T> T parseXMLFile(Path xmlFile, Class<T> clazz) throws IOException {
        return parseXMLFile(xmlFile.toFile(), clazz);
    }

    public static <T> T parseXMLFile(String xmlFile, Class<T> clazz) throws IOException {
        return parseXMLFile(Paths.get(xmlFile), clazz);
    }

    /*
     * Replace ampersand not followed by # (used in ascii code number)
     * Ascii code 38 is for ampersand
     * Also does not overwrite xml/html codes: ( &amp; &lt; &gt; &quot; &apos;)
     * Leaves alone anything starting with & and ending with ; with 2 to 4 chars in between
     * So this will not edit phrases (longer than 4 chars) ending with and ampersand
     */
    public static <T> T parseXML(String xmlContent, Class<T> clazz) throws IOException {
        xmlContent = xmlContent.replaceAll("&(?![^&]{2,4};)", "&#038;");
        try {
            return XML_MAPPER.readerFor(clazz).readValue(xmlContent);
        } catch (Exception e) {
            throw new IOException("xmlContent=" + xmlContent + "; " + e.getMessage());
        }
    }

    public static <T> T parseJson(String jSONString, Class<T> clazz) throws IOException {
        return OBJECT_MAPPER.readerFor(clazz).with(JsonParser.Feature.ALLOW_SINGLE_QUOTES)
                .with(JsonReadFeature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER).readValue(jSONString);
    }

    public static <T> T parseJson(String jSONString, TypeReference<T> ref) throws IOException {
        return OBJECT_MAPPER.readerFor(ref).with(JsonParser.Feature.ALLOW_SINGLE_QUOTES)
                .with(JsonReadFeature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER).readValue(jSONString);
    }

    public static <T, V> T convertValue(V obj, Class<T> clazz) {
        return OBJECT_MAPPER.convertValue(obj, clazz);
    }

    public static <T> T readValue(String jsonString, Class<T> clazz) throws IOException {
        return OBJECT_MAPPER.readerFor(clazz).readValue(jsonString);
    }

    public static <T> T readValue(String jsonString, TypeReference<T> typeReference) throws JsonProcessingException {
        return OBJECT_MAPPER.readValue(jsonString, typeReference);
    }

    public static <T> T parseJsonWithDateFormat(String jSONString, Class<T> clazz, SimpleDateFormat spf ) throws IOException {
        return DATE_FORMAT_MAPPER.setDateFormat(spf)
                .readerFor(clazz)
                .with(JsonParser.Feature.ALLOW_SINGLE_QUOTES)
                .readValue(jSONString);
    }

    public static <T> T parseJson(String jSONString, Class<T> clazz, boolean allowSingleQuotes) throws IOException {
        ObjectReader reader = OBJECT_MAPPER.readerFor(clazz);
        if (allowSingleQuotes) {
            reader.with(JsonParser.Feature.ALLOW_SINGLE_QUOTES);
        } else {
            reader.without(JsonParser.Feature.ALLOW_SINGLE_QUOTES);
        }
        return reader.readValue(jSONString);
    }

    public static String toJson(Object objectToConvert) throws IOException {
        return OBJECT_MAPPER.writer().writeValueAsString(objectToConvert);
    }

    public static String toJson(Object objectToConvert, String format, TimeZone tz) throws IOException {
        DateFormat df = new SimpleDateFormat(format);
        df.setTimeZone(tz);
        return OBJECT_MAPPER.writer(df).writeValueAsString(objectToConvert);
    }

    public static String toJson(Object objectToConvert, String format) throws IOException {
        DateFormat df = new SimpleDateFormat(format);
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        return OBJECT_MAPPER.writer(df).writeValueAsString(objectToConvert);
    }
    // method to write date as date and not timestamp based on boolean value
    public static String toJson(Object objectToConvert, boolean value, String format) throws IOException{
        DateFormat df = new SimpleDateFormat(format);
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        ObjectWriter writer = OBJECT_MAPPER.writer(df);
        if (!value) {
            writer.without(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        }
        return writer.writeValueAsString(objectToConvert);
    }

    @SuppressWarnings("rawtypes")
    public static String toJsonWithFilters(Object objectToConvert, Class filterMixinClass, String[] fieldsToFilter) throws JsonProcessingException {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        FilterProvider filters = new SimpleFilterProvider()
                .addFilter(
                        "filter properties by name",
                        SimpleBeanPropertyFilter.serializeAllExcept(fieldsToFilter)
                );
        return MIX_IN_MAPPER.addMixIn(Object.class, filterMixinClass).writer(filters).with(df).writeValueAsString(objectToConvert);
    }


    public static String xmltoJson(boolean prettyPrint, String xml) {
        var xmlJSONObj = XML.toJSONObject(xml);
        return xmlJSONObj.toString((prettyPrint)?PRETTY_PRINT_INDENT_FACTOR: PRINT_DEFAULT_IDENTATION);
    }

    public static String toXML(Object objectToConvert) throws JsonProcessingException {
        return XML_MAPPER.writeValueAsString(objectToConvert);
    }

    public static String inputStreamToString(InputStream is) throws IOException {
        try (InputStreamReader isr = detectAndExcludeBOM(is)) {
            var sb = new StringBuilder();
            String line;
            var br = new BufferedReader(isr);
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            return sb.toString();
        }
    }
    
    public static String inputStreamToStringNoBomExclusion(InputStream is) throws IOException {
        try (InputStreamReader isr = new InputStreamReader(is)) {
            var sb = new StringBuilder();
            String line;
            var br = new BufferedReader(isr);
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            return sb.toString();
        }
    }

    protected static InputStreamReader detectAndExcludeBOM(InputStream is) throws IOException{
        BOMInputStream bomIn = new BOMInputStream(is, ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
        if (! bomIn.hasBOM()) {
            return new InputStreamReader(bomIn);
        }
        if (bomIn.hasBOM(ByteOrderMark.UTF_8)) {
            return new InputStreamReader(bomIn);
        }
        if (bomIn.hasBOM(ByteOrderMark.UTF_16BE)) {
            LOGGER.debug("BOM: UTF-16BE");
            return new InputStreamReader(bomIn, StandardCharsets.UTF_16BE);
        }
        if (bomIn.hasBOM(ByteOrderMark.UTF_16LE)) {
            LOGGER.debug("BOM: UTF-16LE");
            return new InputStreamReader(bomIn, StandardCharsets.UTF_16LE);
        }
        LOGGER.error("BOM: NOT UTF-8 or UTF-16");
        throw new IOException("BOM: Exists and not UTF-8 or UTF-16");
    }
}