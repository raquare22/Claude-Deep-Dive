package real.time.service.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import real.time.service.config.ConfigData;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.mongo.processors.MetaDataStatus;
import real.time.service.revision.DocumentRevision;

public class DocumentUtil {

    @Autowired
    private ConfigData config;

    public static void updateDateModified(DocumentMetaData doc) {
        doc.setDateModified(new Date());
    }

    public static void updateDocumentMetaDataRevisions(DocumentMetaData doc) {
        DocumentRevision revision = createRevision(doc, String.valueOf(doc.getSpaceId()));
        List<DocumentRevision> revisionList = doc.getRevisions();
        if (revisionList != null) {
            revisionList.add(revision);
        } else {
            revisionList = new ArrayList<>();
            revisionList.add(revision);
            doc.setRevisions(revisionList);
        }
    }

    public static DocumentRevision createRevision(DocumentMetaData doc, String spaceId) {

        // routine to take DocumentMetaData and create a document revision Entry
        // for it
        DocumentRevision revisionEntry = new DocumentRevision();
        if (doc.getExternalId() != null) {
            revisionEntry.setExternalId(doc.getExternalId());
        }
        revisionEntry.setAppIdentifier(doc.getAppIdentifier());
        revisionEntry.setClientId(doc.getClientId());
        revisionEntry.setDateCreated(doc.getDateCreated());
        revisionEntry.setDateModified(doc.getDateModified());
        revisionEntry.setStatus(doc.getStatus());
        revisionEntry.setSpaceId(spaceId);
        revisionEntry.setTransactionId(doc.getTransactionId());

        if (doc.getMetadata() != null) {
            Document metadata = new org.bson.Document();
            doc.getMetadata().forEach((key, value) -> {
                metadata.append(key, value);
            });
            revisionEntry.setMetadata(metadata);
        }
        if (doc.getDocumentAttachments() != null && !doc.getDocumentAttachments().isEmpty()) {
            revisionEntry.setDocumentAttachments(doc.getDocumentAttachments());
        }
        if (doc.getErrorMessage() != null && !doc.getErrorMessage().isEmpty()) {
            revisionEntry.setErrorMessage(doc.getErrorMessage());
        }
        return revisionEntry;

    }


}
