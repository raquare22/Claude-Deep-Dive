package real.time.service.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.UUID;

import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service("FilestoreUtil")
public class FilestoreUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(FilestoreUtil.class);

	@Value("${INGEST_ROOT}")
	private String ingestRoot;

	private static final String DATE_FORMAT = "yyyyMMddHHmmssSSS";

	public static final String DEFAULT_FILE_SEPARATOR = "/";

	protected String saveFileToIngest(String fileName, MultipartFile file, Integer spaceId, String cid) {
		Path tempWorkingPath = null;
		try {
			
			if (fileName == null || fileName.isEmpty() || fileName.contains("..") || fileName.contains("/") || fileName.contains("\\")) {
				LOGGER.error("saveFileToIngest -- Invalid file name after sanitization: '{}', CID={}", Encode.forJava(fileName), Encode.forJava(cid));
				return null;
			}

			tempWorkingPath = createWorkingDirectoryWithParams(DEFAULT_FILE_SEPARATOR, ingestRoot, "filestore", spaceId.toString(), getCurrentDateFormattedWithUUIdFormat(), Encode.forJava(cid));

			String tempWorkingPathStr = tempWorkingPath.toAbsolutePath().toString();

			LOGGER.info("saveFileToIngest -- tempWorkingPathStr={}, CID={}", tempWorkingPathStr, Encode.forJava(cid));

			String fullFilePath = tempWorkingPathStr + DEFAULT_FILE_SEPARATOR + fileName;

			File copyFile = new File(fullFilePath);

			if (copyFile.exists()) {
				LOGGER.error("saveFileToIngest -- file already exists, unable to save to ingest path={}, fileName={}, CID={}", Encode.forJava(tempWorkingPathStr), Encode.forJava(fileName), Encode.forJava(cid));
				return null;
			}

			Files.copy(file.getInputStream(), copyFile.toPath());
			
			// Set file permissions
	        Set<PosixFilePermission> permissions = PosixFilePermissions.fromString("r--r--r--");
	        Files.setPosixFilePermissions(copyFile.toPath(), permissions);

			return fullFilePath;
		} catch (Exception e) {
			LOGGER.error("saveFileToIngest -- Unable to save file to ingest, fileName={}, spaceId={}, ingestLocation={}, CID={}", Encode.forJava(fileName), SanitizeUtil.sanitizeIntegerString(spaceId.toString()), Encode.forJava(tempWorkingPath.toString()), Encode.forJava(cid));
			return null;
		}
	}

	public Path createWorkingDirectoryWithParams(String delimiter, String cid, String... elements) throws IOException {
		return createWorkingDirectory(String.join(delimiter, elements), Encode.forJava(cid));
	}

	private Path createWorkingDirectory(String tempDirRoot, String cid) throws IOException {
		LOGGER.debug("createWorkingDirectory -- Creating working directory for {}, CID={}", tempDirRoot, Encode.forJava(cid));
		return Files.createDirectories(Paths.get(tempDirRoot));
	}

	private String getCurrentDateFormattedWithUUIdFormat() {
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
		return now.format(formatter) + UUID.randomUUID();
	}
}