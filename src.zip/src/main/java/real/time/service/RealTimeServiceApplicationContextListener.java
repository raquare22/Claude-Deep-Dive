package real.time.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;



public class RealTimeServiceApplicationContextListener implements ApplicationListener<ContextClosedEvent>{

    private static final Logger LOGGER = LoggerFactory.getLogger(RealTimeServiceApplicationContextListener.class);

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        LOGGER.warn("SHUTDOWN: event.getSource={}; Calling RealTimeServiceApplication.shutdown", event.getSource());
        RealTimeServiceApplication.shutdown();
        LOGGER.warn("SHUTDOWN: complete");
    }

}
