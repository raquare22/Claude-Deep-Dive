package real.time.service.revision;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import real.time.service.mongo.DocumentAttachmentMetaData;

/**
 * 
 * @author tviolett.
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentRevision extends Revision implements Serializable{
    private static final long serialVersionUID = 1L;

    private Date dateAttachmentUpdated;
    @JsonProperty("attachments")
    private List<DocumentAttachmentMetaData> documentAttachments;
    private String errorMessage;
    private String externalId;
    private transient Document metadata;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public Date getDateAttachmentUpdated() {
        return dateAttachmentUpdated==null?null:(Date)dateAttachmentUpdated.clone();
    }

    public void setDateAttachmentUpdated(Date dateAttachmentUpdated) {
         this.dateAttachmentUpdated = dateAttachmentUpdated==null?null:(Date)dateAttachmentUpdated.clone();
    }

    public Document getMetadata() {
        return metadata;
    }

    public void setMetadata(Document metadata) {
        this.metadata = metadata;
    }

    @JsonProperty("attachments")
    public List<DocumentAttachmentMetaData> getDocumentAttachments() {
        return documentAttachments==null?null:new ArrayList<>(documentAttachments);
    }

    @JsonProperty("attachments")
    public void setDocumentAttachments(List<DocumentAttachmentMetaData> documentAttachments) {
        this.documentAttachments = documentAttachments==null?null:new ArrayList<>(documentAttachments);
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
