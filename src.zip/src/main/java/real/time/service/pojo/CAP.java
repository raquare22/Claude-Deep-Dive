package real.time.service.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import real.time.service.pojo.ClientMetadata;

public class CAP extends ClientMetadata {
    private static final long serialVersionUID = 1L;

    @JsonProperty("tin")
    private String tin;

    @JsonProperty("mpin")
    private String mpin="";

    @JsonProperty("emailAlertReq")
    private String emailAlertReq="Y";

    @JsonProperty("providerName")
    @JsonAlias({"ProviderName", "providerName"})
    private String physicianName;

    @JsonProperty("memberId")
    private String multMemberId;

    @JsonProperty("CLAIMNUMBER")
    @JsonAlias("multClaimNumber")
    private String multClaimNumber;

    @JsonProperty("CONFIGKEY")
    private String CONFIGKEY="9999";

    @JsonProperty("originalPrintTrail")
    private String originalPrintTrail="9999";

    @JsonProperty("PassThruData")
    private String PassThruData="9999";

    @JsonProperty("providerName")
    @JsonAlias("MailToAddress1")
    private String MailToAddress1;

    @JsonProperty("addressLine1")
    @JsonAlias("MailToAddress2")
    private String MailToAddress2;

    @JsonProperty("addressLine2")
    @JsonAlias("MailToAddress3")
    private String MailToAddress3;

    @JsonProperty("city")
    @JsonAlias("MailToAddress4")
    private String MailToAddress4;

    @JsonProperty("state")
    @JsonAlias("MailToAddress5")
    private String MailToAddress5;

    @JsonProperty("zip")
    @JsonAlias("MailToAddress6")
    private String MailToAddress6;

    @JsonProperty("subCategory")
    protected String subCategory;

    @JsonProperty("letterId")
    private String letterId;

    public CAP() {
        this.category = "Claim";
        this.originalPrintTrail = "9999";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Claim status update";
        this.createApplication = "CAP";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "XX";
        CAP.Subcategory subCat = CAP.Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null){
            this.mpin = mpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }


    public String getMultMemberId() {
        return multMemberId;
    }

    public void setMultMemberId(String multMemberId) {
        this.multMemberId = multMemberId;
    }

    public String getMultClaimNumber() {
        return multClaimNumber;
    }

    public void setMultClaimNumber(String multClaimNumber) {
        this.multClaimNumber = multClaimNumber;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String providerName) {
        this.physicianName = providerName;
        this.MailToAddress1 = providerName;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String cONFIGKEY) {
    	if(cONFIGKEY != null && !cONFIGKEY.isEmpty())
    	CONFIGKEY = cONFIGKEY;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
    	if(originalPrintTrail != null && !originalPrintTrail.isEmpty())
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
    	if(passThruData != null && !passThruData.isEmpty())
            PassThruData = passThruData;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String providerName) {
        this.MailToAddress1 = providerName;
        this.physicianName = providerName;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String addressLine1) {
        this.MailToAddress2 = addressLine1;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String addressLine2) { this.MailToAddress3 = addressLine2;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String city) {
        this.MailToAddress4 = city;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String state) {
        this.MailToAddress5 = state;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String zip) {
        this.MailToAddress6 = zip;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "XX";
            this.setFilePath(CAP.Subcategory.XX.getFilePath());
        } else {
            this.subCategory = subCategory;
            CAP.Subcategory subCat = null;
            try {
                subCat = CAP.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = CAP.Subcategory.XX;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getLetterId() { return letterId; }

    public void setLetterId( String letterId ) { this.letterId = letterId; }

    public enum ErrorMsg implements ErrorMessage {
        tin (12, "Missing or invalid data: tin"),
        mpin (12, "Missing or invalid data: mpin"),
        subCategory (12, "Missing or invalid data: subCategory"),
        emailAlertReq (12,"Missing or invalid data: emailAlertReq"),//verify
        createdDate (12, "Missing or invalid data: createdDate"),
        multClaimNumber(12, "Missing or invalid data: Claim Number"),

        providerName (22, "Missing or invalid data: providerName(SEVERE)"),
        addressLine1 (22, "Missing or invalid data: addressLine1(SEVERE)"),
        city (22, "Missing or invalid data: city(SEVERE)"),
        state (22, "Missing or invalid data: state(SEVERE)"),
        zip (22, "Missing or invalid data: zip(SEVERE)");


        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {
        C9 ("C9", "Commercial/Review Decision"),
        O6 ("O6", "Medicare/Review Decision"),
        O7("O7", "Community Plan/Review Decision"),

        C1 ("C1", "Commercial/Action Required"),
        C3 ("C3", "Commercial/Denials"),
        R1 ("R1", "Medicare/Action Required"),
        R7 ("R7", "Medicare/Denials"),
        S1 ("S1", "Community Plan/Action Required"),
        S2 ("S2", "Community Plan/Denials"),
        S8 ("S8", "Commercial/Individual & Family Plan"),
        XX ("XX", "Other Top-level folder/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }

}