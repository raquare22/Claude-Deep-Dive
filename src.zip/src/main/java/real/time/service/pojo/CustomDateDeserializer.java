package real.time.service.pojo;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.temporal.ChronoField;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Date;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tika.utils.ExceptionUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;


/**
 * The CustomDateDeserializer class is used to convert the client metadata createdDate
 * from this format: MM/dd/yyyy hh:mm:ss
 * to this format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'
 * @author jwang39
 *
 */
public class CustomDateDeserializer extends StdDeserializer<Date> {
	
	private static final long serialVersionUID = -1026166191652831116L;
	
	private static final Logger LOGGER = LogManager.getLogger(CustomDateDeserializer.class);

	// 12/31/2021 5:45:22 PM
	
	private DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder()
            .appendPattern("[MM/dd/yyyy H:mm:ss]")
            .appendPattern("[MMddyyyy]")
            .appendPattern("[MM/dd/yyyy]")
            .appendPattern("[MM/dd/yy]")
            .appendPattern("[M/dd/yyyy]")
            .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
            .parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
            .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
            .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
            .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00)
            .parseDefaulting(ChronoField.MILLI_OF_SECOND, 000)
            .toFormatter()
            .withLocale(Locale.US)
            .withZone(ZoneId.of("UTC"));

	private DateTimeFormatter dateTimeFormatter1 = new DateTimeFormatterBuilder()
            .appendPattern("[MM/dd/yyy hh:mm:ss a]")
            .appendPattern("[MM/dd/yyyy h:mm:ss a]")
            .appendPattern("[MM/d/yyyy h:mm:ss a]")
            .appendPattern("[M/dd/yyyy h:mm:ss a]")
            .appendPattern("[M/d/yyyy h:mm:ss a]")
            .appendPattern("[d/MM/yyyy h:mm:ss a]")
            .appendPattern("[dd/M/yyyy h:mm:ss a]")
            .appendPattern("[dd/MM/yyyy h:mm:ss a]")
            .appendPattern("[d/M/yyyy h:mm:ss a]")
            .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
            .parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
            .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
            .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00)
            .parseDefaulting(ChronoField.MILLI_OF_SECOND, 000)
            .toFormatter()
            .withLocale(Locale.US)
            .withZone(ZoneId.of("UTC"));

//	private DateTimeFormatter dateTimeFormatter2 = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a", Locale.US);


	private DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("[yyyy-MM-dd'T'HH:mm:ss.SSS'Z']");

	private SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	
	public CustomDateDeserializer() {
        this(null);
    }

    public CustomDateDeserializer(Class<?> vc) {
        super(vc);
    }
	
	@Override
    public Date deserialize(JsonParser jsonparser, DeserializationContext context) throws IOException, JsonProcessingException {
		
		String date = jsonparser.getText();
		
        try {
    		if (date == null || date.isEmpty()) {
    			return null;
    		}
            ZonedDateTime zdt = ZonedDateTime.parse(date, dateTimeFormatter);
            String convertedDate = zdt.format(outputFormat);
            return formatter.parse(convertedDate);

        } catch (Exception e1) {
        	LOGGER.warn("Failed first try dateTimeFormatter e={}", e1.getMessage());
            try {
                ZonedDateTime zdt = ZonedDateTime.parse(date, dateTimeFormatter1);
                String convertedDate = zdt.format(outputFormat);
                return formatter.parse(convertedDate);
            } catch (Exception e2) {
            	LOGGER.warn("Failed second try dateTimeFormatter1 e={}", e2.getMessage());
                return null;
            }
        }
    }

}
