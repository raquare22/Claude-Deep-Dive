package real.time.service.pojo;

public interface ErrorMessage {
	int getErrorCode();
	String getErrorMessage();
}
