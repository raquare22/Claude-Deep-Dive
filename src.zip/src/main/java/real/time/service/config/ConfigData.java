package real.time.service.config;


import java.util.Collections;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;
import real.time.service.ness.RealTimeNessConfig;

@Configuration
@Component
public class ConfigData {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigData.class);
	private static final String DEFAULT_UPLOAD_PROVIDER = "FDS_CLOUD";
	private Map<String, Object> allClientCredentials = new java.util.HashMap<>();
	
	@Value("${fdsCloudSpaceIdMap}")
	private String fdsCloudSpaceIdMap;
	
	@Value("${OCM.credentials}")
	private String OCM_configcredentials;

	@Value("${CAP.credentials}")
	private String CAP_configcredentials;

	@Value("${OTHER.credentials}")
	private String OTHER_configcredentials;


	@Autowired
	private ObjectMapper mapper;


	@SuppressWarnings({ "unchecked" })
	public Map<String, Object> getCredentials(Integer spaceId) {
		if(allClientCredentials.isEmpty()) setCredentials();
		return (Map<String, Object>) Collections.unmodifiableMap(allClientCredentials).get(spaceId.toString());
	}

	private void setCredentials() {
		mapper = new ObjectMapper();
		final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
		try {

			allClientCredentials.putAll(mapper.readValue(OCM_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CAP_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(OTHER_configcredentials, type));

		} catch (JsonProcessingException ex) {
			LOGGER.error("Error in ConfigData-->setCredentials, {}",ex.getMessage());
		}
	}
	
	public String getClientNameFromSpaceId(Integer spaceId) {
		Map<String, Object> credentialsMap = getCredentials(spaceId);
		
		return (String) credentialsMap.get("clientName");
	}

	public String getUploadProvider(Integer spaceId) {
		Map<String, Object> credentialsMap = getCredentials(spaceId);
		if (credentialsMap == null || credentialsMap.isEmpty()) {
			return DEFAULT_UPLOAD_PROVIDER;
		}

		Object provider = credentialsMap.get("uploadProvider");
		if (provider == null || provider.toString().trim().isEmpty()) {
			return DEFAULT_UPLOAD_PROVIDER;
		}

		return provider.toString().trim().toUpperCase();
	}

	public String getDoc360DocClass(Integer spaceId) {
		Map<String, Object> credentialsMap = getCredentials(spaceId);
		if (credentialsMap == null || credentialsMap.isEmpty()) {
			return "";
		}

		Object docClass = credentialsMap.get("doc360DocClass");
		return docClass == null ? "" : docClass.toString();
	}
	
	
	
	@SuppressWarnings({"unchecked"})
	public Map<String, Object> getClientMapFromFdsCloudSPaceId(String fdsCloudSpaceId) {
		mapper = new ObjectMapper();
		final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
		Map<String, Object> data = null;
		try {
			data = mapper.readValue(fdsCloudSpaceIdMap, type);
			return (Map<String, Object>) data.get(fdsCloudSpaceId);
		} catch (Exception ex) {
			LOGGER.error("Error in ConfigData-->getClientFromFdsCloudSpaceId, fdsCloudSpaceId, e={}", ex.getMessage());
			return null;
		}
	}
	
	@Bean
    public HttpHeaders httpHeaders() {
        return new HttpHeaders();
    }

	@Bean
	public RealTimeNessConfig getRealTimeNessConfig() {
		return new RealTimeNessConfig();
	}
}
