package real.time.service.util;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

public class HttpUtilsTest {

    @Mock
    private RestTemplate restTemplate;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testPostExchange() {
        HttpHeaders headers = new HttpHeaders();
        MultiValueMap<String, String> reqPayload = new LinkedMultiValueMap<>();
        String url = "http://example.com";
        Class<String> responseType = String.class;

        ResponseEntity<String> responseEntity = new ResponseEntity<>("response", HttpStatus.OK);
        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(responseType)))
                .thenReturn(responseEntity);

        ResponseEntity<String> response = HttpUtils.postExchange(headers, reqPayload, url, responseType, restTemplate);

        assertNotNull(response);
        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void testValidateStatusCode() {
        assertTrue(HttpUtils.validateStatusCode(HttpStatus.INTERNAL_SERVER_ERROR));
        assertTrue(HttpUtils.validateStatusCode(HttpStatus.BAD_GATEWAY));
        assertTrue(HttpUtils.validateStatusCode(HttpStatus.SERVICE_UNAVAILABLE));
        assertTrue(HttpUtils.validateStatusCode(HttpStatus.GATEWAY_TIMEOUT));
    }
}