package real.time.service.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Date;
import java.util.Map;

import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import real.time.service.config.ConfigData;
import real.time.service.mongo.DocumentMetaData;


public class DocumentUtilTest {

    @InjectMocks
    private DocumentUtil documentUtil;

    @Mock
    private ConfigData config;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testUpdateDateModified() {
        DocumentMetaData doc = new DocumentMetaData();
        DocumentUtil.updateDateModified(doc);
        assertNotNull(doc.getDateModified());
    }

    @Test
    public void testUpdateDocumentMetaDataRevisions() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(123);
        DocumentUtil.updateDocumentMetaDataRevisions(doc);
        assertNotNull(doc.getRevisions());
        assertEquals(1, doc.getRevisions().size());
    }


}
