package real.time.service.util;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static org.junit.Assert.*;

public class ParserTest {

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testParseJson() throws IOException {
        String jsonString = "{\"name\":\"test\"}";
        TestClass result = Parser.parseJson(jsonString, TestClass.class);
        assertNotNull(result);
        assertEquals("test", result.getName());
    }

    @Test
    public void testConvertValue() {
        TestClass testClass = new TestClass();
        testClass.setName("test");
        TestClass result = Parser.convertValue(testClass, TestClass.class);
        assertNotNull(result);
        assertEquals("test", result.getName());
    }

    @Test
    public void testToJson() throws IOException {
        TestClass testClass = new TestClass();
        testClass.setName("test");
        String jsonString = Parser.toJson(testClass);
        assertNotNull(jsonString);
        assertTrue(jsonString.contains("test"));
    }

    @Test
    public void testToJsonWithDateFormat() throws IOException {
        TestClass testClass = new TestClass();
        testClass.setName("test");
        String jsonString = Parser.toJson(testClass, "yyyy-MM-dd", TimeZone.getTimeZone("GMT"));
        assertNotNull(jsonString);
        assertTrue(jsonString.contains("test"));
    }

    @Test
    public void testXmlToJson() {
        String xml = "<root><name>test</name></root>";
        String jsonString = Parser.xmltoJson(true, xml);
        assertNotNull(jsonString);
        JSONObject jsonObject = new JSONObject(jsonString);
        assertEquals("test", jsonObject.getJSONObject("root").getString("name"));
    }

    @Test
    public void testInputStreamToString() throws IOException {
        InputStream is = new ByteArrayInputStream("test".getBytes(StandardCharsets.UTF_8));
        String result = Parser.inputStreamToString(is);
        assertNotNull(result);
        assertEquals("test", result);
    }

    @Test
    public void testDetectAndExcludeBOM() throws IOException {
        InputStream is = new ByteArrayInputStream("test".getBytes(StandardCharsets.UTF_8));
        InputStreamReader isr = Parser.detectAndExcludeBOM(is);
        assertNotNull(isr);
    }

    @Test
    public void testParseJsonWithDateFormat() throws IOException {
        String jsonString = "{\"date\":\"2023-10-10\"}";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        TestClassWithDate result = Parser.parseJsonWithDateFormat(jsonString, TestClassWithDate.class, sdf);
        assertNotNull(result);
        assertEquals("2023-10-10", sdf.format(result.getDate()));
    }


    @Test
    public void testToJsonWithFormat() throws IOException {
        TestClass testClass = new TestClass();
        testClass.setName("test");
        String jsonString = Parser.toJson(testClass, "yyyy-MM-dd");
        assertNotNull(jsonString);
        assertTrue(jsonString.contains("test"));
    }

    @Test
    public void testToJsonWithFormatAndTimeZone() throws IOException {
        TestClass testClass = new TestClass();
        testClass.setName("test");
        String jsonString = Parser.toJson(testClass, "yyyy-MM-dd", TimeZone.getTimeZone("PST"));
        assertNotNull(jsonString);
        assertTrue(jsonString.contains("test"));
    }

    @Test
    public void testToJsonWithBooleanAndFormat() throws IOException {
        TestClass testClass = new TestClass();
        testClass.setName("test");
        String jsonString = Parser.toJson(testClass, false, "yyyy-MM-dd");
        assertNotNull(jsonString);
        assertTrue(jsonString.contains("test"));
    }

    @Test
    public void testInputStreamToStringNoBomExclusion() throws IOException {
        InputStream is = new ByteArrayInputStream("test".getBytes(StandardCharsets.UTF_8));
        String result = Parser.inputStreamToStringNoBomExclusion(is);
        assertNotNull(result);
        assertEquals("test", result);
    }

    @Test
    public void testParseJsonWithoutSingleQuotes() throws IOException {
        String jsonString = "{\"name\":\"test\"}";
        TestClass result = Parser.parseJson(jsonString, TestClass.class, false);
        assertNotNull(result);
        assertEquals("test", result.getName());
    }

    @Test
    public void testToXML() throws JsonProcessingException {
        TestClass testClass = new TestClass();
        testClass.setName("test");
        String xmlString = Parser.toXML(testClass);
        assertNotNull(xmlString);
        assertTrue(xmlString.contains("test"));
    }

    @Test
    public void testInputStreamToStringWithBOM() throws IOException {
        byte[] bomUtf8 = new byte[] {(byte)0xEF, (byte)0xBB, (byte)0xBF};
        byte[] content = "test".getBytes(StandardCharsets.UTF_8);
        byte[] combined = new byte[bomUtf8.length + content.length];
        System.arraycopy(bomUtf8, 0, combined, 0, bomUtf8.length);
        System.arraycopy(content, 0, combined, bomUtf8.length, content.length);
        InputStream is = new ByteArrayInputStream(combined);
        String result = Parser.inputStreamToString(is);
        assertNotNull(result);
        assertEquals("test", result);
    }

    // Define a simple TestClass for testing purposes
    public static class TestClass {
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    // Define a TestClassWithDate for testing purposes
    public static class TestClassWithDate {
        private Date date;

        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        }
    }

    @Test
    public void testToJsonWithFilters() throws JsonProcessingException {
        TestClass testClass = new TestClass();
        testClass.setName("test");

        @JsonFilter("filter properties by name")
        class TestFilterMixin {}
        String[] fieldsToFilter = {"name"};
        String jsonString = Parser.toJsonWithFilters(testClass, TestFilterMixin.class, fieldsToFilter);
        assertNotNull(jsonString);
        assertFalse(jsonString.contains("name"));
    }

    @Test
    public void testReadValueWithClass() throws IOException {
        String jsonString = "{\"name\":\"test\"}";
        ParserTest.TestClass result = Parser.readValue(jsonString, ParserTest.TestClass.class);
        assertNotNull(result);
        assertEquals("test", result.getName());
    }

    @Test
    public void testReadValueWithTypeReference() throws IOException {
        String jsonString = "[{\"name\":\"test1\"}, {\"name\":\"test2\"}]";
        TypeReference<List<TestClass>> typeRef = new TypeReference<>() {};
        List<TestClass> result = Parser.readValue(jsonString, typeRef);
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("test1", result.get(0).getName());
        assertEquals("test2", result.get(1).getName());
    }

    @Test
    public void testParseJsonWithTypeReference() throws IOException {
        String jsonString = "[{\"name\":\"test1\"}, {\"name\":\"test2\"}]";
        TypeReference<List<ParserTest.TestClass>> typeRef = new TypeReference<>() {};
        List<ParserTest.TestClass> result = Parser.parseJson(jsonString, typeRef);
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("test1", result.get(0).getName());
        assertEquals("test2", result.get(1).getName());
    }

    @Test
    public void testParseXMLFile() throws IOException {
        // Create a temporary XML file for testing
        String xmlContent = "<TestClass><name>test</name></TestClass>";
        Path tempFile = Files.createTempFile("test", ".xml");
        Files.write(tempFile, xmlContent.getBytes(StandardCharsets.UTF_8));

        try {
            ParserTest.TestClass result = Parser.parseXMLFile(tempFile.toString(), ParserTest.TestClass.class);
            assertNotNull(result);
            assertEquals("test", result.getName());
        } finally {

            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    public void testDetectAndExcludeBOM_UTF16BE() throws IOException {
        // Simulate an input stream with a UTF-16BE BOM
        byte[] utf16beBom = new byte[] {(byte) 0xFE, (byte) 0xFF}; // UTF-16BE BOM
        byte[] content = "test".getBytes(StandardCharsets.UTF_16BE);
        byte[] combined = new byte[utf16beBom.length + content.length];
        System.arraycopy(utf16beBom, 0, combined, 0, utf16beBom.length);
        System.arraycopy(content, 0, combined, utf16beBom.length, content.length);

        InputStream is = new ByteArrayInputStream(combined);
        InputStreamReader reader = Parser.detectAndExcludeBOM(is);

        // Verify the result
        assertNotNull(reader);
        BufferedReader br = new BufferedReader(reader);
        String result = br.readLine();
        assertEquals("test", result);
    }

    @Test
    public void testDetectAndExcludeBOM_UTF16LE() throws IOException {
        // Simulate an input stream with a UTF-16LE BOM
        byte[] utf16leBom = new byte[] {(byte) 0xFF, (byte) 0xFE}; // UTF-16LE BOM
        byte[] content = "test".getBytes(StandardCharsets.UTF_16LE);
        byte[] combined = new byte[utf16leBom.length + content.length];
        System.arraycopy(utf16leBom, 0, combined, 0, utf16leBom.length);
        System.arraycopy(content, 0, combined, utf16leBom.length, content.length);

        InputStream is = new ByteArrayInputStream(combined);

        InputStreamReader reader = Parser.detectAndExcludeBOM(is);
        assertNotNull(reader);
        BufferedReader br = new BufferedReader(reader);
        String result = br.readLine();
        assertEquals("test", result);
    }
}