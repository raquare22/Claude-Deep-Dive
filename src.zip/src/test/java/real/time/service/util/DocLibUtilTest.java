package real.time.service.util;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import real.time.service.EhCache;
import real.time.service.java.delegate.docvault.OutOfRetriesException;
import real.time.service.mongo.DocumentAttachmentMetaData;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.oauth.OauthTokenExtended;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DocLibUtilTest {

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private DocLibUtil docLibUtil;

    @Mock
    private EhCache ehCache;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(docLibUtil, "docLibOauthUrl", "url");
        ReflectionTestUtils.setField(docLibUtil, "docLibClientId", "clientId");
        ReflectionTestUtils.setField(docLibUtil, "docLibClientSecret", "clientSecret");

        ReflectionTestUtils.setField(docLibUtil, "docLibPostUrl", "endpoint");
    }

//    @Test
    public void testGetOauthToken() {
        String clientId = "clientId";
        String clientSecret = "clientSecret";
        String url = "url";
        String grantType = "client_credentials";
        String accessToken = "accessToken";

        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(clientId, clientSecret, url, grantType, null);
        oauthTokenExtended.setAccessToken(accessToken);

        when(oauthManagerUtil.getOauthTokenExtended(clientId, clientSecret, url, grantType, null))
                .thenReturn(Optional.of(oauthTokenExtended));

        try (var mockedEhCache = mockStatic(EhCache.class)) {
            mockedEhCache.when(() -> ehCache.getOauthTokenCache("tokenStargate")).thenReturn(null);

            String token = oauthManagerUtil.getOauthToken("tokenStargate", clientId, clientSecret, grantType, url, true, null);

            assertEquals("accessToken", token);
        }
    }

//    @Test
    public void testGetOauthTokenFromCache() {
        try (var mockedEhCache = mockStatic(EhCache.class)) {
            mockedEhCache.when(() -> ehCache.getOauthTokenCache("tokenStargate")).thenReturn("cachedToken");

            String token = oauthManagerUtil.getOauthToken("docLib", "clientId", "clientSecret", "client_credentials", "url", false, null);

            assertEquals("cachedToken", token);
        }
    }

    @Test
    public void testIsResponseSuccess() {
        String responseBody = "{\"metadata\":{\"success\":1}}";

        boolean isSuccess = docLibUtil.isResponseSuccess(responseBody, "optum_cid");

        assertTrue(isSuccess);
    }

    private DocumentMetaData getDocumentMetaData() {
        DocumentMetaData docMetaData = new DocumentMetaData();
        docMetaData.setId("1234");
        docMetaData.setParentId("1");
        docMetaData.setClientId(684);
        docMetaData.setSpaceId(2804);
        docMetaData.setAppIdentifier("testApp");
        docMetaData.setStatus("ACTIVE");
        docMetaData.setDateCreated(new Date(1662662046076L));

        String TransId =docMetaData.getTransactionId();
        org.bson.Document metadataJson = new org.bson.Document();
        metadataJson.put("fileName","abc");
        metadataJson.put("createApplication","OCM");
        metadataJson.put("category", "Claim");
        metadataJson.put("emailAlertReq", "Y");
        metadataJson.put("physicianName", "Brooke Fisher");
        DocumentAttachmentMetaData documentAttachment = new DocumentAttachmentMetaData();
        documentAttachment.setFsId("3934-afdk-e083420j");
        documentAttachment.setIndex(1);
        documentAttachment.setName("my_report.pdf");


        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        attachments.add(documentAttachment);

        docMetaData.setDocumentAttachments(attachments);
        docMetaData.setMetadata(metadataJson);
        docMetaData.setTransactionId("0bc09b5f-a2f6-4ef0-9139-c039e75aa269");
        return docMetaData;
    }

    @Test
    public void testRunDoclib() {
        DocumentMetaData document = getDocumentMetaData();

        String endpoint = "http://example.com";
        String accessToken = "Bearer accessToken";
        String jsonToDocLib = "{\"document\":\"data\"}";
        ResponseEntity<Object> responseEntity = new ResponseEntity<>("{\"metadata\":{\"success\":1}}", HttpStatus.OK);

        // Mocking
        when(restTemplate.postForEntity(anyString(), any(), any())).thenReturn(responseEntity);

        DocumentMetaData result = docLibUtil.runDocLibProcess(document, "cid");

        assertNotNull(result);
    }

    @Test
    public void testPostDocumentToDocLib() {
        // Setup
        String endpoint = "http://example.com";
        String accessToken = "Bearer accessToken";
        String jsonToDocLib = "{\"document\":\"data\"}";
        ResponseEntity<String> responseEntity = new ResponseEntity<>("{\"metadata\":{\"success\":1}}", HttpStatus.OK);

        // Mocking
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(String.class))).thenReturn(responseEntity);

        // Execute
        ResponseEntity<String> response = docLibUtil.postDocumentToDocLib(endpoint, accessToken, jsonToDocLib);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testPostDocumentToDocLibInternalServerError() {
        // Setup
        String endpoint = "http://example.com";
        String accessToken = "Bearer accessToken";
        String jsonToDocLib = "{\"document\":\"data\"}";
        ResponseEntity<String> responseEntity = new ResponseEntity<>("{\"metadata\":{\"success\":1}}", HttpStatus.INTERNAL_SERVER_ERROR);

        // Mocking
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(String.class))).thenReturn(responseEntity);

        // Execute
        ResponseEntity<String> response = docLibUtil.postDocumentToDocLib(endpoint, accessToken, jsonToDocLib);

        // Verify
        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

//    @Test
    public void testGetOauthTokenFromCacheNotExpired() {
        try (var mockedEhCache = mockStatic(EhCache.class)) {
            mockedEhCache.when(() -> ehCache.getOauthTokenCache("tokenStargate")).thenReturn("cachedToken");

            String token = oauthManagerUtil.getOauthToken("docLib", "clientId", "clientSecret", "client_credentials", "url", false, null);

            assertEquals("cachedToken", token);
        }
    }

//    @Test
    public void testGetOauthTokenFromCacheExpired() {
        String clientId = "clientId";
        String clientSecret = "clientSecret";
        String url = "url";
        String grantType = "client_credentials";
        String newAccessToken = "newAccessToken";

        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(clientId, clientSecret, url, grantType, null);
        oauthTokenExtended.setAccessToken(newAccessToken);

        when(oauthManagerUtil.getOauthTokenExtended(clientId, clientSecret, url, grantType, null))
                .thenReturn(Optional.of(oauthTokenExtended));

        try (var mockedEhCache = mockStatic(EhCache.class)) {
            mockedEhCache.when(() -> ehCache.getOauthTokenCache("tokenStargate")).thenReturn(null);

            String token = oauthManagerUtil.getOauthToken("docLib", clientId, clientSecret, grantType, url, false, null);

            assertEquals("newAccessToken", token);
        }
    }


//    @Test
    public void testGetOauthTokenFetchNewToken() {
        String clientId = "clientId";
        String clientSecret = "clientSecret";
        String url = "url";
        String grantType = "client_credentials";
        String newAccessToken = "newAccessToken";

        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(clientId, clientSecret, url, grantType, null);
        oauthTokenExtended.setAccessToken(newAccessToken);

        when(oauthManagerUtil.getOauthTokenExtended(clientId, clientSecret, url, grantType, null))
                .thenReturn(Optional.of(oauthTokenExtended));

        try (var mockedEhCache = mockStatic(EhCache.class)) {
            mockedEhCache.when(() -> ehCache.getOauthTokenCache("tokenStargate")).thenReturn(null);

            String token = oauthManagerUtil.getOauthToken("docLib", clientId, clientSecret, grantType, url, false, null);

            assertEquals("newAccessToken", token);
        }
    }

    @Test
    public void testGetOauthTokenFetchNewTokenFailure() {
        String clientId = "clientId";
        String clientSecret = "clientSecret";
        String url = "url";
        String grantType = "client_credentials";


            String token = oauthManagerUtil.getOauthToken("docLib", clientId, clientSecret, grantType, url, false, null);

            assertNull(token);

    }

//    @Test
    public void testGetOauthTokenForceNewToken() {
        String clientId = "clientId";
        String clientSecret = "clientSecret";
        String url = "url";
        String grantType = "client_credentials";
        String newAccessToken = "newAccessToken";

        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(clientId, clientSecret, url, grantType, null);
        oauthTokenExtended.setAccessToken(newAccessToken);

        when(oauthManagerUtil.getOauthTokenExtended(clientId, clientSecret, url, grantType, null))
                .thenReturn(Optional.of(oauthTokenExtended));

        try (var mockedEhCache = mockStatic(EhCache.class)) {
            mockedEhCache.when(() -> ehCache.getOauthTokenCache("tokenStargate")).thenReturn("cachedToken");

            String token = oauthManagerUtil.getOauthToken("docLib", clientId, clientSecret, grantType, url, true, null);

            assertEquals("newAccessToken", token);
        }
    }

    @Test
    public void testPostDocumentToDocLibWithRetry_Success() throws OutOfRetriesException {
        // Setup
        String endpoint = "http://example.com";
        String accessToken = "Bearer accessToken";
        String jsonToDocLib = "{\"document\":\"data\"}";
        String docId = "doc123";
        String cid = "testCid";

        ResponseEntity<String> responseEntity = new ResponseEntity<>("{\"metadata\":{\"success\":1}}", HttpStatus.OK);

        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(String.class)))
                .thenReturn(responseEntity);

        ResponseEntity<String> response = docLibUtil.postDocumentToDocLibWithRetry(endpoint, accessToken, jsonToDocLib, docId, cid);
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(restTemplate, times(1)).postForEntity(anyString(), any(HttpEntity.class), eq(String.class));
    }

    @Test
    public void testPostDocumentToDocLibWithRetry_ClientError() throws OutOfRetriesException {
        String endpoint = "http://example.com";
        String accessToken = "Bearer accessToken";
        String jsonToDocLib = "{\"document\":\"data\"}";
        String docId = "doc123";
        String cid = "testCid";

        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Bad Request");
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(String.class)))
                .thenThrow(exception);

        ResponseEntity<String> response = docLibUtil.postDocumentToDocLibWithRetry(endpoint, accessToken, jsonToDocLib, docId, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    //@Test
//    public void testPostDocumentToDocLibWithRetry_RestClientException() throws OutOfRetriesException {
//        String endpoint = "http://example.com";
//        String accessToken = "Bearer accessToken";
//        String jsonToDocLib = "{\"document\":\"data\"}";
//        String docId = "doc123";
//        String cid = "testCid";
//
//        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(String.class)))
//                .thenThrow(new RestClientException("RestClientException"));
//
//        assertThrows(NullPointerException.class, () -> {
//            docLibUtil.postDocumentToDocLibWithRetry(endpoint, accessToken, jsonToDocLib, docId, cid);
//        });
//    }


    @Test
    public  void testIsResponseSuccess_JsonProcessingException() throws Exception {
        String invalidResponseBody = "invalid_json";
        String cid = "testCID";
        boolean result = docLibUtil.isResponseSuccess(invalidResponseBody, cid);
        assertFalse(result);
    }

}