package real.time.service.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EnvironmentsTest {

    @Test
    public void testGetEnv() {
        assertEquals("local", Environments.LOCAL.getEnv());
        assertEquals("test", Environments.TEST.getEnv());
        assertEquals("dev", Environments.DEV.getEnv());
        assertEquals("stage", Environments.STAGE.getEnv());
        assertEquals("prod", Environments.PROD.getEnv());
    }

    @Test
    public void testEnumValues() {
        Environments[] expectedValues = { Environments.LOCAL, Environments.TEST, Environments.DEV, Environments.STAGE, Environments.PROD };
        Environments[] actualValues = Environments.values();
        assertEquals(expectedValues.length, actualValues.length);
        for (int i = 0; i < expectedValues.length; i++) {
            assertEquals(expectedValues[i], actualValues[i]);
        }
    }

    @Test
    public void testEnumValueOf() {
        assertEquals(Environments.LOCAL, Environments.valueOf("LOCAL"));
        assertEquals(Environments.TEST, Environments.valueOf("TEST"));
        assertEquals(Environments.DEV, Environments.valueOf("DEV"));
        assertEquals(Environments.STAGE, Environments.valueOf("STAGE"));
        assertEquals(Environments.PROD, Environments.valueOf("PROD"));
    }
}