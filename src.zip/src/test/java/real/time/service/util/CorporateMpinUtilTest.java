package real.time.service.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import real.time.service.EhCache;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.oauth.OauthTokenExtended;
import real.time.service.provider.pojo.*;

import java.io.IOException;
import java.util.Collections;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class CorporateMpinUtilTest {

    @Mock
    private EhCache ehcache;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @InjectMocks
    private CorporateMpinUtil corporateMpinUtil;

    @Mock
    private Parser parser;

    @Mock
    private Request mockRequest;

    @Mock
    private RequestBody mockRequestBody;

    @Mock
    private RequestHeader mockRequestHeader;

    @Mock
    private OauthTokenExtended mockOauthTokenExtended;

    @Before
    public void setUp() {

        MockitoAnnotations.initMocks(this);
        PhysicianFacility mockPhysicianFacility = mock(PhysicianFacility.class);
        DocumentMetaData document = mock(DocumentMetaData.class);
    }


//    @Test
//    public void testGetMpinFromSvcs() {
//        String tin = "123456789";
//        Request request = mock(Request.class);
//        when(request.getRequestBody()).thenReturn(mock(RequestBody.class));
//        when(request.getRequestHeader()).thenReturn(mock(RequestHeader.class));
//
//        when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString()))
//                .thenReturn(Optional.of(new OauthTokenExtended("appId", "appSecret", "authUrl", "client_credentials")));
//
//        String mpin = corporateMpinUtil.getMpinFromSvcs(tin);
//
//        assertNull(mpin);
//    }

    @Test
    public void testFormatTin() {
        String tin = "12345678901234";
        String formattedTin = corporateMpinUtil.formatTin(tin);
        assertEquals("123456789", formattedTin);
    }

    @Test
    public void testFormatTinWithShortTin() {
        String tin = "123456789";
        String formattedTin = corporateMpinUtil.formatTin(tin);
        assertEquals("123456789", formattedTin);
    }

    @Test
    public void testFormatTinWithWhitespace() {
        String tin = "  12345678901234  ";
        String formattedTin = corporateMpinUtil.formatTin(tin);
        assertEquals("123456789", formattedTin);
    }


    @Test
    public void testParseResponseBodyWithNullResponseBody() throws IOException {
        String responseBody = null;
        MediaType mediaType = MediaType.APPLICATION_JSON;
        String cid = "testCid";

        Object result = corporateMpinUtil.parseResponseBody(responseBody, mediaType, cid);

        assertNull(result);
    }

    @Test
    public void testParseResponseBodyWithNullMediaType() throws IOException {
        String responseBody = "{\"records\":[]}";
        MediaType mediaType = null;
        String cid = "testCid";
        Object result = corporateMpinUtil.parseResponseBody(responseBody, mediaType, cid);

        assertNull(result);
    }

    @Test
    public void testParseResponseBodyWithJsonMediaType() throws IOException {
        String responseBody = "{\"records\":[]}";
        MediaType mediaType = MediaType.APPLICATION_JSON;
        String cid = "testCid";

        ProviderSearchResults mockProviderSearchResults = mock(ProviderSearchResults.class);

        Object result = corporateMpinUtil.parseResponseBody(responseBody, mediaType, cid);


        assertNotNull(result);
        assertTrue(result instanceof ProviderSearchResults);
    }


    @Test
    public void testGetProviderCorpMpinWithPhysicianFacility() {

        PhysicianFacility mockPhysicianFacility = mock(PhysicianFacility.class);
        SvcResponse mockSvcResponse = mock(SvcResponse.class);
        PhysicianFacilityInformation mockPhysicianFacilityInformation = mock(PhysicianFacilityInformation.class);
        TaxIdType mockTaxIdType = mock(TaxIdType.class);

        when(mockPhysicianFacility.getSvcResponse()).thenReturn(mockSvcResponse);
        when(mockSvcResponse.getPhysicianFacilityInformation()).thenReturn(mockPhysicianFacilityInformation);
        when(mockPhysicianFacilityInformation.getTaxId()).thenReturn(Collections.singletonList(mockTaxIdType));
        when(mockTaxIdType.getcorpMPIN()).thenReturn("TestCorpMpin");

        String result = corporateMpinUtil.getProviderCorpMpin(mockPhysicianFacility);

        assertEquals("TestCorpMpin", result);
    }

    @Test
    public void testGetProviderCorpMpinWithNullPhysicianFacility() {
        String result = corporateMpinUtil.getProviderCorpMpin((PhysicianFacility) null);
        assertNull(result);
    }

    @Test
    public void testGetProviderCorpMpinFromEmptyProviderInfo() throws Exception {
        String corpMpin = corporateMpinUtil.getProviderCorpMpin(new ProviderSearchResults());
        assertNull(corpMpin);
    }

    @Test
    public void testRetrieveCorporateMpin_FromCache() {

        DocumentMetaData document = mock(DocumentMetaData.class);
        when(document.getMetadata()).thenReturn(new org.bson.Document());
        String tin = "123456789";
        String cid = "testCid";
        String cachedMpin = "123456789";
        when(ehcache.getCorpMpinCache(tin)).thenReturn(cachedMpin);

        corporateMpinUtil.retrieveCorporateMpin(tin, document, cid);

        verify(ehcache, times(1)).getCorpMpinCache(tin);
        verify(ehcache, never()).putCorpMpinCache(anyString(), anyString());
    }


    @Test
    public void testParseResponseBody_Xml() throws IOException {
        String responseBody = "<PhysicianFacility></PhysicianFacility>";
        MediaType mediaType = MediaType.APPLICATION_XML;
        String cid = "testCid";

        Object result = corporateMpinUtil.parseResponseBody(responseBody, mediaType, cid);

        assertNotNull(result);
        assertTrue(result instanceof PhysicianFacility);
    }

    @Test
    public void testGetProviderCorpMpin_WithNullProviderSearchResults() {
        String result = corporateMpinUtil.getProviderCorpMpin((ProviderSearchResults) null);

        assertNull(result);
    }


    @Test
    public void testGetProviderCorpMpin_WithProviderSearchResults() {
        ProviderSearchResults mockResults = mock(ProviderSearchResults.class);
        Records mockRecord = mock(Records.class);
        Rosterdata mockRosterdata = mock(Rosterdata.class);
        TaxId mockTaxId = mock(TaxId.class);

        when(mockResults.getRecords()).thenReturn(Collections.singletonList(mockRecord));
        when(mockRecord.getRosterdata()).thenReturn(mockRosterdata);
        when(mockRosterdata.getTaxId()).thenReturn(Collections.singletonList(Collections.singletonList(mockTaxId)));
        when(mockTaxId.getCorpOwnrProvId()).thenReturn("TestCorpMpin");

        String result = corporateMpinUtil.getProviderCorpMpin(mockResults);
        assertEquals("TestCorpMpin", result);
    }

}

