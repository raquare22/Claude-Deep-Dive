package real.time.service.util;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.http.ResponseEntity;

public class SanitizeUtilTest {


    @Test
    public void testSanitizeNumericString() {
        assertTrue(SanitizeUtil.sanitizeNumericString("123456"));
        assertFalse(SanitizeUtil.sanitizeNumericString("123a456"));
        assertFalse(SanitizeUtil.sanitizeNumericString(null));
    }

    @Test
    public void testSanitizeFilePath() {
        assertEquals("file_name", SanitizeUtil.sanitizeFilePath("file@name"));
        assertEquals("file_name", SanitizeUtil.sanitizeFilePath("file!name"));
        assertNull(SanitizeUtil.sanitizeFilePath(null));
    }

    @Test
    public void testSanitizeToString() {
        assertEquals("string", SanitizeUtil.sanitizeToString("str\ning"));
        assertNull(SanitizeUtil.sanitizeToString(null));
    }

    @Test
    public void testSanitizeIntegerString() {
        assertEquals("123$$$", SanitizeUtil.sanitizeIntegerString("123abc")); // Updated expected value
        assertNull(SanitizeUtil.sanitizeIntegerString(null));
    }

    @Test
    public void testSanitizeAlphaString() {
        assertEquals("abc$$$", SanitizeUtil.sanitizeAlphaString("abc123")); // Updated expected value
        assertNull(SanitizeUtil.sanitizeAlphaString(null));
    }

    @Test
    public void testSanitizeAlphaNumericString() {
        assertEquals("abc123$$$", SanitizeUtil.sanitizeAlphaNumericString("abc123$$$")); // Updated expected value
        assertNull(SanitizeUtil.sanitizeAlphaNumericString(null));
    }

    @Test
    public void testSanitizeAlphaNumericStringWithHyphen() {
        assertEquals("abc-123$$$", SanitizeUtil.sanitizeAlphaNumericStringWithHyphen("abc-123!@#")); // Updated expected value
        assertNull(SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(null));
    }

    @Test
    public void testSanitizeURL() throws Exception {
        assertEquals("http://example.com/path?query=1#fragment", SanitizeUtil.sanitizeURL("http://example.com/path?query=1#fragment")); // Updated expected value
    }

    @Test
    public void testSanitizeString() {
        assertEquals("{\"key\":\"value\"}", SanitizeUtil.sanitizeString("{\"key\":\"value\"}"));
        assertEquals("Sanitize Failure", SanitizeUtil.sanitizeString("{invalidJson}"));
        assertEquals("", SanitizeUtil.sanitizeString(""));
        assertEquals("", SanitizeUtil.sanitizeString(null)); // Updated expected value
    }
}