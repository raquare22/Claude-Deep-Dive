package real.time.service.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import real.time.service.exception.HttpServerException;
import real.time.service.mongo.FDSCloudDocument;
import real.time.service.oauth.OauthManagerUtil;

import java.io.File;
import java.lang.reflect.Field;
import java.net.URI;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class WebClientSyncTest {

    @InjectMocks
    private WebClientSync webClientSync;

    @Mock
    private WebClient.Builder webClientBuilder;

    @Mock
    private WebClient webClient;

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(webClientBuilder.build()).thenReturn(webClient);
    }

    @Test
    public void testIncrementAndGetTotalHttpFailureCnt() {
        int initialCount = WebClientSync.totalHttpFailureCnt;
        int newCount = WebClientSync.incrementAndGetTotalHttpFailureCnt();
        assertEquals(initialCount + 1, newCount);
    }

    @Test
    public void testIncrementAndGetTotalFailureCnt() {
        int initialCount = WebClientSync.totalFailureCnt;
        int newCount = WebClientSync.incrementAndGetTotalFailureCnt();
        assertEquals(initialCount + 1, newCount);
    }

    private void setLoggerField(Logger logger) throws Exception {
        Field loggerField = WebClientSync.class.getDeclaredField("LOGGER");
        loggerField.setAccessible(true);
        loggerField.set(null, logger);
    }

    @Test
    public void testLogStats() {
        WebClientSync.totalHttpFailureCnt = 5;
        WebClientSync.totalFailureCnt = 10;
        WebClientSync.logStats();
    }

    @Test
    public void testGetMultiValueMap() {
        File file = new File("test.txt");
        String document = "testDocument";
        String searchTerms = "testSearch";

        MultiValueMap<String, HttpEntity<?>> map = webClientSync.getMultiValueMap(file, document, searchTerms);

        assertNotNull(map);
        assertTrue(map.containsKey("file"));
        assertTrue(map.containsKey("metadata"));
        assertTrue(map.containsKey("searchTerms"));
    }



    @Test
    public void testGetNewWebClient() {
        WebClient client = webClientSync.getNewWebClient();
        assertNotNull(client);
    }


    @Test
    public void testSendMultiPartData_Failure() throws Exception {
        URI uri = new URI("http://example.com");
        File file = new File("test.txt");
        String document = "testDocument";
        String searchTerms = "testSearchTerms";
        String cid = "testCid";
        String oauthToken = "mockAccessToken";

        WebClient webClient = mock(WebClient.class);
        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(uri)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.MULTIPART_FORM_DATA)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.header(anyString(), anyString())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(BodyInserters.MultipartInserter.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(FDSCloudDocument.class)).thenThrow(new HttpServerException("Error", HttpStatus.INTERNAL_SERVER_ERROR));

        Exception exception = assertThrows(HttpServerException.class, () -> {
            webClientSync.sendMultiPartData(uri, oauthToken, file, document, searchTerms, cid);
        });

        assertNotNull(exception);
    }
    /*@Test
    public void testSendMultiPartDataWithRetry_NullValueHandling() throws Exception {
        URI uri = new URI("http://example.com");
        File file = new File("test.txt");
        String document = null; // Simulating a null value
        String cid = "testCid";
        String searchTerms = "testSearchTerms";
        String fdsCloudPostDocumentsUrl = "http://example.com";

        WebClient webClient = mock(WebClient.class);
        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(uri)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.MULTIPART_FORM_DATA)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.header(anyString(), anyString())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(BodyInserters.MultipartInserter.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(FDSCloudDocument.class)).thenReturn(Mono.error(new WebClientResponseException(500, "Internal Server Error", null, null, null)));

        Exception exception = assertThrows(NullPointerException.class, () -> {
            webClientSync.sendMultiPartDataWithRetry(fdsCloudPostDocumentsUrl, uri, file, document, searchTerms, cid);
        });

        assertNotNull(exception);
        assertTrue(exception.getMessage().contains("Cannot invoke \"String.isEmpty()\" because \"value\" is null"));
    }*/


}