package real.time.service.util;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

public class FilestoreUtilTest {

    @Mock
    private MultipartFile multipartFile;

    @InjectMocks
    private FilestoreUtil filestoreUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        setIngestRoot(filestoreUtil, "/tmp/ingest");
        Files.createDirectories(Path.of("/tmp/ingest"));
    }

    @After
    public void tearDown() throws Exception {
        // Clean up created directories and files
        Files.walk(Path.of("/tmp/ingest"))
                .map(Path::toFile)
                .forEach(file -> {
                    if (!file.delete()) {
                        file.deleteOnExit();
                    }
                });
    }

    private void setIngestRoot(FilestoreUtil filestoreUtil, String ingestRoot) throws Exception {
        Field field = FilestoreUtil.class.getDeclaredField("ingestRoot");
        field.setAccessible(true);
        field.set(filestoreUtil, ingestRoot);
    }

    @Test
    public void testCreateWorkingDirectoryWithParams() throws IOException {
        String[] elements = {"/tmp", "ingest", "filestore", "123", "20230101010101000"};
        Path result = filestoreUtil.createWorkingDirectoryWithParams(FilestoreUtil.DEFAULT_FILE_SEPARATOR, "cid", elements);

        assertNotNull(result);
        assertTrue(Files.exists(result));

        // Clean up
        result.toFile().delete();
    }

    @Test
    public void testSaveFileToIngest() throws IOException {
        String fileName = "testFile.txt";
        String content = "This is a test file";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(content.getBytes());

        when(multipartFile.getInputStream()).thenReturn(inputStream);
        when(multipartFile.getOriginalFilename()).thenReturn(fileName);

        String result = filestoreUtil.saveFileToIngest(fileName, multipartFile, 123, "cid");

        assertNotNull(result);
        assertTrue(Files.exists(Path.of(result)));

        // Clean up
        Files.deleteIfExists(Path.of(result));
    }

    @Test
    public void testSaveFileToIngest_FileAlreadyExists() throws IOException {
        String fileName = "existingFile.txt";
        String content = "This is an existing file";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(content.getBytes());

        when(multipartFile.getInputStream()).thenReturn(inputStream);
        when(multipartFile.getOriginalFilename()).thenReturn(fileName);

        // Manually create the file to simulate it already exists
        Path existingFilePath = Path.of("/tmp/ingest", "123", "cid", fileName);
        Files.createDirectories(existingFilePath.getParent());
        Files.write(existingFilePath, content.getBytes());
        assertTrue(Files.exists(existingFilePath));

        // Try to save the file again, it should return null
        String result = filestoreUtil.saveFileToIngest(fileName, multipartFile, 123, "cid");
        assertNull(null);

        // Clean up
        Files.deleteIfExists(existingFilePath);
    }

}