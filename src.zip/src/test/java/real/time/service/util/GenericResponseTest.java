package real.time.service.util;

import static org.junit.Assert.*;
import org.junit.Test;
import real.time.service.util.GenericResponse;

public class GenericResponseTest {

    @Test
    public void testDefaultConstructor() {
        GenericResponse response = new GenericResponse();
        assertNull(response.getStatusCode());
        assertNull(response.getStatusMessage());
        assertNull(response.getResponse());
    }

    @Test
    public void testConstructorWithStatusCodeAndMessage() {
        GenericResponse response = new GenericResponse("200", "Success");
        assertEquals("200", response.getStatusCode());
        assertEquals("Success", response.getStatusMessage());
        assertNull(response.getResponse());
    }

    @Test
    public void testConstructorWithAllFields() {
        Object responseObject = new Object();
        GenericResponse response = new GenericResponse("200", "Success", responseObject);
        assertEquals("200", response.getStatusCode());
        assertEquals("Success", response.getStatusMessage());
        assertEquals(responseObject, response.getResponse());
    }

    @Test
    public void testFromMethod() {
        Object responseObject = new Object();
        GenericResponse response = GenericResponse.from("200", "Success", responseObject);
        assertEquals("200", response.getStatusCode());
        assertEquals("Success", response.getStatusMessage());
        assertEquals(responseObject, response.getResponse());
    }

    @Test
    public void testSettersAndGetters() {
        GenericResponse response = new GenericResponse();
        response.setStatusCode("404");
        response.setStatusMessage("Not Found");
        Object responseObject = new Object();
        response.setResponse(responseObject);

        assertEquals("404", response.getStatusCode());
        assertEquals("Not Found", response.getStatusMessage());
        assertEquals(responseObject, response.getResponse());
    }

    @Test
    public void testToString() {
        GenericResponse response = new GenericResponse("200", "Success", "Response Data");
        String expectedString = "GenericResponse [statusCode=200, statusMessage=Success, response=Response Data]";
        assertEquals(expectedString, response.toString());
    }
}
