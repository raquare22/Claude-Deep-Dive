package real.time.service.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import real.time.service.mongo.DocumentAttachmentMetaData;
import real.time.service.mongo.FDSCloudDocument;

import java.net.URI;
import java.net.URISyntaxException;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class RetryUtilTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private RetryUtil retryUtil;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRetryGetAttachment() throws InterruptedException, URISyntaxException {
        URI awsUri = new URI("http://example.com");
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);
        ResponseEntity<byte[]> responseEntity = ResponseEntity.ok(new byte[0]);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(attachmentEntity), eq(byte[].class)))
                .thenReturn(responseEntity);

        ResponseEntity<byte[]> response = retryUtil.retryGetAttachment(awsUri, restTemplate);

        assertNotNull(response);
        assertEquals(responseEntity, response);
    }

    @Test
    public void testRetryFDSCloudCall() throws InterruptedException, URISyntaxException {
        URI awsUri = new URI("http://example.com");
        String newAccessToken = "newAccessToken";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("fds-authorization", newAccessToken);
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);
        ResponseEntity<DocumentAttachmentMetaData> responseEntity = ResponseEntity.ok(new DocumentAttachmentMetaData());

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), eq(attachmentEntity), eq(DocumentAttachmentMetaData.class)))
                .thenReturn(responseEntity);

        ResponseEntity<DocumentAttachmentMetaData> response = retryUtil.retryFDSCloudCall(awsUri, newAccessToken, restTemplate, "http://example.com");

        assertNotNull(response);
        assertEquals(responseEntity, response);
    }

    @Test
    public void testRetryFDSCloudGetCall() throws InterruptedException, URISyntaxException {
        String uri = "http://example.com";
        String newAccessToken = "newAccessToken";
        String fdsCloudGetDocumentUrl = "http://example.com";
        String cid = "cid";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("fds-authorization", newAccessToken);
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);
        ResponseEntity<FDSCloudDocument> responseEntity = ResponseEntity.ok(new FDSCloudDocument());

        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(attachmentEntity), eq(FDSCloudDocument.class)))
                .thenReturn(responseEntity);

        ResponseEntity<FDSCloudDocument> response = retryUtil.retryFDSCloudGetCall(uri, newAccessToken, restTemplate, fdsCloudGetDocumentUrl, cid);

        assertNotNull(response);
        assertEquals(responseEntity, response);
    }

    @Test
    public void testRetryGetAttachmentWithException() throws InterruptedException, URISyntaxException {
        URI awsUri = new URI("http://example.com");
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(attachmentEntity), eq(byte[].class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        try {
            retryUtil.retryGetAttachment(awsUri, restTemplate);
            fail("Expected HttpServerErrorException");
        } catch (HttpServerErrorException e) {
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getStatusCode());
        }
    }

    @Test
    public void testRetryFDSCloudCallWithException() throws InterruptedException, URISyntaxException {
        URI awsUri = new URI("http://example.com");
        String newAccessToken = "newAccessToken";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("fds-authorization", newAccessToken);
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), eq(attachmentEntity), eq(DocumentAttachmentMetaData.class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        try {
            retryUtil.retryFDSCloudCall(awsUri, newAccessToken, restTemplate, "http://example.com");
            fail("Expected HttpServerErrorException");
        } catch (HttpServerErrorException e) {
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getStatusCode());
        }
    }

    @Test
    public void testRetryFDSCloudGetCallWithSuccessOnLastRetry() throws InterruptedException, URISyntaxException {
        String uri = "http://example.com";
        String newAccessToken = "newAccessToken";
        String fdsCloudGetDocumentUrl = "http://example.com";
        String cid = "cid";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("fds-authorization", newAccessToken);
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);
        ResponseEntity<FDSCloudDocument> responseEntity = ResponseEntity.ok(new FDSCloudDocument());

        // Adjust the mock to throw the exception twice and then return a successful response
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(attachmentEntity), eq(FDSCloudDocument.class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR))
                .thenReturn(responseEntity);

        ResponseEntity<FDSCloudDocument> response = retryUtil.retryFDSCloudGetCall(uri, newAccessToken, restTemplate, fdsCloudGetDocumentUrl, cid);

        assertNotNull(response);
        assertEquals(responseEntity, response);
    }

    @Test
    public void testRetryFDSCloudGetCallWithSuccessOnFirstAttempt() throws InterruptedException, URISyntaxException {
        String uri = "http://example.com";
        String newAccessToken = "newAccessToken";
        String fdsCloudGetDocumentUrl = "http://example.com";
        String cid = "cid";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("fds-authorization", newAccessToken);
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);
        ResponseEntity<FDSCloudDocument> responseEntity = ResponseEntity.ok(new FDSCloudDocument());

        // Adjust the mock to return a successful response on the first attempt
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(attachmentEntity), eq(FDSCloudDocument.class)))
                .thenReturn(responseEntity);

        ResponseEntity<FDSCloudDocument> response = retryUtil.retryFDSCloudGetCall(uri, newAccessToken, restTemplate, fdsCloudGetDocumentUrl, cid);

        assertNotNull(response);
        assertEquals(responseEntity, response);
    }

    @Test
    public void testRetryFDSCloudGetCall_NonRetryableStatusCode() throws InterruptedException, URISyntaxException {
        String uri = "http://example.com";
        String newAccessToken = "newAccessToken";
        String fdsCloudGetDocumentUrl = "http://example.com";
        String cid = "cid";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("fds-authorization", newAccessToken);
        HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

        HttpStatusCodeException exception = mock(HttpStatusCodeException.class);
        when(exception.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST); // Non-retryable status code
        when(exception.getResponseBodyAsString()).thenReturn("Error response");

        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(attachmentEntity), eq(FDSCloudDocument.class)))
                .thenThrow(exception);

        ResponseEntity<FDSCloudDocument> response = retryUtil.retryFDSCloudGetCall(uri, newAccessToken, restTemplate, fdsCloudGetDocumentUrl, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNull(response.getBody());
    }

}