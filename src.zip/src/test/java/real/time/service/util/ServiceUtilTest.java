package real.time.service.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import real.time.service.email.EmailService;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.oauth.OauthTokenExtended;

import java.lang.reflect.Field;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ServiceUtilTest {

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private ServiceUtil serviceUtil  = spy(new ServiceUtil());

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        setField(serviceUtil, "emailSender", "testSender@example.com");
        setField(serviceUtil, "emailReceiver", "testReceiver@example.com");
        setField(serviceUtil, "env", "testEnv");
    }

    private void setField(Object targetObject, String fieldName, Object value) throws Exception {
        Field field = targetObject.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(targetObject, value);
    }

    @Test
    public void testSendEmailNotificationELGS() {
        when(emailService.sendEmail(anyString(), anyString(), anyString(), anyString())).thenReturn(true);

        serviceUtil.sendEmailNotificationELGS("requestJson", "fdsCloudDocumentId", "cid");

        verify(emailService, times(1)).sendEmail(eq("testSender@example.com"), eq("testReceiver@example.com"), eq("ELGS Metadata Validation API failure - testEnv"), eq("requestJson"));
    }

//    @Test
//    public void testGetOauthToken() throws Exception {
//        setField(serviceUtil, "fdsCloudOauthUrl", "http://example.com/oauth");
//        setField(serviceUtil, "fdsCloudClientId", "clientId");
//        setField(serviceUtil, "fdsCloudClientSecret", "clientSecret");
//        setField(serviceUtil, "fdsCloudGrantType", "client_credentials");
//
//        OauthTokenExtended token = new OauthTokenExtended("clientId", "clientSecret", "http://example.com/oauth", "client_credentials");
//        token.setAccessToken("accessToken");
//        when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString())).thenReturn(Optional.of(token));
//
//        String result = serviceUtil.getOauthToken(true, "fdsCloud", "cid");
//
//        assertEquals("accessToken", result);
//    }
//
//    @Test
//    public void testGetOauthTokenFromCache() throws Exception {
//        setField(serviceUtil, "fdsCloudOauthUrl", "http://example.com/oauth");
//        setField(serviceUtil, "fdsCloudClientId", "clientId");
//        setField(serviceUtil, "fdsCloudClientSecret", "clientSecret");
//        setField(serviceUtil, "fdsCloudGrantType", "client_credentials");
//
//        // Mock the cache to return a token
//        String cachedToken = "cachedAccessToken";
//        EhCache.putOauthTokenWithExpiry("tokenFDSCloudPrun", cachedToken, 3600);
//
//        String result = serviceUtil.getOauthToken(false, "fdsCloud", "cid");
//
//        assertEquals(cachedToken, result);
//    }

    @Test
    public void testPostELGSRequest_Success() throws Exception {
        // Arrange
        String token = "Bearer validToken";
        String requestStr = "{\"key\":\"value\"}";
        String cid = "12345";
        String elgsPostUrl = "http://example.com/elgs";
        setField(serviceUtil, "elgsPostUrl", elgsPostUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", token);
        headers.set("accept", "application/json");
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(requestStr, headers);
        ResponseEntity<String> mockResponse = new ResponseEntity<>("Success", HttpStatus.OK);

        when(restTemplate.postForEntity(elgsPostUrl, request, String.class)).thenReturn(mockResponse);

        ResponseEntity<String> response = serviceUtil.postELGSRequest(token, requestStr, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Success", response.getBody());
        verify(restTemplate, times(1)).postForEntity(elgsPostUrl, request, String.class);
    }

    @Test
    public void testPostELGSRequest_Unauthorized() throws Exception {

        String token = "Bearer invalidToken";
        String requestStr = "{\"key\":\"value\"}";
        String cid = "12345";
        String elgsPostUrl = "http://example.com/elgs";
        setField(serviceUtil, "elgsPostUrl", elgsPostUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", token);
        headers.set("accept", "application/json");
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(requestStr, headers);

        when(restTemplate.postForEntity(elgsPostUrl, request, String.class))
                .thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED, "Unauthorized"));


        HttpClientErrorException exception = assertThrows(HttpClientErrorException.class, () -> {
            serviceUtil.postELGSRequest(token, requestStr, cid);
        });

        assertEquals(HttpStatus.UNAUTHORIZED, exception.getStatusCode());
        verify(restTemplate, times(1)).postForEntity(elgsPostUrl, request, String.class);
    }

    @Test
    public void testPostELGSRequest_Exception() throws Exception {
        // Arrange
        String token = "Bearer validToken";
        String requestStr = "{\"key\":\"value\"}";
        String cid = "12345";
        String elgsPostUrl = "http://example.com/elgs";
        setField(serviceUtil, "elgsPostUrl", elgsPostUrl);


        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", token);
        headers.set("accept", "application/json");
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(requestStr, headers);

        when(restTemplate.postForEntity(elgsPostUrl, request, String.class))
                .thenThrow(new RuntimeException("Unexpected error"));


        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            serviceUtil.postELGSRequest(token, requestStr, cid);
        });

        assertEquals("Unexpected error", exception.getMessage());
        verify(restTemplate, times(1)).postForEntity(elgsPostUrl, request, String.class);
    }


    @Test
    public void testSendMetadataValidationNotificationELGS_Failure() throws Exception {
        // Arrange
        List<Map<String, String>> errorList = new ArrayList<>();
        Map<String, String> error = new HashMap<>();
        error.put("errorKey", "errorValue");
        errorList.add(error);

        DocumentMetaData document = mock(DocumentMetaData.class);
        org.bson.Document metadata = new org.bson.Document("key", "value");
        String fdsCloudSpaceId = "spaceId";
        String fdsCloudDocumentId = "documentId";
        String cid = "12345";

        String token = "Bearer validToken";
        String requestJson = "{\"key\":\"value\"}";
        ResponseEntity<String> mockResponse = new ResponseEntity<>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);

        when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(new OauthTokenExtended("clientId", "clientSecret", "url", "grantType","scope")));
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(String.class))).thenReturn(mockResponse);
        serviceUtil.sendMetadataValidationNotificationELGS(errorList, document, metadata, fdsCloudSpaceId, fdsCloudDocumentId, cid);
        verify(emailService, times(1)).sendEmail(anyString(), anyString(), anyString(), anyString());
    }

    @Test
    public void testPostELGSWithRetry_Success() throws Exception {
        // Arrange
        String accessToken = "Bearer validToken";
        String requestJson = "{\"key\":\"value\"}";
        String docId = "12345";
        String cid = "testCID";
        String elgsPostUrl = "http://example.com/elgs";
        setField(serviceUtil, "elgsPostUrl", elgsPostUrl);

        ResponseEntity<String> mockResponse = new ResponseEntity<>("Success", HttpStatus.OK);

        doReturn(mockResponse).when(serviceUtil).postELGSRequest(accessToken, requestJson, cid);

        ResponseEntity<String> response = serviceUtil.postELGSWithRetry(accessToken, requestJson, docId, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Success", response.getBody());
        verify(serviceUtil, times(1)).postELGSRequest(accessToken, requestJson, cid);
    }



    @Test
    public void testPostELGSWithRetry_GatewayTimeoutRetry() throws Exception {
        // Arrange
        String accessToken = "Bearer validToken";
        String requestJson = "{\"key\":\"value\"}";
        String docId = "12345";
        String cid = "testCID";


        doThrow(new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT))
                .doReturn(new ResponseEntity<>("Gateway Timeout", HttpStatus.GATEWAY_TIMEOUT))
                .when(serviceUtil).postELGSRequest(anyString(), eq(requestJson), eq(cid));
        ResponseEntity<String> response = serviceUtil.postELGSWithRetry(accessToken, requestJson, docId, cid);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.GATEWAY_TIMEOUT, response.getStatusCode());
   }
}
