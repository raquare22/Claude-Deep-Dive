package real.time.service.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import real.time.service.config.ConfigData;
import real.time.service.domain.service.DocumentMetaDataService;
import real.time.service.domain.service.FilestoreService;
import real.time.service.model.Doc360UploadResponse;
import real.time.service.mongo.DocumentAttachmentMetaData;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.mongo.FDSCloudDocument;
import real.time.service.mongo.processors.MetaDataStatus;
import real.time.service.template.java.impl.FDSCloudSearchTermsTemplate;
import real.time.service.workflow.constants.Workflow;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ProcessDocumentUtilTest {

    @Mock
    private ConfigData config;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private FilestoreService filestoreService;

    @Mock
    private CorporateMpinUtil corpMpinUtil;

    @Mock
    private ServiceUtil serviceUtil;

    @Mock
    private FilestoreUtil filestoreUtil;

    @Mock
    private FDSCloudSearchTermsTemplate fdsCloudSearchTermsTemplate;

    @InjectMocks
    private ProcessDocumentUtil processDocumentUtil;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testProcessDocument() throws URISyntaxException, InterruptedException, IOException {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "docId");
        requestMap.put("fdsCloudSpaceId", "spaceId");

        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());

        when(serviceUtil.getFDSCloudSearchTerms(anyString(), anyString(), anyString())).thenReturn(ResponseEntity.ok(new FDSCloudDocument()));

        Map<String, Object> result = processDocumentUtil.processDocument(requestMap, "cid");

        assertNotNull(result);
    }

    @Test
    public void testPostDocumentToFDSCloud() throws JsonProcessingException {
        String filePath = "testFilePath";
        Integer spaceId = 1;
        Document metadata = new Document();
        String cid = "testCid";

        FDSCloudDocument fdsCloudDocument = new FDSCloudDocument();
        fdsCloudDocument.setDocumentId("testDocumentId");
        DocumentAttachmentMetaData attachmentMetaData = new DocumentAttachmentMetaData();
        attachmentMetaData.setAttachmentId("testAttachmentId");
        fdsCloudDocument.setAttachments(Collections.singletonList(attachmentMetaData));

        ResponseEntity<FDSCloudDocument> responseEntity = new ResponseEntity<>(fdsCloudDocument, HttpStatus.OK);

        when(config.getCredentials(spaceId)).thenReturn(Map.of("fdsCloudSpaceId", "testSpaceId"));
        when(mapper.writeValueAsString(metadata)).thenReturn("metadataString");
        when(fdsCloudSearchTermsTemplate.getSearchTermsString(metadata, cid)).thenReturn("searchTermsString");
        when(filestoreService.postDocumentToFDSCloudWithAttachmentRetry(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(responseEntity);

        ResponseEntity<FDSCloudDocument> response = processDocumentUtil.postDocumentToFDSCloud(filePath, spaceId, metadata, cid);

        assertNotNull(response);
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().getDocumentId());
        assertNotNull(response.getBody().getAttachments());
        assertFalse(response.getBody().getAttachments().isEmpty());
        assertNotNull(response.getBody().getAttachments().get(0).getAttachmentId());
    }

    @Test
    public void testRunRequiredFieldRuleProcess() {
        DocumentMetaData document = new DocumentMetaData();
        Document metadata = new Document();
        metadata.put(Workflow.TIN, "tin");
        metadata.put("emailAlertReq", "N"); // Ensure this key is present to avoid NPE
        document.setMetadata(metadata);
        String cid = "cid";

        processDocumentUtil.runRequiredFieldRuleProcess(document, cid);

        assertNotNull(document.getMetadata());
        assertNotNull(document.getMetadata().get(Workflow.SEND_TO_DOCVAULT));
    }

    @Test(expected = RuntimeException.class)
    public void testProcessDocumentThrowsException() throws URISyntaxException, InterruptedException, IOException {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "docId");
        requestMap.put("fdsCloudSpaceId", "spaceId");

        // Mock the convertAndCreateDocument method to throw RuntimeException
        doThrow(new RuntimeException("Test exception"))
                .when(processDocumentUtil).convertAndCreateDocument(anyString(), anyString(), anyMap(), anyString());

        processDocumentUtil.processDocument(requestMap, "cid");
    }

    @Test
    public void testProcessDocumentWithValidData() throws URISyntaxException, InterruptedException, IOException {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "validDocId");
        requestMap.put("fdsCloudSpaceId", "validSpaceId");

        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());

        when(serviceUtil.getFDSCloudSearchTerms(anyString(), anyString(), anyString())).thenReturn(ResponseEntity.ok(new FDSCloudDocument()));

        Map<String, Object> result = processDocumentUtil.processDocument(requestMap, "cid");

        assertNotNull(result);
    }

    @Test
    public void testProcessDocumentWithInvalidData() throws URISyntaxException, InterruptedException, IOException {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "invalidDocId");
        requestMap.put("fdsCloudSpaceId", "invalidSpaceId");

        when(serviceUtil.getFDSCloudSearchTerms(anyString(), anyString(), anyString())).thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null));

        Map<String, Object> result = processDocumentUtil.processDocument(requestMap, "cid");

        assertTrue(result.isEmpty());
    }

    @Test
    public void testProcessDocumentWithNullData() throws URISyntaxException, InterruptedException, IOException {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", null);
        requestMap.put("fdsCloudSpaceId", null);

        Map<String, Object> result = processDocumentUtil.processDocument(requestMap, "cid");

        assertTrue(result.isEmpty());
    }

    @Test
    public void testUpdateDocumentWithFDSCloudResponse() {
        DocumentMetaData document = new DocumentMetaData();
        document.setMetadata(new Document());
        Integer spaceId = 1;
        String cid = "testCid";

        FDSCloudDocument fdsCloudDocument = new FDSCloudDocument();
        fdsCloudDocument.setDocumentId("testDocumentId");
        DocumentAttachmentMetaData attachmentMetaData = new DocumentAttachmentMetaData();
        attachmentMetaData.setAttachmentId("testAttachmentId");
        fdsCloudDocument.setAttachments(Collections.singletonList(attachmentMetaData));

        ResponseEntity<FDSCloudDocument> responseEntity = new ResponseEntity<>(fdsCloudDocument, HttpStatus.OK);

        when(config.getCredentials(spaceId)).thenReturn(Map.of("clientId", "123", "appIdentifier", "testApp"));
        // Mocking the fDSRetentionPeriod field directly
        processDocumentUtil.fDSRetentionPeriod = 30;

        processDocumentUtil.updateDocumentWithFDSCloudResponse(document, spaceId, responseEntity, cid);

        assertNotNull(document.getFdsDocumentId());
        assertEquals("testDocumentId", document.getFdsDocumentId());
        assertNotNull(document.getFsId());
        assertEquals("testAttachmentId", document.getFsId());
        assertEquals(MetaDataStatus.AVAILABLE, document.getStatus());
    }

    @Test
    public void testPostDocumentToFDSCloud_JsonProcessingException() throws JsonProcessingException {
        String filePath = "testFilePath";
        Integer spaceId = 1;
        Document metadata = new Document();
        String cid = "testCid";

        when(config.getCredentials(spaceId)).thenReturn(Map.of("fdsCloudSpaceId", "testSpaceId"));
        when(mapper.writeValueAsString(metadata)).thenThrow(new JsonProcessingException("Error") {});

        ResponseEntity<FDSCloudDocument> response = processDocumentUtil.postDocumentToFDSCloud(filePath, spaceId, metadata, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    public void testPostDocumentToDoc360_UsesConfigDocClassOnly() throws JsonProcessingException {
        String filePath = "testFilePath";
        Integer spaceId = 11502;
        String cid = "testCid";
        Document metadata = new Document();
        metadata.put("doc360DocumentType", "FROM_METADATA_DOCUMENT_TYPE");
        metadata.put("doc360DocClass", "FROM_METADATA_DOC_CLASS");

        Doc360UploadResponse doc360UploadResponse = new Doc360UploadResponse();
        doc360UploadResponse.setGlobalDocId("doc360-id");

        when(mapper.writeValueAsString(metadata)).thenReturn("metadataString");
        when(config.getDoc360DocClass(spaceId)).thenReturn("FROM_CONFIG");
        when(filestoreService.postDocumentToDoc360WithAttachmentRetry(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(ResponseEntity.ok(doc360UploadResponse));

        processDocumentUtil.postDocumentToDoc360(filePath, spaceId, metadata, cid);

        verify(filestoreService).postDocumentToDoc360WithAttachmentRetry("metadataString", filePath, "FROM_CONFIG", cid);
        verify(config).getDoc360DocClass(spaceId);
    }

    @Test
    public void testProcessFileUpload_UsesConfiguredUploadProviderOnly() throws JsonProcessingException {
        ProcessDocumentUtil spyUtil = spy(processDocumentUtil);
        Integer spaceId = 11502;
        String cid = "testCid";
        String fileName = "cap-letter.pdf";
        MultipartFile file = mock(MultipartFile.class);

        Document metadata = new Document();
        metadata.put("uploadProvider", "DOC360");

        Document convertedMetadata = new Document();
        doReturn(convertedMetadata)
                .when(spyUtil)
                .convertAndValidateMetadata(any(DocumentMetaData.class), eq(metadata), eq(spaceId), anyMap(), eq(cid));

        when(filestoreUtil.saveFileToIngest(eq(fileName), eq(file), eq(spaceId), anyString())).thenReturn("/tmp/cap-letter.pdf");
        when(config.getUploadProvider(spaceId)).thenReturn("FDS_CLOUD");
        when(config.getCredentials(spaceId)).thenReturn(Map.of("fdsCloudSpaceId", "space", "clientId", "123", "appIdentifier", "testApp"));
        when(mapper.writeValueAsString(metadata)).thenReturn("metadataString");
        when(fdsCloudSearchTermsTemplate.getSearchTermsString(metadata, cid)).thenReturn("searchTerms");

        FDSCloudDocument fdsCloudDocument = new FDSCloudDocument();
        fdsCloudDocument.setDocumentId("fds-doc-id");
        DocumentAttachmentMetaData attachmentMetaData = new DocumentAttachmentMetaData();
        attachmentMetaData.setAttachmentId("attachment-id");
        fdsCloudDocument.setAttachments(Collections.singletonList(attachmentMetaData));

        when(filestoreService.postDocumentToFDSCloudWithAttachmentRetry(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(ResponseEntity.ok(fdsCloudDocument));
        when(documentMetaDataService.saveDocumentMetaData(any(DocumentMetaData.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        spyUtil.fDSRetentionPeriod = 30;
        Map<String, Object> response = spyUtil.processFileUpload(fileName, file, metadata, spaceId, cid);

        verify(filestoreService).postDocumentToFDSCloudWithAttachmentRetry(anyString(), anyString(), anyString(), anyString(), anyString());
        verify(filestoreService, never()).postDocumentToDoc360WithAttachmentRetry(anyString(), anyString(), anyString(), anyString());
        assertFalse(response.containsKey("doc360DocumentId"));
    }

    @Test
    public void testRunRequiredFieldRuleProcess_EmailAlertReqNotN() {
        DocumentMetaData document = new DocumentMetaData();
        Document metadata = new Document();
        metadata.put(Workflow.TIN, "tin");
        metadata.put("emailAlertReq", "Y");
        document.setMetadata(metadata);
        String cid = "cid";

        processDocumentUtil.runRequiredFieldRuleProcess(document, cid);

        assertNotNull(document.getMetadata());
        assertNotNull(document.getMetadata().get(Workflow.SEND_TO_DOCVAULT));
    }

    @Test
    public void testGetErrEnumFromClientName() {
        // Valid client name
        String validClientName = "ValidClient";
        Class<?> result = processDocumentUtil.getErrEnumFromClientName(validClientName);

        String invalidClientName = "InvalidClient";
        result = processDocumentUtil.getErrEnumFromClientName(invalidClientName);
        assertNull("Expected null for an invalid client name", result);
    }

    @Test
    public void testGetClassFromClientName_InvalidClientName() {
        String invalidClientName = "InvalidClient";

        Class<?> result = processDocumentUtil.getClassFromClientName(invalidClientName);
        assertNull(result);
    }


    @Test
    public void testProcessDocument_ValidData() throws URISyntaxException, InterruptedException, IOException {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "docId");
        requestMap.put("fdsCloudSpaceId", "spaceId");

        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());
        documentMetaData.getMetadata().put(Workflow.SEND_TO_DOCVAULT, true);

        when(serviceUtil.getFDSCloudSearchTerms(anyString(), anyString(), anyString()))
                .thenReturn(ResponseEntity.ok(new FDSCloudDocument()));

        Map<String, Object> result = processDocumentUtil.processDocument(requestMap, "cid");

        assertNotNull(result);
    }


    @Test
    public void testProcessDocument_InvalidData() throws URISyntaxException, InterruptedException, IOException {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "invalidDocId");
        requestMap.put("fdsCloudSpaceId", "invalidSpaceId");

        when(serviceUtil.getFDSCloudSearchTerms(anyString(), anyString(), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null));

        Map<String, Object> result = processDocumentUtil.processDocument(requestMap, "cid");

        assertTrue(result.isEmpty());
    }


    @Test
    public void testUpdateDocumentWithFDSCloudResponse_ValidResponse() {
        DocumentMetaData document = new DocumentMetaData();
        document.setMetadata(new Document());
        Integer spaceId = 1;
        String cid = "testCid";

        FDSCloudDocument fdsCloudDocument = new FDSCloudDocument();
        fdsCloudDocument.setDocumentId("testDocumentId");

        ResponseEntity<FDSCloudDocument> responseEntity = new ResponseEntity<>(fdsCloudDocument, HttpStatus.OK);


        if (responseEntity.getBody() != null && responseEntity.getBody().getAttachments() != null && !responseEntity.getBody().getAttachments().isEmpty()) {
            document.setFsId(responseEntity.getBody().getAttachments().get(0).getAttachmentId());

            processDocumentUtil.updateDocumentWithFDSCloudResponse(document, spaceId, responseEntity, cid);
        }
        assertEquals("testDocumentId", fdsCloudDocument.getDocumentId());
    }





  @Test
  public void testUpdateDocumentWithDoc360Response() {
    DocumentMetaData document = new DocumentMetaData();
    document.setMetadata(new Document());
    Integer spaceId = 11502;
    String cid = "testCid";

    Doc360UploadResponse body = new Doc360UploadResponse();
    body.setGlobalDocId("doc360-123");

    when(config.getCredentials(spaceId)).thenReturn(Map.of("clientId", "123", "appIdentifier", "testApp"));
    when(config.getDoc360DocClass(spaceId)).thenReturn("CAP_LETTER");
    processDocumentUtil.fDSRetentionPeriod = 30;

    processDocumentUtil.updateDocumentWithDoc360Response(document, spaceId, new ResponseEntity<>(body, HttpStatus.OK), cid);

    assertEquals("doc360-123", document.getDoc360DocumentId());
    assertEquals("CAP_LETTER", document.getDoc360DocClass());
    assertEquals(MetaDataStatus.AVAILABLE, document.getStatus());
  }

  @Test
  public void testUpdateDocumentWithDoc360Response_Failure() {
    DocumentMetaData document = new DocumentMetaData();
    document.setMetadata(new Document());
    Integer spaceId = 11503;
    String cid = "testCid";

    when(config.getCredentials(spaceId)).thenReturn(Map.of("clientId", "123", "appIdentifier", "testApp"));
    processDocumentUtil.fDSRetentionPeriod = 30;

    processDocumentUtil.updateDocumentWithDoc360Response(document, spaceId,
        ResponseEntity.status(HttpStatus.BAD_GATEWAY).body((Doc360UploadResponse) null), cid);

    assertEquals(MetaDataStatus.STORAGE_ERROR, document.getStatus());
  }

}