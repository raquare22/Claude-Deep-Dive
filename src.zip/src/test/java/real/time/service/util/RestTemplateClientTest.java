package real.time.service.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import real.time.service.mongo.FDSCloudDocument;

import java.net.URI;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

public class RestTemplateClientTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private RestTemplateClient restTemplateClient;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testPutExchangeWithRetry_Success() throws Exception {
        URI uri = new URI("http://example.com");
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Object> request = new HttpEntity<>(headers);
        ResponseEntity<FDSCloudDocument> responseEntity = ResponseEntity.ok(new FDSCloudDocument());

        when(restTemplate.exchange(uri, HttpMethod.PUT, request, FDSCloudDocument.class)).thenReturn(responseEntity);

        ResponseEntity<FDSCloudDocument> response = restTemplateClient.putExchangeWithRetry(uri, HttpMethod.PUT, request);

        assertNotNull(response);
        assertEquals(responseEntity, response);
    }

    @Test(expected = RestClientException.class)
    public void testPutExchangeWithRetry_Failure() throws Exception {
        URI uri = new URI("http://example.com");
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Object> request = new HttpEntity<>(headers);

        when(restTemplate.exchange(uri, HttpMethod.PUT, request, FDSCloudDocument.class)).thenThrow(new RestClientException("Error"));

        restTemplateClient.putExchangeWithRetry(uri, HttpMethod.PUT, request);
    }


    @Test
    public void testRecoverMethod() {
        RetryException retryException = new RetryException("Retry failed");

        restTemplateClient.recover(retryException);

        assertEquals(1, RestTemplateClient.totalFailureCnt);
    }
}
