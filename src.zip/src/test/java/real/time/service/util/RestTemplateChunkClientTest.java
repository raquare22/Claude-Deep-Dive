package real.time.service.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.net.URI;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import real.time.service.mongo.FDSCloudDocument;

@RunWith(MockitoJUnitRunner.class)
public class RestTemplateChunkClientTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private RestTemplateChunkClient restTemplateChunkClient;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testPutExchangeWithRetry_Success() throws Exception {
        URI uri = new URI("http://example.com");
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Object> request = new HttpEntity<>(headers);
        ResponseEntity<FDSCloudDocument> responseEntity = ResponseEntity.ok(new FDSCloudDocument());

        when(restTemplate.exchange(uri, HttpMethod.PUT, request, FDSCloudDocument.class)).thenReturn(responseEntity);

        ResponseEntity<FDSCloudDocument> response = restTemplateChunkClient.putExchangeWithRetry(uri, HttpMethod.PUT, request);

        assertNotNull(response);
        assertEquals(responseEntity, response);
    }

    @Test(expected = RestClientException.class)
    public void testPutExchangeWithRetry_Failure() throws Exception {
        URI uri = new URI("http://example.com");
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Object> request = new HttpEntity<>(headers);

        when(restTemplate.exchange(uri, HttpMethod.PUT, request, FDSCloudDocument.class)).thenThrow(new RestClientException("Error"));

        restTemplateChunkClient.putExchangeWithRetry(uri, HttpMethod.PUT, request);
    }

    @Test
    public void testRecover() {
        RetryException exception = new RetryException("Error");
        int initialFailureCount = RestTemplateChunkClient.totalFailureCnt;

        restTemplateChunkClient.recover(exception);

        assertEquals(initialFailureCount + 1, RestTemplateChunkClient.totalFailureCnt);
    }
}