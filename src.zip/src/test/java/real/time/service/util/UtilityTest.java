package real.time.service.util;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.function.Function;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;

public class UtilityTest {

    @Mock
    private Function<String, String> envFunctionMock;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        UtilityWrapper.setEnvFunction(envFunctionMock);
        setActiveProfile("testProfile");
    }

    private void setActiveProfile(String profile) {
        try {
            java.lang.reflect.Field field = Utility.class.getDeclaredField("activeProfile");
            field.setAccessible(true);
            field.set(null, profile);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Test
    public void testGetEnvironment_ReturnsMatchingEnvironment() {
        when(envFunctionMock.apply(anyString())).thenReturn("local");

        String environment = UtilityWrapper.getEnvironment();

        assertEquals("local", environment);
    }

    @Test
    public void testGetEnvironment_ReturnsLocalWhenEnvIsNull() {
        when(envFunctionMock.apply(anyString())).thenReturn(null);

        String environment = UtilityWrapper.getEnvironment();

        assertEquals("local", environment);
    }



    @Test
    public void testGetEnvironment_ReturnsLocalWhenEnvDoesNotMatch() {
        when(envFunctionMock.apply(anyString())).thenReturn("unknown");

        String environment = UtilityWrapper.getEnvironment();

        assertEquals("local", environment);
    }
}

class UtilityWrapper {
    private static Function<String, String> envFunction = Utility.envFunction;

    public static void setEnvFunction(Function<String, String> envFunction) {
        UtilityWrapper.envFunction = envFunction;
    }

    public static String getEnvironment() {
        return Utility.getEnvironment();
    }
}