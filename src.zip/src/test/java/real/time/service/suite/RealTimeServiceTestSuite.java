package real.time.service.suite;

import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


import real.time.service.EhCacheTest;
import real.time.service.RealTimeServiceApplicationTest;
import real.time.service.config.ConfigDataTest;
import real.time.service.config.RestTemplateConfigTest;
import real.time.service.controller.RealTimeServiceControllerTest;
import real.time.service.controller.RootControllerTest;
import real.time.service.document.response.util.DocumentResponseUtilTest;
import real.time.service.document.util.AttachmentTest;
import real.time.service.document.util.RulesTest;
import real.time.service.domain.service.DocumentMetaDataServiceImplTest;
import real.time.service.domain.service.FilestoreServiceImplTest;
import real.time.service.email.EmailSenderTest;
import real.time.service.email.EmailServiceImplTest;
import real.time.service.email.EmailServiceTest;
import real.time.service.exception.ErrorCodeTest;
import real.time.service.exception.HttpServerExceptionTest;
import real.time.service.exception.ProcessExceptionTest;
import real.time.service.exception.PrunExceptionTest;
import real.time.service.java.delegate.docvault.OutOfRetriesExceptionTest;
import real.time.service.java.delegate.docvault.RetryOnExceptionHandlerTest;
import real.time.service.model.Doc360UploadResponseTest;
import real.time.service.model.MultiPutResponseTest;
import real.time.service.model.PingTest;
import real.time.service.mongo.AttachmentMetaDataTest;
import real.time.service.mongo.DocumentAttachmentMetaDataTest;
import real.time.service.mongo.DocumentMetaDataTest;
import real.time.service.mongo.FDSCloudDocumentTest;
import real.time.service.mongo.file.metadata.PostCardIndTest;
import real.time.service.mongo.processors.MetaDataTest;
import real.time.service.ness.KafkaConfigTest;
import real.time.service.ness.KafkaProducerTest;
import real.time.service.oauth.AuthorizationOauthProviderTest;
import real.time.service.oauth.OauthManagerUtilImplTest;
import real.time.service.oauth.TokenTest;
import real.time.service.pojo.*;
import real.time.service.provider.pojo.*;
import real.time.service.revision.AttachmentRevisionTest;
import real.time.service.revision.DocumentRevisionTest;
import real.time.service.revision.RevisionTest;
import real.time.service.template.java.impl.ElgsMetadataValidationRequestTemplateTest;
import real.time.service.template.java.impl.FDSCloudSearchTermsTemplateTest;
import real.time.service.template.java.impl.FilterReqFieldForDocvaultTemplateTest;
import real.time.service.template.java.renderer.CustomStringRendererTest;
import real.time.service.util.*;
import real.time.service.workflow.util.WorkFlowUtilTest;
import real.time.service.workflow.constants.WorkflowTest;

@RunWith(Suite.class)

@Suite.SuiteClasses({
		ConfigDataTest.class,
		RestTemplateConfigTest.class,
		RealTimeServiceControllerTest.class,
		RootControllerTest.class,
		DocumentResponseUtilTest.class,
		AttachmentTest.class,
		RulesTest.class,
		DocumentMetaDataServiceImplTest.class,
		//FilestoreServiceImplTest.class,
		FilestoreServiceImplTest.class,
		EmailSenderTest.class,
		ErrorCodeTest.class,
		HttpServerExceptionTest.class,
		ProcessExceptionTest.class,
		PrunExceptionTest.class,
		RetryOnExceptionHandlerTest.class,
		EmailServiceImplTest.class,
		EmailServiceTest.class,
		OutOfRetriesExceptionTest.class,
		PingTest.class,
		PostCardIndTest.class,
		MetaDataTest.class,
		AttachmentMetaDataTest.class,
		DocumentAttachmentMetaDataTest.class,
		DocumentMetaDataTest.class,
		KafkaConfigTest.class,
		AuthorizationOauthProviderTest.class,
		TokenTest.class,
		CAPMetadataTest.class,
		OCMMetadataTest.class,
		ClientMetadataTest.class,
		ClientRootMetadataTest.class,
		CustomDateSerializerTest.class,
		CustomizeDateDeserializerTest.class,
		IndexFieldTest.class,
		AddressDataTest.class,
		AddressTest.class,
		ContractInformationTypeTest.class,
		CorpOwnerInformationTypeTest.class,
		DegreeTest.class,
		EntityInformationTypeTest.class,
		MetadataTest.class,
		NpiTest.class,
		NpiTypeTest.class,
		OrganizationTest.class,
		PhoneTest.class,
		PhysicianFacilityInformationTest.class,
		PhysicianFacilityTest.class,
		ProviderSearchResultsTest.class,
		ProviderTest.class,
		QualityTypeTest.class,
		RecordsTest.class,
		RequestTest.class,
		RosterdataTest.class,
		SpecialtyTest.class,
		SpecialtyTypeTest.class,
		SvcResponseTest.class,
		TaxIdTest.class,
		TaxIdTypeTest.class,
		UhpdDateRangeTypeTest.class,
		UhpdTypeTest.class,
		UnetContractTest.class,
		AttachmentRevisionTest.class,
		DocumentRevisionTest.class,
		RevisionTest.class,
		ElgsMetadataValidationRequestTemplateTest.class,
		CorporateMpinUtilTest.class,
		FilestoreUtilTest.class,
		GenericResponseTest.class,
		RetryUtilTest.class,
		SanitizeUtilTest.class,
		UtilityTest.class,
		HttpUtilsTest.class,
		DocLibUtilTest.class,
		FDSCloudDocumentTest.class,
		EnvironmentsTest.class,
		FDSCloudSearchTermsTemplateTest.class,
//		KafkaProducerTest.class,
		ProcessDocumentUtilTest.class,
		RestTemplateChunkClientTest.class,
		WorkFlowUtilTest.class,
		RealTimeServiceApplicationTest.class,
		RequestHeaderTest.class,
		RequestBodyTest.class,
		WorkflowTest.class,
		ParserTest.class,
		CustomStringRendererTest.class,
		FilterReqFieldForDocvaultTemplateTest.class,
		OauthManagerUtilImplTest.class,
		ServiceUtilTest.class,
		WebClientSyncTest.class,
		EhCacheTest.class,
		DocumentUtilTest.class,
		Doc360UploadResponseTest.class,
		MultiPutResponseTest.class

	
})

public class RealTimeServiceTestSuite extends TestCase {}