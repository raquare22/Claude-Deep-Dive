package real.time.service.email;

import jakarta.mail.internet.MimeMessage;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class EmailServiceImplTest {

    private EmailServiceImpl emailService;

    @Mock
    private JavaMailSender javaMailSender;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        emailService = new EmailServiceImpl(javaMailSender);
    }

    @Test
    public void testSendEmail_Success() {
        when(javaMailSender.createMimeMessage()).thenReturn(mock(MimeMessage.class));
        boolean result = emailService.sendEmail("sender@example.com", "receiver@example.com", "Test Subject", "Test Message");
        assertTrue(result);
    }

    @Test
    public void testSendEmail_MultipleRecipients() {
        when(javaMailSender.createMimeMessage()).thenReturn(mock(MimeMessage.class));
        boolean result = emailService.sendEmail("sender@example.com", "{receiver1@example.com;receiver2@example.com}", "Test Subject", "Test Message");
        assertTrue(result);
    }


    @Test
    public void testParseEmailReceiver() {
        String[] result = emailService.parseEmailReceiver("{receiver1@example.com;receiver2@example.com}");
        assertArrayEquals(new String[]{"receiver1@example.com", "receiver2@example.com"}, result);
    }

    @Test
    public void testSendEmail_MultipleReceivers() {
        JavaMailSender mockJavaMailSender = mock(JavaMailSender.class);
        EmailServiceImpl emailService = new EmailServiceImpl(mockJavaMailSender);

        String multipleReceivers = "{receiver1@example.com; receiver2@example.com}";
        boolean result = emailService.sendEmail("sender@example.com", multipleReceivers, "Test Subject", "Test Message");

        assertTrue(result);
    }

    @Test
    public void testSendEmail_Exception() {
        // Create a mock for JavaMailSender
        JavaMailSender javaMailSender = mock(JavaMailSender.class);
        EmailServiceImpl emailService = new EmailServiceImpl(javaMailSender);

        try (MockedStatic<EmailSender> mockedStatic = Mockito.mockStatic(EmailSender.class)) {
            // Configure the static EmailSender.sendMail to throw an exception

            // Configure the static EmailSender.sendMail to throw an exception for the single recipient overload
            mockedStatic.when(() -> EmailSender.sendMail(anyString(), anyString(), anyString(), anyString(), any(JavaMailSender.class)))
                    .thenThrow(new RuntimeException("Simulated exception"));

            // Call sendEmail, which should catch the exception and return false
            boolean result = emailService.sendEmail("sender@example.com", "receiver@example.com", "Test Subject", "Test Message");
            assertFalse(result);
        }
    }

    @Test(expected = MailSendException.class)
    public void testSendMail_catchBlock() throws Exception {
        // Force the JavaMailSender to throw an exception to trigger the catch block
        JavaMailSender javaMailSender = mock(JavaMailSender.class);
        Mockito.doThrow(new MailSendException("Send email failed"))
                .when(javaMailSender)
                .send(Mockito.any(SimpleMailMessage.class));

        // Call the method under test, which should throw the MailSendException
        EmailSender.sendMail("sender@example.com", "recipient@example.com", "Unit Test", "msg", javaMailSender);
    }


}