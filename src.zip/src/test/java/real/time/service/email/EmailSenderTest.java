package real.time.service.email;

import jakarta.mail.internet.MimeMessage;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessagePreparator;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;


public class EmailSenderTest {


	private ArgumentCaptor<MimeMessagePreparator> preparatorArgumentCaptor;
	private MimeMessage mimeMessage;

	EmailSender emailSender;

	@Mock
	JavaMailSender mailSender;

	@Before
	public void setup() {
		MockitoAnnotations.openMocks(this);
		preparatorArgumentCaptor = ArgumentCaptor.forClass(MimeMessagePreparator.class);
		Mockito.doNothing().when(mailSender).send(preparatorArgumentCaptor.capture());
		mimeMessage = new JavaMailSenderImpl().createMimeMessage();
	}

	@Test
	public void sendMailTest() throws Exception {
		Mockito.doNothing().when(mailSender).send(Mockito.any(SimpleMailMessage.class));
		emailSender.sendMail("doe.john@optum.com", "doe.john@optum.com", "Unit Test", "msg", mailSender);
		Mockito.verify(mailSender).send(Mockito.any(SimpleMailMessage.class));
	}

	@Test(expected=MailSendException.class)
	public void sendMailTestWithException() throws Exception, MailSendException {
		Mockito.doThrow(new MailSendException("Send email failed")).when(mailSender).send(Mockito.any(SimpleMailMessage.class));
		emailSender.sendMail("doe.john@optum.com", "doe.john@optum.com", "Unit Test", "msg", mailSender);
		Mockito.verify(mailSender).send(Mockito.any(SimpleMailMessage.class));
	}


	@Test
	public void sendMailWithAttachmentsTest() throws Exception {
		Mockito.doNothing().when(mailSender).send(Mockito.any(MimeMessage.class));
		Mockito.when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
		List<File> attachments = new ArrayList<>();
		File file =  new File("/src/test/resources/sendmail/sendemail.pdf");
		attachments.add(file);
		emailSender.sendMailWithAttachments("john_doe@optum.com", "john_doe@optum.com", "Unit Test", "msg",attachments, mailSender);
	}

	@Test
	public void sendMailWithMultipleRecipientsTest() throws Exception {
		Mockito.doNothing().when(mailSender).send(Mockito.any(SimpleMailMessage.class));
		String[] recipients = {"doe.john@optum.com", "jane.doe@optum.com"};
		emailSender.sendMail("doe.john@optum.com", recipients, "Unit Test", "msg", mailSender);
		Mockito.verify(mailSender).send(Mockito.any(SimpleMailMessage.class));
	}

	@Test
	public void sendMailWithAttachmentsNoAttachmentsTest() throws Exception {
		Mockito.doNothing().when(mailSender).send(Mockito.any(MimeMessage.class));
		Mockito.when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
		emailSender.sendMailWithAttachments("john_doe@optum.com", "john_doe@optum.com", "Unit Test", "msg", null, mailSender);
		Mockito.verify(mailSender).send(Mockito.any(MimeMessage.class));
	}

	@Test(expected = MailSendException.class)
	public void sendMailWithAttachmentsTestWithException() throws Exception {
		Mockito.doThrow(new MailSendException("Send email failed")).when(mailSender).send(Mockito.any(MimeMessage.class));
		Mockito.when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
		List<File> attachments = new ArrayList<>();
		attachments.add(new File("/src/test/resources/sendmail/sendemail.pdf"));
		emailSender.sendMailWithAttachments("john_doe@optum.com", "john_doe@optum.com", "Unit Test", "msg", attachments, mailSender);
	}



	@Test(expected = MailSendException.class)
	public void testSendMailThrowsException() throws Exception {
		// Throw exception to test catch block for sendMail with single recipient
		Mockito.doThrow(new MailSendException("Failure")).when(mailSender).send(Mockito.any(SimpleMailMessage.class));
		EmailSender.sendMail("sender@domain.com", "recipient@domain.com", "Subject", "Message", mailSender);
	}


	@Test
	public void testPrivateConstructor() throws Exception {
		// Use reflection to call the private constructor and assert that it throws the exception.
		Constructor<EmailSender> constructor = EmailSender.class.getDeclaredConstructor();
		constructor.setAccessible(true);
		try {
			constructor.newInstance();
			fail("Expected InvocationTargetException due to IllegalStateException");
		} catch (InvocationTargetException e) {
			// Verify that the cause is the IllegalStateException with expected message.
			Throwable cause = e.getCause();
			assertEquals("Utility class", cause.getMessage());
		}
	}

	@Test(expected = MailSendException.class)
	public void testSendMail_catchBlock() throws Exception {
		// Force the JavaMailSender to throw an exception to trigger the catch block
		Mockito.doThrow(new MailSendException("Send email failed"))
				.when(mailSender)
				.send(Mockito.any(SimpleMailMessage.class));

		// Call the method under test, which should throw the MailSendException
		EmailSender.sendMail("sender@example.com", "recipient@example.com", "Unit Test", "msg", mailSender);
	}

}
