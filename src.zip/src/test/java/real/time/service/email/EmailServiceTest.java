package real.time.service.email;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class EmailServiceTest {

    private EmailService emailService;

    @Before
    public void setUp() {
        emailService = mock(EmailService.class);
    }

    @Test
    public void testSendEmail() {
        when(emailService.sendEmail("sender@example.com", "receiver@example.com", "Test Subject", "Test Message")).thenReturn(true);

        boolean result = emailService.sendEmail("sender@example.com", "receiver@example.com", "Test Subject", "Test Message");
        assertTrue(result);

        verify(emailService).sendEmail("sender@example.com", "receiver@example.com", "Test Subject", "Test Message");
    }
}