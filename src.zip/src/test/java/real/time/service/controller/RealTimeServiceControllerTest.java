package real.time.service.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;
import real.time.service.config.ConfigData;
import real.time.service.domain.service.DocumentMetaDataService;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.util.GenericResponse;
import real.time.service.util.ProcessDocumentUtil;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class RealTimeServiceControllerTest {

    @Mock
    private Logger logger;

    @Mock
    private ProcessDocumentUtil processDocumentUtil;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private ConfigData config;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private RealTimeServiceController realTimeServiceController = new RealTimeServiceController(100, 100);

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    HttpHeaders headers = new HttpHeaders();

    @Test
    public void testProcessFileUpload_Success() throws Exception {

    	Path path = Paths.get("src/test/resources/1412123657_1412123660.pdf");


    	 if (!Files.exists(path)) {
             System.err.println("File not found: " + path.toAbsolutePath());
             return;
         }


    	String name = "1412123657_1412123660";
        String originalFileName = "1412123657_1412123660.pdf";
        String contentType = "application/pdf";
        byte[] content = Files.readAllBytes(path);

        MultipartFile file = new MockMultipartFile(name, originalFileName, contentType, content);

        String metadata = "{\"key\":\"value\"}";
        String spaceId = "123";

        Document metadataJson = Document.parse(metadata);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("documentStatus", "SUCCESS");

        when(processDocumentUtil.processFileUpload(anyString(), any(MultipartFile.class), any(Document.class), anyInt(), anyString()))
                .thenReturn(responseMap);


        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processFileUpload(headers, file, metadata, spaceId, "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(responseMap, response.getBody());
    }

    @Test
    public void testProcessFileUpload_InvalidRequest() {
        MultipartFile file = null;
        String metadata = null;
        String spaceId = null;

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processFileUpload(headers, file, metadata, spaceId, "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Null or invalid request", response.getBody().get("error"));
    }

    @Test
    public void testProcessDocument_Success() throws Exception {
        String requestBody = "{\"fdsCloudDocumentId\":\"123\", \"fdsCloudSpaceId\":\"456\"}";
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "123");
        requestMap.put("fdsCloudSpaceId", "456");

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("status", "success");

        doReturn(requestMap).when(objectMapper).readValue(requestBody, HashMap.class);
        when(processDocumentUtil.processDocument(any(), anyString())).thenReturn(responseMap);

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processDocument(headers, requestBody, "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(responseMap, response.getBody());
    }

    @Test
    public void testProcessDocument_InvalidJson() throws Exception {
        String requestBody = "invalid json";

        when(objectMapper.readValue(requestBody, HashMap.class)).thenThrow(new JsonProcessingException("Invalid JSON") {});

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processDocument(headers, requestBody, "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Invalid JSON format", response.getBody().get("error"));
    }

    @Test
    public void testProcessDocument_EmptyRequestBody() {
        String requestBody = "";

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processDocument(headers, requestBody, "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Request body is empty", response.getBody().get("error"));
    }

    @Test
    public void testProcessFileUpload_RateLimitExceeded() {
        // Simulate rate limit exceeded
        for (int i = 0; i < 101; i++) {
            realTimeServiceController.processFileUpload(headers, mock(MultipartFile.class), "{}", "123", "optum-cid-ext");
        }

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processFileUpload(headers, mock(MultipartFile.class), "{}", "123", "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
    }

    @Test
    public void testProcessFileUpload_InvalidFileName() throws Exception {
        MultipartFile file = mock(MultipartFile.class);
        when(file.getOriginalFilename()).thenReturn("../invalid.txt");

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processFileUpload(headers, file, "{\"key\":\"value\"}", "123", "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE, response.getStatusCode());
        assertEquals("Invalid file type", response.getBody().get("error"));
    }

    @Test
    public void testProcessFileUpload_InternalServerError() throws Exception {
        MultipartFile file = mock(MultipartFile.class);
        when(file.getOriginalFilename()).thenReturn("testfile.txt");

        doThrow(new RuntimeException("Test Exception")).when(processDocumentUtil).processFileUpload(anyString(), any(MultipartFile.class), any(Document.class), anyInt(), anyString());

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processFileUpload(headers, file, "{\"key\":\"value\"}", "123", "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE, response.getStatusCode());
        assertEquals("Invalid file type", response.getBody().get("error"));
    }

    @Test
    public void testProcessDocument_RateLimitExceeded() {
        // Simulate rate limit exceeded
        for (int i = 0; i < 101; i++) {
            realTimeServiceController.processDocument(headers, "{\"fdsCloudDocumentId\":\"123\", \"fdsCloudSpaceId\":\"456\"}", "optum-cid-ext");
        }

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processDocument(headers, "{\"fdsCloudDocumentId\":\"123\", \"fdsCloudSpaceId\":\"456\"}", "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
    }

    @Test
    public void testProcessDocument_EmptyResponseMap() throws Exception {
        String requestBody = "{\"fdsCloudDocumentId\":\"123\", \"fdsCloudSpaceId\":\"456\"}";
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "123");
        requestMap.put("fdsCloudSpaceId", "456");

        doReturn(requestMap).when(objectMapper).readValue(requestBody, HashMap.class);
        when(processDocumentUtil.processDocument(any(), anyString())).thenReturn(new HashMap<>());

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processDocument(headers, requestBody, "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Invalid FDS Document Id/SpaceId", response.getBody().get("error"));
    }

    @Test
    public void testProcessDocument_InternalServerError() throws Exception {
        String requestBody = "{\"fdsCloudDocumentId\":\"123\", \"fdsCloudSpaceId\":\"456\"}";
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("fdsCloudDocumentId", "123");
        requestMap.put("fdsCloudSpaceId", "456");

        doReturn(requestMap).when(objectMapper).readValue(requestBody, HashMap.class);
        when(processDocumentUtil.processDocument(any(), anyString())).thenThrow(new RuntimeException("Test Exception"));

        ResponseEntity<Map<String, Object>> response = realTimeServiceController.processDocument(headers, requestBody, "optum-cid-ext");

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Internal server error", response.getBody().get("error"));
    }

    @Test
    public void testIsInvalidSpaceId_NumberFormatException() throws Exception {
        RealTimeServiceController controller = new RealTimeServiceController(100, 100);
        Method method = RealTimeServiceController.class.getDeclaredMethod("isInvalidSpaceId", String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(controller, "123abc");
        assertTrue(result); // Expecting true because the input is invalid
    }

    @Test
    public void testInsertDocumentForBouncedEmail_Success() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        String jsonStr = "{\"spaceId\":1}";
        DocumentMetaData metaData = new DocumentMetaData();
        metaData.setSpaceId(1);

        when(objectMapper.readValue(jsonStr, DocumentMetaData.class)).thenReturn(metaData);

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "123");
        creds.put("appIdentifier", "appId");
        when(config.getCredentials(1)).thenReturn(creds);

        ResponseEntity<GenericResponse> response = realTimeServiceController.insertDocumentForBouncedEmail(headers, jsonStr, "cid");
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(documentMetaDataService, times(1)).saveDocumentMetaData(metaData);
    }

    @Test
    public void testInsertDocumentForBouncedEmail_EmptyRequest() {
        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<GenericResponse> response = realTimeServiceController.insertDocumentForBouncedEmail(headers, "", "cid");
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }


    @Test
    public void testInsertDocumentForBouncedEmail_InternalServerError() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        String jsonStr = "{\"spaceId\":1}";
        when(objectMapper.readValue(jsonStr, DocumentMetaData.class)).thenThrow(new RuntimeException("Test Exception"));

        ResponseEntity<GenericResponse> response = realTimeServiceController.insertDocumentForBouncedEmail(headers, jsonStr, "cid");
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

}