package real.time.service.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

public class RootControllerTest {

    private MockMvc mockMvc;
    private RootController rootController;

    @Before
    public void setUp() {
        rootController = new RootController();
        mockMvc = MockMvcBuilders.standaloneSetup(rootController).build();
    }

    @Test
    public void testHealthCheck() throws Exception {
        String response = rootController.healthCheck();
        assertEquals("ppl real time service is up and running", response);
    }
}