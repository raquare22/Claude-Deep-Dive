package real.time.service.config;

import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
public class ConfigDataTest {

    @InjectMocks
    private ConfigData configData;

    @Before
    public void setUp() throws Exception {
        ReflectionTestUtils.setField(configData, "fdsCloudSpaceIdMap", "{}");
        ReflectionTestUtils.setField(configData, "OCM_configcredentials", "{\"1\": {\"clientName\": \"OCM\"}}");
        ReflectionTestUtils.setField(configData, "CAP_configcredentials", "{}");
        ReflectionTestUtils.setField(configData, "OTHER_configcredentials", "{}");

        Method setCredentialsMethod = ConfigData.class.getDeclaredMethod("setCredentials");
        setCredentialsMethod.setAccessible(true);
        setCredentialsMethod.invoke(configData);
    }

    @Test
    public void testGetCredentials() {
        Map<String, Object> credentials = configData.getCredentials(1);
        assertNotNull(credentials);
    }

    @Test
    public void testGetClientNameFromSpaceId() {
        String clientName = configData.getClientNameFromSpaceId(1);
        assertEquals("OCM", clientName);
    }

    @Test
    public void testGetUploadProvider_DefaultWhenMissingInCredentials() {
        assertEquals("FDS_CLOUD", configData.getUploadProvider(1));
    }

    @Test
    public void testGetUploadProvider_DefaultWhenSpaceIdNotFound() {
        assertEquals("FDS_CLOUD", configData.getUploadProvider(999));
    }

    @Test
    public void testGetUploadProvider_NormalizesConfiguredValue() throws Exception {
        ReflectionTestUtils.setField(configData, "CAP_configcredentials", "{\"2\": {\"clientName\": \"CAP\", \"uploadProvider\": \" doc360 \"}}");
        Method setCredentialsMethod = ConfigData.class.getDeclaredMethod("setCredentials");
        setCredentialsMethod.setAccessible(true);
        setCredentialsMethod.invoke(configData);

        assertEquals("DOC360", configData.getUploadProvider(2));
    }

    @Test
    public void testGetDoc360DocClass_DefaultWhenMissingInCredentials() {
        assertEquals("", configData.getDoc360DocClass(1));
    }

    @Test
    public void testGetDoc360DocClass_DefaultWhenSpaceIdNotFound() {
        assertEquals("", configData.getDoc360DocClass(999));
    }

    @Test
    public void testGetDoc360DocClass_ReturnsConfiguredValue() throws Exception {
        ReflectionTestUtils.setField(configData, "OTHER_configcredentials", "{\"3\": {\"clientName\": \"OTHER\", \"doc360DocClass\": \"CAP_LETTER\"}}");
        Method setCredentialsMethod = ConfigData.class.getDeclaredMethod("setCredentials");
        setCredentialsMethod.setAccessible(true);
        setCredentialsMethod.invoke(configData);

        assertEquals("CAP_LETTER", configData.getDoc360DocClass(3));
    }

    @Test
    public void testGetClientMapFromFdsCloudSpaceId() {
        Map<String, Object> clientMap = configData.getClientMapFromFdsCloudSPaceId("someId");
        assertNull(clientMap);
    }

    @Test
    public void testSetCredentials() throws Exception {
        Method setCredentialsMethod = ConfigData.class.getDeclaredMethod("setCredentials");
        setCredentialsMethod.setAccessible(true);
        setCredentialsMethod.invoke(configData);
        assertFalse(configData.getCredentials(1).isEmpty());
    }

    @Test
    public void testGetClientMapFromFdsCloudSpaceIdWithValidId() {
        ReflectionTestUtils.setField(configData, "fdsCloudSpaceIdMap", "{\"someId\": {\"key\": \"value\"}}");
        Map<String, Object> clientMap = configData.getClientMapFromFdsCloudSPaceId("someId");
        assertNotNull(clientMap);
        assertEquals("value", clientMap.get("key"));
    }

    @Test
    public void testGetClientMapFromFdsCloudSpaceIdWithInvalidId() {
        ReflectionTestUtils.setField(configData, "fdsCloudSpaceIdMap", "{\"someId\": {\"key\": \"value\"}}");
        Map<String, Object> clientMap = configData.getClientMapFromFdsCloudSPaceId("invalidId");
        assertNull(clientMap);
    }
}