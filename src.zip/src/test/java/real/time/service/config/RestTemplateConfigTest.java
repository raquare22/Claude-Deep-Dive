package real.time.service.config;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.web.client.RestTemplate;
import org.springframework.test.util.ReflectionTestUtils;

public class RestTemplateConfigTest {

    private RestTemplateConfig restTemplateConfig;

    @Before
    public void setUp() {
        restTemplateConfig = new RestTemplateConfig();
        ReflectionTestUtils.setField(restTemplateConfig, "chunkSize", 5000000);
    }

    @Test
    public void testRestTemplate() {
        RestTemplate restTemplate = restTemplateConfig.restTemplate();
        assertNotNull(restTemplate);
    }

    @Test
    public void testRestTemplates() {
        RestTemplate restTemplateChunk = restTemplateConfig.restTemplates();
        assertNotNull(restTemplateChunk);
    }

    @Test
    public void testChunkSize() {
        int expectedChunkSize = 5000000; // default value
        assertEquals(expectedChunkSize, restTemplateConfig.chunkSize);
    }
}