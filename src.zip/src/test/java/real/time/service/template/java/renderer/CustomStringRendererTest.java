package real.time.service.template.java.renderer;

import org.junit.Before;
import org.junit.Test;
import org.stringtemplate.v4.StringRenderer;

import java.util.Locale;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class CustomStringRendererTest {

    private CustomStringRenderer renderer;

    @Before
    public void setUp() {
        renderer = new CustomStringRenderer();
    }

    @Test
    public void testToStringWithNullFormatString() {
        String input = "testString";
        String result = renderer.toString(input, null, Locale.getDefault());
        assertEquals(input, result);
    }

    @Test
    public void testToStringWithEmptyFormatString() {
        String input = "testString";
        String result = renderer.toString(input, "", Locale.getDefault());
        assertEquals(input, result);
    }

    @Test
    public void testSubStringHandler() {
        String input = "testString";
        String formatString = "s-2-6";
        String result = renderer.toString(input, formatString, Locale.getDefault());
        assertEquals("stSt", result);
    }

    @Test
    public void testSubStringHandlerWithInvalidIndexes() {
        String input = "testString";
        String formatString = "s-20-30";
        String result = renderer.toString(input, formatString, Locale.getDefault());
        assertEquals("", result);
    }

    @Test
    public void testMyStringHandlerLeftPadding() {
        String input = "test";
        String formatString = "10-*-L";
        String result = renderer.toString(input, formatString, Locale.getDefault());
        assertEquals("******test", result);
    }

    @Test
    public void testMyStringHandlerRightPadding() {
        String input = "test";
        String formatString = "10-*-R";
        String result = renderer.toString(input, formatString, Locale.getDefault());
        assertEquals("test******", result);
    }

    @Test
    public void testMyStringHandlerWithEmptyPaddingString() {
        String input = "test";
        String formatString = "10--L";
        String result = renderer.toString(input, formatString, Locale.getDefault());
        assertNull(result);
    }

    @Test
    public void testMyStringHandlerWithNonNumericLength() {
        String input = "test";
        // Format string with non-numeric length part triggers NumberFormatException.
        String formatString = "1a-*-L";
        String result = renderer.toString(input, formatString, Locale.getDefault());
        assertNull(result);
    }

    @Test
    public void testSuperToStringFallback() {
        String input = "example";
        String formatString = "x-test";
        // Using the base StringRenderer to determine the expected value.
        String expected = new StringRenderer().toString(input, formatString, Locale.getDefault());
        String result = renderer.toString(input, formatString, Locale.getDefault());
        assertEquals(expected, result);
    }

    @Test
    public void testMyStringHandlerWithTruncation() {
        // When the specified length is less than the original string length,
        // the method should truncate the value.
        String input = "abcdefgh"; // length = 8
        // Format: "5-*-L" triggers myStringHandler branch.
        // length parameter = 5, so input becomes "abcde", then padStart returns "abcde"
        String result = renderer.toString(input, "5-*-L", Locale.getDefault());
        assertEquals("abcde", result);
    }

}