package real.time.service.template.listener;

import org.junit.Test;
import org.mockito.Mockito;
import org.stringtemplate.v4.misc.STMessage;

import static org.junit.Assert.assertThrows;

public class ErrorListenerTest {

    @Test
    public void testCompileTimeError() {
        ErrorListener errorListener = new ErrorListener();
        STMessage mockMessage = Mockito.mock(STMessage.class);

        assertThrows(RuntimeException.class, () -> errorListener.compileTimeError(mockMessage));
    }

    @Test
    public void testRunTimeError() {
        ErrorListener errorListener = new ErrorListener();
        STMessage mockMessage = Mockito.mock(STMessage.class);

        assertThrows(RuntimeException.class, () -> errorListener.runTimeError(mockMessage));
    }


    @Test
    public void testIOError() {
        ErrorListener errorListener = new ErrorListener();
        STMessage mockMessage = Mockito.mock(STMessage.class);

        assertThrows(RuntimeException.class, () -> errorListener.IOError(mockMessage));
    }

    @Test
    public void testInternalError() {
        ErrorListener errorListener = new ErrorListener();
        STMessage mockMessage = Mockito.mock(STMessage.class);

        assertThrows(RuntimeException.class, () -> errorListener.internalError(mockMessage));
    }

}
