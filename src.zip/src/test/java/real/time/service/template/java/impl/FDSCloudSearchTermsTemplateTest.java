package real.time.service.template.java.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class FDSCloudSearchTermsTemplateTest {

    private FDSCloudSearchTermsTemplate template;

    @Before
    public void setUp() {
        template = new FDSCloudSearchTermsTemplate();
    }

    @Test
    public void testConvertWithTemplate() {
        Document metadata = new Document();
        metadata.put("createApplication", "CAP");
        metadata.put("createdDate", "2021-07-12");
        metadata.put("expiryDate", "2022-07-12");
        metadata.put("category", "TestCategory");
        metadata.put("subCategory", "TestSubCategory");
        metadata.put("filePath", "/test/path");
        metadata.put("emailAlertReq", "true");
        metadata.put("tin", "123456789");
        metadata.put("mpin", "987654321");
        metadata.put("policyNumber", "POL123456");
        metadata.put("providerName", "Dr. John Doe");
        metadata.put("multMemberId", "MEM123456");
        metadata.put("memberName", "John Doe");
        metadata.put("claimNumber", "CLM123456");
        metadata.put("dateOfService", "2021-07-12T00:00:00.000Z");

        String result = template.convertWithTemplate(metadata);

        assertNotNull(result);
        // Add more assertions based on the expected output
    }

    @Test
    public void testGetSearchTermsString() {
        Document metadata = new Document();
        metadata.put("createApplication", "CAP");
        metadata.put("createdDate", "2021-07-12");
        metadata.put("expiryDate", "2022-07-12");
        metadata.put("category", "TestCategory");
        metadata.put("subCategory", "TestSubCategory");
        metadata.put("filePath", "/test/path");
        metadata.put("emailAlertReq", "true");
        metadata.put("tin", "123456789");
        metadata.put("mpin", "987654321");
        metadata.put("policyNumber", "POL123456");
        metadata.put("providerName", "Dr. John Doe");
        metadata.put("multMemberId", "MEM123456");
        metadata.put("memberName", "John Doe");
        metadata.put("claimNumber", "CLM123456");
        metadata.put("dateOfService", "2021-07-12T00:00:00.000Z");

        String result = template.getSearchTermsString(metadata, "CID123");

        assertNotNull(result);
        // Add more assertions based on the expected output
    }

    @Test
    public void testFilterDuplicates() {
        String inputString = "value1|value2|value1|value3|";
        String result = template.filterDuplicates(inputString, "CID123");

        assertEquals("|value2|value1|value3|", result);
    }

    @Test
    public void testFilterDuplicatesWithEmptyString() {
        String inputString = "";
        String result = template.filterDuplicates(inputString, "CID123");

        assertEquals("", result);
    }

    @Test
    public void testFilterDuplicatesWithNullString() {
        String result = template.filterDuplicates(null, "CID123");

        assertEquals("", result);
    }


    @Test
    public void testConvertWithTemplateStringReturnsNull() {
        // Given a JSON string, the current implementation returns null.
        String jsonString = "{\"createApplication\":\"CAP\", \"createdDate\":\"2021-07-12\", \"expiryDate\":\"2022-07-12\", \"category\":\"TestCategory\", \"subCategory\":\"TestSubCategory\", \"filePath\":\"/test/path\", \"emailAlertReq\":\"true\", \"tin\":\"123456789\", \"mpin\":\"987654321\", \"policyNumber\":\"POL123456\", \"providerName\":\"Dr. John Doe\", \"multMemberId\":\"MEM123456\", \"memberName\":\"John Doe\", \"claimNumber\":\"CLM123456\", \"dateOfService\":\"2021-07-12T00:00:00.000Z\"}";
        String result = template.convertWithTemplate(jsonString);
        assertNull(result);
    }

    @Test
    public void testConvertWithTemplateFromFilePathReturnsNull() {
        // Given a file path, the current implementation returns null.
        String filePath = "dummy/path";
        String result = template.convertWithTemplateFromFilePath(filePath);
        assertNull(result);
    }


    @Test
    public void testGetSearchTermsStringJsonProcessingException() throws Exception {
        ObjectMapper mockMapper = mock(ObjectMapper.class);
        // Inject our mocked ObjectMapper into the template instance
        Field mapperField = FDSCloudSearchTermsTemplate.class.getDeclaredField("mapper");
        mapperField.setAccessible(true);
        mapperField.set(template, mockMapper);

        // Setup metadata with required fields so createSearchTermsMap returns a non-null map
        Document metadata = new Document();
        metadata.put("createApplication", "NON_CAP");
        metadata.put("createdDate", "2021-07-12");
        metadata.put("expiryDate", "2022-07-12");
        metadata.put("category", "TestCategory");
        metadata.put("subCategory", "TestSubCategory");
        metadata.put("filePath", "/test/path");
        metadata.put("emailAlertReq", "true");
        metadata.put("tin", "123456789");
        metadata.put("mpin", "987654321");

        // Force the ObjectMapper to throw an exception when converting the map to string
        when(mockMapper.writeValueAsString(any(Map.class)))
                .thenThrow(new JsonProcessingException("Test exception") {});

        // Since the exception is caught, the method should return the default empty string
        String result = template.getSearchTermsString(metadata, "CID123");
        assertEquals("", result);
    }
}