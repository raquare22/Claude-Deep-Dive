package real.time.service.template.java.impl;

import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import real.time.service.document.util.Attachment;
import real.time.service.document.util.DocumentResponse;
import real.time.service.workflow.util.WorkFlowUtil;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class FilterReqFieldForDocvaultTemplateTest {

    private FilterReqFieldForDocvaultTemplate template;

    @Before
    public void setUp() {
        template = new FilterReqFieldForDocvaultTemplate();
    }

    @Test
    public void testFilterDuplicates() {
        String input = "value1|value2|value1|value3||value2|";
        String expected = "|value2|value1|value3|";
        String result = template.filterDuplicates(input);
        assertEquals(expected, result);
    }

    @Test
    public void testFilterDuplicatesWithEmptyInput() {
        String input = "";
        String expected = "";
        String result = template.filterDuplicates(input);
        assertEquals(expected, result);
    }

    @Test
    public void testFilterDuplicatesWithNullInput() {
        String result = template.filterDuplicates(null);
        assertEquals("", result);
    }

    @Test
    public void testConvertDateToGMTFormat() throws Exception {
        String input = "2021-07-12T00:00:00.000Z";
        String expected = "Mon Jul 12 00:00:00 GMT 2021";

        Method method = FilterReqFieldForDocvaultTemplate.class.getDeclaredMethod("convertDateToGMTFormat", String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(template, input);

        assertEquals(expected, result);
    }

    @Test
    public void testConvertDateToGMTFormatWithInvalidDate() throws Exception {
        String input = "invalid-date";

        Method method = FilterReqFieldForDocvaultTemplate.class.getDeclaredMethod("convertDateToGMTFormat", String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(template, input);

        assertNull(result);
    }
    @Test
    public void testConvertWithTemplateFromJsonString() {
        String jsonString = "{"
                + "\"metadata\": {"
                + "    \"createApplication\": \"CAP\","
                + "    \"multClaimNumber\": \"123|456|123\","
                + "    \"multMemberId\": \"789|101|789\""
                + "},"
                + "\"attachments\": []"
                + "}";

        String result = template.convertWithTemplate(jsonString);

        assertNotNull(result);
        assertTrue(result.contains("123"));
        assertTrue(result.contains("456"));
        assertTrue(result.contains("789"));
    }

    @Test
    public void testConvertWithTemplateFromFilePath() throws IOException, IOException {
        // Mock the file path and its content
        String filePath = "test-document.json";
        String jsonContent = "{"
                + "\"metadata\": {"
                + "    \"createApplication\": \"CAP\","
                + "    \"multClaimNumber\": \"123|456|123\","
                + "    \"multMemberId\": \"789|101|789\""
                + "},"
                + "\"attachments\": []"
                + "}";

        DocumentResponse mockDocument = WorkFlowUtil.readDocumentResponseFromJsonString(jsonContent);

        Path tempFile = Files.createTempFile("test-document", ".json");
        Files.write(tempFile, jsonContent.getBytes());

        String result = template.convertWithTemplateFromFilePath(tempFile.toString());
        assertNotNull(result);
        assertTrue(result.contains("123"));
        assertTrue(result.contains("456"));
        assertTrue(result.contains("789"));

        Files.delete(tempFile);
    }

    @Test
    public void testConvertWithTemplateFromFilePathThrowsException() {
        String invalidFilePath = "invalid-path.json";

        assertThrows(RuntimeException.class, () -> {
            template.convertWithTemplateFromFilePath(invalidFilePath);
        });
    }


    @Test
    public void testconvertWithTemplateThrowsException() {
        String invalidFilePath = "invalid-path.json";

        assertThrows(RuntimeException.class, () -> {
            template.convertWithTemplateFromFilePath(invalidFilePath);
        });
    }


    @Test
    public void testConvertWithTemplate_CAP() {

        DocumentResponse doc = new DocumentResponse();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("createApplication", "CAP");
        metadata.put("physicianName", "Dr CAP");
        metadata.put("multClaimNumber", "123|456|123");
        metadata.put("multMemberId", "789|101|789");
        metadata.put("createdDate", "2021-07-12T12:00:00.000+0000");
        doc.setMetadata(new Document(metadata));
        doc.setAttachments(new Attachment[0]);

        String result = template.convertWithTemplate(doc);
        assertNotNull(result);

        assertTrue(result.contains("Dr CAP"));

        assertTrue(result.contains("123") && result.contains("456"));
        assertTrue(result.contains("789") && result.contains("101"));
    }

    @Test
    public void testConvertWithTemplate_OCM() {
        // Set up a DocumentResponse for the OCM branch.
        DocumentResponse doc = new DocumentResponse();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("createApplication", "OCM");
        metadata.put("memberId", "M123");
        metadata.put("physicianName", "Dr OCM");
        metadata.put("memberName", "Member One");
        metadata.put("notificationNumber", "N789");
        metadata.put("NotificationLetterID", "L456");
        metadata.put("dateOfService", "2021-07-12");
        metadata.put("createdDate", "2021-07-12T12:00:00.000+0000");
        doc.setMetadata(new Document(metadata));
        doc.setAttachments(new Attachment[0]);

        String result = template.convertWithTemplate(doc);
        assertNotNull(result);
        // Validate that the dummy template was provided the correct entries.
        assertTrue(result.contains("M123"));
        assertTrue(result.contains("Dr OCM"));
        assertTrue(result.contains("Member One"));
        assertTrue(result.contains("N789"));
        assertTrue(result.contains("L456"));
        assertTrue(result.contains("2021-07-12"));
    }


}
