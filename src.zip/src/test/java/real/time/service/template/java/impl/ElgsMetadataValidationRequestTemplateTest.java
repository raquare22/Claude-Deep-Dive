package real.time.service.template.java.impl;

import org.junit.Assert;
import org.junit.Test;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.template.TemplateFactory;
import real.time.service.template.TemplateHandler;
import real.time.service.template.Templates;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.Assert.*;

public class ElgsMetadataValidationRequestTemplateTest {
	
	
	@Test
    public void testConvertWithTemplate() throws ParseException {
		
		List<Map<String, String>> errorList = getErrorsList();
		
		DocumentMetaData doc = getDoc();
		
		org.bson.Document metadata = getMetadata();
		
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("errorList", errorList);
        map.put("document", doc);
        map.put("metadata", metadata);
        map.put("fdsCloudSpaceId", "123456");
        map.put("fdsCloudDocumentId", "123456");
        
        String output = TemplateFactory.getInstance(Templates.ELGS_METADATA_VALIDATION_REQUEST.getTemplate()).convertWithTemplate(map);
        System.out.println(output);
        String expected = "{\"requestHeader\": {\"appUserID\": \"PRUNE\",\"appName\": \"PaperlessRuleEngine\",\"appVersion\": \"V1.0\"},\"letterStatusRequest\": {\"letterTrackingID\": \"1234567890\",\"letterStatus\": [{\"letterGenerationID\": \"1234567\",\"environment\": \"\",\"applicationname\": \"\",\"fdsSpaceID\": null,\"fdsDocumentID\": null,\"disbursementDate\": \"\",\"memberCommunicationStatusType\": \"\",\"statusMessages\": [{\"detail\":\"Missing or invalid data: MemberAltID\",\"error\":\"Error\",\"type\":\"Warning\"},{\"detail\":\"Missing or invalid data: MailToAddress1(SEVERE)\",\"error\":\"Error\",\"type\":\"Severe\"}],\"vendorTrackingID\": null,\"printVendor\": \"PEN\",\"processedFileName\": \"test.pdf\",\"origSystemDateTime\": \"2021-07-12 00:00:00\"}]}}";
        Assert.assertEquals(expected, output);
    }


	@Test
	public void testGetInstanceForValidTemplates() {
		// Assuming that Templates constants are available in your project.
		TemplateHandler handler1 = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
		assertNotNull(handler1);
		assertTrue(handler1 instanceof FilterReqFieldForDocvaultTemplate);

		TemplateHandler handler2 = TemplateFactory.getInstance(Templates.ELGS_METADATA_VALIDATION_REQUEST.getTemplate());
		assertNotNull(handler2);
		assertTrue(handler2 instanceof ElgsMetadataValidationRequestTemplate);

		TemplateHandler handler3 = TemplateFactory.getInstance(Templates.FDS_CLOUD_SEARCH_TERMS.getTemplate());
		assertNotNull(handler3);
		assertTrue(handler3 instanceof FDSCloudSearchTermsTemplate);
	}


	@Test
	public void testGetInstanceForInvalidTemplate() {
		// When an unknown template is requested, the factory should return null.
		TemplateHandler handler = TemplateFactory.getInstance("NonExistingTemplate");
		assertNull(handler);
	}
    
	public List<Map<String, String>> getErrorsList() {
		List<Map<String, String>> errorList = new ArrayList<>();
		
		Map<String, String> errorMap = new HashMap<>();
		errorMap.put("detail", "Missing or invalid data: MemberAltID");
		errorMap.put("error", "Error");
		errorMap.put("type", "Warning");
		
		
		Map<String, String> errorMap1 = new HashMap<>();
		errorMap1.put("detail", "Missing or invalid data: MailToAddress1(SEVERE)");
		errorMap1.put("error", "Error");
		errorMap1.put("type", "Severe");
		
		errorList.add(errorMap);
		errorList.add(errorMap1);
		
		return errorList;
	}
	
	
	public DocumentMetaData getDoc() throws ParseException {
		DocumentMetaData doc = new DocumentMetaData();
		
		org.bson.Document metadata = new org.bson.Document();
		metadata.put("fileName", "test.pdf");
		metadata.put("NotificationLetterID", "1234567890");
		metadata.put("ELGSLETTERGENID", "1234567");
		
		doc.setMetadata(metadata);
		doc.setFdsDocumentId("123456");
		
		
		String dateStr = "2021-07-12";
		Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
		doc.setDateCreated(date);
		
		return doc;
	}
	
	public org.bson.Document getMetadata() throws ParseException {
		org.bson.Document metadata = new org.bson.Document();
		metadata.put("fileName", "test.pdf");
		metadata.put("NotificationLetterID", "1234567890");
		metadata.put("ELGSLETTERGENID", "1234567");		
		return metadata;
	}



}
