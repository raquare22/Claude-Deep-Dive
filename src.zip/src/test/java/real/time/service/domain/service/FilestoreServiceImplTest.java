package real.time.service.domain.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import real.time.service.EhCache;
import real.time.service.exception.ProcessException;
import real.time.service.model.Doc360UploadResponse;
import real.time.service.mongo.FDSCloudDocument;
import real.time.service.oauth.OauthManagerUtil;
import real.time.service.util.RestTemplateChunkClient;
import real.time.service.util.RestTemplateClient;
import real.time.service.util.WebClientSync;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class FilestoreServiceImplTest {

    @InjectMocks
    private FilestoreServiceImpl filestoreService;

    @Mock
    private EhCache ehcache;

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @Mock
    private RestTemplateClient restTemplateClient;

    @Mock
    private RestTemplateChunkClient restTemplateChunkClient;

    @Mock
    private WebClientSync webClientSync;

    @Mock
    private RestTemplate restTemplate;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        FilestoreServiceImpl.shutdown = false;
        filestoreService.fdsDocumentsUrl = "http://example.com/documents";
        filestoreService.fdsOauthUrl = "http://example.com/oauth";
        filestoreService.fdsCloudAppId = "appId";
        filestoreService.fdsCloudAppSecret = "appSecret";
        filestoreService.fileStoreMinSizeToChunk = 6000000;
        filestoreService.fileStoreUseWebClient = true;
        filestoreService.doc360DocumentsUrl = "http://example.com/doc360/upload";
        filestoreService.doc360OauthUrl = "http://example.com/doc360/oauth";
        filestoreService.doc360AppId = "doc360AppId";
        filestoreService.doc360AppSecret = "doc360AppSecret";
        filestoreService.doc360Scope = "doc360-scope";
        filestoreService.doc360RetryCount = 2;
        filestoreService.doc360RetrySleepMS = 1L;
    }

    @Test
    public void testPostDocumentToFDSCloudWithAttachmentRetry() throws Exception {
        String document = "document";
        String searchTerms = "searchTerms";
        String filePath = "path/to/file";
        String fdsCloudSpaceId = "spaceId";
        String cid = "cid";

        Path path = Paths.get(filePath);
        when(webClientSync.sendMultiPartDataWithRetry(anyString(), any(URI.class), any(), anyString(), anyString(), anyString()))
                .thenReturn(new ResponseEntity<>(new FDSCloudDocument(), HttpStatus.OK));

        ResponseEntity<FDSCloudDocument> response = filestoreService.postDocumentToFDSCloudWithAttachmentRetry(document, searchTerms, filePath, fdsCloudSpaceId, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }


    @Test(expected = ProcessException.class)
    public void testPostDocumentToFDSCloudWithAttachment_Shutdown() throws Exception {
        filestoreService.shutdown = true;
        filestoreService.postDocumentToFDSCloudWithAttachment("document", "searchTerms", "path/to/file", "spaceId", "cid");
    }


    @Test
    public void testValidateResponseStatusCode() {
        assertTrue(filestoreService.validateResponseStatusCode(500));
        assertTrue(filestoreService.validateResponseStatusCode(502));
        assertTrue(filestoreService.validateResponseStatusCode(503));
        assertTrue(filestoreService.validateResponseStatusCode(504));
        assertFalse(filestoreService.validateResponseStatusCode(200));
    }

    @Test
    public void testSleep() {
        filestoreService.sleep(100, "test sleep");

    }

    @Test
    public void testChunkStats() {
        String filePath = "path/to/file";
        long length = 7000000;
        int initialTotalChunkCnt = FilestoreServiceImpl.totalChunkCnt;
        long initialLargestChunkSize = FilestoreServiceImpl.largestChunkSize;

        // Ensure the initial largestChunkSize is less than the length to avoid conflicts
        FilestoreServiceImpl.largestChunkSize = 6000000;

        filestoreService.chunkStats(filePath, length);

        assertEquals(initialTotalChunkCnt + 1, FilestoreServiceImpl.totalChunkCnt);
        assertEquals(length, FilestoreServiceImpl.largestChunkSize);
    }

    @Test
    public void testIsNullOrEmpty() throws Exception {
        java.lang.reflect.Method method = FilestoreServiceImpl.class.getDeclaredMethod("isNullOrEmpty", String.class);
        method.setAccessible(true);

        assertTrue((boolean) method.invoke(filestoreService, (String) null));
        assertTrue((boolean) method.invoke(filestoreService, ""));
        assertFalse((boolean) method.invoke(filestoreService, "not empty"));
    }

    @Test
    public void testTotalStats() throws Exception {
        int initialTotalCnt = FilestoreServiceImpl.totalCnt;

        java.lang.reflect.Field field = FilestoreServiceImpl.class.getDeclaredField("totalOutstandingRequests");
        field.setAccessible(true);
        java.util.concurrent.atomic.AtomicInteger totalOutstandingRequests = (java.util.concurrent.atomic.AtomicInteger) field.get(null);
        int initialOutstandingRequests = totalOutstandingRequests.get();

        FilestoreServiceImpl.totalStats();

        assertEquals(initialTotalCnt + 1, FilestoreServiceImpl.totalCnt);
        assertEquals(initialOutstandingRequests + 1, totalOutstandingRequests.get());
    }

    @Test
    public void testChunkStats_LargestChunkSizeUpdate() {
        String filePath = "path/to/large/file";
        long length = 8000000; // A length greater than the current largestChunkSize
        long initialLargestChunkSize = FilestoreServiceImpl.largestChunkSize;

        filestoreService.chunkStats(filePath, length);

        assertEquals(length, FilestoreServiceImpl.largestChunkSize);
        assertTrue(FilestoreServiceImpl.largestChunkSize > initialLargestChunkSize);
    }

    @Test
    public void testIsNullOrEmpty_NonEmptyString() throws Exception {
        java.lang.reflect.Method method = FilestoreServiceImpl.class.getDeclaredMethod("isNullOrEmpty", String.class);
        method.setAccessible(true);

        assertFalse((boolean) method.invoke(filestoreService, "non-empty string"));
    }

//    @Test
//    public void testGetOauthToken_RequestNewToken() throws Exception {
//        String newToken = "newToken";
//        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("appId", "appSecret", "http://example.com/oauth", "client_credentials");
//        oauthTokenExtended.setAccessToken(newToken);
//        when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString())).thenReturn(Optional.of(oauthTokenExtended));
//
//        java.lang.reflect.Method method = FilestoreServiceImpl.class.getDeclaredMethod("getOauthToken", boolean.class);
//        method.setAccessible(true);
//
//        String result = (String) method.invoke(filestoreService, true);
//        assertEquals(newToken, result);
//    }

    @Test
    public void testTotalStats_UpdateCounters() throws Exception {
        int initialTotalCnt = FilestoreServiceImpl.totalCnt;

        java.lang.reflect.Field field = FilestoreServiceImpl.class.getDeclaredField("totalOutstandingRequests");
        field.setAccessible(true);
        java.util.concurrent.atomic.AtomicInteger totalOutstandingRequests = (java.util.concurrent.atomic.AtomicInteger) field.get(null);
        int initialOutstandingRequests = totalOutstandingRequests.get();

        FilestoreServiceImpl.totalStats();

        assertEquals(initialTotalCnt + 1, FilestoreServiceImpl.totalCnt);
        assertEquals(initialOutstandingRequests + 1, totalOutstandingRequests.get());
    }

    @Test
    public void testValidateResponseStatusCode_InvalidCode() {
        assertFalse(filestoreService.validateResponseStatusCode(404));
    }

    @Test
    public void testSleep_InterruptedException() {
        Thread.currentThread().interrupt(); // Interrupt the current thread
        filestoreService.sleep(100, "test sleep interrupted");
        assertTrue(Thread.interrupted()); // Check if the thread was interrupted
    }

//    @Test
//    public void testGetOauthToken_NewToken() throws Exception {
//        String newToken = "newToken";
//        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("appId", "appSecret", "http://example.com/oauth", "client_credentials");
//        oauthTokenExtended.setAccessToken(newToken);
//        when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString())).thenReturn(Optional.of(oauthTokenExtended));
//
//        java.lang.reflect.Method method = FilestoreServiceImpl.class.getDeclaredMethod("getOauthToken", boolean.class);
//        method.setAccessible(true);
//
//        String result = (String) method.invoke(filestoreService, true);
//        assertEquals(newToken, result);
//    }

    @Test
    public void testShutdown() throws Exception {
        FilestoreServiceImpl.shutdown = false;

        // Use reflection to access the private field
        java.lang.reflect.Field field = FilestoreServiceImpl.class.getDeclaredField("totalOutstandingRequests");
        field.setAccessible(true);
        java.util.concurrent.atomic.AtomicInteger totalOutstandingRequests = (java.util.concurrent.atomic.AtomicInteger) field.get(null);
        totalOutstandingRequests.set(0);

        filestoreService.shutdown();

        assertTrue(FilestoreServiceImpl.shutdown);
        assertEquals(0, totalOutstandingRequests.get());
    }

//    @Test
//    public void testPostDocumentToFDSCloudWithAttachment_UseRestTemplateClient() throws Exception {
//        filestoreService.shutdown = false; // Ensure the service is not in shutdown state
//        filestoreService.fileStoreUseWebClient = false;
//        String document = "document";
//        String searchTerms = "searchTerms";
//        String filePath = "path/to/file";
//        String fdsCloudSpaceId = "spaceId";
//        String cid = "cid";
//
//        Path path = Paths.get(filePath);
//        when(restTemplateClient.putExchangeWithRetry(any(URI.class), any(HttpMethod.class), any(HttpEntity.class)))
//                .thenReturn(new ResponseEntity<>(new FDSCloudDocument(), HttpStatus.OK));
//
//        ResponseEntity<FDSCloudDocument> response = filestoreService.postDocumentToFDSCloudWithAttachment(document, searchTerms, filePath, fdsCloudSpaceId, cid);
//
//        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//    }

    @Test
    public void testShutdown_WithOutstandingRequests() throws Exception {
        FilestoreServiceImpl.shutdown = false;

        // Use reflection to access the private field
        java.lang.reflect.Field field = FilestoreServiceImpl.class.getDeclaredField("totalOutstandingRequests");
        field.setAccessible(true);
        java.util.concurrent.atomic.AtomicInteger totalOutstandingRequests = (java.util.concurrent.atomic.AtomicInteger) field.get(null);
        totalOutstandingRequests.set(1);

        filestoreService.shutdown();

        assertTrue(FilestoreServiceImpl.shutdown);
        assertEquals(1, totalOutstandingRequests.get());
    }


  @Test
  public void testPostDocumentToDoc360WithAttachmentRetry_Success() throws Exception {
    Path tempFile = Files.createTempFile("doc360", ".pdf");
    Files.writeString(tempFile, "%PDF-test", StandardCharsets.US_ASCII);

    Doc360UploadResponse doc360Body = new Doc360UploadResponse();
    doc360Body.setGlobalDocId("doc360-1");
    doc360Body.setStatus(201);

    when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), anyBoolean(), any()))
        .thenReturn("token-value");
    when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(Doc360UploadResponse.class)))
        .thenReturn(new ResponseEntity<>(doc360Body, HttpStatus.CREATED));

    ResponseEntity<Doc360UploadResponse> response = filestoreService.postDocumentToDoc360WithAttachmentRetry("{}", tempFile.toString(), "CAP_LETTER", "cid");

    ArgumentCaptor<String> endpointCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<HttpEntity> entityCaptor = ArgumentCaptor.forClass(HttpEntity.class);
    verify(restTemplate).postForEntity(endpointCaptor.capture(), entityCaptor.capture(), eq(Doc360UploadResponse.class));

    assertTrue(endpointCaptor.getValue().contains("document-type=CAP_LETTER"));
    MultiValueMap<String, Object> requestBody = (MultiValueMap<String, Object>) entityCaptor.getValue().getBody();
    assertNotNull(requestBody);
    assertFalse(requestBody.containsKey("docClass"));

    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals("doc360-1", response.getBody().getGlobalDocId());
    assertEquals(Integer.valueOf(201), response.getBody().getStatus());
  }

  @Test
  public void testPostDocumentToDoc360WithAttachmentRetry_EmptyDocClass_DoesNotSetQueryParam() throws Exception {
    Path tempFile = Files.createTempFile("doc360", ".pdf");
    Files.writeString(tempFile, "%PDF-test", StandardCharsets.US_ASCII);

    Doc360UploadResponse doc360Body = new Doc360UploadResponse();
    doc360Body.setGlobalDocId("doc360-2");

    when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), anyBoolean(), any()))
        .thenReturn("token-value");
    when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(Doc360UploadResponse.class)))
        .thenReturn(new ResponseEntity<>(doc360Body, HttpStatus.CREATED));

    filestoreService.postDocumentToDoc360WithAttachmentRetry("{}", tempFile.toString(), "", "cid");

    ArgumentCaptor<String> endpointCaptor = ArgumentCaptor.forClass(String.class);
    verify(restTemplate).postForEntity(endpointCaptor.capture(), any(HttpEntity.class), eq(Doc360UploadResponse.class));
    assertFalse(endpointCaptor.getValue().contains("document-type="));
  }

  @Test
  public void testPostDocumentToDoc360WithAttachmentRetry_NonPdfFile_RejectsRequest() throws Exception {
    Path tempFile = Files.createTempFile("doc360", ".txt");
    Files.writeString(tempFile, "not-a-pdf", StandardCharsets.US_ASCII);

    ResponseEntity<Doc360UploadResponse> response =
        filestoreService.postDocumentToDoc360WithAttachmentRetry("{}", tempFile.toString(), "CAP_LETTER", "cid");

    assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE, response.getStatusCode());
    assertNotNull(response.getBody());
    verify(restTemplate, never()).postForEntity(anyString(), any(HttpEntity.class), eq(Doc360UploadResponse.class));
  }


}