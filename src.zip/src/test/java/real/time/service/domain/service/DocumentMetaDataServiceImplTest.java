package real.time.service.domain.service;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import real.time.service.model.MultiPutResponse;
import real.time.service.mongo.DocumentMetaData;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
public class DocumentMetaDataServiceImplTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private DocumentMetaDataServiceImpl documentMetaDataService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveDocumentMetaData_InsertNewDocument() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId(null); // New document

        when(mongoTemplate.insert(doc, "document")).thenReturn(doc);

        DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);

        assertNotNull(result);
        verify(mongoTemplate, times(1)).insert(doc, "document");
    }

//    @Test
    public void testSaveDocumentMetaData_UpdateExistingDocument() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("id2"); // Existing document

        when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(doc);

        DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);

        assertNotNull(result);
        verify(mongoTemplate, times(1)).findOne(any(Query.class), eq(DocumentMetaData.class), eq("document"));
        verify(mongoTemplate, times(1)).save(doc, "document");
    }

//    @Test
    public void testSaveDocumentMetaData_InsertWhenDocumentNotFound() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("id2");

        when(mongoTemplate.findOne(any(), any(), anyString())).thenReturn(null);
        when(mongoTemplate.insert(doc, "document")).thenReturn(doc);

        DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);

        assertNotNull(result);
        verify(mongoTemplate, times(1)).findOne(any(Query.class), eq(DocumentMetaData.class), eq("document"));
        verify(mongoTemplate, times(1)).insert(doc, "document");
    }

    @Test
    public void testUpdateMultiDocuments_AllUpdated() {
        List<String> docIds = Arrays.asList("id1", "id2");
        DocumentMetaData doc = new DocumentMetaData();

        DocumentMetaData updatedDoc = new DocumentMetaData();
        updatedDoc.setId("id1");
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("document"))).thenReturn(updatedDoc);

        DocumentMetaDataServiceImpl spyService = spy(documentMetaDataService);
        doReturn(updatedDoc).when(spyService).updateDocumentMetaData(any(), anyString());

        MultiPutResponse response = spyService.updateMultiDocuments(docIds, doc);

        assertEquals(2, response.getUpdated().size());
        assertEquals(0, response.getNotUpdated().size());
    }

    @Test
    public void testUpdateMultiDocuments_SomeNotUpdated() {
        List<String> docIds = Arrays.asList("id1", "id2");
        DocumentMetaData doc = new DocumentMetaData();

        DocumentMetaData updatedDoc = new DocumentMetaData();
        updatedDoc.setId("id1");

        DocumentMetaDataServiceImpl spyService = spy(documentMetaDataService);
        doReturn(updatedDoc).when(spyService).updateDocumentMetaData(any(), eq("id1"));
        doReturn(null).when(spyService).updateDocumentMetaData(any(), eq("id2"));

        MultiPutResponse response = spyService.updateMultiDocuments(docIds, doc);

        assertEquals(1, response.getUpdated().size());
        assertEquals(1, response.getNotUpdated().size());
        assertTrue(response.getUpdated().contains("id1"));
        assertTrue(response.getNotUpdated().contains("id2"));
    }

    @Test
    public void testUpdateMultiDocuments_NoneUpdated() {
        List<String> docIds = Arrays.asList("id1", "id2");
        DocumentMetaData doc = new DocumentMetaData();

        DocumentMetaDataServiceImpl spyService = spy(documentMetaDataService);
        doReturn(null).when(spyService).updateDocumentMetaData(any(), anyString());

        MultiPutResponse response = spyService.updateMultiDocuments(docIds, doc);

        assertEquals(0, response.getUpdated().size());
        assertEquals(2, response.getNotUpdated().size());
    }


}