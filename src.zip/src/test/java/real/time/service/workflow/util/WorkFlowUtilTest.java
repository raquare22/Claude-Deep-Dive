package real.time.service.workflow.util;

import static org.mockito.Mockito.*;

import java.io.IOException;

import org.bson.Document;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import real.time.service.workflow.constants.Workflow;

public class WorkFlowUtilTest {

    @Mock
    private Document metaData;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testUpdateEDeliveryError_BlankError() {
        when(metaData.getString(Workflow.E_DELIVERY_ERROR)).thenReturn("");
        WorkFlowUtil.updateEDeliveryError(metaData, "field1");
        verify(metaData).put(Workflow.E_DELIVERY_ERROR, "Missing or invalid data: field1");
    }

    @Test
    public void testUpdateEDeliveryError_NonBlankError() {
        when(metaData.getString(Workflow.E_DELIVERY_ERROR)).thenReturn("Existing error");
        WorkFlowUtil.updateEDeliveryError(metaData, "field1");
        verify(metaData).put(Workflow.E_DELIVERY_ERROR, "Existing error|Missing or invalid data: field1");
    }


    @Test(expected = IOException.class)
    public void testReadDocumentResponseFromJsonFile_InvalidFile() throws IOException, JSONException {
        String fileName = "src/test/resources/invalidDocumentResponse.json";
        WorkFlowUtil.readDocumentResponseFromJsonFile(fileName);
    }


    @Test(expected = com.fasterxml.jackson.core.JsonParseException.class)
    public void testReadDocumentResponseFromJsonString_InvalidString() throws IOException, com.fasterxml.jackson.core.JsonParseException {
        String jsonString = "invalid json string";
        WorkFlowUtil.readDocumentResponseFromJsonString(jsonString);
    }

    @Test
    public void testUpdateEDeliveryError_ErrorAlreadyExists() {
        when(metaData.getString(Workflow.E_DELIVERY_ERROR)).thenReturn("Missing or invalid data: field1");
        WorkFlowUtil.updateEDeliveryError(metaData, "field1");
        verify(metaData, never()).put(anyString(), anyString());
    }

    @Test
    public void testUpdateEDeliveryError_NullError() {
        when(metaData.getString(Workflow.E_DELIVERY_ERROR)).thenReturn(null);
        WorkFlowUtil.updateEDeliveryError(metaData, "field1");
        verify(metaData).put(Workflow.E_DELIVERY_ERROR, "Missing or invalid data: field1");
    }

}