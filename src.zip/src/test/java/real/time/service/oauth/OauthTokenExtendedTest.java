package real.time.service.oauth;

import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class OauthTokenExtendedTest {

    @Test
    public void testSettersAndGetters() {
        OauthTokenExtended tokenExtended = new OauthTokenExtended("appId", "password");
        tokenExtended.setAccessToken("accessToken");
        tokenExtended.setTokenType("bearer");
        tokenExtended.setUrl("http://example.com");
        tokenExtended.setGrantType("authorization");
        tokenExtended.setExpiresIn(3600);

        Assert.assertEquals("accessToken", tokenExtended.getAccessToken());
        Assert.assertEquals("bearer", tokenExtended.getTokenType());
        Assert.assertEquals("http://example.com", tokenExtended.getUrl());
        Assert.assertEquals("authorization", tokenExtended.getGrantType());
        Assert.assertEquals(Integer.valueOf(3600), tokenExtended.getExpiresIn());
        Assert.assertEquals("appId", tokenExtended.getApplicationId());
        Assert.assertEquals("password", tokenExtended.getPassword());
    }


    @Test
    public void testIsTokenGoingToExpire_NoObtainedOn() {
        OauthTokenExtended tokenExtended = new OauthTokenExtended("appId", "password");
        tokenExtended.setExpiresIn(3600);
        // Without setting obtainedOn, token is considered expired
        Assert.assertTrue(tokenExtended.isTokenGoingToExpire());
    }


    @Test
    public void testToString() {
        Date obtainedOn = new Date(100000);
        OauthTokenExtended token = new OauthTokenExtended("appId", "password");
        token.setAccessToken("accessToken");
        token.setTokenType("bearer");
        token.setUrl("http://example.com");
        token.setGrantType("authorization");
        token.setExpiresIn(3600);
        token.setObtainedOn(obtainedOn);
        String tokenStr = token.toString();
        Assert.assertTrue(tokenStr.contains("accessToken"));
        Assert.assertTrue(tokenStr.contains("3600"));
        Assert.assertTrue(tokenStr.contains("appId"));
        Assert.assertTrue(tokenStr.contains("password"));
    }
}
