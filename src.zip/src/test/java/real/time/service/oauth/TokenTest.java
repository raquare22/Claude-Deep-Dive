package real.time.service.oauth;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;


public class TokenTest {
	
	@Test
	public void testSetGrantType()
	{
		Token token = new Token();
		token.setGrantType("grantTest");
		assertEquals("grantTest", token.getGrantType());
	}
	
	
	@Test
	public void testSetAccessToken()
	{
		Token token = new Token();
		token.setAccessToken("accessTest");
		assertEquals("accessTest", token.getAccessToken());
	}
	
	@Test
	public void testSetRefreshToken()
	{
		Token token = new Token();
		token.setRefreshToken("refreshToken");
		assertEquals("refreshToken", token.getRefreshToken());
	}
	
	@Test
	public void testSetTokenType()
	{
		Token token = new Token();
		token.setTokenType("testTokenType");
		assertEquals("testTokenType", token.getTokenType());
	}
	
	@Test
	public void testSetExpiresIn()
	{
		Token token = new Token();
		token.setExpiresIn(50);
		assertEquals(50, token.getExpiresIn());
	}
	
	@Test
	public void testSetClientId()
	{
		Token token = new Token();
		token.setClientId("testClientId");
		assertEquals("testClientId", token.getClientId());
	}
	
	@Test
	public void testSetClientSecret()
	{
		Token token = new Token();
		token.setClientSecret("testClientSecret");
		assertEquals("testClientSecret", token.getClientSecret());
	}
	
	
	
	
	
	
	
	

}
