package real.time.service.oauth;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class OauthManagerUtilImplTest {

    @Mock
    private AuthorizationOauthProvider authorizationProvider;

    @InjectMocks
    private OauthManagerUtilImpl oauthManagerUtil;

    private OauthTokenExtended oauthTokenExtended;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        oauthTokenExtended = new OauthTokenExtended("testAppId", "testAppSecret", "http://test.url", "authorization","testScope");
    }


    @Test
    public void testGetOauthTokenExtended() throws InterruptedException {
        Token token = new Token();
        token.setAccessToken("testAccessToken");
        token.setTokenType("bearer");
        token.setExpiresIn(1800);

        lenient().when(authorizationProvider.getOauth2Token(any(String.class), any(OauthTokenExtended.class)))
                .thenReturn(Optional.of(token));

        Optional<OauthTokenExtended> result = oauthManagerUtil.getOauthTokenExtended("testAppId", "testAppSecret", "http://test.url", "authorization", "testScope");

        assertTrue(result.isPresent());
        assertEquals("testAccessToken", result.get().getAccessToken());
        assertEquals("bearer", result.get().getTokenType());
        assertNotNull(result.get().getObtainedOn());
        assertEquals(Integer.valueOf(1800), result.get().getExpiresIn());
    }

    @Test
    public void testGetOauthTokenExtended_InterruptedException() throws Exception {
        oauthTokenExtended.setAccessToken("");
        lenient().when(authorizationProvider.getOauth2Token(any(String.class), any(OauthTokenExtended.class)))
                .thenThrow(new InterruptedException("Simulated interruption"));

        Optional<OauthTokenExtended> result = oauthManagerUtil.getOauthTokenExtended("testAppId", "testAppSecret", "http://test.url", "authorization", "testScope");
        assertFalse(result.isPresent());
    }

    @Test
    public void testGetOauthTokenExtended_OptionalEmpty() throws Exception {
        oauthTokenExtended.setAccessToken("");
        when(authorizationProvider.getOauth2Token(any(String.class), any(OauthTokenExtended.class)))
                .thenReturn(Optional.empty());

        Optional<OauthTokenExtended> result = oauthManagerUtil.getOauthTokenExtended("emptyAppId", "emptySecret", "http://test.url", "authorization", "testScope");
        assertTrue(result.isPresent());
        assertNull(result.get().getAccessToken());
        assertNull(result.get().getExpiresIn());
    }

}