package real.time.service;



import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.junit.Before;
import org.junit.Test;
import real.time.service.oauth.OauthTokenExtended;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class EhCacheTest {

    private EhCache ehCache;
    private CacheManager cacheManagerMock;
    private Cache<String, OauthTokenExtended> oauthTokenCacheMock;
    private Cache<String, String> corpMpinCacheMock;

    @Before
    public void setUp() {
        cacheManagerMock = mock(CacheManager.class);
        corpMpinCacheMock = mock(Cache.class);
        oauthTokenCacheMock = mock(Cache.class);

        ehCache = new EhCache() {
            {
                this.cacheManager = cacheManagerMock;
            }
            @Override
            public Cache<String, String> getProviderCorpMpinCacheFromCacheManager() {
                return corpMpinCacheMock;
            }
            @Override
            public Cache<String, OauthTokenExtended> getOauthTokenCacheFromCacheManager() {
                return oauthTokenCacheMock;
            }
        };
    }

    @Test
    public void testGetCorpMpinCache_ValuePresent() {
        when(corpMpinCacheMock.containsKey("TIN123")).thenReturn(true);
        when(corpMpinCacheMock.get("TIN123")).thenReturn("MPIN_VALUE");
        String result = ehCache.getCorpMpinCache("TIN123");
        assertEquals("MPIN_VALUE", result);
    }

    @Test
    public void testGetCorpMpinCache_ValueAbsent() {
        when(corpMpinCacheMock.containsKey("TIN123")).thenReturn(false);
        String result = ehCache.getCorpMpinCache("TIN123");
        assertEquals("", result);
    }

    @Test
    public void testGetOauthTokenCache_ValuePresent() {
        when(oauthTokenCacheMock.containsKey("TOKEN123")).thenReturn(true);
        when(oauthTokenCacheMock.get("TOKEN123")).thenReturn(getOauthToken());
        String result = ehCache.getOauthTokenCache("TOKEN123");
        assertEquals("OAUTH_VALUE", result);
    }

    @Test
    public void testGetOauthTokenCache_ValueAbsent() {
        when(oauthTokenCacheMock.containsKey("TOKEN123")).thenReturn(false);
        String result = ehCache.getOauthTokenCache("TOKEN123");
        assertNull(result);
    }

    @Test
    public void testPutOauthTokenWithExpiry_Valid() {
        ehCache.putOauthTokenWithExpiry("TOKEN123", "OAUTH_VALUE", 2);
        verify(oauthTokenCacheMock, times(1)).put(eq("TOKEN123"), any());
    }

    @Test
    public void testPutOauthTokenWithExpiry_EmptyValue() {
        ehCache.putOauthTokenWithExpiry("TOKEN123", "", 2);
        verify(oauthTokenCacheMock, never()).put(anyString(), any());
    }

    private OauthTokenExtended getOauthToken() {
        return new OauthTokenExtended("OAUTH_VALUE", 3540);
    }
}
