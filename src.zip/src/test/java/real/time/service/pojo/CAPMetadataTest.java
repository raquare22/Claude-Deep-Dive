package real.time.service.pojo;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;

public class CAPMetadataTest extends AbstractMetadataTestUtil{
    protected static final String PATH_XML_FILE = "files/metadata/CAP/CAP.metadata";
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/CAP/CAPError12.metadata";
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/CAP/CAPError22.metadata";

    @Before
    public void setUp() {

    }

    @Test
    public void testCAPHappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CAP");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("2021-01-05T05:59:44.000Z", (String) convertedMetadata.get("createdDate"));
        assertEquals("S1", (String) convertedMetadata.get("subCategory"));
        assertEquals("Community Plan/Action Required", (String) convertedMetadata.get("filePath"));
        assertEquals("9999",(String) convertedMetadata.get("CONFIGKEY"));

    }

    @Test
    public void testCAPError12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CAP");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(4, errors.size());

        assertEquals("Claim Status", (String) convertedMetadata.get("privilege"));
    }

    @Test
    public void testCAPError22() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CAP");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(2, errors.size());

        assertEquals("S8", (String) convertedMetadata.get("subCategory"));
        assertEquals("Commercial/Individual & Family Plan", (String) convertedMetadata.get("filePath"));
    }

    @Test
    public void testSetSubCategory() {
        CAP cap = new CAP();

        cap.setSubCategory("S1");
        assertEquals("S1", cap.getSubCategory());
        assertEquals("Community Plan/Action Required", cap.getFilePath());

        cap.setSubCategory("INVALID");
        assertEquals("Other Top-level folder/Other", cap.getFilePath());

        cap.setSubCategory(null);
        assertEquals("XX", cap.getSubCategory());
        assertEquals("Other Top-level folder/Other", cap.getFilePath());
    }

    @Test
    public void testErrorMsg() {
        CAP.ErrorMsg errorMsg = CAP.ErrorMsg.tin;
        assertEquals(12, errorMsg.getErrorCode());
        assertEquals("Missing or invalid data: tin", errorMsg.getErrorMessage());

        CAP.Subcategory subcategory = CAP.Subcategory.S1;
        assertEquals("S1", subcategory.getSubCat());
        assertEquals("Community Plan/Action Required", subcategory.getFilePath());
    }

        @Test
        public void testMailToAddressMethods() {
            CAP cap = new CAP();
            // Test MailToAddress1 setter/getter and that it sets physicianName as well
            cap.setMailToAddress1("TestProvider");
            assertEquals("TestProvider", cap.getMailToAddress1());
            assertEquals("TestProvider", cap.getPhysicianName());

            // Test setters/getters for MailToAddress2 to MailToAddress6
            cap.setMailToAddress2("AddressLine1");
            assertEquals("AddressLine1", cap.getMailToAddress2());

            cap.setMailToAddress3("AddressLine2");
            assertEquals("AddressLine2", cap.getMailToAddress3());

            cap.setMailToAddress4("CityTest");
            assertEquals("CityTest", cap.getMailToAddress4());

            cap.setMailToAddress5("StateTest");
            assertEquals("StateTest", cap.getMailToAddress5());

            cap.setMailToAddress6("ZipTest");
            assertEquals("ZipTest", cap.getMailToAddress6());
        }

        @Test
        public void testOtherSettersAndGetters() {
            CAP cap = new CAP();

            cap.setTin("123456");
            assertEquals("123456", cap.getTin());

            cap.setMpin("7890");
            assertEquals("7890", cap.getMpin());

            cap.setEmailAlertReq("N");
            assertEquals("N", cap.getEmailAlertReq());

            cap.setMultMemberId("Member001");
            assertEquals("Member001", cap.getMultMemberId());

            cap.setMultClaimNumber("Claim001");
            assertEquals("Claim001", cap.getMultClaimNumber());

            // Test CONFIGKEY field
            cap.setCONFIGKEY("1111");
            assertEquals("1111", cap.getCONFIGKEY());

            // Test originalPrintTrail field
            cap.setOriginalPrintTrail("2222");
            assertEquals("2222", cap.getOriginalPrintTrail());

            // Test PassThruData field
            cap.setPassThruData("3333");
            assertEquals("3333", cap.getPassThruData());

            // Test letterId field
            cap.setLetterId("L001");
            assertEquals("L001", cap.getLetterId());
        }

        @Test
        public void testSubCategorySetter() {
            CAP cap = new CAP();

            // Valid subcategory "S1"
            cap.setSubCategory("S1");
            assertEquals("S1", cap.getSubCategory());
            assertEquals("Community Plan/Action Required", cap.getFilePath());

            // Invalid subcategory should fall back to default file path
            cap.setSubCategory("INVALID");
            assertEquals("INVALID", cap.getSubCategory());
            assertEquals("Other Top-level folder/Other", cap.getFilePath());

            // Null subcategory
            cap.setSubCategory(null);
            assertEquals("XX", cap.getSubCategory());
            assertEquals("Other Top-level folder/Other", cap.getFilePath());
        }


}
