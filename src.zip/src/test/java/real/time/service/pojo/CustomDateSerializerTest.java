package real.time.service.pojo;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class CustomDateSerializerTest {

    private CustomDateSerializer customDateSerializer;
    private SimpleDateFormat formatter;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        customDateSerializer = new CustomDateSerializer();
        formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    }

    @Test
    public void testSerialize() throws IOException {
        Date date = new Date();
        String formattedDate = formatter.format(date);

        customDateSerializer.serialize(date, jsonGenerator, serializerProvider);

        verify(jsonGenerator, times(1)).writeString(formattedDate);
    }

    @Test
    public void testDeserializeFallbackToSecondFormatter() throws JsonParseException, IOException {
        Configurator.setAllLevels("", Level.DEBUG);
        String dateJson = "{ \"createdDate\" : \"12/31/2021 5:45:22 PM\"}"; // Format that matches dateTimeFormatter1
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(dateJson);
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();
        String currentName = parser.getCurrentName();
        System.out.println("currentName=" + currentName + ", date=" + parser.getText());

        DeserializationContext context = null;
        CustomizeDateDeserializer dateDeserializer = new CustomizeDateDeserializer("MM/dd/yyyy");
        Date date = dateDeserializer.deserialize(parser, context);
        System.out.println("Date=" + ((date != null) ? date : "NULL"));
        assertNotNull(date); // Ensure the fallback formatter successfully parses the date
    }
}
