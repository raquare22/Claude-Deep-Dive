package real.time.service.pojo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class AbstractMetadataTestUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractMetadataTestUtil.class);
	
	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	
	public static final XmlMapper xmlMapper = new XmlMapper();
	public static final Gson gson = new GsonBuilder().setDateFormat(DATE_FORMAT).create();
	public static final ObjectMapper objectMapper = new ObjectMapper();

	protected String schemaFileBasePath = File.separator + "schemas" + File.separator;

	
    public Class getClassFromClientName(String clientName) {
    	String className = "real.time.service.pojo." + clientName;
    	try {
        	return Class.forName(className);
    	} catch (ClassNotFoundException e) {
    		LOGGER.error("getClassFromClientName -- class not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
    		return null;
    	}    	
    }
    
    public Class getErrEnumFromClientName(String clientName) {
    	String enumName = "real.time.service.pojo." + clientName + "$ErrorMsg";
    	try {
    		return Class.forName(enumName);
		} catch (ClassNotFoundException e) {
    		LOGGER.error("getClassFromClientName -- ErrorMsg enum not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
			return null;
		}
    }
    
    public void getErrors(String errMsg, Set<String> errors, Class enumClass) {
    	
    	ErrorMessage err = null;
    	String key = "";
    	
    	// #: required key [SubCategory] not found
    	// #/DATEOFSERVICE: subject must not be valid against schema {"enum":["00000000"]}
    	// #/CreatingApp: expected minLength: 1, actual: 0
    	// #/isPrintSuppressed: blah is not a valid enum value
    	
    	if (errMsg.contains("[") && errMsg.contains("required key")) {
    		key = errMsg.substring(errMsg.indexOf("[")+1, errMsg.indexOf("]"));		
    	} else if (errMsg.contains("minLength") || errMsg.contains("enum")) {
    		key = errMsg.substring(errMsg.indexOf("#/")+2, errMsg.indexOf(":"));
    	}
    	
    	try {
        	err = (ErrorMessage) Enum.valueOf(enumClass, key.replaceAll("\\s",""));        	
    		LOGGER.info("getErrors -- errorCode={}, errorMessage={}", err.getErrorCode(), err.getErrorMessage());
    		errors.add(err.getErrorMessage());
    	} catch (Exception e) {
    		LOGGER.error("No enum value for key={}", key);
    	}
    }
    
    public static String getResourceFileAsString(String fileName) throws IOException {
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        try (InputStream is = AbstractMetadataTestUtil.class.getResourceAsStream(fileName);) {
            if (is == null) return null;
            try (InputStreamReader isr = new InputStreamReader(is);
                 BufferedReader reader = new BufferedReader(isr)) {
                return reader.lines().collect(Collectors.joining(System.lineSeparator()));
            }
        }
    }
    
    public JSONTokener getClientSchema(String clientName) throws IOException {
    	return new JSONTokener(getResourceFileAsString(schemaFileBasePath + clientName + "_client_schema.json"));
    }

    public String inputStreamToString(InputStream is) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }
	
	
	public String convertMetadataFileToXMLString(File metadataFile) {
        String xml = "";
        
        try {
        	xml = inputStreamToString(new FileInputStream(metadataFile));
        	xml = xml.replaceAll("&(?![^&]{2,4};)", "&#038;");
        } catch (Exception e) {
        	LOGGER.error("convertMetadataFileToXMLString -- error converting metadata file to string, err={}", ExceptionUtils.getStackTrace(e));
        	return null;
        }
        
        return xml;
	}
	
	public ClientJson convertXMLStringToClientJson(String xml) {
        ClientJson value = null;
        try {
        	String cleanedXml = xml.trim().replaceFirst("\ufeff", "");
        	value = xmlMapper.readValue(cleanedXml, ClientJson.class);
        } catch (IOException e) {
        	LOGGER.error("convertMetadata -- error parsing xml string to json, err={}", ExceptionUtils.getStackTrace(e));
        	return null;
        }
        
        return value;
	}
	
	public Map<String, String> convertClientJsonToMap(ClientJson value) {
		Map<String, String> map = new HashMap<>();
		try {
			if (value == null || value.Indices == null || value.Indices.IndexField == null) {
				LOGGER.error("Parse metadata file failed: error converting xml to json; value.Indices.IndexField=null");
				return map;
			}
			for (int i = 0; i < value.Indices.IndexField.size(); i++) {
				String val = value.Indices.IndexField.get(i).idxValue;
				if (val != null && StringUtils.isBlank(val)) {
					val = val.replaceAll("\\s","");
				}
				map.put(value.Indices.IndexField.get(i).idxName, val);
			}
		} catch(Exception e) {
			LOGGER.error("Parse metadata file failed: error parsing xml string to json; map={}, err={}", map, ExceptionUtils.getStackTrace(e));
			return new HashMap<>();
		}
		return map;
	}

	public Map<String, Object> convertAndValidateMetadata(File metadataFile,  Set<String> errors, String clientName) throws IOException, JSONException {
		JSONObject metadata = new JSONObject(); 
		
		String xml = convertMetadataFileToXMLString(metadataFile);
		
		ClientJson value = convertXMLStringToClientJson(xml);
		Map<String, String> map = convertClientJsonToMap(value);
		if (map.isEmpty()) {
			return null;
		}
		
        String clientJson = gson.toJson(map);
        JSONObject clientJsonObj = new JSONObject( clientJson );
        
        LOGGER.debug("clientJson: {} ", clientJson);
        
        try {
	        JSONObject jsonSchema = new JSONObject(getClientSchema(clientName));
	        
	        SchemaLoader loader = SchemaLoader.builder()
	                .schemaJson(jsonSchema)
	                .build();
	        Schema schema = loader.load().build();
	        schema.validate(clientJsonObj);
	        
        } catch (org.everit.json.schema.ValidationException e) {
        	
        	Class enumClass = getErrEnumFromClientName(clientName);
        	LOGGER.error("ValidationException: json {} ", e.toJSON());
        	LOGGER.error("ValidationException: msg {} ", e.getAllMessages());      	
    		for (String errMsg : e.getAllMessages()) {
    		//	System.out.println("msg:"+ errMsg);
    			getErrors(errMsg, errors, enumClass);
    		}

        }
        
        ClientMetadata convertedMetadata = (ClientMetadata) objectMapper.convertValue(map, getClassFromClientName(clientName));

        String convertedMetadataJson = gson.toJson(convertedMetadata);
        JSONObject convertedMetadatajsonObj = new JSONObject( convertedMetadataJson );
        metadata.put("metadata", convertedMetadatajsonObj);
        
        Map<String, Object> finalMetadata = gson.fromJson(metadata.get("metadata").toString(), HashMap.class);
        
        return finalMetadata;
	}

}
