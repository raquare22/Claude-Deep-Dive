package real.time.service.pojo;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


@JacksonXmlRootElement(localName = "Document")
public class ClientJson {
	@JacksonXmlProperty(localName = "ApplicationID")
	public String ApplicationID;
	@JacksonXmlProperty(localName = "Datagroup")
	public String Datagroup;
	@JacksonXmlProperty(localName = "DocumentClass")
	public String DocumentClass;
	@JacksonXmlProperty(localName = "DocumentType")
	public String DocumentType;
	@JacksonXmlProperty(localName = "FileFormat")
	public String FileFormat;
	@JacksonXmlProperty(localName = "Indices")
	public Indices Indices;
}
