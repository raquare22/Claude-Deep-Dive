package real.time.service.pojo;

import org.junit.Test;

import java.time.LocalDate;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ClientMetadataTest {
	
	@Test
	public void testGetCreatedDate()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		LocalDate localDate = LocalDate.of(2024, 4, 1);
		Date date = java.sql.Date.valueOf(localDate);
		clientMetadata.setCreatedDate(date);
		assertEquals(date, clientMetadata.getCreatedDate());
	}
	
	@Test
	public void testGetDocSentTo()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setDocSentTo("testdoc");
		assertEquals("testdoc", clientMetadata.getDocSentTo());
	}
	
	@Test
	public void testGetSendToDocVault()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendToDocVault(true);
		assertEquals(true, clientMetadata.getSendToDocVault());
	}
	
	@Test
	public void testGetSendToShutterfly()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendToShutterfly(false);
		assertEquals(false, clientMetadata.getSendToShutterfly());
	}
	
	@Test
	public void testGetDateEmailSent()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		LocalDate localDate = LocalDate.of(2024, 4, 1);
		Date date = java.sql.Date.valueOf(localDate);
		clientMetadata.setDateEmailSent(date);
		assertEquals(date, clientMetadata.getDateEmailSent());
	}
	
	@Test
	public void testGetSendEmailNotifications()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendEmailNotifications(false);
		assertEquals(false, clientMetadata.getSendEmailNotifications());
	}
	
	@Test
	public void testGetSendPENAPIRequest()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendPENAPIRequest(false);
		assertEquals(false, clientMetadata.getSendPENAPIRequest());
	}
	
	@Test
	public void testGetCategory()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setCategory("categoryOne");
		assertEquals("categoryOne", clientMetadata.getCategory());
	}
	
	@Test
	public void testGetCorporateMpin()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setCorporateMpin("6956966s");
		assertEquals("6956966s", clientMetadata.getCorporateMpin());
	}
	
	@Test
	public void testGetCreateApplication()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setCreateApplication("app");
		assertEquals("app", clientMetadata.getCreateApplication());
	}
	
	@Test
	public void testGetExpiryDate()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setExpiryDate("01-25-2024");
		assertEquals("01-25-2024", clientMetadata.getExpiryDate());
	}
	
	@Test
	public void testGetFileDescription()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFileDescription("testDescription");
		assertEquals("testDescription", clientMetadata.getFileDescription());
	}
	
	@Test
	public void testGetFileName()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFileName("myfile.test");
		assertEquals("myfile.test", clientMetadata.getFileName());
	}
	
	@Test
	public void testGetFilePath()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFilePath("/user/files/file");
		assertEquals("/user/files/file", clientMetadata.getFilePath());
	}
	
	@Test
	public void testGetFileType()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFileType("pdf");
		assertEquals("pdf", clientMetadata.getFileType());
	}
	
	@Test
	public void testGetProviderEmailId()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setProviderEmailId("John_Doe@test.com");
		assertEquals("John_Doe@test.com", clientMetadata.getProviderEmailId());
	}
	
	@Test
	public void testGetTenant()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setTenant("testTenent");
		assertEquals("testTenent", clientMetadata.getTenant());
	}
	
	@Test
	public void testGetPrivilege()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setPrivilege("testPrevililage");
		assertEquals("testPrevililage", clientMetadata.getPrivilege());
	}
	
	@Test
	public void testGetPostCardInd()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setPostCardInd(false);
		assertEquals(false, clientMetadata.getPostCardInd());
	}

	@Test
	public void testVcpExpiryDate()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setExpiryDate("01/2024");
		assertEquals("2024-01-31T23:59:59.000Z", clientMetadata.vcpExpiryDateFormat(clientMetadata.getExpiryDate(),"P7"));
	}

	@Test
	public void testVcpExpiryDateFormatWithInvalidInput() {
		ClientMetadata clientMetadata = new ClientMetadata();
		String invalidInput = "invalid-date";
		String subCategory = "P7";

		String result = clientMetadata.vcpExpiryDateFormat(invalidInput, subCategory);

		assertEquals(invalidInput, result);
	}
	

}
