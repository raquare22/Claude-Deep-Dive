package real.time.service.pojo;


import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


public class Indices {
	@JacksonXmlProperty(localName = "IndexField")
    @JacksonXmlElementWrapper(useWrapping = false)
	public List<IndexField> IndexField;
	
	public List<IndexField> getIndexField() {
		return IndexField;
	}

	public void setIndexField(List<IndexField> indexField) {
		IndexField = indexField;
	}
}
