package real.time.service.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class ClientRootMetadataTest {

    private ClientRootMetadata clientRootMetadata;

    @Before
    public void setUp() {
        clientRootMetadata = new ClientRootMetadata();
        clientRootMetadata.metadata = new ClientMetadata();
        clientRootMetadata.applicationID = "App123";
        clientRootMetadata.datagroup = "GroupA";
        clientRootMetadata.fileFormat = "JSON";
    }

    @Test
    public void testClientRootMetadataFields() {
        assertNotNull(clientRootMetadata.metadata);
        assertEquals("App123", clientRootMetadata.applicationID);
        assertEquals("GroupA", clientRootMetadata.datagroup);
        assertEquals("JSON", clientRootMetadata.fileFormat);
    }
}
