package real.time.service.pojo;

import org.json.JSONException;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.Assert.*;

public class OCMMetadataTest extends AbstractMetadataTestUtil {
	protected static final String PATH_XML_FILE = "files/metadata/OCM/OCM.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/OCM/OCMError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/OCM/OCMError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/OCM/OCMemailAlertReqN.metadata";

	@Test
	public void testOCMHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		String testDate = null;
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "OCM");
			SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			isoFormat.setTimeZone(TimeZone.getTimeZone("EST"));
			Date date = isoFormat.parse((String)convertedMetadata.get("dateOfService")); // 11292017
			testDate = isoFormat.format(date);
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
	}

	@Test
	public void testOCMError12()
	{
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors,"OCM");
		} catch (IOException | JSONException e)
		{  e.printStackTrace(); }

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(10, errors.size());
	}

	@Test
	public void testOCMError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "OCM");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(9, errors.size());

	}

	@Test
	public void testOCMEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "OCM");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

	}

		@Test
		public void testGettersAndSetters() {
			OCM ocm = new OCM();
			ocm.setNotificationNumber("12345");
			assertEquals("12345", ocm.getNotificationNumber());
			ocm.setSubCategory("A1");
			assertEquals("A1", ocm.getSubCategory());

			ocm.setTin("987654321");
			assertEquals("987654321", ocm.getTin());


			ocm.setMpin("1234");
			assertEquals("1234", ocm.getMpin());

			ocm.setProviderName("Provider Name");
			assertEquals("Provider Name", ocm.getProviderName());

			ocm.setMemberId("M123");
			assertEquals("M123", ocm.getMemberId());
			ocm.setMemberName("John Doe");
			assertEquals("John Doe", ocm.getMemberName());

			assertEquals("John Doe", ocm.getMemberName());

			Date date = new Date();
			ocm.setDateOfService(date);
			assertEquals(date, ocm.getDateOfService());

			ocm.setEmailAlertReq("N");
			assertEquals("N", ocm.getEmailAlertReq());

			ocm.setLetterHistoryID("LH123");
			assertEquals("LH123", ocm.getLetterHistoryID());
			ocm.setPassThruData("Data");
			assertEquals("Data", ocm.getPassThruData());

			ocm.setOriginalPrintTrail("Trail");
			assertEquals("Trail", ocm.getOriginalPrintTrail());

			ocm.setCONFIGKEY("Key123");
			assertEquals("Key123", ocm.getCONFIGKEY());
			ocm.setDMSecurityClass("Class1");
			assertEquals("Class1", ocm.getDMSecurityClass());

			ocm.setRelatedID("RID123");
			assertEquals("RID123", ocm.getRelatedID());

			ocm.setMemberAltID("AltID123");
			assertEquals("AltID123", ocm.getMemberAltID());
			ocm.setELGSLETTERGENID("ELG123");
			assertEquals("ELG123", ocm.getELGSLETTERGENID());

			ocm.setProviderDEC("DEC123");
			assertEquals("DEC123", ocm.getProviderDEC());

			ocm.setNotificationLetterID("NLID123");
			assertEquals("NLID123", ocm.getNotificationLetterID());

			ocm.setELGSREQUESTID("REQ123");
			assertEquals("REQ123", ocm.getELGSREQUESTID());
			ocm.setGenerationType("Type1");
			assertEquals("Type1", ocm.getGenerationType());
			ocm.setWORKGROUP_NME("Group1");
			assertEquals("Group1", ocm.getWORKGROUP_NME());
			ocm.setLetterPriority("High");
			assertEquals("High", ocm.getLetterPriority());

			ocm.setDefaultUsed("Yes");
			assertEquals("Yes", ocm.getDefaultUsed());

			ocm.setHHKey("HH123");
			assertEquals("HH123", ocm.getHHKey());

			ocm.setRequesterID("REQID123");
			assertEquals("REQID123", ocm.getRequesterID());

			ocm.setDUPLEXSIMPLEX("Duplex");
			assertEquals("Duplex", ocm.getDUPLEXSIMPLEX());
			ocm.setMailToAddress1("Address1");
			assertEquals("Address1", ocm.getMailToAddress1());


			ocm.setMailToAddress2("Address2");
			assertEquals("Address2", ocm.getMailToAddress2());

			ocm.setMailToAddress3("Address3");
			assertEquals("Address3", ocm.getMailToAddress3());

			ocm.setMailToAddress4("Address4");
			assertEquals("Address4", ocm.getMailToAddress4());

			ocm.setMailToAddress5("Address5");
			assertEquals("Address5", ocm.getMailToAddress5());

			ocm.setMailToAddress6("Address6");
			assertEquals("Address6", ocm.getMailToAddress6());
		}

	@Test
	public void testSetPatientLastName() throws Exception {
		OCM ocm = new OCM();

		// Access the private method `setPatientLastName` using reflection
		Method setPatientLastNameMethod = OCM.class.getDeclaredMethod("setPatientLastName", String.class);
		setPatientLastNameMethod.setAccessible(true);

		setPatientLastNameMethod.invoke(ocm, "Doe");

		Field patientLastNameField = OCM.class.getDeclaredField("PatientLastName");
		patientLastNameField.setAccessible(true);
		String patientLastName = (String) patientLastNameField.get(ocm);

		assertEquals("Doe", patientLastName);

		Field memberNameField = OCM.class.getDeclaredField("memberName");
		memberNameField.setAccessible(true);
		String memberName = (String) memberNameField.get(ocm);
		assertEquals(" Doe", memberName); // Assuming `PatientFirstName` is null
	}

	@Test
	public void testGetPatientLastName() throws Exception {
		OCM ocm = new OCM();

		Field patientLastNameField = OCM.class.getDeclaredField("PatientLastName");
		patientLastNameField.setAccessible(true);
		patientLastNameField.set(ocm, "Doe");

		Method getPatientLastNameMethod = OCM.class.getDeclaredMethod("getPatientLastName");
		getPatientLastNameMethod.setAccessible(true);

		String result = (String) getPatientLastNameMethod.invoke(ocm);
		assertEquals("Doe", result);
	}

	@Test
	public void testSetSegment() throws Exception {
		OCM ocm = new OCM();

		// Access the private method `setSegment` using reflection
		Method setSegmentMethod = OCM.class.getDeclaredMethod("setSegment", String.class);
		setSegmentMethod.setAccessible(true);
		setSegmentMethod.invoke(ocm, "TestSegment");

		Field segmentField = OCM.class.getDeclaredField("Segment");
		segmentField.setAccessible(true);
		String segment = (String) segmentField.get(ocm);

		assertEquals("TestSegment", segment);
	}

	@Test
	public void testGetSegment() throws Exception {
		OCM ocm = new OCM();


		Field segmentField = OCM.class.getDeclaredField("Segment");
		segmentField.setAccessible(true);
		segmentField.set(ocm, "TestSegment");


		Method getSegmentMethod = OCM.class.getDeclaredMethod("getSegment");
		getSegmentMethod.setAccessible(true);

		String result = (String) getSegmentMethod.invoke(ocm);
		assertEquals("TestSegment", result);
	}
	}
