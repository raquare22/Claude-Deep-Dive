package real.time.service.pojo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class IndexFieldTest {
	
	@Test
	public void testGetIdxName()
	{
		IndexField indexField = new IndexField();
		indexField.setIdxName("testIdName");
		assertEquals("testIdName", indexField.getIdxName());
	}
	
	@Test
	public void testGetIdxValue()
	{
		IndexField indexField = new IndexField();
		indexField.setIdxValue("testIdValue");
		assertEquals("testIdValue", indexField.getIdxValue());
	}

}
