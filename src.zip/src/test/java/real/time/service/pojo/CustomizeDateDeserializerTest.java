package real.time.service.pojo;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.util.Date;

import static org.junit.Assert.*;

public class CustomizeDateDeserializerTest {
	@Test
	public void testDeserializeSuccess() throws JsonParseException, IOException
	{
		Configurator.setAllLevels("", Level.DEBUG);
		String dateJson = "{ \"createdDate\" : \"04/16/2024\"}";
		JsonFactory factory = new JsonFactory();
		JsonParser parser = factory.createParser(dateJson);
		parser.nextToken();
		parser.nextToken();
		parser.nextToken();
		String currentName = parser.getCurrentName();
		System.out.println("currentName=" + currentName + ", date=" +  parser.getText());

		DeserializationContext context = null;
		CustomizeDateDeserializer dateDeserializer = new CustomizeDateDeserializer("MM/dd/yyyy");
		Date date = dateDeserializer.deserialize(parser, context);
		System.out.println("Date=" + ((date != null) ? date : "NULL"));
		assertNotEquals(null, date);
	}

	@Test
	public void testDeserializeEmpty() throws JsonParseException, IOException
	{
		Configurator.setAllLevels("", Level.DEBUG);
		String dateJson = "{ \"createdDate\" : \"\"}";
		JsonFactory factory = new JsonFactory();
		JsonParser parser = factory.createParser(dateJson);
		parser.nextToken();
		parser.nextToken();
		parser.nextToken();
		String currentName = parser.getCurrentName();
		System.out.println("currentName=" + currentName + ", date=" +  parser.getText());

		DeserializationContext context = null;
		CustomizeDateDeserializer dateDeserializer = new CustomizeDateDeserializer("MM/dd/yyyy");
		Date date = dateDeserializer.deserialize(parser, context);
		System.out.println("Date=" + ((date != null) ? date : "NULL"));
		assertNull(date);
	}

	@Test
	public void testDeserializeInvalidFormat() throws JsonParseException, IOException {
		Configurator.setAllLevels("", Level.DEBUG);
		String dateJson = "{ \"createdDate\" : \"invalid-date\"}";
		JsonFactory factory = new JsonFactory();
		JsonParser parser = factory.createParser(dateJson);
		parser.nextToken();
		parser.nextToken();
		parser.nextToken();
		String currentName = parser.getCurrentName();
		System.out.println("currentName=" + currentName + ", date=" +  parser.getText());

		DeserializationContext context = null;
		CustomizeDateDeserializer dateDeserializer = new CustomizeDateDeserializer("MM/dd/yyyy");
		Date date = dateDeserializer.deserialize(parser, context);
		System.out.println("Date=" + ((date != null) ? date : "NULL"));
		assertNull(date);
	}

	@Test
	public void testCreateContextualWithoutCustomDateFormat() throws JsonMappingException {
		CustomizeDateDeserializer deserializer = new CustomizeDateDeserializer("MM/dd/yyyy");
		BeanProperty mockProperty = Mockito.mock(BeanProperty.class);

		Mockito.when(mockProperty.getAnnotation(CustomDateFormat.class)).thenReturn(null);

		JsonDeserializer<?> result = deserializer.createContextual(null, mockProperty);
		assertEquals(deserializer, result);
	}

	@Test
	public void testDeserializeInvalidDateFormatSecondCatch() throws JsonParseException, IOException {
		Configurator.setAllLevels("", Level.DEBUG);
		String dateJson = "{ \"createdDate\" : \"invalid-date-format\"}";
		JsonFactory factory = new JsonFactory();
		JsonParser parser = factory.createParser(dateJson);
		parser.nextToken();
		parser.nextToken();
		parser.nextToken();
		String currentName = parser.getCurrentName();
		System.out.println("currentName=" + currentName + ", date=" + parser.getText());

		DeserializationContext context = null;
		CustomizeDateDeserializer dateDeserializer = new CustomizeDateDeserializer("MM/dd/yyyy");
		Date date = dateDeserializer.deserialize(parser, context);
		System.out.println("Date=" + ((date != null) ? date : "NULL"));
		assertNull(date);
	}
}
