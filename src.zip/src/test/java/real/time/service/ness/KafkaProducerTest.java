package real.time.service.ness;

import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class KafkaProducerTest {

    private KafkaProducer kafkaProducer;
    private NessKafkaAsyncProducer mockProducer;

//    @Before
//    public void setUp() {
//        kafkaProducer = new KafkaProducer();
//        mockProducer = mock(NessKafkaAsyncProducer.class);
//    }

//    @Test
    public void testSetUpOff() {
        KafkaProducer.setUpOff();
        assertFalse(KafkaProducer.getSetUp());
    }

//    @Test
    public void testKafkaProducerNotNull() {
        assertNotNull(kafkaProducer);
    }

//    @Test
    public void testGetNewNessKafkaAsyncProducer() {
        KafkaProducer spyProducer = spy(kafkaProducer);
        doReturn(mockProducer).when(spyProducer).getKafkaProducer();
        NessKafkaAsyncProducer producer = spyProducer.getNewNessKafkaAsyncProducer();
        assertNotNull(producer);
        verify(spyProducer).getKafkaProducer();
    }

//    @Test
    public void testGetKafkaProducer() {
        KafkaProducer spyProducer = spy(kafkaProducer);
        doReturn(mockProducer).when(spyProducer).getKafkaProducer();
        NessKafkaAsyncProducer producer = spyProducer.getKafkaProducer();
        assertNotNull(producer);
    }

//    @Test
    public void testKafkaConfigEnableNessFalse() {
        // Assuming KafkaConfig.enableNess is false
        KafkaProducer.setUpOff();
        assertFalse(KafkaProducer.getSetUp());
    }

}