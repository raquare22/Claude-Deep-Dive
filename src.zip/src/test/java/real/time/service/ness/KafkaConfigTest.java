package real.time.service.ness;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;

public class KafkaConfigTest {

    private KafkaConfig kafkaConfig;

    @Before
    public void setUp() {
        kafkaConfig = new KafkaConfig();
    }

    @Test
    public void testSetAppAskId() {
        String appAskId = "testAppAskId";
        kafkaConfig.setAppAskId(appAskId);
        assertEquals(appAskId, ReflectionTestUtils.getField(KafkaConfig.class, "appAskid"));
    }

    @Test
    public void testSetAppName() {
        String appName = "testAppName";
        kafkaConfig.setAppName(appName);
        assertEquals(appName, ReflectionTestUtils.getField(KafkaConfig.class, "appname"));
    }

    @Test
    public void testSetDeviceVendor() {
        String deviceVendor = "testDeviceVendor";
        kafkaConfig.setDeviceVendor(deviceVendor);
        assertEquals(deviceVendor, ReflectionTestUtils.getField(KafkaConfig.class, "devicevendor"));
    }

    @Test
    public void testSetDeviceProduct() {
        String deviceProduct = "testDeviceProduct";
        kafkaConfig.setDeviceProduct(deviceProduct);
        assertEquals(deviceProduct, ReflectionTestUtils.getField(KafkaConfig.class, "deviceproduct"));
    }

    @Test
    public void testSetTags() {
        String tags = "testTags";
        kafkaConfig.setTags(tags);
        assertEquals(tags, ReflectionTestUtils.getField(KafkaConfig.class, "tag"));
    }

    @Test
    public void testSetBrokerList() {
        String brokerList = "testBrokerList";
        kafkaConfig.setBrokerList(brokerList);
        assertEquals(brokerList, ReflectionTestUtils.getField(KafkaConfig.class, "brokerlist"));
    }

    @Test
    public void testSetKafkaTopic() {
        String kafkaTopic = "testKafkaTopic";
        kafkaConfig.setKafkaTopic(kafkaTopic);
        assertEquals(kafkaTopic, ReflectionTestUtils.getField(KafkaConfig.class, "kafkatopic"));
    }

    @Test
    public void testSetKafkaKeyPass() {
        String kafkaKeyPass = "testKafkaKeyPass";
        kafkaConfig.setKafkaKeyPass(kafkaKeyPass);
        assertEquals(kafkaKeyPass, ReflectionTestUtils.getField(KafkaConfig.class, "kafkaKeypass"));
    }

    @Test
    public void testSetKafkaKeystorePass() {
        String kafkaKeystorePass = "testKafkaKeystorePass";
        kafkaConfig.setKafkaKeystorePass(kafkaKeystorePass);
        assertEquals(kafkaKeystorePass, ReflectionTestUtils.getField(KafkaConfig.class, "kafkaKeystorepass"));
    }

    @Test
    public void testSetKafkaClientId() {
        String kafkaClientId = "testKafkaClientId";
        kafkaConfig.setKafkaClientId(kafkaClientId);
        assertEquals(kafkaClientId, ReflectionTestUtils.getField(KafkaConfig.class, "kafkaclientId"));
    }

    @Test
    public void testSetKafkaProtocol() {
        String kafkaProtocol = "testKafkaProtocol";
        kafkaConfig.setKafkaProtocol(kafkaProtocol);
        assertEquals(kafkaProtocol, ReflectionTestUtils.getField(KafkaConfig.class, "Kafkaprotocol"));
    }

    @Test
    public void testSetKafkaKeyStorePath() {
        String kafkaKeyStorePath = "testKafkaKeyStorePath";
        kafkaConfig.setKafkaKeyStorePath(kafkaKeyStorePath);
        assertEquals(kafkaKeyStorePath, ReflectionTestUtils.getField(KafkaConfig.class, "kafkaKeyStorepath"));
    }

    @Test
    public void testSetEnableNess() {
        boolean enableNess = true;
        kafkaConfig.setEnableNess(enableNess);
        assertEquals(enableNess, ReflectionTestUtils.getField(KafkaConfig.class, "enableNess"));
    }
}