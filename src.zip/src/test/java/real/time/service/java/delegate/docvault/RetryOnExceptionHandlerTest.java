package real.time.service.java.delegate.docvault;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class RetryOnExceptionHandlerTest {

    private RetryOnExceptionHandler handler;

    @Before
    public void setUp() {
        handler = new RetryOnExceptionHandler();
    }

    @Test
    public void testDefaultConstructor() {
        assertEquals(RetryOnExceptionHandler.DEFAULT_RETRIES, handler.getNumRetries());
        assertEquals(RetryOnExceptionHandler.DEFAULT_TIME_TO_WAIT_MS, handler.getTimeToWaitMS());
        assertFalse(handler.isRetry());
    }

    @Test
    public void testParameterizedConstructor() {
        handler = new RetryOnExceptionHandler(3, 500L);
        assertEquals(3, handler.getNumRetries());
        assertEquals(500L, handler.getTimeToWaitMS());
        assertFalse(handler.isRetry());
    }

    @Test
    public void testShouldRetry() {
        assertTrue(handler.shouldRetry());
        handler.setNumRetries(0);
        assertTrue(handler.shouldRetry());
        handler.setNumRetries(-1);
        assertFalse(handler.shouldRetry());
    }

    @Test
    public void testWaitUntilNextTry() {
        long startTime = System.currentTimeMillis();
        handler.waitUntilNextTry();
        long endTime = System.currentTimeMillis();
        assertTrue((endTime - startTime) >= RetryOnExceptionHandler.DEFAULT_TIME_TO_WAIT_MS);
    }

    @Test
    public void testExceptionOccurred() {
        handler.setNumRetries(1);
        try {
            handler.exceptionOccurred();
            assertTrue(handler.isRetry());
            assertEquals(0, handler.getNumRetries());
        } catch (OutOfRetriesException e) {
            fail("Exception should not be thrown");
        }

        try {
            handler.exceptionOccurred();
            fail("Exception should be thrown");
        } catch (OutOfRetriesException e) {
            assertEquals("Exceeded -1 retries", e.getMessage());
        }
    }

    @Test
    public void testSettersAndGetters() {
        handler.setNumRetries(5);
        assertEquals(5, handler.getNumRetries());

        handler.setTimeToWaitMS(1000L);
        assertEquals(1000L, handler.getTimeToWaitMS());

        handler.setRetry(true);
        assertTrue(handler.isRetry());
    }

    @Test
    public void testWaitUntilNextTryInterrupted() {
        RetryOnExceptionHandler localHandler = new RetryOnExceptionHandler();
        // Interrupt current thread to force an InterruptedException during sleep
        Thread.currentThread().interrupt();
        localHandler.waitUntilNextTry();
        // Verify that the interrupt flag remains set after catching the exception
        assertTrue(Thread.currentThread().isInterrupted());
        // Clear the interrupt flag for subsequent tests
        Thread.interrupted();
    }
}