package real.time.service.java.delegate.docvault;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import real.time.service.java.delegate.docvault.OutOfRetriesException;

public class OutOfRetriesExceptionTest {

    @Test
    public void testDefaultConstructor() {
        OutOfRetriesException exception = new OutOfRetriesException();
        assertNull(exception.getMessage());
    }

    @Test
    public void testConstructorWithMessage() {
        String message = "Retries exhausted";
        OutOfRetriesException exception = new OutOfRetriesException(message);
        assertEquals(message, exception.getMessage());
    }
}
