package real.time.service.exception;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProcessExceptionTest {

    @Test
    public void testDefaultConstructor() {
        ProcessException exception = new ProcessException();
        assertNotNull(exception);
    }

    @Test
    public void testConstructorWithMessage() {
        String message = "Process error occurred";
        ProcessException exception = new ProcessException(message);
        assertEquals(message, exception.getMessage());
    }

    @Test
    public void testConstructorWithCause() {
        Throwable cause = new Throwable("Cause of the error");
        ProcessException exception = new ProcessException(cause);
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        String message = "Process error occurred";
        Throwable cause = new Throwable("Cause of the error");
        ProcessException exception = new ProcessException(message, cause);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }
}