package real.time.service.exception;

import org.junit.Test;
import static org.junit.Assert.*;

public class ErrorCodeTest {

    @Test
    public void testGetCode() {
        assertEquals(0, ErrorCode.PROCESS.getCode());
        assertEquals(1, ErrorCode.VALIDATION.getCode());
        assertEquals(2, ErrorCode.PROCESS_SEND.getCode());
    }

    @Test
    public void testGetDescription() {
        assertEquals("A process error has occurred.", ErrorCode.PROCESS.getDescription());
        assertEquals("A validation error has occurred.", ErrorCode.VALIDATION.getDescription());
        assertEquals("A process send error has occurred.", ErrorCode.PROCESS_SEND.getDescription());
    }

    @Test
    public void testToString() {
        assertEquals("0: A process error has occurred.", ErrorCode.PROCESS.toString());
        assertEquals("1: A validation error has occurred.", ErrorCode.VALIDATION.toString());
        assertEquals("2: A process send error has occurred.", ErrorCode.PROCESS_SEND.toString());
    }
}