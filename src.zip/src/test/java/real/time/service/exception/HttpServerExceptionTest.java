package real.time.service.exception;

import org.junit.Test;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.HttpStatus;

import static org.junit.Assert.*;

public class HttpServerExceptionTest {

    @Test
    public void testConstructorAndGetStatus() {
        HttpStatusCode status = HttpStatus.INTERNAL_SERVER_ERROR;
        String message = "Internal Server Error";
        HttpServerException exception = new HttpServerException(message, status);

        assertEquals(message, exception.getMessage());
        assertEquals(status, exception.getStatus());
    }
}