package real.time.service.exception;

import org.junit.Test;
import static org.junit.Assert.*;

public class PrunExceptionTest {

    @Test
    public void testConstructorWithErrorCode() {
        ErrorCode code = ErrorCode.PROCESS;
        PrunException exception = new PrunException(code);
        assertEquals(code, exception.getCode());
        assertNull(exception.getMessage());
    }

    @Test
    public void testConstructorWithMessageAndCauseAndErrorCode() {
        String message = "An error occurred";
        Throwable cause = new Throwable("Cause of the error");
        ErrorCode code = ErrorCode.PROCESS;
        PrunException exception = new PrunException(message, cause, code);
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
        assertEquals(code, exception.getCode());
    }

    @Test
    public void testConstructorWithMessageAndErrorCode() {
        String message = "An error occurred";
        ErrorCode code = ErrorCode.PROCESS;
        PrunException exception = new PrunException(message, code);
        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
    }

    @Test
    public void testConstructorWithCauseAndErrorCode() {
        Throwable cause = new Throwable("Cause of the error");
        ErrorCode code = ErrorCode.PROCESS;
        PrunException exception = new PrunException(cause, code);
        assertEquals(cause, exception.getCause());
        assertEquals(code, exception.getCode());
    }

    @Test
    public void testToString() {
        String message = "An error occurred";
        ErrorCode code = ErrorCode.PROCESS;
        PrunException exception = new PrunException(message, code);
        assertEquals(code + ": " + message, exception.toString());
    }
}