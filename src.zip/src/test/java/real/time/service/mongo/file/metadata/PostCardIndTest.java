package real.time.service.mongo.file.metadata;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doThrow;

@RunWith(SpringRunner.class)
public class PostCardIndTest {

    @InjectMocks
    private PostCardInd postCardInd;

    @Mock
    private Map<String, Boolean> postCardIndMap;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        setPrivateField(postCardInd, "ocmPostCardInd", true);
        setPrivateField(postCardInd, "capPostCardInd", false);
        setPrivateField(postCardInd, "postCardIndMap", new HashMap<>());
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    public void testCreateMap() {
        postCardInd.createMap();
        assertEquals(true, postCardInd.postCardIndMap.get("OCM"));
        assertEquals(false, postCardInd.postCardIndMap.get("CAP"));
    }

    @Test
    public void testGetPostCardInd() {
        postCardInd.createMap();
        assertEquals(true, postCardInd.getPostCardInd("OCM"));
        assertEquals(false, postCardInd.getPostCardInd("CAP"));
        assertNull(postCardInd.getPostCardInd("UNKNOWN"));
    }

    @Test
    public void testGetPostCardIndWithException() {
        doThrow(new RuntimeException()).when(postCardIndMap).get("OCM");
        assertEquals(true, postCardInd.getPostCardInd("OCM"));
    }

    @Test
    public void testGetPostCardInd_ExceptionBlock() throws Exception {
        PostCardInd postCardInd = new PostCardInd();
        // Inject a map that throws an exception on get() call to force execution of the catch block
        Map<String, Boolean> throwingMap = new HashMap<String, Boolean>() {
            @Override
            public Boolean get(Object key) {
                throw new RuntimeException("Forced exception");
            }
        };
        // Use reflection to replace the original map with the throwing map
        Field mapField = PostCardInd.class.getDeclaredField("postCardIndMap");
        mapField.setAccessible(true);
        mapField.set(postCardInd, throwingMap);

        // When exception is thrown, getPostCardInd should catch it and default to true
        Boolean result = postCardInd.getPostCardInd("anyClient");
        Assert.assertTrue(result);
    }
}