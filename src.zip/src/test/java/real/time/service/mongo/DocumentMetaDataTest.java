package real.time.service.mongo;

import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static org.junit.Assert.*;

public class DocumentMetaDataTest {

    private DocumentMetaData documentMetaData;

    @Before
    public void setUp() {
        documentMetaData = new DocumentMetaData();
    }

    @Test
    public void testGettersAndSetters() {
        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        attachments.add(new DocumentAttachmentMetaData());

        documentMetaData.setDocumentAttachments(attachments);
        documentMetaData.setExternalId("externalId");
        documentMetaData.setExpires(new Date());
        documentMetaData.setErrorMessage("errorMessage");
        documentMetaData.setParentId("parentId");
        documentMetaData.setSpaceId(123);
        documentMetaData.setFsId("fsId");
        documentMetaData.setFdsAttachmentId("fdsAttachmentId");
        documentMetaData.setFdsDocumentId("fdsDocumentId");
        documentMetaData.setFileName("fileName");
        documentMetaData.setS3FilePath("s3FilePath");
        documentMetaData.setFileType("fileType");
        documentMetaData.setRevisions(new ArrayList<>());

        assertEquals(attachments, documentMetaData.getDocumentAttachments());
        assertEquals("externalId", documentMetaData.getExternalId());
        assertNotNull(documentMetaData.getExpires());
        assertEquals("errorMessage", documentMetaData.getErrorMessage());
        assertEquals("parentId", documentMetaData.getParentId());
        assertEquals(123, documentMetaData.getSpaceId());
        assertEquals("fsId", documentMetaData.getFsId());
        assertEquals("fdsAttachmentId", documentMetaData.getFdsAttachmentId());
        assertEquals("fdsDocumentId", documentMetaData.getFdsDocumentId());
        assertEquals("fileName", documentMetaData.getFileName());
        assertEquals("s3FilePath", documentMetaData.getS3FilePath());
        assertEquals("fileType", documentMetaData.getFileType());
        assertNotNull(documentMetaData.getRevisions());

    }

    @Test
    public void testToString() {
        documentMetaData.setDocumentAttachments(new ArrayList<>());
        documentMetaData.setExternalId("externalId");
        documentMetaData.setExpires(new Date());
        documentMetaData.setErrorMessage("errorMessage");
        documentMetaData.setParentId("parentId");
        documentMetaData.setSpaceId(123);
        documentMetaData.setFsId("fsId");
        documentMetaData.setFdsAttachmentId("fdsAttachmentId");
        documentMetaData.setFdsDocumentId("fdsDocumentId");
        documentMetaData.setFileName("fileName");
        documentMetaData.setS3FilePath("s3FilePath");

        String expectedString = "DocumentMetaData [documentAttachments=[], externalId=externalId, expires=" + documentMetaData.getExpires()
                + ", errorMessage=errorMessage, parentId=parentId, spaceId=123, fsId=fsId, fdsAttachmentId=fdsAttachmentId, fdsDocumentId=fdsDocumentId, fileName=fileName, s3FilePath=s3FilePath]";
        assertEquals(expectedString, documentMetaData.toString());
    }


}
