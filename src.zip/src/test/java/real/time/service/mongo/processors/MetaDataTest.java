package real.time.service.mongo.processors;

import org.junit.Test;

import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class MetaDataTest {

    @Test
    public void testIt() {
        MetaData metadata = new MetaData();

        metadata.setId(new String());
        metadata.setAppIdentifier(new String());

        metadata.getAppIdentifier();
        metadata.getId();
        metadata.getDateCreated();
        metadata.getDateModified();
        metadata.getName();
        assertNotNull(metadata);

        metadata.setVersion("1");
        metadata.incrementVersion();
        assertEquals("2", metadata.getVersion());

        metadata.setRevisions(Collections.singletonList("revision1"));
        assertEquals("revision1",metadata.getRevisions().get(0));
    }

}
