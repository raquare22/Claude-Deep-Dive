package real.time.service.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class FDSCloudDocumentTest {

    private FDSCloudDocument document;

    @Before
    public void setUp() {
        document = new FDSCloudDocument();
    }

    @Test
    public void testSetAndGetDocumentId() {
        String documentId = "doc123";
        document.setDocumentId(documentId);
        assertEquals(documentId, document.getDocumentId());
    }

    @Test
    public void testSetAndGetSpaceId() {
        String spaceId = "space123";
        document.setSpaceId(spaceId);
        assertEquals(spaceId, document.getSpaceId());
    }

    @Test
    public void testSetAndGetMetadata() {
        String metadata = "metadata";
        document.setMetadata(metadata);
        assertEquals(metadata, document.getMetadata());
    }

    @Test
    public void testSetAndGetSearchTerms() {
        List<String> searchTerms = new ArrayList<>();
        searchTerms.add("term1");
        searchTerms.add("term2");
        document.setSearchTerms(searchTerms);
        assertEquals(searchTerms, document.getSearchTerms());
    }

    @Test
    public void testSetAndGetCreatedOn() {
        Date createdOn = new Date();
        document.setCreatedOn(createdOn);
        assertEquals(createdOn, document.getCreatedOn());
    }

    @Test
    public void testSetAndGetModifiedOn() {
        Date modifiedOn = new Date();
        document.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, document.getModifiedOn());
    }

    @Test
    public void testSetAndGetCreatedBy() {
        String createdBy = "user1";
        document.setCreatedBy(createdBy);
        assertEquals(createdBy, document.getCreatedBy());
    }

    @Test
    public void testSetAndGetModifiedBy() {
        String modifiedBy = "user2";
        document.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, document.getModifiedBy());
    }

    @Test
    public void testSetAndGetAttachments() {
        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
        attachments.add(attachment);
        document.setAttachments(attachments);
        assertEquals(attachments, document.getAttachments());
    }

    @Test
    public void testToString() {
        String documentId = "doc123";
        String spaceId = "space123";
        String metadata = "metadata";
        List<String> searchTerms = new ArrayList<>();
        searchTerms.add("term1");
        searchTerms.add("term2");
        Date createdOn = new Date();
        Date modifiedOn = new Date();
        String createdBy = "user1";
        String modifiedBy = "user2";
        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
        attachments.add(attachment);

        document.setDocumentId(documentId);
        document.setSpaceId(spaceId);
        document.setMetadata(metadata);
        document.setSearchTerms(searchTerms);
        document.setCreatedOn(createdOn);
        document.setModifiedOn(modifiedOn);
        document.setCreatedBy(createdBy);
        document.setModifiedBy(modifiedBy);
        document.setAttachments(attachments);

        String expected = "FDSCloudDocument [documentId=" + documentId + ", spaceId=" + spaceId + ", metadata=" + metadata
                + ", searchTerms=" + searchTerms + ", createdOn=" + createdOn + ", modifiedOn=" + modifiedOn
                + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy + ", attachments=" + attachments + "]";
        assertEquals(expected, document.toString());
    }
}
