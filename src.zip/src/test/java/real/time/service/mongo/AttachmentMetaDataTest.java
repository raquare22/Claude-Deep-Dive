package real.time.service.mongo;

import real.time.service.revision.AttachmentRevision;
import real.time.service.mongo.processors.MetaDataStatus;

import org.junit.Test;
import java.util.Date;

public class AttachmentMetaDataTest {

    @Test
    public void testIt() {
    	real.time.service.mongo.AttachmentMetaData attachmentMetaData = new real.time.service.mongo.AttachmentMetaData();
        attachmentMetaData.isAsync();

        attachmentMetaData.setContentType(new java.lang.String());
        attachmentMetaData.setFsId(new java.lang.String());
        attachmentMetaData.setAsync(false);
        attachmentMetaData.setFileSize(0L);
        attachmentMetaData.setFileName(new java.lang.String());
        attachmentMetaData.setExpires(new java.util.Date());
        attachmentMetaData.setAdapterId(new java.lang.String());
        attachmentMetaData.setAdapterName(new java.lang.String());
        attachmentMetaData.setStAdapterDocId(new java.lang.String());
        attachmentMetaData.setAdapterTypeId(new java.lang.String());
        attachmentMetaData.setExternalId(new java.lang.String());
        attachmentMetaData.setSourceSystemName(new java.lang.String());
        attachmentMetaData.setSourceSystemDateCreated(new java.util.Date());
        attachmentMetaData.setSpaceId(Integer.parseInt("1"));
        attachmentMetaData.setName(new java.lang.String());
        attachmentMetaData.setId(new java.lang.String());
        attachmentMetaData.setAppIdentifier(new java.lang.String());
        attachmentMetaData.setClientId(0);
        attachmentMetaData.setDateCreated(new java.util.Date());
        attachmentMetaData.setDateModified(new java.util.Date());
        attachmentMetaData.setRevisions(new java.util.ArrayList<AttachmentRevision>());
        attachmentMetaData.setStatus(MetaDataStatus.ACTIVE);
        attachmentMetaData.setStatus("ACTIVE");
        attachmentMetaData.setTransactionId(new java.lang.String());
        attachmentMetaData.setVersion(new java.lang.String ());
        attachmentMetaData.setCloudSpaceId("2000");

        attachmentMetaData.getFileName();
        attachmentMetaData.getContentType();
        attachmentMetaData.getFsId();
        attachmentMetaData.getFileSize();
        attachmentMetaData.getExpires();
        attachmentMetaData.getAdapterId();
        attachmentMetaData.getAdapterName();
        attachmentMetaData.getStAdapterDocId();
        attachmentMetaData.getAdapterTypeId();
        attachmentMetaData.getExternalId();
        attachmentMetaData.getSourceSystemName();
        attachmentMetaData.getSourceSystemDateCreated();
        attachmentMetaData.getSpaceId();
        attachmentMetaData.getRevisions();
        attachmentMetaData.getName();
        attachmentMetaData.getId();
        attachmentMetaData.getVersion();
        attachmentMetaData.getAppIdentifier();
        attachmentMetaData.getClientId();
        attachmentMetaData.getDateCreated();
        attachmentMetaData.getDateModified();
        attachmentMetaData.getStatus();
        attachmentMetaData.getTransactionId();

        attachmentMetaData.setExpires(new Date());
        attachmentMetaData.getExpires();
        attachmentMetaData.getCloudSpaceId();

        attachmentMetaData.setSourceSystemDateCreated(new Date());
        attachmentMetaData.getSourceSystemDateCreated();
    }

    @Test
    public void testItNull() {
    	real.time.service.mongo.AttachmentMetaData attachmentMetaData = new real.time.service.mongo.AttachmentMetaData();

        attachmentMetaData.setExpires(null);
        attachmentMetaData.setSourceSystemDateCreated(null);
        attachmentMetaData.setDateCreated(null);
        attachmentMetaData.setDateModified(null);
        attachmentMetaData.setRevisions(null);

        attachmentMetaData.setExpires(null);
        attachmentMetaData.getExpires();

        attachmentMetaData.setSourceSystemDateCreated(null);
        attachmentMetaData.getSourceSystemDateCreated();

        attachmentMetaData.setSpaceId(null);
        attachmentMetaData.getSpaceId();
    }

}
