package real.time.service.mongo;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import static org.junit.Assert.*;

public class DocumentAttachmentMetaDataTest {

    @Test
    public void testJsonMapping() throws ParseException, IOException {

        DocumentAttachmentMetaData documentAttachment = new DocumentAttachmentMetaData();
        documentAttachment.setExternalId("abcd");
        documentAttachment.setFsId("5a56789c-b123-4234-abcd-4b123456789a");
        documentAttachment.setIndex(1);
        documentAttachment.setName("close-active.png");
        documentAttachment.setExpires(new Date());
        documentAttachment.setErrorMessage("error");
        documentAttachment.setFileSize(100L);
        documentAttachment.setContentType("contentType");
        documentAttachment.setSpaceId("1063");
        documentAttachment.setStatus("True");
        documentAttachment.setSentToDocVault(true);
        documentAttachment.setVirusScanStatus("virusScanStatus");
        documentAttachment.setCreatedBy("createdBy");
        documentAttachment.setCreatedOn(new Date());
        documentAttachment.setModifiedBy("modifiedBy");
        documentAttachment.setModifiedOn(new Date());
        documentAttachment.setUrl("url");
        documentAttachment.setCloudStorageProvider("cloudStorageProvider");


        documentAttachment.getExpires();
        documentAttachment.getIndex();

        ObjectMapper mapper = new ObjectMapper();
        HashMap<String,Object> result =
                new ObjectMapper().readValue(mapper.writeValueAsString(documentAttachment), HashMap.class);

        assertTrue("removes null values failed", result.size() == 17);
        assertTrue("fsId to id transform failed", result.containsKey("id"));
        assertFalse("index not expected", result.containsKey("index"));
        assertTrue("name to file_name transform failed", result.containsKey("fileName"));
        assertFalse("expires not expected", result.containsKey("expires"));
        assertTrue("externalId to external_id transform failed ", result.containsKey("external_id"));
        assertTrue("errorMessage to error_message transform failed", result.containsKey("error_message"));


        String fsId = documentAttachment.getFsId();
        int index = documentAttachment.getIndex();
        String name = documentAttachment.getName();
        Date expires = documentAttachment.getExpires();
        String status = documentAttachment.getStatus();
        String externalId = documentAttachment.getExternalId();
        String errorMessage = documentAttachment.getErrorMessage();
        boolean sentToDocVault = documentAttachment.isSentToDocVault();

        String metadataString = "DocumentAttachmentMetaData [fsId=" + fsId + ", index=" + index + ", fileName=" + name + ", expires=" + expires
                        + ", status=" + status + ", externalId=" + externalId + ", errorMessage=" + errorMessage + ", sentToDocVault="
                        + sentToDocVault + "]";

        String DocumentAttachmentMetaDataString = documentAttachment.toString();
        assertEquals(metadataString,DocumentAttachmentMetaDataString);

    }
}
