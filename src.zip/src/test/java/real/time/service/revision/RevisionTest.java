package real.time.service.revision;

import org.junit.Before;
import org.junit.Test;
import real.time.service.mongo.processors.MetaDataStatus;

import java.util.Date;

import static org.junit.Assert.*;

public class RevisionTest {

    private Revision revision;

    @Before
    public void setUp() {
        revision = new Revision();
    }

    @Test
    public void testGetSetAppIdentifier() {
        String appIdentifier = "app123";
        revision.setAppIdentifier(appIdentifier);
        assertEquals(appIdentifier, revision.getAppIdentifier());
    }

    @Test
    public void testGetSetClientId() {
        int clientId = 123;
        revision.setClientId(clientId);
        assertEquals(clientId, revision.getClientId());
    }

    @Test
    public void testGetSetDateCreated() {
        Date dateCreated = new Date();
        revision.setDateCreated(dateCreated);
        assertEquals(dateCreated, revision.getDateCreated());
    }

    @Test
    public void testGetSetDateModified() {
        Date dateModified = new Date();
        revision.setDateModified(dateModified);
        assertEquals(dateModified, revision.getDateModified());
    }

    @Test
    public void testGetSetName() {
        String name = "revisionName";
        revision.setName(name);
        assertEquals(name, revision.getName());
    }

    @Test
    public void testGetSetSpaceId() {
        int spaceId = 456;
        String spaceIdString = "456";
        revision.setSpaceId(spaceId);
        revision.setSpaceId(spaceIdString);
        assertEquals(spaceId, revision.getSpaceId());
    }

    @Test
    public void testGetSetStatus() {
        MetaDataStatus status = MetaDataStatus.ACTIVE;
        String statusString = "ACTIVE";
        revision.setStatus(statusString);
        revision.setStatus(status);
        assertEquals(status, revision.getStatus());
    }

    @Test
    public void testGetSetTransactionId() {
        String transactionId = "txn123";
        revision.setTransactionId(transactionId);
        assertEquals(transactionId, revision.getTransactionId());
    }

    @Test
    public void testGetSetVersion() {
        String version = "1.0";
        revision.setVersion(version);
        assertEquals(version, revision.getVersion());
    }
}