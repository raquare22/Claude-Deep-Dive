package real.time.service.revision;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class AttachmentRevisionTest {

    private AttachmentRevision attachmentRevision;

    @Before
    public void setUp() {
        attachmentRevision = new AttachmentRevision();
    }

    @Test
    public void testGetSetAdapterId() {
        String adapterId = "adapter123";
        attachmentRevision.setAdapterId(adapterId);
        assertEquals(adapterId, attachmentRevision.getAdapterId());
    }

    @Test
    public void testGetSetAdapterName() {
        String adapterName = "adapterName";
        attachmentRevision.setAdapterName(adapterName);
        assertEquals(adapterName, attachmentRevision.getAdapterName());
    }

    @Test
    public void testGetSetAdapterTypeId() {
        String adapterTypeId = "type123";
        attachmentRevision.setAdapterTypeId(adapterTypeId);
        assertEquals(adapterTypeId, attachmentRevision.getAdapterTypeId());
    }

    @Test
    public void testGetSetContentType() {
        String contentType = "application/json";
        attachmentRevision.setContentType(contentType);
        assertEquals(contentType, attachmentRevision.getContentType());
    }

    @Test
    public void testGetSetDateAttachmentUpdated() {
        Date date = new Date();
        attachmentRevision.setDateAttachmentUpdated(date);
        assertEquals(date, attachmentRevision.getDateAttachmentUpdated());
    }

    @Test
    public void testGetSetExpires() {
        Date date = new Date();
        attachmentRevision.setExpires(date);
        assertEquals(date, attachmentRevision.getExpires());
    }

    @Test
    public void testGetSetExternalId() {
        String externalId = "external123";
        attachmentRevision.setExternalId(externalId);
        assertEquals(externalId, attachmentRevision.getExternalId());
    }

    @Test
    public void testGetSetFilename() {
        String filename = "file.txt";
        attachmentRevision.setFilename(filename);
        assertEquals(filename, attachmentRevision.getFilename());
    }

    @Test
    public void testGetSetFileSize() {
        long fileSize = 12345L;
        attachmentRevision.setFileSize(fileSize);
        assertEquals(fileSize, attachmentRevision.getFileSize());
    }

    @Test
    public void testGetSetFsId() {
        String fsId = "fs123";
        attachmentRevision.setFsId(fsId);
        assertEquals(fsId, attachmentRevision.getFsId());
    }

    @Test
    public void testGetSetOriginalStorageDate() {
        Date date = new Date();
        attachmentRevision.setOriginalStorageDate(date);
        assertEquals(date, attachmentRevision.getOriginalStorageDate());
    }

    @Test
    public void testGetSetSourceSystemDateCreated() {
        Date date = new Date();
        attachmentRevision.setSourceSystemDateCreated(date);
        assertEquals(date, attachmentRevision.getSourceSystemDateCreated());
    }

    @Test
    public void testGetSetSourceSystemName() {
        String sourceSystemName = "sourceSystem";
        attachmentRevision.setSourceSystemName(sourceSystemName);
        assertEquals(sourceSystemName, attachmentRevision.getSourceSystemName());
    }

    @Test
    public void testGetSetStAdapterDocId() {
        String stAdapterDocId = "doc123";
        attachmentRevision.setStAdapterDocId(stAdapterDocId);
        assertEquals(stAdapterDocId, attachmentRevision.getStAdapterDocId());
    }
}
