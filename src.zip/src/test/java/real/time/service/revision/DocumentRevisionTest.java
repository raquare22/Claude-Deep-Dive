package real.time.service.revision;

import org.junit.Before;
import org.junit.Test;
import org.bson.Document;
import real.time.service.mongo.DocumentAttachmentMetaData;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class DocumentRevisionTest {

    private DocumentRevision documentRevision;

    @Before
    public void setUp() {
        documentRevision = new DocumentRevision();
    }

    @Test
    public void testGetSetExternalId() {
        String externalId = "external123";
        documentRevision.setExternalId(externalId);
        assertEquals(externalId, documentRevision.getExternalId());
    }

    @Test
    public void testGetSetDateAttachmentUpdated() {
        Date date = new Date();
        documentRevision.setDateAttachmentUpdated(date);
        assertEquals(date, documentRevision.getDateAttachmentUpdated());
    }

    @Test
    public void testGetSetMetadata() {
        Document metadata = new Document("key", "value");
        documentRevision.setMetadata(metadata);
        assertEquals(metadata, documentRevision.getMetadata());
    }

    @Test
    public void testGetSetDocumentAttachments() {
        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
        attachments.add(attachment);
        documentRevision.setDocumentAttachments(attachments);
        assertEquals(attachments, documentRevision.getDocumentAttachments());
    }

    @Test
    public void testGetSetErrorMessage() {
        String errorMessage = "error";
        documentRevision.setErrorMessage(errorMessage);
        assertEquals(errorMessage, documentRevision.getErrorMessage());
    }
}