package real.time.service.model;

import static org.junit.Assert.assertEquals;

import java.util.Collections;
import java.util.Map;

import org.junit.Test;

public class Doc360UploadResponseTest {

    @Test
    public void testGettersAndSetters() {
        Doc360UploadResponse response = new Doc360UploadResponse();
		Map<String, Object> messageMap = Collections.emptyMap();

        response.setGlobalDocId("f4979166-6553-441d-aff8-575c5a26c8bb");
        response.setIndexName("u_clinical_docs_2026-04");
        response.setReceivedDate("2026-04-27T20:02:30.107Z");
        response.setStatus(201);
        response.setMessageMap(messageMap);

        assertEquals("f4979166-6553-441d-aff8-575c5a26c8bb", response.getGlobalDocId());
        assertEquals("u_clinical_docs_2026-04", response.getIndexName());
        assertEquals("2026-04-27T20:02:30.107Z", response.getReceivedDate());
        assertEquals(Integer.valueOf(201), response.getStatus());
        assertEquals(messageMap, response.getMessageMap());
    }
}

