package real.time.service.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PingTest {

    private Ping ping;

    @Before
    public void setUp() {
        ping = new Ping("build123", "2023-10-10T10:00:00Z");
    }

    @Test
    public void testGetSetBuildNumber() {
        String buildNumber = "build456";
        ping.setBuildNumber(buildNumber);
        assertEquals(buildNumber, ping.getBuildNumber());
    }

    @Test
    public void testGetSetTimeStamp() {
        String timeStamp = "2023-10-11T11:00:00Z";
        ping.setTimeStamp(timeStamp);
        assertEquals(timeStamp, ping.getTimeStamp());
    }

    @Test
    public void testToString() {
        String expected = "buildNumber: build123, timeStamp: 2023-10-10T10:00:00Z";
        assertEquals(expected, ping.toString());
    }
}