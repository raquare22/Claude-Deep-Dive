package real.time.service.document.util;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class RulesTest {

    @Test
    public void testCustomRule() {
        Rules rules = new Rules();
        String customRule = "customRuleValue";
        rules.setCustomRule(customRule);
        assertEquals(customRule, rules.getCustomRule());
    }

    @Test
    public void testEncryptScheme() {
        Rules rules = new Rules();
        String encryptScheme = "encryptSchemeValue";
        rules.setEncryptScheme(encryptScheme);
        assertEquals(encryptScheme, rules.getEncryptScheme());
    }

    @Test
    public void testVirusScan() {
        Rules rules = new Rules();
        String virusScan = "virusScanValue";
        rules.setVirusScan(virusScan);
        assertEquals(virusScan, rules.getVirusScan());
    }

    @Test
    public void testConvertTo() {
        Rules rules = new Rules();
        String convertTo = "convertToValue";
        rules.setConvertTo(convertTo);
        assertEquals(convertTo, rules.getConvertTo());
    }

    @Test
    public void testNotNull() {
        Rules rules = new Rules();
        assertNotNull(rules);
    }
}