package real.time.service.document.response.util;


import org.bson.Document;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import real.time.service.document.util.DocumentResponse;
import real.time.service.mongo.AttachmentMetaData;
import real.time.service.mongo.DocumentMetaData;
import real.time.service.mongo.processors.MetaDataStatus;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;

public class DocumentResponseUtilTest {


    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentResponseUtilTest.class);

    @Test(expected = Test.None.class /* no exception expected */)
    public void testLogInfoWithTransactionId() {
        DocumentResponseUtil.logInfoWithTransactionId(LOGGER, "testMsg", "transId1234");
    }

    @Test
    public void test() throws IOException, ParseException {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        List<AttachmentMetaData> attmtsMetaDataList = new ArrayList<>();
        String documentJsonStr = DocumentResponseUtil.buildDocumentResponseInJson(documentMetaData, attmtsMetaDataList);
        assertNotNull(documentJsonStr);
    }

    /*
     * List not null, not empty
     */
    @Test
    public void testPrepareFullDocumentResposne() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getAttachments().length, equalTo(1) );
    }

    /*
     * List not null, but empty
     */
    @Test
    public void testPrepareFullDocumentResposne2() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        List<AttachmentMetaData> amds = new ArrayList<>();
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getId(), nullValue() );
    }

    /*
     * List  null
     */
    @Test
    public void testPrepareFullDocumentResposne3() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        List<AttachmentMetaData> amds = null;
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getId(), nullValue() );
    }

    /*
     * documentMetaData not null
     */
    @Test
    public void testPrepareFullDocumentResposne4() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        Document metadata = new Document();
        documentMetaData.setMetadata(metadata);
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getAttachments().length, equalTo(1) );
    }

    /*
     * documentMetaData is null
     */
    @Test
    public void testPrepareFullDocumentResposne5() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        Document metadata = null;
        documentMetaData.setMetadata(metadata);
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getAttachments().length, equalTo(1) );
    }

    /*
     * status not null
     */
    @Test
    public void testPrepareFullDocumentResposne6() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setStatus(MetaDataStatus.ACTIVE);
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getAttachments().length, equalTo(1) );
    }

    /*
     * dateCreated not null
     */
    @Test
    public void testPrepareFullDocumentResposne7() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setDateCreated(new Date());
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getAttachments().length, equalTo(1) );
    }

    /*
     * dateCreated is null
     */
    @Test
    public void testPrepareFullDocumentResposne8() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setDateCreated(null);
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getAttachments().length, equalTo(1) );
    }

    /*
     * revisions not null
     */
    @Test
    public void testPrepareFullDocumentResposne9() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        List<String> revs = new ArrayList<>();
        revs.add("rev1");
        documentMetaData.setRevisions(revs);
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertNull(documentResponse.getRevisions());
    }

    /*
     * revisions is null
     */
    @Test
    public void testPrepareFullDocumentResposne10() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        List<String> revs = null;
        documentMetaData.setRevisions(revs);
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setStatus(MetaDataStatus.ACTIVE);
        List<AttachmentMetaData> amds = new ArrayList<>();
        amds.add(amd);
        DocumentResponse documentResponse = DocumentResponseUtil.prepareFullDocumentResponse(documentMetaData, amds);
        assertThat(documentResponse.getRevisions(), equalTo(null) );
    }

    @Test
    public void testPrivateConstructor() throws Exception {
        Constructor<DocumentResponseUtil> constructor = DocumentResponseUtil.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        try {
            constructor.newInstance();
            fail("Expected an InvocationTargetException with AssertionError as cause.");
        } catch (InvocationTargetException e) {
            assertTrue(e.getCause() instanceof AssertionError);
        }
    }
}

