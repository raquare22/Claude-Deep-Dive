package real.time.service.document.util;

import real.time.service.revision.AttachmentRevision;
import real.time.service.mongo.AttachmentMetaData;
import real.time.service.mongo.processors.MetaDataStatus;
import org.junit.Test;

import java.util.Date;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class AttachmentTest {

    @Test
    public void testIt() {
        Attachment attachment = new Attachment();
        attachment.getId();
        attachment.setId("id");
        attachment.getStatus();
        attachment.setStatus("status");
        attachment.getSpaceId();
        attachment.setSpaceId(0);
        attachment.getExpires();
        attachment.setExpires(null);
        attachment.getFileName();
        attachment.setFileName("fileName");
        attachment.getFileSize();
        attachment.setFileSize(0L);
        attachment.getContentType();
        attachment.setContentType("contentType");
        attachment.getDateCreated();
        attachment.setDateCreated(null);
        attachment.getExternalId();
        attachment.setExternalId("externalId");
        attachment.setIndex(0);
        attachment.getSourceSystemName();
        attachment.setSourceSystemName("sourceSystemName");
        attachment.getSourceSystemDateCreated();
        attachment.setSourceSystemDateCreated(null);
        attachment.getRevisions();
        attachment.setRevisions(null);
        attachment.getIndex();
        attachment.getFileId();
        attachment.setFileId("fileId");
        attachment.getFileDescription();
        attachment.setFileDescription("fileDescription");
        attachment.getFileCreatedDate();
        attachment.setFileCreatedDate(null);
        attachment.getFileSize();
        attachment.setFileSize(0L);
        attachment.getSpaceIdUnder();
        attachment.setSpaceIdUnder(1);
        attachment.getFileNameUnder();
        attachment.setFileNameUnder("fileNameUnder");
        attachment.getFileSizeUnder();
        attachment.setFileSizeUnder(1L);
        attachment.getContentTypeUnder();
        attachment.setContentTypeUnder("contentTypeUnder");
    }

    @Test
    public void testNotNulls() {
        Attachment attachment = new Attachment();
        attachment.setExpires(new Date());
        assertNotNull(attachment.getExpires());
        attachment.setDateCreated(new Date());
        assertNotNull(attachment.getDateCreated());
        attachment.setSourceSystemName("sourceSystemName");
        assertNotNull(attachment.getSourceSystemName());
        attachment.setSourceSystemDateCreated(new Date());
        assertNotNull(attachment.getSourceSystemDateCreated());
        attachment.setRevisions(new ArrayList<AttachmentRevision>());
        assertNotNull(attachment.getRevisions());
    }

    @Test
    public void testGetSerialVersionUID() {
        assertEquals(1L, Attachment.getSerialVersionUID());
    }

    @Test
    public void testCreateDocLibAndDocVaultAttachment() {
        AttachmentMetaData amd = new AttachmentMetaData();
        amd.setAttachmentId("fileId");
        amd.setDateCreated(new Date());
        //amd.setSpaceId(123);
        amd.setFileName("fileName");
        //amd.setFileSize(12345L);
        amd.setContentType("contentType");
        amd.setExpires(new Date());
        amd.setFsId("fsId");
        amd.setStatus(MetaDataStatus.ACTIVE);
        amd.setExternalId("externalId");

        Attachment docLibAttachment = Attachment.createDocLibAttachment(amd);
        assertEquals("fileId", docLibAttachment.getFileId());
        assertEquals("fileName", docLibAttachment.getFileName());
        //assertEquals(String.valueOf(12345L), docLibAttachment.getFileSize()); // Cast expected value to String
        assertEquals("contentType", docLibAttachment.getContentType());
        //assertEquals(123, docLibAttachment.getSpaceId());
        assertNotNull(docLibAttachment.getFileCreatedDate());

        Attachment docVaultAttachment = Attachment.createDocVaultAttachment(amd);
        assertEquals("fsId", docVaultAttachment.getId());
        assertEquals("fileName", docVaultAttachment.getFileNameUnder());
        //assertEquals(Long.valueOf(12345L), docVaultAttachment.getFileSizeUnder());
        assertEquals("contentType", docVaultAttachment.getContentTypeUnder());
        //assertEquals(Integer.valueOf(123), docVaultAttachment.getSpaceIdUnder());
        assertEquals("externalId", docVaultAttachment.getExternalId());
        assertNotNull(docVaultAttachment.getExpires());
        assertNotNull(docVaultAttachment.getDateCreated());
        assertEquals("ACTIVE", docVaultAttachment.getStatus());
    }


    @Test
    public void testSettersWithInteger() {
        Attachment attachment = new Attachment();
        attachment.setIndex(Integer.valueOf(10));
        attachment.setSpaceIdUnder(10);
        assertEquals(Integer.valueOf(10), attachment.getIndex());
        assertEquals(Integer.valueOf(10), attachment.getSpaceIdUnder());
    }

    @Test
    public void testSetIndexWithPrimitive() {
        Attachment attachment = new Attachment();
        attachment.setIndex(20);
        attachment.setFileSize("fileSize");;
        attachment.setFileSizeUnder(Long.valueOf(20L));
        attachment.setSpaceIdUnder(Integer.valueOf(10));
        assertEquals(Integer.valueOf(10), attachment.getSpaceIdUnder());
        assertEquals(Integer.valueOf(20), attachment.getIndex());
        assertEquals(Long.valueOf(20L), attachment.getFileSizeUnder());
        assertEquals("fileSize", attachment.getFileSize());
    }


}