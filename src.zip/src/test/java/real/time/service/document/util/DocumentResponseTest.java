package real.time.service.document.util;

import real.time.service.revision.DocumentRevision;
import org.bson.Document;
import org.junit.Test;

public class DocumentResponseTest {

    @Test
    public void testIt() {
    	real.time.service.document.util.DocumentResponse documentResponse = new  real.time.service.document.util.DocumentResponse();
        documentResponse.toString();
        documentResponse.getId();
        documentResponse.setId(new java.lang.String());
        documentResponse.getSpaceId();
        documentResponse.setSpaceId(new java.lang.Integer("1"));
        documentResponse.getStatus();
        documentResponse.setStatus(new java.lang.String());
        documentResponse.setVersion(new java.lang.String());
        documentResponse.getExpires();
        documentResponse.setExpires(new java.lang.String());
        documentResponse.getParentId();
        documentResponse.setParentId((new java.lang.String()));

        documentResponse.setAttachments(new real.time.service.document.util.Attachment[1]);
        documentResponse.getAttachments();

        documentResponse.getRules();
        documentResponse.setRules( new real.time.service.document.util.Rules());
        documentResponse.getExternalId();
        documentResponse.setExternalId(new java.lang.String());
        documentResponse.getStoreInputFiles();
        documentResponse.setStoreInputFiles(new java.lang.String());
        documentResponse.getErrorMessage();
        documentResponse.setErrorMessage(new java.lang.String());
        documentResponse.setMetadata(new Document());
        documentResponse.getMetadata();
        documentResponse.setDateCreated(new java.lang.String());
        documentResponse.getDateCreated();
        documentResponse.getCloudSpaceId();
        documentResponse.setCloudSpaceId("1");
        documentResponse.setRevisions(new java.util.ArrayList<DocumentRevision>());
        documentResponse.getRevisions();
        documentResponse.getDateModified();
        documentResponse.setDateModified(new java.lang.String());

        documentResponse.getVersion();
    }

    @Test
    public void testNullObjects() {
    	real.time.service.document.util.DocumentResponse documentResponse= new real.time.service.document.util.DocumentResponse();
        documentResponse.setAttachments(null);
        documentResponse.getAttachments();
        documentResponse.setRevisions(null);
        documentResponse.getRevisions();
    }

}
