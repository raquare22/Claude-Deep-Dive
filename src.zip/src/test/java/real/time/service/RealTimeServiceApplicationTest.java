package real.time.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import real.time.service.ness.KafkaConfig;
import real.time.service.ness.RealTimeNessConfig;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class RealTimeServiceApplicationTest {

    @InjectMocks
    private RealTimeServiceApplication realTimeServiceApplication;

    @Mock
    private SpringApplication springApplication;

    @Mock
    private RealTimeServiceApplicationContextListener contextListener;

    @Mock
    private JavaMailSenderImpl javaMailSender;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }



    @Test
    public void testJavaMailSender() {
        JavaMailSender sender = realTimeServiceApplication.javaMailSender();
        assertNotNull(sender);
        assertTrue(sender instanceof JavaMailSenderImpl);
    }

}