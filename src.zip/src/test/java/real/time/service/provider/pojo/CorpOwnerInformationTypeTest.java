package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class CorpOwnerInformationTypeTest {

    @Test
    public void testProviderId() {
        CorpOwnerInformationType corpOwnerInfo = new CorpOwnerInformationType();
        String providerId = "12345";
        corpOwnerInfo.setProviderId(providerId);
        assertEquals(providerId, corpOwnerInfo.getProviderId());
    }

    @Test
    public void testLastName() {
        CorpOwnerInformationType corpOwnerInfo = new CorpOwnerInformationType();
        String lastName = "Doe";
        corpOwnerInfo.setLastName(lastName);
        assertEquals(lastName, corpOwnerInfo.getLastName());
    }

    @Test
    public void testFirstName() {
        CorpOwnerInformationType corpOwnerInfo = new CorpOwnerInformationType();
        String firstName = "John";
        corpOwnerInfo.setFirstName(firstName);
        assertEquals(firstName, corpOwnerInfo.getFirstName());
    }

    @Test
    public void testMiddleName() {
        CorpOwnerInformationType corpOwnerInfo = new CorpOwnerInformationType();
        String middleName = "A.";
        corpOwnerInfo.setMiddleName(middleName);
        assertEquals(middleName, corpOwnerInfo.getMiddleName());
    }

    @Test
    public void testSuffix() {
        CorpOwnerInformationType corpOwnerInfo = new CorpOwnerInformationType();
        String suffix = "Jr.";
        corpOwnerInfo.setSuffix(suffix);
        assertEquals(suffix, corpOwnerInfo.getSuffix());
    }
}