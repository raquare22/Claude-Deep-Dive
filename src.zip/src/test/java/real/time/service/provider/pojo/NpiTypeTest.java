package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class NpiTypeTest {

    @Test
    public void testNpiType() {
        NpiType npiType = new NpiType();

        // Test setting and getting npi
        String npi = "1234567890";
        npiType.setNpi(npi);
        assertEquals(npi, npiType.getNpi());

        // Test setting and getting npiLevelCode
        String npiLevelCode = "Level1";
        npiType.setNpiLevelCode(npiLevelCode);
        assertEquals(npiLevelCode, npiType.getNpiLevelCode());
    }
}