package real.time.service.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class NpiTest {
    @Test
    public void testIt() {
        Npi npi = new Npi();

        npi.setNpiId(new String());
        npi.setNpiLvlCd(new String());
        npi.setNpiEffDt(new java.util.Date());
        npi.setNpiCancDt(new java.util.Date());

        npi.getNpiId();
        npi.getNpiLvlCd();
        npi.getNpiEffDt();
        npi.getNpiCancDt();
        assertNotNull(npi);
    }

    @Test
    public void testItNulls() {
        Npi npi = new Npi();

        npi.setNpiEffDt(null);
        npi.setNpiCancDt(null);

        npi.getNpiEffDt();
        npi.getNpiCancDt();
        assertNotNull(npi);
    }

}
