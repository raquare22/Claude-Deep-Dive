package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class RequestBodyTest {

    @Test
    public void testRequestBodyBuilder() {
        RequestBody requestBody = new RequestBody.RequestBodyBuilder()
                .setTaxIdNumber("123456789")
                .setAppName("testApp")
                .setAttributeSet("testAttributeSet")
                .setCount("10")
                .build();

        assertNotNull(requestBody);
        assertEquals("123456789", requestBody.getTaxIdNumber());
        assertEquals("testApp", requestBody.getAppName());
        assertEquals("testAttributeSet", requestBody.getAttributeSet());
        assertEquals("10", requestBody.getCount());
    }
}