package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class QualityTypeTest {

    @Test
    public void testQualityType() {
        QualityType qualityType = new QualityType();

        // Test setting and getting name
        qualityType.setName("QualityName");
        assertEquals("QualityName", qualityType.getName());

        // Test setting and getting value
        qualityType.setValue("QualityValue");
        assertEquals("QualityValue", qualityType.getValue());
    }
}