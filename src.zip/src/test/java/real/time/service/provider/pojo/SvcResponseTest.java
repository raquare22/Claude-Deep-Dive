package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class SvcResponseTest {

    @Test
    public void testPhysicianFacilityInformation() {
        SvcResponse svcResponse = new SvcResponse();
        PhysicianFacilityInformation physicianFacilityInformation = new PhysicianFacilityInformation();

        svcResponse.setPhysicianFacilityInformation(physicianFacilityInformation);

        assertNotNull(svcResponse.getPhysicianFacilityInformation());
        assertEquals(physicianFacilityInformation, svcResponse.getPhysicianFacilityInformation());
    }
}