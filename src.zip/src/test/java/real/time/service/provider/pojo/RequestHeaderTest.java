package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Date;

public class RequestHeaderTest {

    @Test
    public void testRequestHeaderBuilder() {
        Date now = new Date();
        RequestHeader requestHeader = new RequestHeader.RequestHeaderBuilder()
                .setScope("testScope")
                .setActor("testActor")
                .setCorrelationId("testCorrelationId")
                .setToken("testToken")
                .setTimeStamp(now)
                .build();

        assertNotNull(requestHeader);
        assertEquals("testScope", requestHeader.getScope());
        assertEquals("testActor", requestHeader.getActor());
        assertEquals("testCorrelationId", requestHeader.getCorrelationId());
        assertEquals("testToken", requestHeader.getToken());
        assertEquals(now.toString(), requestHeader.getTimeStamp());
    }

    @Test
    public void testRequestHeaderBuilderWithNullTimeStamp() {
        RequestHeader requestHeader = new RequestHeader.RequestHeaderBuilder()
                .setScope("testScope")
                .setActor("testActor")
                .setCorrelationId("testCorrelationId")
                .setToken("testToken")
                .build();

        assertNotNull(requestHeader);
        assertEquals("testScope", requestHeader.getScope());
        assertEquals("testActor", requestHeader.getActor());
        assertEquals("testCorrelationId", requestHeader.getCorrelationId());
        assertEquals("testToken", requestHeader.getToken());
        assertNotNull(requestHeader.getTimeStamp());
    }
}