package real.time.service.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class DegreeTest {
    @Test
    public void testIt() {
        Degree degree = new Degree();

        degree.setDegCd(new String());
        degree.setDegPriCd(new String());
        degree.setDegDesc(new String());
        degree.getDegCd();
        degree.getDegPriCd();
        degree.getDegDesc();
        assertNotNull ( degree );
    }
}
