package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class EntityInformationTypeTest {

    @Test
    public void testGetEntityId() {
        EntityInformationType entityInformationType = new EntityInformationType();
        entityInformationType.setEntityId("Entity123");
        assertEquals("Entity123", entityInformationType.getEntityId());
    }

    @Test
    public void testSetEntityId() {
        EntityInformationType entityInformationType = new EntityInformationType();
        entityInformationType.setEntityId("Entity123");
        assertNotNull(entityInformationType.getEntityId());
    }

    @Test
    public void testGetEntityType() {
        EntityInformationType entityInformationType = new EntityInformationType();
        entityInformationType.setEntityType("TypeA");
        assertEquals("TypeA", entityInformationType.getEntityType());
    }

    @Test
    public void testSetEntityType() {
        EntityInformationType entityInformationType = new EntityInformationType();
        entityInformationType.setEntityType("TypeA");
        assertNotNull(entityInformationType.getEntityType());
    }

    @Test
    public void testGetEntityName() {
        EntityInformationType entityInformationType = new EntityInformationType();
        entityInformationType.setEntityName("EntityName");
        assertEquals("EntityName", entityInformationType.getEntityName());
    }

    @Test
    public void testSetEntityName() {
        EntityInformationType entityInformationType = new EntityInformationType();
        entityInformationType.setEntityName("EntityName");
        assertNotNull(entityInformationType.getEntityName());
    }
}