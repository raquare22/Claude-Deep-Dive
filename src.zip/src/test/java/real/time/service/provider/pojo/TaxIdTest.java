package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Date;

public class TaxIdTest {

    @Test
    public void testTaxId() {
        TaxId taxId = new TaxId();

        String taxIdNbr = "123456789";
        String taxIdTypCd = "SSN";
        Date tinEffDt = new Date();
        Date tinCancDt = new Date();
        Date taxEffDt = new Date();
        Date taxCancDt = new Date();
        String corpOwnrProvId = "987654321";
        String corpOwnerLstNm = "Doe";
        String corpOwnerFstNm = "John";
        String corpOwnerMdlNm = "A";
        String corpOwnerNmSufxCd = "Jr";
        String payTypCd = "Direct";
        String payeeProvId = "123456789";
        String payeeProvLstNm = "Smith";
        String payeeProvFstNm = "Jane";
        String payeeProvMdlNm = "B";
        String payeeProvNmSufxCd = "Sr";

        taxId.setTaxIdNbr(taxIdNbr);
        taxId.setTaxIdTypCd(taxIdTypCd);
        taxId.setTinEffDt(tinEffDt);
        taxId.setTinCancDt(tinCancDt);
        taxId.setTaxEffDt(taxEffDt);
        taxId.setTaxCancDt(taxCancDt);
        taxId.setCorpOwnrProvId(corpOwnrProvId);
        taxId.setCorpOwnerLstNm(corpOwnerLstNm);
        taxId.setCorpOwnerFstNm(corpOwnerFstNm);
        taxId.setCorpOwnerMdlNm(corpOwnerMdlNm);
        taxId.setCorpOwnerNmSufxCd(corpOwnerNmSufxCd);
        taxId.setPayTypCd(payTypCd);
        taxId.setPayeeProvId(payeeProvId);
        taxId.setPayeeProvLstNm(payeeProvLstNm);
        taxId.setPayeeProvFstNm(payeeProvFstNm);
        taxId.setPayeeProvMdlNm(payeeProvMdlNm);
        taxId.setPayeeProvNmSufxCd(payeeProvNmSufxCd);

        assertEquals(taxIdNbr, taxId.getTaxIdNbr());
        assertEquals(taxIdTypCd, taxId.getTaxIdTypCd());
        assertEquals(tinEffDt, taxId.getTinEffDt());
        assertEquals(tinCancDt, taxId.getTinCancDt());
        assertEquals(taxEffDt, taxId.getTaxEffDt());
        assertEquals(taxCancDt, taxId.getTaxCancDt());
        assertEquals(corpOwnrProvId, taxId.getCorpOwnrProvId());
        assertEquals(corpOwnerLstNm, taxId.getCorpOwnerLstNm());
        assertEquals(corpOwnerFstNm, taxId.getCorpOwnerFstNm());
        assertEquals(corpOwnerMdlNm, taxId.getCorpOwnerMdlNm());
        assertEquals(corpOwnerNmSufxCd, taxId.getCorpOwnerNmSufxCd());
        assertEquals(payTypCd, taxId.getPayTypCd());
        assertEquals(payeeProvId, taxId.getPayeeProvId());
        assertEquals(payeeProvLstNm, taxId.getPayeeProvLstNm());
        assertEquals(payeeProvFstNm, taxId.getPayeeProvFstNm());
        assertEquals(payeeProvMdlNm, taxId.getPayeeProvMdlNm());
        assertEquals(payeeProvNmSufxCd, taxId.getPayeeProvNmSufxCd());
    }
}