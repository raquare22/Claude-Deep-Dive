package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Date;

public class SpecialtyTest {

    @Test
    public void testSpecialty() {
        Specialty specialty = new Specialty();

        // Test setting and getting spclTypCd
        specialty.setSpclTypCd("spclTypCd");
        assertEquals("spclTypCd", specialty.getSpclTypCd());

        // Test setting and getting spclPriCd
        specialty.setSpclPriCd("spclPriCd");
        assertEquals("spclPriCd", specialty.getSpclPriCd());

        // Test setting and getting spclEffDt
        Date spclEffDt = new Date();
        specialty.setSpclEffDt(spclEffDt);
        assertEquals(spclEffDt, specialty.getSpclEffDt());

        // Test setting and getting spclCancDt
        Date spclCancDt = new Date();
        specialty.setSpclCancDt(spclCancDt);
        assertEquals(spclCancDt, specialty.getSpclCancDt());

        // Test setting and getting spclTypShrtDesc
        specialty.setSpclTypShrtDesc("spclTypShrtDesc");
        assertEquals("spclTypShrtDesc", specialty.getSpclTypShrtDesc());

        // Test setting and getting spclTypFullDesc
        specialty.setSpclTypFullDesc("spclTypFullDesc");
        assertEquals("spclTypFullDesc", specialty.getSpclTypFullDesc());
    }
}