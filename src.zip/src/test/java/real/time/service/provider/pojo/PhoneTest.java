package real.time.service.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class PhoneTest {
    @Test
    public void testIt() {
        Phone phone = new Phone();

        phone.setTelActvCd(new String());
        phone.setTelPriCd(new String());
        phone.setTelExtNbr(new String());
        phone.setTelUseTypCd(new String());
        phone.setTelUseTypDesc(new String());
        phone.setAreaCd(new String());
        phone.setTelNbr(new String());

        phone.getTelActvCd();
        phone.getTelPriCd();
        phone.getTelExtNbr(); 
        phone.getTelUseTypCd();
        phone.getTelUseTypDesc();
        phone.getAreaCd();
        phone.getTelNbr();
        assertNotNull(phone);
    }
}
