package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class UnetContractTest {

    @Test
    public void testUnetContract() {
        UnetContract unetContract = new UnetContract();

        // Test setting and getting acptPtntCd
        String acptPtntCd = "APC123";
        unetContract.setAcptPtntCd(acptPtntCd);
        assertEquals(acptPtntCd, unetContract.getAcptPtntCd());

        // Test setting and getting provContrRoleCd
        String provContrRoleCd = "PCR456";
        unetContract.setProvContrRoleCd(provContrRoleCd);
        assertEquals(provContrRoleCd, unetContract.getProvContrRoleCd());
    }
}