package real.time.service.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class AddressDataTest {

    @Test
    public void testIt() {
        AddressData addressData = new AddressData();

        addressData.setAdrId(new String());
        addressData.setAdrTypCd(new String());
        addressData.setAddress(new java.util.ArrayList<>());
        addressData.setPhone(new java.util.ArrayList<>());

        addressData.getAddress();
        addressData.getAdrId();
        addressData.getAdrTypCd();
        addressData.getPhone();
        assertNotNull ( addressData );

    }
}
