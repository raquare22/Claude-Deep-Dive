package real.time.service.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class ProviderSearchResultsTest {
    @Test
    public void testIt ( ) {
        ProviderSearchResults providerSearchResults = new ProviderSearchResults ();

        providerSearchResults.setRecords ( new java.util.ArrayList<> () );
        providerSearchResults.setMetadata ( new Metadata () );

        providerSearchResults.getRecords ();
        providerSearchResults.getMetadata ();

        assertNotNull(providerSearchResults);
    }
}
