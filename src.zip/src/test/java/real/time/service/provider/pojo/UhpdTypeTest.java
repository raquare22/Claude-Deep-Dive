package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class UhpdTypeTest {

    @Test
    public void testUhpdType() {
        UhpdType uhpdType = new UhpdType();

        // Test setting and getting efficiency
        EfficiencyType efficiency = new EfficiencyType();
        uhpdType.setEfficiency(efficiency);
        assertEquals(efficiency, uhpdType.getEfficiency());

        // Test setting and getting focusCode
        String focusCode = "FC123";
        uhpdType.setFocusCode(focusCode);
        assertEquals(focusCode, uhpdType.getFocusCode());

        // Test setting and getting focusDescription
        String focusDescription = "Focus Description";
        uhpdType.setFocusDescription(focusDescription);
        assertEquals(focusDescription, uhpdType.getFocusDescription());

        // Test setting and getting qeDesignationTierNumber
        String qeDesignationTierNumber = "Tier1";
        uhpdType.setQeDesignationTierNumber(qeDesignationTierNumber);
        assertEquals(qeDesignationTierNumber, uhpdType.getQeDesignationTierNumber());

        // Test setting and getting qeDesignationPriority
        String qeDesignationPriority = "High";
        uhpdType.setQeDesignationPriority(qeDesignationPriority);
        assertEquals(qeDesignationPriority, uhpdType.getQeDesignationPriority());

        // Test setting and getting quality
        QualityType quality = new QualityType();
        uhpdType.setQuality(quality);
        assertEquals(quality, uhpdType.getQuality());

        // Test setting and getting uhpdDateRange
        UhpdDateRangeType uhpdDateRange = new UhpdDateRangeType();
        uhpdType.setUhpdDateRange(uhpdDateRange);
        assertEquals(uhpdDateRange, uhpdType.getUhpdDateRange());
    }
}