package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class UhpdDateRangeTypeTest {

    @Test
    public void testUhpdDateRangeType() {
        UhpdDateRangeType dateRange = new UhpdDateRangeType();

        // Test setting and getting end
        String end = "2023-12-31";
        dateRange.setEnd(end);
        assertEquals(end, dateRange.getEnd());

        // Test setting and getting start
        String start = "2023-01-01";
        dateRange.setStart(start);
        assertEquals(start, dateRange.getStart());
    }
}