package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class TaxIdTypeTest {

    @Test
    public void testTaxIdType() {
        TaxIdType taxIdType = new TaxIdType();

        // Test setting and getting taxId
        String taxId = "123456789";
        taxIdType.setTaxId(taxId);
        assertEquals(taxId, taxIdType.getTaxId());

        // Test setting and getting taxIdType
        String taxIdTypeValue = "EIN";
        taxIdType.setTaxIdType(taxIdTypeValue);
        assertEquals(taxIdTypeValue, taxIdType.getTaxIdType());

        // Test setting and getting tpsmInd
        String tpsmInd = "Y";
        taxIdType.setTpsmInd(tpsmInd);
        assertEquals(tpsmInd, taxIdType.getTpsmInd());

        // Test setting and getting tpsmDesc
        String tpsmDesc = "Description";
        taxIdType.setTpsmDesc(tpsmDesc);
        assertEquals(tpsmDesc, taxIdType.getTpsmDesc());

        // Test setting and getting corpMPIN
        String corpMPIN = "MPIN123";
        taxIdType.setcorpMPIN(corpMPIN);
        assertEquals(corpMPIN, taxIdType.getcorpMPIN());
    }
}