package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class PhysicianFacilityTest {

    PhysicianFacility physicianFacility = new PhysicianFacility();

    @Test
    public void testPojoV2GettersSetters() {
        SvcResponse svcResponse = new SvcResponse();
        physicianFacility.setSvcResponse(svcResponse);
        assertEquals(svcResponse, physicianFacility.getSvcResponse());
    }
}