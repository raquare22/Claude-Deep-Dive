package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class SpecialtyTypeTest {

    @Test
    public void testSpecialtyType() {
        SpecialtyType specialtyType = new SpecialtyType();

        // Test setting and getting primarySpecialtyIndicator
        specialtyType.setPrimarySpecialtyIndicator("primarySpecialtyIndicator");
        assertEquals("primarySpecialtyIndicator", specialtyType.getPrimarySpecialtyIndicator());

        // Test setting and getting specialtyTypeCode
        specialtyType.setSpecialtyTypeCode("specialtyTypeCode");
        assertEquals("specialtyTypeCode", specialtyType.getSpecialtyTypeCode());

        // Test setting and getting specialtyFullDescription
        specialtyType.setSpecialtyFullDescription("specialtyFullDescription");
        assertEquals("specialtyFullDescription", specialtyType.getSpecialtyFullDescription());
    }
}