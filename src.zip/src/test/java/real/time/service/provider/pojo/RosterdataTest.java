package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

public class RosterdataTest {

    @Test
    public void testRosterdata() {
        Rosterdata rosterdata = new Rosterdata();

        // Test setting and getting provKey
        rosterdata.setProvKey("provKey");
        assertEquals("provKey", rosterdata.getProvKey());

        // Test setting and getting provId
        rosterdata.setProvId("provId");
        assertEquals("provId", rosterdata.getProvId());

        // Test setting and getting taxIdNbr
        rosterdata.setTaxIdNbr("taxIdNbr");
        assertEquals("taxIdNbr", rosterdata.getTaxIdNbr());

        // Test setting and getting taxIdTypCd
        rosterdata.setTaxIdTypCd("taxIdTypCd");
        assertEquals("taxIdTypCd", rosterdata.getTaxIdTypCd());

        // Test setting and getting provider
        List<List<Provider>> provider = new ArrayList<>();
        rosterdata.setProvider(provider);
        assertEquals(provider, rosterdata.getProvider());

        // Test setting and getting taxId
        List<List<TaxId>> taxId = new ArrayList<>();
        rosterdata.setTaxId(taxId);
        assertEquals(taxId, rosterdata.getTaxId());

        // Test setting and getting specialty
        List<List<Specialty>> specialty = new ArrayList<>();
        rosterdata.setSpecialty(specialty);
        assertEquals(specialty, rosterdata.getSpecialty());

        // Test setting and getting organization
        List<List<Organization>> organization = new ArrayList<>();
        rosterdata.setOrganization(organization);
        assertEquals(organization, rosterdata.getOrganization());

        // Test setting and getting npi
        List<List<Npi>> npi = new ArrayList<>();
        rosterdata.setNpi(npi);
        assertEquals(npi, rosterdata.getNpi());

        // Test setting and getting unetContract
        List<List<UnetContract>> unetContract = new ArrayList<>();
        rosterdata.setUnetContract(unetContract);
        assertEquals(unetContract, rosterdata.getUnetContract());

        // Test setting and getting degree
        List<List<Degree>> degree = new ArrayList<>();
        rosterdata.setDegree(degree);
        assertEquals(degree, rosterdata.getDegree());

        // Test setting and getting addressData
        List<List<AddressData>> addressData = new ArrayList<>();
        rosterdata.setAddressData(addressData);
        assertEquals(addressData, rosterdata.getAddressData());
    }
}