package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class MetadataTest {

    @Test
    public void testSetAndGetOffset() {
        Metadata metadata = new Metadata();
        metadata.setOffset(10);
        assertEquals(10, metadata.getOffset());
    }

    @Test
    public void testSetAndGetPsize() {
        Metadata metadata = new Metadata();
        metadata.setPsize(20);
        assertEquals(20, metadata.getPsize());
    }

    @Test
    public void testSetAndGetTotal() {
        Metadata metadata = new Metadata();
        metadata.setTotal(30);
        assertEquals(30, metadata.getTotal());
    }

    @Test
    public void testSetAndGetElapsedtime() {
        Metadata metadata = new Metadata();
        metadata.setElapsedtime("100ms");
        assertEquals("100ms", metadata.getElapsedtime());
    }

    @Test
    public void testSetAndGetElastictime() {
        Metadata metadata = new Metadata();
        metadata.setElastictime("200ms");
        assertEquals("200ms", metadata.getElastictime());
    }
}