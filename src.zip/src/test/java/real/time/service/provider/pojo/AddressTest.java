package real.time.service.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class AddressTest {
    @Test
    public void testIt() {
        Address address = new Address();

        address.setAdrPriCd(new String());
        address.setMdcdLocCd(new String());
        address.setMdcdId(new String());
        address.setAddrSeq(0);
        address.setAdrEffDt(new java.util.Date());
        address.setAdrCancDt(new java.util.Date());
        address.setAdrId(new String());
        address.setAdrLn1Txt(new String());
        address.setCtyNm(new String());
        address.setStCd(new String());
        address.setZipCd(new String());
        address.setZipPls4Cd(new String());
        address.setCntyNm(new String());
        address.setHncpAcsblInd(new String());
        address.setAdrTypCd(new String());
        address.setAdrTypDesc(new String());
        address.setBillAdrId(new String());
        address.setBillAdrTyp(new String());
        address.setBillAdrTypDesc(new String());
        address.setBillAdrSeq(0);

        address.getAdrPriCd();
        address.getMdcdLocCd();
        address.getMdcdId();
        address.getAddrSeq();
        address.getAdrEffDt();
        address.getAdrCancDt();
        address.getAdrId();
        address.getAdrLn1Txt();
        address.getCtyNm();
        address.getStCd();
        address.getZipCd();
        address.getZipPls4Cd();
        address.getCntyNm();
        address.getHncpAcsblInd();
        address.getAdrTypCd();
        address.getAdrTypDesc();
        address.getBillAdrId();
        address.getBillAdrTyp();
        address.getBillAdrTypDesc();
        address.getBillAdrSeq();
        assertNotNull ( address );

    }

    @Test
    public void testItNulls() {
        Address address = new Address ();

        address.setAdrEffDt(null);
        address.setAdrCancDt(null);

        address.getAdrEffDt();
        address.getAdrCancDt();
        assertNotNull ( address );
    }
}
