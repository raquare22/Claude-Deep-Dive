package real.time.service.provider.pojo;


import org.junit.Test;
import static org.junit.Assert.assertNotNull;

public class OrganizationTest {

    @Test
    public void testIt() {
        Organization organization = new Organization();

        organization.setOrgOrgTypCd(new String());
        organization.setOrgTypDesc(new String());

        organization.getOrgOrgTypCd();
        organization.getOrgTypDesc();
        assertNotNull(organization);
    }
}
