package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class EfficiencyTypeTest {

    @Test
    public void testGetName() {
        EfficiencyType efficiencyType = new EfficiencyType();
        efficiencyType.setName("Efficiency Name");
        assertEquals("Efficiency Name", efficiencyType.getName());
    }

    @Test
    public void testSetName() {
        EfficiencyType efficiencyType = new EfficiencyType();
        efficiencyType.setName("Efficiency Name");
        assertNotNull(efficiencyType.getName());
    }

    @Test
    public void testGetValue() {
        EfficiencyType efficiencyType = new EfficiencyType();
        efficiencyType.setValue("Efficiency Value");
        assertEquals("Efficiency Value", efficiencyType.getValue());
    }

    @Test
    public void testSetValue() {
        EfficiencyType efficiencyType = new EfficiencyType();
        efficiencyType.setValue("Efficiency Value");
        assertNotNull(efficiencyType.getValue());
    }
}