package real.time.service.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class RequestTest {

    @Test
    public void testToString() {
        RequestBody requestBody = new RequestBody.RequestBodyBuilder().setAppName("testapp").build();
        RequestHeader requestHeader = new RequestHeader.RequestHeaderBuilder().setActor("testactor").build();
        Request request = new Request.RequestBuilder()
                .setRequestBody(requestBody)
                .setRequestHeader(requestHeader).build();

        System.out.println(request);
        assertNotNull(request);
        assertNotNull(requestBody);
        assertNotNull(request.getRequestHeader());
        assertNotNull(request.getRequestBody());
        assertEquals(requestHeader, request.getRequestHeader());
    }

}
