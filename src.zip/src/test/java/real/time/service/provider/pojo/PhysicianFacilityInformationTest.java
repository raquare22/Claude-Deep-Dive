package real.time.service.provider.pojo;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class PhysicianFacilityInformationTest {

    @Test
    public void testPhysicianFacilityInformation() {
        PhysicianFacilityInformation info = new PhysicianFacilityInformation();

        // Set values
        info.setFirstName("John");
        info.setGender("Male");
        info.setLastName("Doe");
        info.setMiddleName("A");
        info.setNhpInd("Y");
        info.setNhpFlexInd("N");
        info.setUnetTciParStatus("Active");
        info.setDivPanelParStatus("Active");
        info.setLobParStatus("Active");
        info.setProviderId("12345");
        info.setSuffix("Jr.");
        info.setOrganizationalType("Type1");
        info.setOrganizationalTypeDescription("Description1");
        List<CorpOwnerInformationType> list = new ArrayList<>();
        list.add(new CorpOwnerInformationType());
        info.setCorpOwnerInformation(list);


        List<TaxIdType> taxIds = new ArrayList<>();
        taxIds.add(new TaxIdType());
        info.getTaxId().addAll(taxIds);

        List<NpiType> npis = new ArrayList<>();
        npis.add(new NpiType());
        info.getNpi().addAll(npis);

        List<SpecialtyType> specialties = new ArrayList<>();
        specialties.add(new SpecialtyType());
        info.getSpecialty().addAll(specialties);

        List<CorpOwnerInformationType> corpOwners = new ArrayList<>();
        corpOwners.add(new CorpOwnerInformationType());
        info.getCorpOwnerInformation().addAll(corpOwners);

        ContractInformationType contractInfo = new ContractInformationType();
        info.setContractInformation(contractInfo);

        List<EntityInformationType> entities = new ArrayList<>();
        entities.add(new EntityInformationType());
        info.getEntityInformation().addAll(entities);

        List<UhpdType> uhpdList = new ArrayList<>();
        uhpdList.add(new UhpdType());
        info.getUhpd().addAll(uhpdList);

        // Assert values
        assertEquals("John", info.getFirstName());
        assertEquals("Male", info.getGender());
        assertEquals("Doe", info.getLastName());
        assertEquals("A", info.getMiddleName());
        assertEquals("Y", info.getNhpInd());
        assertEquals("N", info.getNhpFlexInd());
        assertEquals("Active", info.getUnetTciParStatus());
        assertEquals("Active", info.getDivPanelParStatus());
        assertEquals("Active", info.getLobParStatus());
        assertEquals("12345", info.getProviderId());
        assertEquals("Jr.", info.getSuffix());
        assertEquals("Type1", info.getOrganizationalType());
        assertEquals("Description1", info.getOrganizationalTypeDescription());
        assertNotNull(info.getTaxId());
        assertNotNull(info.getNpi());
        assertNotNull(info.getSpecialty());
        assertNotNull(info.getCorpOwnerInformation());
        assertNotNull(info.getContractInformation());
        assertNotNull(info.getEntityInformation());
        assertNotNull(info.getUhpd());
    }

    @Test
    public void testGetCorpOwnerInformationInitialization() {
        PhysicianFacilityInformation info = new PhysicianFacilityInformation();
        // Calling getter should initialize corpOwnerInformation
        List<CorpOwnerInformationType> corpOwners = info.getCorpOwnerInformation();
        assertNotNull(corpOwners);
        assertTrue(corpOwners.isEmpty());

        // Verify that modifications persist
        CorpOwnerInformationType dummy = new CorpOwnerInformationType();
        corpOwners.add(dummy);
        List<CorpOwnerInformationType> updatedList = info.getCorpOwnerInformation();
        assertEquals(1, updatedList.size());
        assertEquals(dummy, updatedList.get(0));
    }
}