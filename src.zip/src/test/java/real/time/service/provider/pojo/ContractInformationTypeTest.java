package real.time.service.provider.pojo;

import org.junit.Test;
import static org.junit.Assert.*;

public class ContractInformationTypeTest {

    @Test
    public void testContractId() {
        ContractInformationType contractInfo = new ContractInformationType();
        String contractId = "12345";
        contractInfo.setContractId(contractId);
        assertEquals(contractId, contractInfo.getContractId());
    }

    @Test
    public void testIncentiveDisincentiveId() {
        ContractInformationType contractInfo = new ContractInformationType();
        String incentiveDisincentiveId = "67890";
        contractInfo.setIncentiveDisincentiveId(incentiveDisincentiveId);
        assertEquals(incentiveDisincentiveId, contractInfo.getIncentiveDisincentiveId());
    }

    @Test
    public void testPreferredNetworkIndicator() {
        ContractInformationType contractInfo = new ContractInformationType();
        String preferredNetworkIndicator = "PNI";
        contractInfo.setPreferredNetworkIndicator(preferredNetworkIndicator);
        assertEquals(preferredNetworkIndicator, contractInfo.getPreferredNetworkIndicator());
    }

    @Test
    public void testTierIndicator() {
        ContractInformationType contractInfo = new ContractInformationType();
        String tierIndicator = "TI";
        contractInfo.setTierIndicator(tierIndicator);
        assertEquals(tierIndicator, contractInfo.getTierIndicator());
    }

    @Test
    public void testContractRoleCode() {
        ContractInformationType contractInfo = new ContractInformationType();
        String contractRoleCode = "CRC";
        contractInfo.setContractRoleCode(contractRoleCode);
        assertEquals(contractRoleCode, contractInfo.getContractRoleCode());
    }

    @Test
    public void testDemoteIndicator() {
        ContractInformationType contractInfo = new ContractInformationType();
        String demoteIndicator = "DI";
        contractInfo.setDemoteIndicator(demoteIndicator);
        assertEquals(demoteIndicator, contractInfo.getDemoteIndicator());
    }

    @Test
    public void testAcoId() {
        ContractInformationType contractInfo = new ContractInformationType();
        String acoId = "ACO123";
        contractInfo.setAcoId(acoId);
        assertEquals(acoId, contractInfo.getAcoId());
    }

    @Test
    public void testAcoName() {
        ContractInformationType contractInfo = new ContractInformationType();
        String acoName = "ACO Name";
        contractInfo.setAcoName(acoName);
        assertEquals(acoName, contractInfo.getAcoName());
    }
}