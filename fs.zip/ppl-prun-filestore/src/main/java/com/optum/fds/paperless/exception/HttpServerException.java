package com.optum.fds.paperless.exception;

import org.springframework.http.HttpStatusCode;

public class HttpServerException extends RuntimeException{

	private static final long serialVersionUID = -3130853967314096765L;

	private final HttpStatusCode status;

	public HttpServerException(String message, HttpStatusCode status2) {
		super(message);
		this.status = status2;
	}

	public HttpStatusCode getStatus() { return status; }
}
