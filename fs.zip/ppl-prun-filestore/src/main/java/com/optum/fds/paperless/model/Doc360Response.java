package com.optum.fds.paperless.model;

import java.util.HashMap;

public class Doc360Response {
    private String globalDocId;
    private String indexName;
    private String receivedDate;
    private String status;
    private HashMap<String, Object> messageMap;

    public String getGlobalDocId() {
        return globalDocId;
    }

    public void setGlobalDocId(String globalDocId) {
        this.globalDocId = globalDocId;
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public String getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public HashMap<String, Object> getMessageMap() {
        return messageMap;
    }

    public void setMessageMap(HashMap<String, Object> messageMap) {
        this.messageMap = messageMap;
    }
}
