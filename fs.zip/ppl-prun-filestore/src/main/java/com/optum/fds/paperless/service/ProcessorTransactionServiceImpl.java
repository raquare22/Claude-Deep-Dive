package com.optum.fds.paperless.service;

import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.model.mongo.MetaDataStatus;
import com.optum.fds.paperless.model.mongo.ProcessorMetaData;
import com.optum.fds.paperless.model.mongo.ProcessorRecordTypes;
import com.optum.fds.paperless.model.mongo.ProcessorTransaction;
import com.optum.fds.paperless.util.SanitizeUtil;

@Service("ProcessorTransactionServiceImpl")
public class ProcessorTransactionServiceImpl implements ProcessorTransactionService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorTransactionServiceImpl.class);
	
	private static final String PROCESSOR_TRANSACTION_COLLECTION_NAME = "processorTransaction";
    private static final String QUERY_STRING = "{} query={}";
    private static final String PROCESSOR_RECORD_TYPE_FIELD_NAME = "processorRecordType";
    private static final String PROCESSOR_COLLECTION_NAME = "processor";
    private static final String STATUS_KEY = "status";
    private static final String CONFIG_SPACE_ID = "configSpaceId";
    private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";
	private static final String VERSION = "1";
	
	@Autowired
    MongoTemplate mongoTemplate;
	
	@Override
    public ProcessorTransaction createProcessorTransaction(String fileName, String fileLocation, String spaceId) {

		ProcessorMetaData processor = getProcessorMetaDataBySpaceId(spaceId);
		
		if (processor == null) {
			return null;
		}
		
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setAppIdentifier(processor.getAppIdentifier());
        processorTransaction.setClientId(processor.getClientId());
        processorTransaction.setFileName(fileName);
        processorTransaction.setLocation(fileLocation);
        processorTransaction.setConfigSpaceId(processor.getConfigSpaceId());
        processorTransaction.setTransactionId(UUID.randomUUID().toString());
        processorTransaction.setVersion(VERSION);
        processorTransaction.setProcessorId(processor.getId());
        processorTransaction.setStatus(MetaDataStatus.NEW);
        processorTransaction.setProcessorRecordType(ProcessorRecordTypes.processorTransaction);
//        processorTransaction.setServerType(serverType);
        saveProcessorTransactionMetaData(processorTransaction);

        return processorTransaction;
    }
	
	public ProcessorMetaData getProcessorMetaDataBySpaceId(String spaceId) {

			Integer configSpaceId = Integer.parseInt(spaceId);

	        Query query = new Query();

	        Criteria statusCriteria = getValidStatusCriteria();

	        Criteria criterias = new Criteria().andOperator(statusCriteria);

	        query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processorRealTimeAPI))
	                .addCriteria(criterias).addCriteria(Criteria.where(CONFIG_SPACE_ID).is(configSpaceId));

	        LOGGER.debug(QUERY_STRING, "findAllAvailableProcessorMetaData", query);
	        try {
	            List<ProcessorMetaData> processorMetaDataList = mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
	            String msg = String.format("Number of docs returned: %d", processorMetaDataList.size());
	            LOGGER.debug(msg);
	            LOGGER.debug("Leaving processor by startDate and endDate");
	            if (!processorMetaDataList.isEmpty()) {
	            	return processorMetaDataList.get(0);
	            } else {
	            	return null;
	            }
	        } catch (Exception e) {
	            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllAvailableProcessorMetaData", query, ExceptionUtils.getStackTrace(e));
	            throw e;
	        }
		
	}

	@Override
	public ProcessorTransaction findProcessorTransactionByFileName(String fileName, Integer configSpaceId) {
		LOGGER.debug("fileName={}, configSpaceId={}", SanitizeUtil.sanitizeAlphaString(fileName), configSpaceId);
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("fileName").is(fileName)).addCriteria(Criteria.where(CONFIG_SPACE_ID).is(configSpaceId));
        LOGGER.debug(QUERY_STRING, "findProcessorTransactionByFileName", query);
        try {
            return op.findOne(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorTransactionByFileName", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

	private Criteria getValidStatusCriteria() {
        return new Criteria().orOperator(Criteria.where(STATUS_KEY)
                .in(MetaDataStatus.ACTIVE,
                        MetaDataStatus.NEW,
                        MetaDataStatus.IN_PROCESS,
                        MetaDataStatus.READY)
        );
    }
	
	
	public ProcessorTransaction saveProcessorTransactionMetaData(ProcessorTransaction processorTransaction) {
		LOGGER.debug("ProcessorTransactionService-->saveProcessorTransactionMetaData-->ENTER");
        mongoTemplate.save(processorTransaction, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        return processorTransaction;
	}

}
