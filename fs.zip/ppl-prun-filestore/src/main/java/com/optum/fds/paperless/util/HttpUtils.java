package com.optum.fds.paperless.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;

public class HttpUtils {
	
	public static boolean validateStatusCode(HttpStatusCode httpStatusCode) {

		return HttpStatus.INTERNAL_SERVER_ERROR.equals(httpStatusCode)
				|| HttpStatus.BAD_GATEWAY.equals(httpStatusCode)
				|| HttpStatus.SERVICE_UNAVAILABLE.equals(httpStatusCode)
				|| HttpStatus.GATEWAY_TIMEOUT.equals(httpStatusCode);
	}

}
