package com.optum.fds.paperless;

import java.util.Collections;
import java.util.Map;

import com.optum.fds.paperless.util.SanitizeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;

public class ConfigData {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigData.class);
	private Map<String, Object> allClientCredentials = new java.util.HashMap<>();
	@Value("${LETGEN.credentials}")
	private String LETGEN_configcredentials;

	@Value("${UNET.credentials}")
	private String UNET_configcredentials;

	@Value("${NEXTGEN.credentials}")
	private String NEXTGEN_configcredentials;

	@Value("${1CLICK.credentials}")
	private String _1CLICK_configcredentials;

	@Value("${CCSManual.credentials}")
	private String CCSManual_configcredentials;

	@Value("${UNET_PRA.credentials}")
	private String UNET_PRA_configcredentials;

	@Value("${COSMOS_PRA.credentials}")
	private String COSMOS_PRA_configcredentials;

	@Value("${COSMOS.credentials}")
	private String COSMOS_configcredentials;

	@Value("${UHC_WEST.credentials}")
	private String UHC_WEST_configcredentials;

	@Value("${CSP_PRA.credentials}")
	private String CSP_PRA_configcredentials;

	@Value("${ODAR.credentials}")
	private String ODAR_configcredentials;

	@Value("${MR_APPEALS.credentials}")
	private String MR_APPEALS_configcredentials;

	@Value("${ETS_APPEALS.credentials}")
	private String ETS_APPEALS_configcredentials;

	@Value("${USP_CLAIMS.credentials}")
	private String USP_CLAIMS_configcredentials;

	@Value("${USP_PRA.credentials}")
	private String USP_PRA_configcredentials;

	@Value("${CSP_CLAIMS.credentials}")
	private String CSP_CLAIMS_configcredentials;

	@Value("${OCM.credentials}")
	private String OCM_configcredentials;

	@Value("${IHR.credentials}")
	private String IHR_configcredentials;

	@Value("${CC.credentials}")
	private String CC_configcredentials;

	@Value("${CAP.credentials}")
	private String CAP_configcredentials;

	@Value("${TEXAS_GOLD_CARD.credentials}")
	private String TEXAS_GOLD_CARD_configcredentials;
	
	@Value("${HouseCalls.credentials}")
	private String HouseCalls_configcredentials;

	@Value("${TRACKIT.credentials}")
	private String TRACKIT_configcredentials;

	@Value("${NGSClaims.credentials}")
	private String NGSClaims_configcredentials;

	@Value("${MemberPayment.credentials}")
	private String MemberPayment_configcredentials;

	@Value("${PECosmos_PRA.credentials}")
	private String PECosmos_PRA_configcredentials;
	
	@Value("${OTHER.credentials}")
	private String OTHER_configcredentials;
	
	 @Value("${spring.cloud.vault.enabled}")
	 private Boolean isVaultServer;
	 
	 @Autowired
	 private ObjectMapper mapper;

	@SuppressWarnings({ "unchecked" })
	public Map<String, Object> getCredentials(String spaceId) {
		if(allClientCredentials.isEmpty()) setCredentials();
		return (Map<String, Object>) Collections.unmodifiableMap(allClientCredentials).get(spaceId);
	}

	private void setCredentials() {
		mapper = new ObjectMapper();
		final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
		try {
			allClientCredentials.putAll(mapper.readValue(LETGEN_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(UNET_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(NEXTGEN_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(_1CLICK_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CCSManual_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(UNET_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(COSMOS_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(COSMOS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(UHC_WEST_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CSP_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ODAR_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(MR_APPEALS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ETS_APPEALS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(USP_CLAIMS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(USP_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CSP_CLAIMS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(OCM_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(IHR_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CC_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CAP_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(TEXAS_GOLD_CARD_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(TRACKIT_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(NGSClaims_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(HouseCalls_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(MemberPayment_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(PECosmos_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(OTHER_configcredentials, type));
		} catch (JsonProcessingException ex) {
			LOGGER.error("Error in ConfigData-->setCredentials, {}",ex.getMessage());
		}
	}

}
