package com.optum.fds.paperless.controller;

import com.optum.fds.paperless.util.SanitizeUtil;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.multipart.MultipartFile;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.model.mongo.ProcessorTransaction;
import com.optum.fds.paperless.ness.FilestoreNessConfig;
import com.optum.fds.paperless.ness.KafkaProducer;
import com.optum.fds.paperless.service.FilestoreService;
import com.optum.fds.paperless.service.ProcessorTransactionService;

@RestController
@RequestMapping("/api/services/v1/filestore")
public class FilestoreController {
		
	private static final Logger LOGGER = LoggerFactory.getLogger(FilestoreController.class);
	
	private static final List<String> ALLOWED_FILE_TYPES = Arrays.asList("text/csv");
	
	 private final Bucket getRequestBucket;
	 private final Bucket postRequestBucket;

	@Autowired
	public FilestoreController(@Value("${filestorePostRateLimit}")long postRateLimit) {
		
		Bandwidth getLimit = Bandwidth.classic(10, Refill.greedy(10, Duration.ofMinutes(1)));
		Bandwidth postLimit = Bandwidth.classic(postRateLimit, Refill.greedy(postRateLimit, Duration.ofMinutes(1)));
		
		this.getRequestBucket = Bucket.builder()
	             .addLimit(getLimit)
	             .build();
	         
	    this.postRequestBucket = Bucket.builder()
	             .addLimit(postLimit)
	             .build();		
	}
	
	@Autowired
	private FilestoreService fileStoreService;
	
	@Autowired
	private ConfigData config;
	
	@Autowired
	ProcessorTransactionService processorTransactionService;

	String serviceCallError="Error during service call";
	String invalidReq="Invalid request";
	String emptyRequest="Null or empty request body";
	String strResponse="response={}";

	
	@PostMapping(value="/sendFile/{spaceId}", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	public ResponseEntity<GenericResponse> sendFile(@RequestPart("file") MultipartFile file, @PathVariable String spaceId, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) {
		if(postRequestBucket.tryConsume(1)) {
     // download file to ingest and create a processorTransaction	
		 LOGGER.info("sendFile -- request payload: spaceId={}, CID={}", Encode.forJava(String.valueOf(spaceId)), Encode.forJava(optumCidExt));
		 
		 
		if(KafkaProducer.getSetUp())
		{
			String nessLog = "sendFile --> request spaceId=" + spaceId;
			FilestoreNessConfig.createNessLogEvent(nessLog);  
		}
		
		Integer spaceIdInt = getSpaceId(spaceId);
		if (file == null || spaceId == null || spaceIdInt == null) {
			LOGGER.error("sendFile -- Null or invalid request, CID={}", Encode.forJava(optumCidExt));
			return new ResponseEntity<>(new GenericResponse("400", invalidReq, emptyRequest), HttpStatus.BAD_REQUEST);
		}
		
		String fileName = "";
		try {
			
			// verify file format
		    if (!isValidFileType(file.getContentType())) {
			     return new ResponseEntity<>(new GenericResponse("415", invalidReq, "Invalid file type"), HttpStatus.UNSUPPORTED_MEDIA_TYPE);
			    }
			
	
			fileName = file.getOriginalFilename();
			if (fileName.contains("..") || fileName.contains("/")) {
				LOGGER.error("sendFile -- Invalid filename: {}, CID={}", Encode.forJava(fileName), Encode.forJava(optumCidExt));
				return new ResponseEntity<>(new GenericResponse("400", invalidReq, "Invalid filename" + fileName), HttpStatus.BAD_REQUEST); 
			}
            
			 
			// verify file content 
			if (!isValidFileContent(file.getInputStream())) {
				LOGGER.error("sendFile -- Invalid CSV content: {}, CID={}", Encode.forJava(fileName), Encode.forJava(optumCidExt));
				return new ResponseEntity<>(new GenericResponse("400", invalidReq, "Invalid CSV content" + fileName), HttpStatus.BAD_REQUEST);
	        }
			
			// save file to ingest and create processor transaction
			
			ProcessorTransaction processorTransaction = processorTransactionService.findProcessorTransactionByFileName(fileName, spaceIdInt);
			if (processorTransaction != null) {
				LOGGER.warn("sendFile -- ProcessorTransaction already exists: fileName={}, processorTransactionId={}, CID={}", SanitizeUtil.sanitizeAlphaNumericString(fileName), processorTransaction.getId(), Encode.forJava(optumCidExt));
				return new ResponseEntity<>(new GenericResponse("400", invalidReq, "ProcessorTransaction already exists: fileName=" + fileName), HttpStatus.BAD_REQUEST); 
			}
			
			String processorTransactionId = fileStoreService.processFileUpload(fileName, file, spaceId, optumCidExt);

			LOGGER.info("sendFile -- file ingested, fileName={}, processorTransactionId={}, CID={}", SanitizeUtil.sanitizeAlphaNumericString(fileName), processorTransactionId, Encode.forJava(optumCidExt));
			
			if (processorTransactionId == null) {
				LOGGER.error("sendFile -- Error uploading file, processorTransactionId is null, CID={}", Encode.forJava(optumCidExt));
				return new ResponseEntity<>(GenericResponse.from("500", "Error uploading file", "location or processorTransactionId is null"), HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
			if(KafkaProducer.getSetUp())
			{
				String nessLog = "Response processorTransactionId="+processorTransactionId;
				FilestoreNessConfig.createNessLogEvent(nessLog);  
			}
			
			return new ResponseEntity<>(GenericResponse.from("200", "File ingested", "processorTransactionId : " + processorTransactionId), HttpStatus.OK);
			
		} catch (HttpServerException e) {

			LOGGER.error("sendFile -- Error executing POST request /sendFile/{}, status={}, {}, CID={}", SanitizeUtil.sanitizeNumericString(spaceId), e.getStatus(), e.getMessage(), Encode.forJava(optumCidExt));
			if(KafkaProducer.getSetUp())
			{
				String errorLog = "Error executing POST request /sendFile/"+spaceId+"status="+e.getStatus()+""+e.getMessage();
				FilestoreNessConfig.createNessLogEvent(errorLog);  
			}
			return new ResponseEntity<>(new GenericResponse(e.getStatus().toString(), e.getMessage(), e.getStatus()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (HttpClientErrorException e) {

			LOGGER.error("sendFile -- Error executing POST request /sendFile/{}, fileName={}; {}: {}, CID={}", SanitizeUtil.sanitizeNumericString(spaceId), SanitizeUtil.sanitizeAlphaNumericString(fileName), e.getClass().getSimpleName(), e.getMessage(), Encode.forJava(optumCidExt));
			if(KafkaProducer.getSetUp())
			{
				String errorLog = "Error executing POST request /sendFile/"+spaceId+"fileName="+fileName+e.getClass().getSimpleName()+e.getMessage();
				FilestoreNessConfig.createNessLogEvent(errorLog);  
			}
			return new ResponseEntity<GenericResponse>(new GenericResponse(Integer.toString(e.getStatusCode().value()), e.getResponseBodyAsString(), "fileName=" + fileName + "; " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {

			LOGGER.error("sendFile -- Error executing POST request, HTTPStatus={}, apiPath=/sendFile/{}, fileName={}, error={}, CID={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(spaceId), SanitizeUtil.sanitizeAlphaNumericString(fileName), ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt));
			if(KafkaProducer.getSetUp())
			{
				String errorLog = "Error executing POST request /sendFile/"+spaceId+"fileName="+fileName+ExceptionUtils.getStackTrace(e);
				FilestoreNessConfig.createNessLogEvent(errorLog);  
			}
			return new ResponseEntity<>(new GenericResponse("500", serviceCallError, "fileName=" + fileName + "; " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  } else {
		  LOGGER.info("Too many requests made. Wait for 1 minute and try again.");
          return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
	  }
	}
	
	private Integer getSpaceId(String spaceId) {
		try { 
	        return Integer.parseInt(spaceId); 
	    } catch(NumberFormatException e) { 
	        return null; 
	    } catch(NullPointerException e) {
	        return null;
	    }
	}

	public boolean isValidFileType(String fileType) {
	    return ALLOWED_FILE_TYPES.contains(fileType);
	}
	
	public boolean isValidFileContent(InputStream inputStream) {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
		         CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {

		        for (CSVRecord currentRecord : csvParser) {
		            if (currentRecord == null) {
		                return false;
		            }
		        }
		        return true;
		    } catch (IOException e) {
		    	LOGGER.error("Exception while reading csv content:{}",ExceptionUtils.getStackTrace(e));
		        return false;
	    }
	}
	

}