package com.optum.fds.paperless.oauth;

import org.ehcache.expiry.ExpiryPolicy;
import java.util.function.Supplier;
import java.time.Duration;

public class OauthTokenCacheExpiryPolicy implements ExpiryPolicy<String, OauthToken> {

    @Override
    public Duration getExpiryForCreation(String key, OauthToken oauthToken) {
        long ttl = oauthToken.getExpiresIn().longValue() * 1000L;
        return ttl > 0 ? Duration.ofMillis(ttl) : Duration.ZERO;
    }

    @Override
    public Duration getExpiryForAccess(String key, Supplier<? extends OauthToken> value) {
        return null; // No change on access
    }

    @Override
    public Duration getExpiryForUpdate(String key, Supplier<? extends OauthToken> oldValue, OauthToken newValue) {
        return getExpiryForCreation(key, newValue);
    }
}
