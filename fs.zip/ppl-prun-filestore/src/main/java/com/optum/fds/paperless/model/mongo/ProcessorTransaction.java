package com.optum.fds.paperless.model.mongo;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class ProcessorTransaction extends ProcessorTransactionCore implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Integer fileCount;
	transient List<String> missingFileList;
	transient List<String> extraFileList;
	transient List<String> fileToProcessList;
	transient List<String> documentIds;
	AckStatus ackStatus;
	
	
	public List<String> getDocumentIds() {
		return documentIds;
	}
	public void setDocumentIds(List<String> documentIds) {
		this.documentIds = documentIds;
	}
	public Integer getFileCount() {
        return fileCount;
    }
    public void setFileCount(Integer fileCount) {
        this.fileCount = fileCount;
    }
    public List<String> getMissingFileList() {
        return missingFileList;
    }
    public void setMissingFileList(List<String> missingFileList) {
        this.missingFileList = missingFileList;
    }
    public List<String> getExtraFileList() {
        return extraFileList;
    }
    public void setExtraFileList(List<String> extraFileList) {
        this.extraFileList = extraFileList;
    }
    public List<String> getFileToProcessList() {
        return fileToProcessList;
    }
    public void setFileToProcessList(List<String> fileToProcessList) {
        this.fileToProcessList = fileToProcessList;
    }

    public void addMissingFile(String fileName){
        if(missingFileList == null){
            missingFileList = new ArrayList<>();
        }

        missingFileList.add(fileName);
    }
    public void addExtraFile(String fileName){
        if(extraFileList == null){
            extraFileList = new ArrayList<>();
        }

        extraFileList.add(fileName);
    }
    public void addFileToProcess(String fileName){
        if(fileToProcessList == null){
            fileToProcessList = new ArrayList<>();
        }

        fileToProcessList.add(fileName);
    }
    
    public AckStatus getAckStatus() {
		return ackStatus;
	}
	public void setAckStatus(AckStatus ackStatus) {
		this.ackStatus = ackStatus;
	}
}
