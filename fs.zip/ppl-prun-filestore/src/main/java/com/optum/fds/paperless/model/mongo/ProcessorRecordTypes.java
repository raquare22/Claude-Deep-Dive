package com.optum.fds.paperless.model.mongo;

public enum ProcessorRecordTypes {
	processorTextFile,
    processor,
    processorTransaction,
    processorFileTask,
    processorMapping,
    csvProcessorTransaction,
    csvProcessorRowTask,
    processorTransactionMetadata,
    processorSftpSendEmail,
    sftpConvertFileToDocument,
    processorRealTimeAPI
}

