package com.optum.fds.paperless.service;

import com.optum.fds.paperless.model.Doc360Response;
import org.springframework.http.ResponseEntity;

import com.optum.fds.paperless.model.FDSCloudDocument;

public interface DocumentsService {
	public ResponseEntity<FDSCloudDocument> postDocumentToFDSCloudWithAttachmentRetry(String document, String searchTerms, String filePath, String fdsCloudSpaceId, String cid);
    public ResponseEntity<Doc360Response> postDocumentToDoc360WithAttachmentRetry(String document, String filePath, String doc360DocClass, String cid);
}
