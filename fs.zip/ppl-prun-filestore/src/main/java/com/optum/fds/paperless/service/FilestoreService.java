package com.optum.fds.paperless.service;

import org.springframework.web.multipart.MultipartFile;

public interface FilestoreService {
	
	public String saveFileToIngest(String fileName, MultipartFile file, String spaceId, String cid);
	
	public String processFileUpload(String fileName, MultipartFile file, String spaceId, String cid);

}
