package com.optum.fds.paperless.model.mongo;


public class ProcessingMetrics extends ProcessingMetricsCore {
    private Long                  averageRunTime;
    private Long                  averageFileSize;
    private Integer               fileCount;

    public Long getAverageRunTime() {
        return averageRunTime;
    }
    public void setAverageRunTime(Long averageRunTime) {
        this.averageRunTime = averageRunTime;
    }
    public Long getAverageFileSize() {
        return averageFileSize;
    }
    public void setAverageFileSize(Long averageFileSize) {
        this.averageFileSize = averageFileSize;
    }
    public Integer getFileCount() {
        return fileCount;
    }
    public void setFileCount(Integer fileCount) {
        this.fileCount = fileCount;
    }

}
