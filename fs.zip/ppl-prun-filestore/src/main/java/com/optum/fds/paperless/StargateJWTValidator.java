package com.optum.fds.paperless;

import java.io.FileInputStream;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.exceptions.JWTVerificationException;

import jakarta.annotation.PostConstruct;
@Component
public class StargateJWTValidator {

    @Value("${stargate.cert.filename}")
    private String stargateCert;

    private static final Logger logger = LogManager.getLogger(StargateJWTValidator.class);

    private X509Certificate cachedCertificate;

    @PostConstruct
    public void init() throws Exception {
        try (FileInputStream certFileStream = new FileInputStream(stargateCert)) {
            cachedCertificate = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(certFileStream);
            
            cachedCertificate.checkValidity();
            
            logger.info("@StargateJWTValidator - Certificate loaded and cached successfully.");
        } catch (CertificateExpiredException | CertificateNotYetValidException e) {
        logger.error("@StargateJWTValidator - Certificate validity check failed during initialization: {}", e.getMessage(), e);
        throw new Exception("Certificate validity check failed during initialization.", e);
        } catch (Exception e) {
            logger.error("@StargateJWTValidator - Failed to load and cache the certificate: {}", e.getMessage(), e);
            throw new Exception("Failed to load and cache the certificate.", e);
        }
    }

    public void validateJWT(String jwtToken) throws Exception {
        try {
            // Step 1: Decode the JWT
            if (jwtToken == null || jwtToken.isEmpty()) {
                logger.error("@StargateJWTValidator - JWT token is null or empty.");
                throw new IllegalArgumentException("JWT token cannot be null or empty.");
            }

            DecodedJWT decodedJWT = JWT.decode(jwtToken);

            // Step 2: Extract the x5c claim from the header
            List<String> x5c = decodedJWT.getHeaderClaim("x5c").asList(String.class);
            if (x5c == null || x5c.isEmpty()) {
                logger.error("@StargateJWTValidator - x5c claim is missing in the JWT header.");
                throw new IllegalArgumentException("x5c claim is missing in the JWT header.");
            }

            // Step 3: Get the certificate from the x5c claim
            String derEncodedCert = x5c.get(0);
            if (derEncodedCert == null || derEncodedCert.isEmpty()) {
                logger.error("@StargateJWTValidator - Certificate in x5c claim is missing or empty.");
                throw new IllegalArgumentException("Certificate in x5c claim is missing or empty.");
            }

            // Check if the certificate is in PEM format and convert it to DER
            if (derEncodedCert.contains("-----BEGIN CERTIFICATE-----")) {
                logger.info("@StargateJWTValidator - PEM format detected. Converting to DER format.");
                derEncodedCert = derEncodedCert.replace("-----BEGIN CERTIFICATE-----", "")
                                               .replace("-----END CERTIFICATE-----", "")
                                               .replaceAll("\\s", "");
            }

            try {
                byte[] certBytes = java.util.Base64.getUrlDecoder().decode(derEncodedCert);
            } catch (IllegalArgumentException e) {
                logger.error("@StargateJWTValidator - Certificate is not a valid Base64 string.");
                throw new IllegalArgumentException("Certificate is not a valid Base64 string.", e);
            }

            // Step 4: Verify the token's signature using the public key
            try {                
                PublicKey publicKey = cachedCertificate.getPublicKey();
                if (!(publicKey instanceof RSAPublicKey)) {
                    logger.error("@StargateJWTValidator - Public key is not an instance of RSAPublicKey.");
                    throw new IllegalArgumentException("Public key is not an instance of RSAPublicKey.");
                }
                Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) publicKey, null);
                JWT.require(algorithm).build().verify(decodedJWT);
                logger.info("@StargateJWTValidator - JWT validation successful.");
            } catch (Exception e) {
                logger.error("@StargateJWTValidator - Error during JWT signature verification: {}", e.getMessage());
                throw new Exception("JWT signature verification failed.", e);
            }
        } catch (JWTVerificationException e) {
            logger.error("@StargateJWTValidator - JWT verification failed: {}", e.getMessage(), e);
            throw e;
        } catch (IllegalArgumentException e) {
            logger.error("@StargateJWTValidator - Illegal argument: {}", e.getMessage(), e);
            throw e;
        } catch (CertificateException e) {
            logger.error("@StargateJWTValidator - Certificate error: {}", e.getMessage(), e);
            throw e;
        }
    }
}

