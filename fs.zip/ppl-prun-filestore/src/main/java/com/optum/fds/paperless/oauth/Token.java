package com.optum.fds.paperless.oauth;

import jakarta.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;

@XmlRootElement(name = "token")
public class Token {
	@JsonProperty("grant_type")
    private String grantType;
	@JsonProperty("access_token")
    private String accessToken;
	@JsonProperty("refresh_token")
    private String refreshToken;
	@JsonProperty("token_type")
    private String tokenType;
	@JsonProperty("expires_in")
    private int expiresIn;
	@JsonProperty("client_id")
    private String clientId;
	@JsonProperty("client_secret")
    private String clientSecret;

    /**
     * @return the grant_type
     */
    public String getGrantType() {
        return grantType;
    }

    /**
     * @param grant_type
     *            the grant_type to set
     */
    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    /**
     * @return the access_token
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * @param access_token
     *            the access_token to set
     */
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * @return the refresh_token
     */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * @param refresh_token
     *            the refresh_token to set
     */
    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    /**
     * @return the token_type
     */
    public String getTokenType() {
        return tokenType;
    }

    /**
     * @param token_type
     *            the token_type to set
     */
    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    /**
     * @return the expires_in
     */
    public int getExpiresIn() {
        return expiresIn;
    }

    /**
     * @param expires_in
     *            the expires_in to set
     */
    public void setExpiresIn(int expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

	@Override
	public String toString() {
		return "Token [grantType=" + grantType + ", accessToken=" + accessToken + ", refreshToken=" + refreshToken
				+ ", tokenType=" + tokenType + ", expiresIn=" + expiresIn + ", clientId=" + clientId + ", clientSecret="
				+ clientSecret + "]";
	}
    
}