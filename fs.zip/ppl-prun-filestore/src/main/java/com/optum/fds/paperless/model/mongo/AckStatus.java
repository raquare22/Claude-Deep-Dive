package com.optum.fds.paperless.model.mongo;



import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum AckStatus {
IN_PROCESS,
COMPLETE
}
