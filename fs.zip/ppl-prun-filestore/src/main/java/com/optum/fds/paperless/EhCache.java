package com.optum.fds.paperless;

import com.optum.fds.paperless.oauth.OauthTokenCacheExpiryPolicy;
import com.optum.fds.paperless.oauth.OauthToken;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.ehcache.config.builders.CacheConfigurationBuilder;
import org.ehcache.config.builders.ResourcePoolsBuilder;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
public class EhCache  {

	private static final Logger LOGGER = LoggerFactory.getLogger(EhCache.class);

	protected CacheManager cacheManager;

	public EhCache() {
		cacheManager = CacheManagerBuilder.newCacheManagerBuilder().withCache("oauthToken",
				CacheConfigurationBuilder.newCacheConfigurationBuilder(
						String.class,
						OauthToken.class,
						ResourcePoolsBuilder.heap(100)
					)
					.withExpiry(new OauthTokenCacheExpiryPolicy())
				)
				.build(true);
	}

	public Cache<String, OauthToken> getOauthTokenCacheFromCacheManager() {
		return cacheManager.getCache("oauthToken", String.class, OauthToken.class);
	}

	public String getOauthTokenCache(String tokenType) {
		var cache = getOauthTokenCacheFromCacheManager();
		if (cache.containsKey(tokenType)) {
			OauthToken cacheEle = null;
			try {
				cacheEle = cache.get(tokenType);
			} catch (Exception e) {
				LOGGER.error("Failure oauthToken cache.get e={}", ExceptionUtils.getStackTrace(e));
			}
			
			if (cacheEle != null && !cacheEle.isEmpty() && cacheEle.getAccessToken() != null && !cacheEle.getAccessToken().isEmpty()) {
				LOGGER.info("Token is in cache and not expired");
				return cacheEle.getAccessToken();
			} else {
				LOGGER.warn("Token is not in cache or it is expired");
				return null;
			}
		} else {
			LOGGER.warn("Token is not in cache or it is expired");
			return null;
		}
	}

	public void putOauthTokenWithExpiry(String key, String token, Integer expiresIn) {
		try {

			if (key != null && !key.isEmpty() && token != null && !token.isEmpty()) {
				var cache = getOauthTokenCacheFromCacheManager();
				var oauthToken = new OauthToken(token, expiresIn);
				cache.put(key, oauthToken);
				LOGGER.info("Successfully put OAuth token in cache, key={} exists in cache= {}", Encode.forJava(key), cache.containsKey(key));
			}
		} catch (Exception e) {
			LOGGER.warn("EhCache putOauthToken failed err={}", ExceptionUtils.getStackTrace(e));
		}
	}


}