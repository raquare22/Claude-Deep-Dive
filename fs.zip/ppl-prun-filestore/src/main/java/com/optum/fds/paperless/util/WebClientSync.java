package com.optum.fds.paperless.util;

import com.optum.fds.paperless.model.Doc360Response;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.exception.OutOfRetriesException;
import com.optum.fds.paperless.model.FDSCloudDocument;
import com.optum.fds.paperless.oauth.OauthUtil;

import io.netty.channel.ChannelOption;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
//import real.time.service.java.delegate.docvault.RetryOnExceptionHandler;
import java.io.File;
import java.net.URI;

@Service("WebClientSync")
public class WebClientSync {
	private static final Logger LOGGER = LoggerFactory.getLogger(WebClientSync.class);

	protected static int totalHttpFailureCnt = 0;
	protected static int totalFailureCnt = 0;

	@Autowired
	private WebClient.Builder webClientBuilder;
	
	@Autowired
	private OauthUtil oauthUtil;

	@Value("${FDSOauthUrl}")
	protected String fdsOauthUrl;
	
	@Value("${FDSCloudAppId}")
	protected String fdsCloudAppId;
	
	@Value("${FDSCloudAppSecret}")
	protected String fdsCloudAppSecret;

    @Value("${Doc360OauthUrl}")
    protected String doc360OauthUrl;

    @Value("${Doc360AppId}")
    protected String doc360AppId;

    @Value("${Doc360AppSecret}")
    protected String doc360AppSecret;

    @Value("${Doc360UploadDocumentScope}")
    protected String doc360UploadDocumentScope;

    @Value("${Doc360UpstreamEnv}")
    protected String doc360UpstreamEnv;

	private WebClient webClientSingleton = null;

	protected static final String GRANT_TYPE = "client_credentials";
	
	ExchangeFilterFunction errorResponseFilter = ExchangeFilterFunction.ofResponseProcessor(WebClientSync::responseFilter);

	public static void logStats() {
		LOGGER.warn("STATS: totalHttpFailureCnt={}, totalFailureCnt={}", totalHttpFailureCnt, totalFailureCnt);
	}

    public ResponseEntity<Doc360Response> sendMultiPartDataWithRetryForDoc360(String doc360PostDocumentsUrl, URI uri, File file, String document) throws OutOfRetriesException {
        var numRetries = 3;
        var timeToWaitMS = 250L;

        var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);

        String oauthToken = oauthUtil.getOauthToken("tokenDoc360Upload", doc360AppId, doc360AppSecret, GRANT_TYPE, doc360OauthUrl, doc360UploadDocumentScope, false);
        System.out.println("oauthToken: " + oauthToken);
        ResponseEntity<Doc360Response> response = null;
        long startTime = System.nanoTime();

        while (retryHandler.shouldRetry()) {
            try {
                try {

                    if (retryHandler.isRetry()) {
                        String newToken = oauthUtil.getOauthToken("tokenDoc360Upload", doc360AppId, doc360AppSecret, GRANT_TYPE, doc360OauthUrl, doc360UploadDocumentScope, true);
                        response = getWebClient()
                                .post().uri(uri).contentType(MediaType.MULTIPART_FORM_DATA)
                                .header("x-upstream-env", doc360UpstreamEnv)
                                .header("Authorization", "Bearer " + newToken)
                                .body(BodyInserters.fromMultipartData(getMultiValueMap(file, document, null)))
                                .retrieve()
                                .toEntity(Doc360Response.class)
                                .block();

                    } else {
                        response = getWebClient()
                                .post().uri(uri).contentType(MediaType.MULTIPART_FORM_DATA)
                                .header("x-upstream-env", doc360UpstreamEnv)
                                .header("Authorization", "Bearer " + oauthToken)
                                .body(BodyInserters.fromMultipartData(getMultiValueMap(file, document, null)))
                                .retrieve()
                                .toEntity(Doc360Response.class)
                                .block();
                    }

                    long latency = (System.nanoTime() - startTime) / 1000000;

                    LOGGER.info("sendMultiPartDataWithRetryForDoc360 Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}",
                            doc360PostDocumentsUrl, HttpMethod.POST.toString(), response.getStatusCode().value(), latency );
                    break;
                } catch (HttpStatusCodeException e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;

                    incrementAndGetTotalHttpFailureCnt();

                    if (HttpUtils.validateStatusCode(e.getStatusCode())) {
                        LOGGER.warn("sendMultiPartDataWithRetryForDoc360 HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
                                doc360PostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );

                        retryHandler.exceptionOccurred();
                    } else {
                        LOGGER.error("sendMultiPartDataWithRetryForDoc360 HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
                                doc360PostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
                        return new ResponseEntity<Doc360Response>(e.getStatusCode());
                    }
                } catch (WebClientResponseException e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;

                    incrementAndGetTotalHttpFailureCnt();

                    if (HttpUtils.validateStatusCode(e.getStatusCode())) {
                        LOGGER.warn("sendMultiPartDataWithRetryForDoc360 WebClientResponseException Invoking Retry Mechanism  Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
                                doc360PostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );

                        retryHandler.exceptionOccurred();
                    } else {
                        LOGGER.error("sendMultiPartDataWithRetryForDoc360 WebClientResponseException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
                                doc360PostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
                        return new ResponseEntity<Doc360Response>(e.getStatusCode());
                    }
                } catch (Exception e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;
                    LOGGER.error("sendMultiPartDataWithRetryForDoc360 Exception Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, TotalLatency={}, err={}",
                            doc360PostDocumentsUrl, HttpMethod.POST.toString(), latency, ExceptionUtils.getStackTrace(e) );

                    return new ResponseEntity<Doc360Response>(HttpStatus.INTERNAL_SERVER_ERROR);
                }
            } catch (OutOfRetriesException e) {

                LOGGER.error("sendMultiPartDataWithRetryForDoc360 OutOfRetriesException 3 retries exhausted  Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, err={}",
                        doc360PostDocumentsUrl, HttpMethod.POST.toString(), ExceptionUtils.getStackTrace(e) );
                return new ResponseEntity<Doc360Response>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }


        return response;

    }

	public ResponseEntity<FDSCloudDocument> sendMultiPartDataWithRetry(String fdsCloudPostDocumentsUrl, URI uri, File file, String document, 
			String searchTerms) throws OutOfRetriesException {
		
		var numRetries = 3;
		var timeToWaitMS = 250L;
		
		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		
		String oauthToken = oauthUtil.getOauthToken("tokenFDSCloudPrun", fdsCloudAppId, fdsCloudAppSecret, GRANT_TYPE, fdsOauthUrl, null, false);

		ResponseEntity<FDSCloudDocument> response = null;
		
		long startTime = System.nanoTime();
		
		while (retryHandler.shouldRetry()) {
			try {
				try {
					
					if (retryHandler.isRetry()) {
						String newToken = oauthUtil.getOauthToken("tokenFDSCloudPrun", fdsCloudAppId, fdsCloudAppSecret, GRANT_TYPE, fdsOauthUrl, null, true);
						response = getWebClient()
								.post().uri(uri).contentType(MediaType.MULTIPART_FORM_DATA)
								.header("fds-authorization", newToken)
								.body(BodyInserters.fromMultipartData(getMultiValueMap(file, document, searchTerms)))
								.retrieve()
//								.bodyToMono(FDSCloudDocument.class)
//								.retry(3)
					            .toEntity(FDSCloudDocument.class)
								.block();
						
					} else {
						response = getWebClient()
								.post().uri(uri).contentType(MediaType.MULTIPART_FORM_DATA)
								.header("fds-authorization", oauthToken)
								.body(BodyInserters.fromMultipartData(getMultiValueMap(file, document, searchTerms)))
								.retrieve()
//								.bodyToMono(FDSCloudDocument.class)
//								.retry(3)
					            .toEntity(FDSCloudDocument.class)
								.block();
					}
					
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					LOGGER.info("sendMultiPartDataWithRetry Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
							fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), response.getStatusCode().value(), latency );
					break;
				} catch (HttpStatusCodeException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
				
					incrementAndGetTotalHttpFailureCnt();
					
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						LOGGER.warn("sendMultiPartDataWithRetry HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
								fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("sendMultiPartDataWithRetry HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						ResponseEntity<FDSCloudDocument> errorResponse = new ResponseEntity<FDSCloudDocument>(e.getStatusCode());
						return errorResponse;
					}
				} catch (WebClientResponseException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					incrementAndGetTotalHttpFailureCnt();
					
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						LOGGER.warn("sendMultiPartDataWithRetry WebClientResponseException Invoking Retry Mechanism  Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
								fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("sendMultiPartDataWithRetry WebClientResponseException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						return new ResponseEntity<FDSCloudDocument>(e.getStatusCode());
					}
				} catch (Exception e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.error("sendMultiPartDataWithRetry Exception Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, TotalLatency={}, err={}", 
							fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), latency, ExceptionUtils.getStackTrace(e) );
					
					return new ResponseEntity<FDSCloudDocument>(HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} catch (OutOfRetriesException e) {

				LOGGER.error("retryFDSCloudPostCall OutOfRetriesException 3 retries exhausted  Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, err={}", 
						fdsCloudPostDocumentsUrl, HttpMethod.POST.toString(), ExceptionUtils.getStackTrace(e) );
				return new ResponseEntity<FDSCloudDocument>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		
		return response;
	}

	protected MultiValueMap<String, HttpEntity<?>> getMultiValueMap(File file, String document, String searchTerms) {
		MultipartBodyBuilder builder = new MultipartBodyBuilder();
		builder.part("file", new FileSystemResource(Encode.forJava(String.valueOf(file))));
		builder.part("metadata", document);

        // only add searchTerms for FDS cloud request, not Doc360
        if (searchTerms != null && !searchTerms.isEmpty()) {
            builder.part("searchTerms", searchTerms);
        }
		return builder.build();
	}

	protected final WebClient getWebClient() {
		if (webClientSingleton == null) {
			getNewWebClient();
		}
		return webClientSingleton;
	}

	protected final synchronized WebClient getNewWebClient() {
		if (webClientSingleton == null) {
			HttpClient httpClient = HttpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000); //default 30000
			webClientSingleton = webClientBuilder.clientConnector(new ReactorClientHttpConnector(httpClient))
//					.filter(errorResponseFilter)
					.build();
		}
		return webClientSingleton;
	}

	protected static Mono<ClientResponse> responseFilter(ClientResponse response) {
		HttpStatusCode status = response.statusCode();
		if (status.isError()) {
			String msg = "body=" + response.bodyToMono(String.class) + ", headers=" + response.headers().asHttpHeaders();
			LOGGER.error("FAILURE: status={}, msg={}", status, msg);
			return response.bodyToMono(String.class).flatMap(body -> Mono.error(new HttpServerException(msg, status)));
		}
		LOGGER.info("OK: status={}, body={}, headers={}", status, response.bodyToMono(String.class), response.headers().asHttpHeaders());
		return Mono.just(response);
	}

	protected static int incrementAndGetTotalHttpFailureCnt() {
		return ++totalHttpFailureCnt;
	}

	protected static int incrementAndGetTotalFailureCnt() {
		return ++totalFailureCnt;
	}
}