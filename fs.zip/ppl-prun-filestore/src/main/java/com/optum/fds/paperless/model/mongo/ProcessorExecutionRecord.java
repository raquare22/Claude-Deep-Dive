package com.optum.fds.paperless.model.mongo;

import java.io.Serializable;


public class ProcessorExecutionRecord extends ExecutionRecord implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String description;

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}
