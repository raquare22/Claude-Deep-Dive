package com.optum.fds.paperless.service;

import com.optum.fds.paperless.model.mongo.ProcessorTransaction;

public interface ProcessorTransactionService {
	
    public ProcessorTransaction createProcessorTransaction(String fileName, String fileLocation, String spaceId);

	public ProcessorTransaction findProcessorTransactionByFileName(String fileName, Integer integer);

}
