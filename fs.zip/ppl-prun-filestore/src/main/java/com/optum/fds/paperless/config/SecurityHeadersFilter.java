package com.optum.fds.paperless.config;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Component
public class SecurityHeadersFilter extends OncePerRequestFilter {

    private static final Logger logger = LogManager.getLogger(SecurityHeadersFilter.class);

    private static final String CSP_POLICY =
            "script-src 'self'; " +
            "style-src 'self' 'unsafe-inline'; " +
            "img-src 'self' data:; " +
            "connect-src 'self'; " +
            "font-src 'self'; " +
            "frame-ancestors 'none'; " +
            "base-uri 'none'; " +
            "form-action 'self'";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String path = request.getRequestURI();
        try {
            if (path != null && (path.contains("/api/services/v1/filestore/sendFile") || path.contains("/api/services/v1/fds/documents"))) {
                response.setHeader("Content-Security-Policy", CSP_POLICY);
                response.setHeader("X-Content-Type-Options", "nosniff");
                response.setHeader("X-Frame-Options", "DENY");
                response.setHeader("Referrer-Policy", "no-referrer");
                response.setHeader("Access-Control-Allow-Origin", "*");
                response.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,OPTIONS");
                response.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization");
                response.setHeader("Access-Control-Allow-Credentials", "true");
                // Handle preflight requests
                if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
                    response.setStatus(HttpServletResponse.SC_OK);
                    return;
                }
            }
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            logger.error("Error in SecurityHeadersFilter", e);
            if (!response.isCommitted()) {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.setContentType("application/json");
                response.getWriter().write("{\"error\": \"An unexpected error occurred while processing the request.\"}");
            } else {
                logger.error("Response already committed. Unable to modify response status or write error message.");
            }
        }
    }
}
