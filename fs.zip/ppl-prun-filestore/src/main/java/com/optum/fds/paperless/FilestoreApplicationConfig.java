package com.optum.fds.paperless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.restclient.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Configuration
public class FilestoreApplicationConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(FilestoreApplicationConfig.class);
			
	@Value("${ChunkSize:5000000}")
	int chunkSize;

	@Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
       return builder.build();
	}

	@Bean("RestTemplateChuck")
	public RestTemplate restTemplates() {
		LOGGER.warn("RestTemplateChuck: chunkSize={}", chunkSize);
		SimpleClientHttpRequestFactory rf = new SimpleClientHttpRequestFactory();
		rf.setChunkSize(chunkSize);
		return new RestTemplate(rf);
	}

    @Bean
    public HttpHeaders httpHeaders() {
    	return new HttpHeaders();
    }
    
    @Bean
    public ConfigData getConfigData() {
    	return new ConfigData();
    }
    
    @Bean
    public ObjectMapper objectMapper() {
    	
    	 ObjectMapper mapper = new ObjectMapper();
    	 mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
    	 mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    	 
        return mapper;
    }
    
    @Bean
	public WebClient.Builder webClientBuilder() {
	    return WebClient.builder();
	}

}
