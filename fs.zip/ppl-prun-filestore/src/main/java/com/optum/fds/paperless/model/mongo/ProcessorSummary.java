package com.optum.fds.paperless.model.mongo;

import java.util.HashMap;

public class ProcessorSummary extends ProcessorSummaryCore {

    private transient Object     xmlObject;
	ProcessingMetrics processingMetrics;

	public ProcessorSummary() {
    	this.runTime = 0L;
    }

    public ProcessingMetrics getProcessingMetrics() {
    	if (processingMetrics == null) {
    		processingMetrics = new ProcessingMetrics();
    		processingMetrics.setAverageFileSize(0L);
    		processingMetrics.setBytesProcessed(0L);
    		processingMetrics.setFileCount(0);
    		processingMetrics.setTotalBytes(0L);
    		processingMetrics.setTotalRunTime(0L);
    		processingMetrics.setErrorCount(new HashMap());
    	} else {
    		if (processingMetrics.getAverageFileSize() == null) {
    			processingMetrics.setAverageFileSize(0L);
    		}
    		if (processingMetrics.getBytesProcessed() == null) {
    			processingMetrics.setBytesProcessed(0L);
    		}
    		if (processingMetrics.getFileCount() == null) {
    			processingMetrics.setFileCount(0);
    		}
    		if (processingMetrics.getTotalBytes() == null) {
    			processingMetrics.setTotalBytes(0L);
    		}
    		if (processingMetrics.getTotalRunTime() == null) {
    			processingMetrics.setTotalRunTime(0L);
    		}
    		if (processingMetrics.getErrorCount() == null) {
    			processingMetrics.setErrorCount(new HashMap());
    		}
    	}
        return processingMetrics;
    }
    public void setProcessingMetrics(ProcessingMetrics processingMetrics) {
        this.processingMetrics = processingMetrics;
    }
    public Object getXmlObject() {
        return xmlObject;
    }
    public void setXmlObject(Object xmlObject) {
        this.xmlObject = xmlObject;
    }

}
