package com.optum.fds.paperless.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Set;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.optum.fds.paperless.model.mongo.ProcessorTransaction;
import com.optum.fds.paperless.util.SanitizeUtil;


@Service("FilestoreServiceImpl")
public class FilestoreServiceImpl implements FilestoreService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FilestoreServiceImpl.class);
	
	@Value("${INGEST_ROOT}")
	private String ingestRoot;
	
	private static final String DATE_FORMAT = "yyyyMMddHHmmssSSS";
	
	public static final String DEFAULT_FILE_SEPARATOR = "/";
	
	@Autowired
	ProcessorTransactionService processorTransactionService;
	
	
	@Override
	public String processFileUpload(String fileName, MultipartFile file, String spaceId, String cid) {
		String location = saveFileToIngest(fileName, file, spaceId, cid);
		if (location != null && !location.isEmpty()) {
			ProcessorTransaction processorTransaction = processorTransactionService.createProcessorTransaction(file.getOriginalFilename(), location, spaceId);
			if (processorTransaction == null) {
				return null;
			}
			return processorTransaction.getId();
		}
		return null;	
	}
	
	
	@Override
	public String saveFileToIngest(String fileName, MultipartFile file, String spaceId, String cid) {
		// save file to ingest location and return location
		
		Path tempWorkingPath = null;
		try {
			
			tempWorkingPath = createWorkingDirectoryWithParams(DEFAULT_FILE_SEPARATOR,
					ingestRoot, "filestore", spaceId, getCurrentDateFormattedWithUUIdFormat());
			
			String tempWorkingPathStr = tempWorkingPath.toAbsolutePath().toString();
			
			LOGGER.info("saveFileToIngest fileName={}, tempWorkingPathStr={}, CID={}", SanitizeUtil.sanitizeAlphaString(fileName), tempWorkingPathStr, Encode.forJava(cid));
			
			
			File copyFile = new File(tempWorkingPath + DEFAULT_FILE_SEPARATOR + fileName);
			
			if (copyFile.exists()) {
				LOGGER.error("file already exists, unable to save to ingest path={}, fileName={}, CID={}", tempWorkingPathStr, SanitizeUtil.sanitizeAlphaString(fileName), Encode.forJava(cid));
				return null;
			}
			
			Files.copy(file.getInputStream(), copyFile.toPath() );
			
			// Set file permissions
	        Set<PosixFilePermission> permissions = PosixFilePermissions.fromString("r--r--r--");
	        Files.setPosixFilePermissions(copyFile.toPath(), permissions);

			
			return tempWorkingPathStr;
		} catch (Exception e) {
			LOGGER.error("Unable to save file to ingest, fileName={}, spaceId={}, ingestLocation={}, CID={}", SanitizeUtil.sanitizeAlphaString(fileName),  SanitizeUtil.sanitizeNumericString(spaceId), tempWorkingPath, Encode.forJava(cid));
			return null;
		}
		
		
	}
	
	
	
	public Path createWorkingDirectoryWithParams(String delimiter, String...elements) throws IOException {
        return createWorkingDirectory(String.join(delimiter, elements));
    }
	
	private Path createWorkingDirectory(String tempDirRoot) throws IOException {
        LOGGER.debug("Creating working directory for {}", tempDirRoot);

        return Files.createDirectories(Paths.get(tempDirRoot));
    }
	
	private String getCurrentDateFormattedWithUUIdFormat() {
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
		return now.format(formatter) + UUID.randomUUID();
	}

}
