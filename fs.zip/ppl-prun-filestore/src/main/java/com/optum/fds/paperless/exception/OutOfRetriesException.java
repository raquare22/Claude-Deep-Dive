package com.optum.fds.paperless.exception;

public class OutOfRetriesException extends Exception {
    private static final long serialVersionUID = 1L;

    public OutOfRetriesException() {
        super();
    }

    public OutOfRetriesException(String message) {
        super(message);
    }

}
