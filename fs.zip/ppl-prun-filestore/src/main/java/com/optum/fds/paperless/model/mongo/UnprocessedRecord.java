package com.optum.fds.paperless.model.mongo;

import java.io.Serializable;

public class UnprocessedRecord extends ExecutionRecord implements Serializable{
    
	public UnprocessedRecord(String unprocessedRecord, int index) {
		super();
		this.unprocessRecord = unprocessedRecord;
		this.index = index;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String unprocessRecord;
	
	private int index;

	public String getUnprocessRecord() {
		return unprocessRecord;
	}
	public void setUnprocessRecord(String unprocessRecord) {
		this.unprocessRecord = unprocessRecord;
	}
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }
}
