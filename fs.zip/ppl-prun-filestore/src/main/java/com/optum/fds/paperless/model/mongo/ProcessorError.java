/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/31/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.model.mongo;

import java.io.Serializable;

public class ProcessorError implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String  fileName;
    String  errorMessage;
    Integer errorCode;

    public ProcessorError(){}
    public ProcessorError(ProcessorErrorCode processorErrorCode){
        this.errorCode    = processorErrorCode.getErrorCode();
        this.errorMessage = processorErrorCode.getErrorMessage();
    }
    public ProcessorError(ProcessorErrorCode processorErrorCode, String fileName){
        this(processorErrorCode);
        this.fileName = fileName;
    }
    
   

    public ProcessorError(String errorMessage, Integer errorCode) {
    	 this.errorCode    =errorCode;
         this.errorMessage = errorMessage;
	}
	public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getErrorMessage() {
        return errorMessage;
    }
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    public Integer getErrorCode() {
        return errorCode;
    }
}
