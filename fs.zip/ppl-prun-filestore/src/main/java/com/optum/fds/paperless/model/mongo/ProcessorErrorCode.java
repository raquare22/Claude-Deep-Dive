/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/31/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.model.mongo;


public enum ProcessorErrorCode {
    FILE_NOT_FOUND                             ( 1, "File not found"),
    FILE_COULD_NOT_BE_PARSED                   ( 2, "File could not be parsed"),
    XML_COULD_NOT_BE_MAPPED                    ( 3, "XML in metadata file could not be mapped correctly."),
    UNKNOWN_ERROR_READING_FILE                 ( 4, "There was an error reading file."),
    XML_MISSING_FILES_NODE                     ( 5, "XML is missing required field FILES"),
    XML_MISSING_FILES_TO_PROCESS               ( 6, "XML must have at least one FILE node"),
    FILE_COUNT_MISMATCH                        ( 7, "There was a mismatch between count and files to be processed."),
    EXTRA_FILE_FOUND_WITH_NO_METADATA          ( 8, "There was an extra file with no corresponding metadata file found in content to process."),
    EXTRA_METADATA_FILE_FOUND                  ( 9, "There was an extra metadata file with no corresponding file found in content to process."),
    PDF_FILE_NAME_MISMATCH			           (10, "There is a mismatch between pdf name(s) in zip file and summary file."),
    FILE_COULD_NOT_BE_UNZIPPED                 (11, "File could not be unzipped."),
    REQUIRED_METADATA_FIELDS_MISSING           (12, "Required metadata fields are missing or invalid."),
    NO_MAPPING_INFORMATION_FOUND               (13, "No Mapping information found."),
    UNKNOWN_ERROR_CONVERTING_TO_JSON           (14, "Unknown error while parsing Map to JSON string."),
    EMPTY_METADATA_FILE                        (15, "Metadata file was empty."),
    UNKNOWN_ERROR_GETTING_OAUTH                (16, "Unknown error trying to get OAUTH token."),
    UNKNOWN_ERROR_RETRIEVING_FDS_CONFIGURATION (17, "Unknown error retrieving FDS Configuration."),
    UNKNOWN_ERROR_POSTING_TO_FDS               (18, "Unknown error posting to FDS."),
    ERROR_PARSING_FDS_RESPONSE                 (19, "Error parsing FDS Response."),
    NO_METADATA_FILE_FOUND                     (20, "Required Metadata file is missing."),
	STORAGE_ERROR							   (21, "Storage Error"),
    REQUIRED_METADATA_FIELDS_MISSING_SEVERE_ERROR (22, "Required metadata fields are missing or invalid (SEVERE_ERROR)."),
    XML_COULD_NOT_BE_MAPPED_IN_SUMMARY         (23, "XML in summary file could not be mapped correctly."),
	NUMBER_FORMAT_EXCEPTION_SUMMARY_COUNT      (24,"Bad format in summary file Count"),
	ERROR_POSTING_TO_FDS                       (25, "Error returned from service layer, unable to post to FDS"),
	MISSING_PROCESSOR_CONFIGURATION			   (26, "Missing configuration in processor config"),
	UNABLE_TO_CONVERT_WITH_STRING_TEMPLATE     (27, "Error converting file to document with string template");
    private Integer errorCode;
    private String errorMessage;

    ProcessorErrorCode(Integer code, String message){
        this.errorCode = code;
        this.errorMessage = message;
    }

    public Integer getErrorCode() {
        return errorCode;
    }
    public String getErrorMessage() {
        return errorMessage;
    }
}
