package com.optum.fds.paperless.exception;

public enum ErrorCode {
	PROCESS(0, "A process error has occurred."),
	VALIDATION(1, "A validation error has occurred."),
	PROCESS_SEND(2, "A process send error has occurred.");

	private final int code;
	private final String description;

	private ErrorCode(int code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public int getCode() {
		return code;
	}

	@Override
	public String toString() {
		return code + ": " + description;
	}
}
