package com.optum.fds.paperless.oauth;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.owasp.encoder.Encode;

import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.util.SanitizeUtil;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class OauthUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(OauthUtil.class);

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private EhCache ehcache;

	private static final int POST_RETRIES = 3;
	private static final long THREAD_SLEEP_TIME = 250;

	public String getOauthToken(String tokenType, String clientId, String clientSecret, String grantType, String oauthUrl, String scope, boolean getNewToken) {
    	Optional<OauthToken> oauthTokenExtendedOptional = null ;
        String docToken = ehcache.getOauthTokenCache(tokenType);
        
		if ( docToken == null || getNewToken ) {
			oauthTokenExtendedOptional = getOauthTokenExtended(clientId, clientSecret, oauthUrl, grantType, scope);
			
			// got new token so put it in cache
			var accessTokenOptional = oauthTokenExtendedOptional.map(OauthToken::getAccessToken);
			var expiresInOptional = oauthTokenExtendedOptional.map(OauthToken::getExpiresIn);
			
			var accessToken = accessTokenOptional.orElse(null);
			var expiresIn = expiresInOptional.orElse(3600);
			
			// expire token 1 minute before actual expiry
			if (expiresIn > 60) {
				expiresIn = expiresIn - 60;
			}
			ehcache.putOauthTokenWithExpiry(tokenType, accessToken, expiresIn);
			
			return accessToken;
		}
        return docToken;
    }
    
    public Optional<OauthToken> getOauthTokenExtended(String appId, String appSecret, String url, String grantType, String scope) {
    	var tokenExtended = new OauthToken(appId, appSecret, url, grantType, scope);
        try {
            tokenExtended = refreshToken(tokenExtended);
        } catch (InterruptedException e) {
            LOGGER.error("OauthUtil-->getOauthTokenExtended-->Error getting the OauthToken e={}", ExceptionUtils.getStackTrace(e));
            return Optional.empty();
        }
        return Optional.of(tokenExtended);
    }


    public OauthToken refreshToken(OauthToken oauthTokenExtended) throws InterruptedException {
        try {

            var url = oauthTokenExtended.getUrl();

            var optionalToken = getOauth2Token(url, oauthTokenExtended);
            if (optionalToken.isPresent()) {
                var token = optionalToken.get();
                oauthTokenExtended.setAccessToken(token.getAccessToken());
                oauthTokenExtended.setTokenType(token.getTokenType());
                oauthTokenExtended.setObtainedOn(new Date());
                oauthTokenExtended.setExpiresIn(token.getExpiresIn());
            } else {
                oauthTokenExtended.setAccessToken(null);
                oauthTokenExtended.setObtainedOn(null);
                oauthTokenExtended.setExpiresIn(null);
            }
        } catch (InterruptedException e) {
            LOGGER.error("refreshToken Error retrieving Token {}",ExceptionUtils.getStackTrace(e));
            throw e;

        }
        return oauthTokenExtended;
    }
	
	private Optional<Token> getOauth2Token(String url, OauthToken oauthTokenExtended) throws InterruptedException {
        var count = 0;
        var response = postOauthToken(oauthTokenExtended, url);
        while (count < POST_RETRIES && response.getStatusCode().value() >= HttpStatus.INTERNAL_SERVER_ERROR.value()) {
            ++count;
            synchronized (this) {
                this.wait(THREAD_SLEEP_TIME);
            }
            response = postOauthToken(oauthTokenExtended, url);
        }
        if (response.getStatusCode() == HttpStatus.OK) {
            return Optional.of(response.getBody());
        } else {
            LOGGER.error("Failed postOauthToken response status: {}, appIdentifier: {}", response.getStatusCode(), oauthTokenExtended.getAppId());
            return Optional.empty();
        }
	}

	
    private ResponseEntity<Token> postOauthToken(OauthToken oauthTokenExtended, String url) {
        var headers = new HttpHeaders();
        headers.set(HttpConstants.HEADER_ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        var uri = UriComponentsBuilder.fromUriString(url).build().encode().toUri();

        var reqPayload = new LinkedMultiValueMap<String, String>();
        reqPayload.add(HttpConstants.FORM_PARAM_CLIENT_ID, oauthTokenExtended.getAppId());
        reqPayload.add(HttpConstants.FORM_PARAM_CLIENT_SECRET, oauthTokenExtended.getAppSecret());
        reqPayload.add(HttpConstants.FORM_PARAM_GRANT_TYPE, (StringUtils.isEmpty(oauthTokenExtended.getGrantType())) ?
                HttpConstants.FORM_VALUE_AUTHORIZATION_CODE : oauthTokenExtended.getGrantType());

        if (oauthTokenExtended.getScope() != null && !oauthTokenExtended.getScope().isEmpty()) {
            reqPayload.add(HttpConstants.FORM_PARAM_SCOPE, oauthTokenExtended.getScope());
        }

        var request = new HttpEntity<MultiValueMap<String, String>>(reqPayload, headers);
        return restTemplate.exchange(uri, HttpMethod.POST, request, Token.class);
    }

	public static String createAuthHeader(String username, String password){
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64( 
           auth.getBytes(StandardCharsets.US_ASCII));
        return "Basic " + new String( encodedAuth );
	}
}
