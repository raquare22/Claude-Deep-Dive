package com.optum.fds.paperless.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

public final class SanitizeUtil {
    private static final String AUTHORIZATION = "Authorization";
    protected static final String REGEX_REPLACEMENT_CHARACTER = "\\$";
	public static final String REPLACEMENT_CHARACTER = "$";

    private SanitizeUtil() {}

    public static String sanitizeString(String input){
        if (input == null) {
            return null;
        }
        try {
            return JsonParser.parseString(input).toString();
        } catch (JsonSyntaxException e) {
            //return input.replaceAll("[^a-zA-Z0-9_-]", "");
            return "Sanitize Failure";
        }
    }

    public static HttpEntity<?> sanitizeHttpEntityHeaderRmAuth(HttpEntity<?> requestEntity) {
        requestEntity = new HttpEntity<>(requestEntity.getHeaders());
        HttpHeaders httpHeaders = requestEntity.getHeaders();
        httpHeaders.remove(AUTHORIZATION);
        if (requestEntity.getHeaders().getContentType() != null) {
            httpHeaders.setContentType(new MediaType(sanitizeString(requestEntity.getHeaders().getContentType().toString())));
        }
        return requestEntity;
    }

    public static String sanitizeResponseEntityBody(ResponseEntity<?> response) {
        return response != null && response.getBody() != null ? response.toString() : null;
    }

    public static String sanitizeNumericString(String input){
        try {
            if(input.matches("[0-9]+"))
                return input;
            return "0";
        } catch (NumberFormatException e) {
            return "0";
        }
    }
    public static String sanitizeFilePath(String input){
        if (input == null) {
            return null;
        }
        return input.replaceAll("[@!$%^&:*?\"<>|]", "_");

    }
    
    public static String sanitizeToString(String str){
        return str == null ? null : str.replaceAll("\\v", "");
    }

    public static String sanitizeIntegerString(String str) {
        return str == null ? null : str.replaceAll("[^0-9]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaString(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaNumericString(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z0-9]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaNumericStringWithHyphen(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z0-9-]", REGEX_REPLACEMENT_CHARACTER);
    }

}