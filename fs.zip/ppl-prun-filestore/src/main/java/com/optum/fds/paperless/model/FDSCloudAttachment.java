package com.optum.fds.paperless.model;

import java.util.Date;

public class FDSCloudAttachment {

	private String attachmentId;
	
	private String contentType;
	
	private String fileName;
	
	private long fileSize;
	
	private Date createdOn;
	
	private Date modifiedOn;
	
	private String spaceId;
	
	private String virusScanStatus;
	
	private String url;
	
	private String cloudStorageProvider;

	public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}

	public String getVirusScanStatus() {
		return virusScanStatus;
	}

	public void setVirusScanStatus(String virusScanStatus) {
		this.virusScanStatus = virusScanStatus;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getCloudStorageProvider() {
		return cloudStorageProvider;
	}

	public void setCloudStorageProvider(String cloudStorageProvider) {
		this.cloudStorageProvider = cloudStorageProvider;
	}
	
	@Override
	public String toString() {
		return "FDSCloudAttachment = [ " + attachmentId + " ]";
		
	}
	
}