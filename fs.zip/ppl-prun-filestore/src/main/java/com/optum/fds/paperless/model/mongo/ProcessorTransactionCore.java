package com.optum.fds.paperless.model.mongo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProcessorTransactionCore extends ProcessorTask {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorTransactionCore.class);
    public void setReadyStatus() {
        setEndTime();
        setStatus(MetaDataStatus.READY);
    }

    public MetaDataStatus setCompleteStatus() {
        MetaDataStatus status = MetaDataStatus.COMPLETE;
        if (!super.getSummary().getErrorList().isEmpty()) {
            status = MetaDataStatus.COMPLETE_WITH_ERRORS;
        }
        setStatus(status);
        LOGGER.info("Updated ProcessorTransaction status to {}", getStatus());
        return status;
    }
}
