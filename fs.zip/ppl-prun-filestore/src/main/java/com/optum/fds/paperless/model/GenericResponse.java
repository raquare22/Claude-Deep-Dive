package com.optum.fds.paperless.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class GenericResponse {
	private String statusCode;
	private String statusMessage;
	private Object response;

	public GenericResponse() {
	}

	public GenericResponse(String statusCode, String statusMessage, Object response) {
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.response = response;
	}

	public static GenericResponse from(String statusCode, String statusMessage, Object response) {
		return new GenericResponse(statusCode, statusMessage, response);
	}

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public Object getResponse() {
    	return response;
    }

    public void setResponse(Object response) {
    	this.response = response;
    }

	@Override
	public String toString() {
		return "GenericResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", response=" + response + "]";
	}
}
