package com.optum.fds.paperless.model.mongo;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProcessorCore extends MetaData {
    private Integer              configSpaceId;
    private ProcessorRecordTypes processorRecordType;
    private ProcessorSummary     summary;


    public Integer getConfigSpaceId() {
        return configSpaceId;
    }
    public void setConfigSpaceId(Integer configSpaceId) {
        if(configSpaceId != null) {
            this.configSpaceId = configSpaceId;
        }
    }
    public ProcessorRecordTypes getProcessorRecordType() {
        return processorRecordType;
    }
    public void setProcessorRecordType(ProcessorRecordTypes processorRecordType) {
        this.processorRecordType = processorRecordType;
    }
    @JsonProperty("summary")
    public ProcessorSummary getSummaryForDB(){
        // Check and see if summary is Null
        if(summary == null || summary.getErrorList() == null && summary.getProcessingMetrics() == null && summary.getRunTime() == null){
            summary = null;
        }
        return summary;
    }
    @JsonIgnore
    public ProcessorSummary getSummary() {
        if(summary == null){
            summary = new ProcessorSummary();
        }

        return summary;
    }
    @JsonProperty("summary")
    public void setSummary(ProcessorSummary summary) {
        this.summary = summary;
    }
}
