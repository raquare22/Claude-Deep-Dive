package com.optum.fds.paperless;

import com.optum.fds.paperless.config.SecurityHeadersFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterRegistrationBeanConfig {

    private final StargateJWTFilter jwtFilter;
    private final SecurityHeadersFilter securityHeadersFilter;

    public FilterRegistrationBeanConfig(StargateJWTFilter jwtFilter, SecurityHeadersFilter securityHeadersFilter) {
        this.jwtFilter = jwtFilter;
        this.securityHeadersFilter = securityHeadersFilter;
    }

    @Bean
    public FilterRegistrationBean<StargateJWTFilter> jwtFilterRegistration() {
        FilterRegistrationBean<StargateJWTFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(jwtFilter);
        registrationBean.addUrlPatterns("/api/services/v1/filestore/*"); // Define URL patterns
        registrationBean.setOrder(1); // Set filter order
        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean<SecurityHeadersFilter> securityHeadersFilterRegistration() {
        FilterRegistrationBean<SecurityHeadersFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(securityHeadersFilter);
        registrationBean.addUrlPatterns("/api/services/v1/filestore/*", "/api/services/v1/fds/*");
        registrationBean.setOrder(0); // Ensure this runs before JWT filter
        return registrationBean;
    }
}