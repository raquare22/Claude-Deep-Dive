package com.optum.fds.paperless.model.mongo;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.springframework.data.annotation.Id;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class MetaData implements Serializable {
            @Id
            String          id;
            String          appIdentifier;
            int             clientId;
            Date            dateCreated;
            Date            dateModified;
    private String          name;
          transient List            revisions;

            MetaDataStatus  status;
            String          transactionId;
            String          version;

    public MetaData(){
        dateCreated = new Date();
        dateModified = new Date();
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getAppIdentifier() {
        return appIdentifier;
    }
    public void setAppIdentifier(String appIdentifier) {
        this.appIdentifier = appIdentifier;
    }
    public int getClientId() {
        return clientId;
    }
    public void setClientId(int clientId) {
        this.clientId = clientId;
    }
    public Date getDateCreated() {
        return dateCreated;
    }
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }
    public Date getDateModified() {
        return dateModified;
    }
    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public List getRevisions() {
        return revisions;
    }
    public void setRevisions(List revisions) {
        this.revisions = revisions;
    }
    public MetaDataStatus getStatus() {
        return status;
    }
    @JsonIgnore
    public void setStatus(MetaDataStatus status) {
        this.status = status;
    }
    @JsonProperty("status")
    public void setStatus(String status){
        this.status = MetaDataStatus.valueOf(status);
    }
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public String getVersion() {
        return version;
    }
    public void setVersion(String version) throws NumberFormatException {
        String versionString = version.isEmpty() ? "1" : version;

        if(Integer.parseInt(versionString) > 0) {
            this.version = versionString;
        }
    }

    public void incrementVersion() throws NumberFormatException {
        int versionInteger = Integer.parseInt(version);
        versionInteger++;
        version = Integer.toString(versionInteger);
    }
}
