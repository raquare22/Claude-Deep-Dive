package com.optum.fds.paperless.oauth;

import java.io.Serializable;
import java.time.Instant;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;


public class OauthToken implements Serializable {
    private static final long MILLISECOND_CONVERSION_MULTIPLIER = 1000;
    private static final long serialVersionUID = 1L;
    private static final long TOKEN_EXPIRY_LATENT_TIME = 600000;
    
    @JsonProperty("access_token")
    private String accessToken;
    @JsonProperty("token_type")
    private String tokenType;
    @JsonProperty("expires_in")
    private Integer expiresIn;
    @JsonProperty("expiry_time")
    private Long expiryTime;
    @JsonProperty("refresh_token")
    private String refreshToken;
    private Date obtainedOn;
    @JsonProperty("app_secret")
    private String appSecret;
    @JsonProperty("app_id")
    private String appId;
    private String url;
    @JsonProperty("grant_type")
    private String grantType;
    private String scope;
    
    
    public OauthToken(String appId, String appSecret) {
        this.appId = appId;
        this.appSecret = appSecret;
    }

    public OauthToken(String appId, String appSecret, String url, String grantType, String scope) {
    	this.appId = appId;
    	this.appSecret = appSecret;
    	this.url = url;
    	this.grantType = grantType;
        this.scope = scope;
    }
    
    public OauthToken(OauthToken oauthTokenExtended) {
        this(oauthTokenExtended.appId, oauthTokenExtended.appSecret);
        this.url = oauthTokenExtended.url;
        this.grantType = oauthTokenExtended.grantType;
    }

    public OauthToken(String token, Integer expiresIn) {
        // Create OauthToken with accessToken and set expiryTime to be current time + expiresIn
        this.accessToken = token;
        this.expiresIn = expiresIn;
        this.expiryTime = Instant.now().plusSeconds(expiresIn.longValue()).toEpochMilli();
    }

    public String getScope() {
        return scope;
    }
    public void setScope(String scope) {
        this.scope = scope;
    }
    public String getAccessToken() {
        return accessToken;
    }
    
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
    
    public String getTokenType() {
        return tokenType;
    }
    
    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }
    
    public Integer getExpiresIn() {
        return expiresIn;
    }
    
    public void setExpiresIn(Integer expiresIn) {
        this.expiresIn = expiresIn;
    }
    
    public String getRefreshToken() {
        return refreshToken;
    }
    
    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }
    
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getGrantType() {
		return grantType;
	}
	
	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}
	
    public Date getObtainedOn() {
		return (Date) obtainedOn.clone();
	}

	public void setObtainedOn(Date obtainedOn) {
		this.obtainedOn = (obtainedOn != null)?(Date) obtainedOn.clone(): null;
	}
	
    public String getAppSecret() {
		return appSecret;
	}
    
    public void setAppSecret(String appSecret) {
    	this.appSecret = appSecret;
    }
    
    public String getAppId() {
    	return appId;
    }
    
    public void setAppId(String appId) {
    	this.appId = appId;
    }
    
	public boolean isTokenGoingToExpire() {
        // We will get a new token 5 minutes before the actual expiry
        Date now = new Date();
        if (obtainedOn == null) return true;
        return now.getTime() > (expiresIn * MILLISECOND_CONVERSION_MULTIPLIER + obtainedOn.getTime() - TOKEN_EXPIRY_LATENT_TIME);
    }

    public void setExpiryTime(Long expiryTime) {
    	this.expiryTime = expiryTime;
    }

    public Long getExpiryTime() {
    	return expiryTime;
    }

    public boolean isEmpty() {
        return (this.accessToken == null || this.accessToken.isEmpty());
    }

    @Override
    public String toString() {
        return "OauthToken{" +
                "accessToken='" + accessToken + '\'' +
                ", tokenType='" + tokenType + '\'' +
                ", expiresIn=" + expiresIn +
                ", expiryTime=" + expiryTime +
                ", refreshToken='" + refreshToken + '\'' +
                ", obtainedOn=" + obtainedOn +
                ", appSecret='" + appSecret + '\'' +
                ", appId='" + appId + '\'' +
                ", url='" + url + '\'' +
                ", grantType='" + grantType + '\'' +
                '}';
    }
}
