package com.optum.fds.paperless;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

import com.optum.fds.paperless.service.DocumentsServiceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilestoreApplicationListener implements ApplicationListener<ContextClosedEvent>{
	private static final Logger LOGGER = LoggerFactory.getLogger(FilestoreApplicationListener.class);

	@Override
	public void onApplicationEvent(ContextClosedEvent event) {
		LOGGER.warn("SHUTDOWN: event.getSource={}; Calling DocumentsServiceImpl.shutdown", event.getSource());
		DocumentsServiceImpl.shutdown();
		FilestoreApplication.shutdown();
		LOGGER.warn("SHUTDOWN: complete");
	}
}
