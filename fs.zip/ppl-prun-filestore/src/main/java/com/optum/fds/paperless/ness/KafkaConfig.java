package com.optum.fds.paperless.ness;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class KafkaConfig {
	
	
    public static String appAskid;

    
    public static String appname;

   
    public  static String devicevendor;

   
    public  static String deviceproduct;

    
    public static String tag;
    
  
    public static String brokerlist;

   
    public static  String kafkatopic;

    
    public static String kafkaKeypass;

    
    public static  String kafkaKeystorepass;

   
    public static  String kafkaclientId;

    
    public static String Kafkaprotocol;
    
   
    public static String kafkaKeyStorepath;
    
    public static boolean enableNess;

	
    
	@Value("${appAskId}")
	public void setAppAskId(String appAskId) {
		appAskid = appAskId;
	}

	

	@Value("${appName}")
	public void setAppName(String appName) {
		appname = appName;
	}

	

	@Value("${deviceVendor}")
	public void setDeviceVendor(String deviceVendor) {
		devicevendor = deviceVendor;
	}
   
	

	@Value("${deviceProduct}")
	public void setDeviceProduct(String deviceProduct) {
		deviceproduct = deviceProduct;
	}

	

	@Value("${tags}")
	public void setTags(String tags) {
		tag = tags;
	}


	@Value("${brokerList}")
	public void setBrokerList(String brokerList) {
		brokerlist = brokerList;
	}

	
	@Value("${kafkaTopic}")
	public void setKafkaTopic(String kafkaTopic) {
		kafkatopic = kafkaTopic;
	}

	
	@Value("${kafkaKeyPass}")
	public void setKafkaKeyPass(String kafkaKeyPass) {
		kafkaKeypass = kafkaKeyPass;
	}

	
	@Value("${kafkaKeystorePass}")
	public void setKafkaKeystorePass(String kafkaKeystorePass) {
		kafkaKeystorepass = kafkaKeystorePass;
	}
	

	@Value("${kafkaClientId}")
	public void setKafkaClientId(String kafkaClientId) {
		kafkaclientId = kafkaClientId;
	}
	

	@Value("${KafkaProtocol}")
	public void setKafkaProtocol(String kafkaProtocol) {
		Kafkaprotocol = kafkaProtocol;
	}
	

	@Value("${kafkaKeyStorePath}")
	public void setKafkaKeyStorePath(String kafkaKeyStorePath) {
		kafkaKeyStorepath = kafkaKeyStorePath;
	}
	

	@Value("${enableNESS}")
	public void setEnableNess(boolean enableness)
	{
		enableNess = enableness; 
	}
    
}
