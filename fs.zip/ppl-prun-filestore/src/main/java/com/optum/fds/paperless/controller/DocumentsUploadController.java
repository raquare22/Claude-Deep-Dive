package com.optum.fds.paperless.controller;

import com.optum.fds.paperless.model.Doc360Response;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;

import java.time.Duration;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.model.FDSCloudDocument;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.service.DocumentsServiceImpl;


@RestController
@RequestMapping("/api/services/v1")
public class DocumentsUploadController {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentsUploadController.class);
	

    private final Bucket postRequestBucket;
	private final Bucket doc360PostRequestBucket;

	@Autowired
	public DocumentsUploadController(@Value("${fdsPostRateLimit:10}") long postRateLimit, @Value("${doc360PostRateLimit:120}") long doc360PostRateLimit) {
		Bandwidth postLimit = Bandwidth.classic(postRateLimit, Refill.greedy(postRateLimit, Duration.ofMinutes(1)));
	    this.postRequestBucket = Bucket.builder()
	             .addLimit(postLimit)
	             .build();
        this.doc360PostRequestBucket = Bucket.builder()
                .addLimit(Bandwidth.classic(doc360PostRateLimit, Refill.greedy(doc360PostRateLimit, Duration.ofMinutes(1))))
                .build();
	}

	@Autowired
	private DocumentsServiceImpl documentsService;
	
	@Autowired
	private ConfigData config;

	String serviceCallError="Error during service call";
	String invalidReq="Invalid request";
	String emptyRequest="Null or empty request body";

	
	@PostMapping(value="/fds/documents/{spaceId}", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	public ResponseEntity<GenericResponse> postDocumentWithAttachment(@RequestPart("documents") String document, @RequestPart("searchTerms") String searchTerms, @RequestPart("filePath") String filePath, @PathVariable String spaceId, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) {
		// pass filepath to /ingest instead of file
	 if(postRequestBucket.tryConsume(1)) {
		   LOGGER.info("postDocumentWithAttachment -- request payload: {}, searchTerms={}, filePath={}, CID={}",
			 Encode.forJava(document), Encode.forJava(searchTerms), Encode.forJava(filePath), Encode.forJava(optumCidExt));
		
		ResponseEntity<FDSCloudDocument> response = null;
		
		if (isNullOrEmpty(document)) {
			LOGGER.error("postDocumentWithAttachment -- Unable to process request: Null or empty document, HTTPStatus={}, searchTerms={}, CID={}", HttpStatus.BAD_REQUEST,
					Encode.forJava(searchTerms), Encode.forJava(optumCidExt));
			return new ResponseEntity<>(new GenericResponse("400", invalidReq, emptyRequest), HttpStatus.BAD_REQUEST);
		}
		
		if (isNullOrEmpty(searchTerms)) {
			LOGGER.error("postDocumentWithAttachment -- Unable to process request: Null or empty searchTerms, HTTPStatus={}, searchTerms={}, CID={}", HttpStatus.BAD_REQUEST,
					Encode.forJava(searchTerms), Encode.forJava(optumCidExt));
			return new ResponseEntity<>(new GenericResponse("400", invalidReq, emptyRequest), HttpStatus.BAD_REQUEST);
		}
		
		if (isNullOrEmpty(filePath)) {
			LOGGER.error("postDocumentWithAttachment -- Unable to process request: Null or empty filepath, HTTPStatus={}, searchTerms={}, CID={}", HttpStatus.BAD_REQUEST,
					Encode.forJava(searchTerms), Encode.forJava(optumCidExt));
			return new ResponseEntity<>(new GenericResponse("400", invalidReq, "Null or empty filepath"), HttpStatus.BAD_REQUEST);
		}
		
		try {
			response = documentsService.postDocumentToFDSCloudWithAttachmentRetry(document, searchTerms, filePath, spaceId, optumCidExt);
		} catch (Exception e) {
			LOGGER.error("Error executing POST request, HTTPStatus={}, apiPath=/documents/{}, filePath={}, error={}, CID={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(String.valueOf((spaceId))), Encode.forJava(filePath), ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt));
			return new ResponseEntity<>(new GenericResponse("500", serviceCallError, "filePath=" + filePath + "; " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if (response == null || response.getBody() == null) {
			LOGGER.error("Error executing POST request: FDS response returned null, filePath={}, CID={}", Encode.forJava(filePath), Encode.forJava(optumCidExt));
			return new ResponseEntity<>(new GenericResponse("500", serviceCallError, "FDS response returned null: filePath=" + filePath), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		int statusCode = response.getStatusCode().value();

		 LOGGER.info("postDocumentWithAttachment request complete: filePath={}, statusCode={}, CID={}", Encode.forJava(filePath), Encode.forJava(response.getStatusCode().toString()), Encode.forJava(optumCidExt));
		 return new ResponseEntity<GenericResponse>(new GenericResponse(Integer.toString(statusCode), response.getStatusCode().toString(), response.getBody()), HttpStatus.valueOf(statusCode));
	 } else {
		 LOGGER.info("Too many requests made. Wait for 1 minute and try again.");
         return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
	 }
   }

    @PostMapping(value="/doc360/documents/{spaceId}", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public ResponseEntity<GenericResponse> postDocumentDoc360WithAttachment(@RequestPart("documents") String document, @RequestPart("docClass") String docClass, @RequestPart("filePath") String filePath, @PathVariable String spaceId, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) {
        // pass filepath to /ingest instead of file
        if(doc360PostRequestBucket.tryConsume(1)) {
            LOGGER.info("postDocumentDoc360WithAttachment -- request payload: {}, filePath={}, CID={}",
                    Encode.forJava(document), Encode.forJava(filePath), Encode.forJava(optumCidExt));

            ResponseEntity<Doc360Response> response = null;

            if (isNullOrEmpty(document)) {
                LOGGER.error("postDocumentDoc360WithAttachment -- Unable to process request: Null or empty document, HTTPStatus={}, CID={}",
                        HttpStatus.BAD_REQUEST, Encode.forJava(optumCidExt));
                return new ResponseEntity<>(new GenericResponse("400", invalidReq, emptyRequest), HttpStatus.BAD_REQUEST);
            }

            if (isNullOrEmpty(filePath)) {
                LOGGER.error("postDocumentDoc360WithAttachment -- Unable to process request: Null or empty filepath, HTTPStatus={}, CID={}",
                        HttpStatus.BAD_REQUEST, Encode.forJava(optumCidExt));
                return new ResponseEntity<>(new GenericResponse("400", invalidReq, "Null or empty filepath"), HttpStatus.BAD_REQUEST);
            }

            if (isNullOrEmpty(docClass)) {
                LOGGER.error("postDocumentDoc360WithAttachment -- Unable to process request: Null or empty docClass, HTTPStatus={}, CID={}",
                        HttpStatus.BAD_REQUEST, Encode.forJava(optumCidExt));
                return new ResponseEntity<>(new GenericResponse("400", invalidReq, "Null or empty docClass"), HttpStatus.BAD_REQUEST);
            }

            try {
                response = documentsService.postDocumentToDoc360WithAttachmentRetry(document, filePath, docClass, optumCidExt);
            } catch (Exception e) {
                LOGGER.error("Error executing POST request, HTTPStatus={}, apiPath=/documents/{}, filePath={}, error={}, CID={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(String.valueOf((spaceId))), Encode.forJava(filePath), ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt));
                return new ResponseEntity<>(new GenericResponse("500", serviceCallError, "filePath=" + filePath + "; " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
            }

            if (response == null || response.getBody() == null) {
                LOGGER.error("Error executing POST request: Doc360 response returned null, filePath={}, CID={}", Encode.forJava(filePath), Encode.forJava(optumCidExt));
                return new ResponseEntity<>(new GenericResponse("500", serviceCallError, "FDS response returned null: filePath=" + filePath), HttpStatus.INTERNAL_SERVER_ERROR);
            }

            int statusCode = response.getStatusCode().value();

            LOGGER.info("postDocumentDoc360WithAttachment request complete: filePath={}, statusCode={}, CID={}", Encode.forJava(filePath), Encode.forJava(response.getStatusCode().toString()), Encode.forJava(optumCidExt));
            return new ResponseEntity<GenericResponse>(new GenericResponse(Integer.toString(statusCode), response.getStatusCode().toString(), response.getBody()), HttpStatus.valueOf(statusCode));
        } else {
            LOGGER.info("postDocumentDoc360WithAttachment: Too many requests made. Wait for 1 minute and try again.");
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }

    private boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }
	
}