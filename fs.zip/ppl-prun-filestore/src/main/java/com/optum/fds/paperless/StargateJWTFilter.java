package com.optum.fds.paperless;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class StargateJWTFilter implements Filter {

    private static final Logger logger = LogManager.getLogger(StargateJWTFilter.class);
    private final StargateJWTValidator jwtValidator;

    @Value("${STARGATE_FILTER_ENABLED:true}")
    private boolean isFilterEnabled;

    public StargateJWTFilter(StargateJWTValidator jwtValidator) {
        this.jwtValidator = jwtValidator;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
        FilterChain chain) throws IOException, ServletException {
        if (!isFilterEnabled) {
            logger.info("@StargateJWTFilter - Filter is disabled via ConfigMap, skipping JWT validation.");
            chain.doFilter(request, response);
            return;
        }

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String requestURI = httpRequest.getRequestURI();

        if (requestURI.contains("/api/loggers/v1/")) {
            logger.info("@StargateJWTFilter - Skipping JWT validation for Loggers URIs");
            chain.doFilter(request, response);
            return;
        }
        
        logger.info("@StargateJWTFilter - Stargate JWT Validation is enabled and will be performed for the requested URI");
        
        String jwtToken = httpRequest.getHeader("JWT");
        if (jwtToken == null || jwtToken.isEmpty()) {
            logger.error("@StargateJWTFilter - JWT missing in request header.");
            httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "JWT missing in request header.");
            return;
        }

        try {
            jwtValidator.validateJWT(jwtToken);
            chain.doFilter(request, response);
        } catch (IllegalArgumentException e) {
            logger.error("@StargateJWTFilter Class - Invalid JWT: {}", e.getMessage());
            httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid JWT: " + e.getMessage());
        } catch (Exception e) {
            logger.error("@StargateJWTFilter Class - Error validating JWT: {}", e.getMessage());
            httpResponse.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal server error during JWT validation.");
        }
    }
}