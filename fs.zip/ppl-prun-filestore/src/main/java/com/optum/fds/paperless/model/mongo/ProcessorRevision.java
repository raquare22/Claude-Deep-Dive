package com.optum.fds.paperless.model.mongo;


import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class ProcessorRevision extends Revision implements Serializable{
    private static final long serialVersionUID = 1L;

    private int configSpaceId;
    private Date endDate;
    private transient Map<String,Object> process;
    private Date startDate;
    transient List<String>  errors;

    public int getConfigSpaceId() {
        return configSpaceId;
    }

    public void setConfigSpaceId(Integer configSpaceId) {
        if (configSpaceId != null) {
            this.configSpaceId = configSpaceId;
        }
    }

    public Date getEndDate() {
    	return endDate==null?null:(Date)endDate.clone();
    }

    public void setEndDate(Date endDate) {
    	this.endDate = endDate==null?null:(Date)endDate.clone();
    }

    public Map<String, Object> getProcess() {
		return process;
	}

	public void setProcess(Map<String, Object> process) {
		this.process = process;
	}

	public Date getStartDate() {
		return startDate==null?null:(Date)startDate.clone();
    }

    public void setStartDate(Date startDate) {
    	this.startDate = startDate==null?null:(Date)startDate.clone();
    }

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

    
}
