package com.optum.fds.paperless.service;

import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.optum.fds.paperless.model.Doc360Response;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.model.FDSCloudDocument;
import com.optum.fds.paperless.oauth.OauthUtil;
import com.optum.fds.paperless.util.RestTemplateChunkClient;
import com.optum.fds.paperless.util.RestTemplateClient;
import com.optum.fds.paperless.util.WebClientSync;

@Service("fdsDocumentsService")
public class DocumentsServiceImpl implements DocumentsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(DocumentsServiceImpl.class);

	@Autowired
	private OauthUtil oauthUtil;
	
	@Autowired
	private ConfigData config;

	@Autowired
	private RestTemplateClient restTemplateClient;

	@Autowired
	private RestTemplateChunkClient restTemplateChunkClient;

	@Autowired
	private WebClientSync webClientSync;
	
	@Value("${FDSDocumentsUrl}")
	protected String fdsDocumentsUrl;

    @Value("${Doc360DocumentsUrl}")
    protected String doc360DocumentsUrl;

	@Value("${FileStoreMinSizeToChunk:6000000}")
	protected int fileStoreMinSizeToChunk;
	
	@Value("${FileStoreUseWebClient:true}")
	protected boolean fileStoreUseWebClient;

	protected static final String GRANT_TYPE = "client_credentials";
	protected static int totalCnt = 0;
	protected static int totalChunkCnt = 0;
	protected static long largestChunkSize = 0L;
	private static AtomicInteger totalOutstandingRequests = new AtomicInteger(0);

	protected static boolean shutdown = false;
	private static final String SHUTTING_DOWN = "Filestore is shutting down";
	// Allow 5 seconds in shutdown for processing to finish
	private static Long maxShutdownLoop = 100L;

	public static synchronized void shutdown() {
		LOGGER.warn("SHUTDOWN: shutdown={}, maxShutdownLoop={}", shutdown, maxShutdownLoop);
		if (shutdown) {
			LOGGER.warn("SHUTDOWN: COMPLETE; Already performed; shutdown={},", shutdown);
			return;
		}

		try {
			shutdown = true;
			long i = 0;
			int totalOutstandingRequestsInt = totalOutstandingRequests.get();
			while (totalOutstandingRequestsInt > 0 && ++i <= maxShutdownLoop) {
				sleep(50, "SHUTDOWN: sleeping; totalOutstandingRequests=" + totalOutstandingRequestsInt);
				totalOutstandingRequestsInt = totalOutstandingRequests.get();
			}
			LOGGER.warn("SHUTDOWN: COMPLETE; shutdown={}", shutdown);
			logStats();
			WebClientSync.logStats();
		} catch (Exception e) {
			LOGGER.error("SHUTDOWN: {}", ExceptionUtils.getStackTrace(e));
		}
	}
	
	
	@Override
	public ResponseEntity<FDSCloudDocument> postDocumentToFDSCloudWithAttachmentRetry(String document, String searchTerms, String filePath, String spaceId, String cid) {
		ResponseEntity<FDSCloudDocument> response = null;
		
		try {
			String fdsCloudSpaceId = (String) config.getCredentials(spaceId).get("fdsCloudSpaceId");

			Path path = Paths.get(filePath);
			Map<String, String> pathParams = new HashMap<>();
			pathParams.put("spaceId", fdsCloudSpaceId);
			
			URI uri = UriComponentsBuilder.fromUriString(fdsDocumentsUrl).buildAndExpand(pathParams).toUri();
			
			totalStats();
			var length = path.toFile().length();
			if (length >= fileStoreMinSizeToChunk) {
				chunkStats(filePath, length, cid);
			}
			
			LOGGER.info("PRE: fdsCloud file={}, length={}, CID={}, totalOutstandingRequests={}", Encode.forJava(filePath),Encode.forJava(String.valueOf(length)), Encode.forJava(cid), Encode.forJava(String.valueOf(totalOutstandingRequests)));
			
			if (fileStoreUseWebClient) {
				response = webClientSync.sendMultiPartDataWithRetry(fdsDocumentsUrl, uri, path.toFile(), document, searchTerms);
			}
			
			LOGGER.info("POST: fdsCloud file={}, length={}, CID={}, totalCnt={}, totalChunkCnt={}, largestChunkSize={}",
					Encode.forJava(filePath), Encode.forJava(String.valueOf(length)), Encode.forJava(cid), Encode.forJava(String.valueOf(totalCnt)), Encode.forJava(String.valueOf(totalChunkCnt)), Encode.forJava(String.valueOf(largestChunkSize)));

			
		} catch (Exception e) {
			LOGGER.error("POST: CID={}, filePath={}; {}: {}",Encode.forJava(cid), Encode.forJava(String.valueOf(filePath)), Encode.forJava(e.getClass().getSimpleName()), ExceptionUtils.getStackTrace(e));
			totalOutstandingRequests.decrementAndGet();
		}
		
		totalOutstandingRequests.decrementAndGet();
		return response;
	}

    @Override
    public ResponseEntity<Doc360Response> postDocumentToDoc360WithAttachmentRetry(String document, String filePath, String doc360DocClass, String cid) {
        ResponseEntity<Doc360Response> response = null;

        try {
            Path path = Paths.get(filePath);
            URI uri = UriComponentsBuilder.fromUriString(doc360DocumentsUrl)
                    .queryParam("document-type", doc360DocClass)
                    .build()
                    .toUri();
            totalStats();
            var length = path.toFile().length();
            if (length >= fileStoreMinSizeToChunk) {
                chunkStats(filePath, length, cid);
            }

            LOGGER.info("PRE: Doc360 file={}, length={}, CID={}, totalOutstandingRequests={}", Encode.forJava(filePath),Encode.forJava(String.valueOf(length)), Encode.forJava(cid), Encode.forJava(String.valueOf(totalOutstandingRequests)));

            if (fileStoreUseWebClient) {
                response = webClientSync.sendMultiPartDataWithRetryForDoc360(doc360DocumentsUrl, uri, path.toFile(), document);
            }

            LOGGER.info("POST: Doc360 file={}, length={}, CID={}, totalCnt={}, totalChunkCnt={}, largestChunkSize={}",
                    Encode.forJava(filePath), Encode.forJava(String.valueOf(length)), Encode.forJava(cid), Encode.forJava(String.valueOf(totalCnt)), Encode.forJava(String.valueOf(totalChunkCnt)), Encode.forJava(String.valueOf(largestChunkSize)));


        } catch (Exception e) {
            LOGGER.error("POST Doc360: CID={}, filePath={}; {}: {}",Encode.forJava(cid), Encode.forJava(String.valueOf(filePath)), Encode.forJava(e.getClass().getSimpleName()), ExceptionUtils.getStackTrace(e));
            totalOutstandingRequests.decrementAndGet();
        }

        totalOutstandingRequests.decrementAndGet();
        return response;
    }

    protected static void sleep(long milliseconds, String description) {
		try {
			LOGGER.warn("sleeping {} ms: {}", milliseconds, description);
			TimeUnit.MILLISECONDS.sleep(milliseconds);
		} catch (InterruptedException e) {
			LOGGER.error("SLEEP: INTERRUPT; threadId={}", Thread.currentThread().getId());
			Thread.currentThread().interrupt();
		}
	}

	protected static void totalStats() {
		++totalCnt;
		totalOutstandingRequests.incrementAndGet();
	}

	protected static void chunkStats(String filePath, long length, String cid) {
		// fileStoreUseWebClient: These stats only reflect files >= fileStoreMinSizeToChunk
		++totalChunkCnt;
		if (length > largestChunkSize) {
			LOGGER.warn("STATS: largestChunkSize change; length={}, prevLargestChunkSize={}, filePath={}, CID={}", Encode.forJava(String.valueOf(length)), Encode.forJava(String.valueOf(largestChunkSize)), Encode.forJava(String.valueOf(filePath)), Encode.forJava(cid));
			largestChunkSize = length;
		}
	}

	protected static void logStats() {
		LOGGER.warn("STATS: totalCnt={}, totalChunkCnt={}, largestChunkSize={}, totalOutstandingRequests={}", totalCnt, totalChunkCnt, largestChunkSize, totalOutstandingRequests.get());
	}

	public boolean validateResponseStatusCode(int statusCode) {
		return statusCode == 500 || statusCode == 502 || statusCode == 503 || statusCode == 504;
	}
}
