package com.optum.fds.paperless;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.optum.fds.paperless.ness.FilestoreNessConfig;
import com.optum.fds.paperless.ness.KafkaConfig;

@EnableAutoConfiguration
@SpringBootApplication
public class FilestoreApplication {
	
	private static final Logger LOGGER = LogManager.getLogger(FilestoreApplication.class);

	protected static boolean shutdown = false;

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(FilestoreApplication.class);
		application.addListeners(new FilestoreApplicationListener());
		application.run(args);
		if(KafkaConfig.enableNess) {
		  FilestoreNessConfig.startup();
		}
		
	}
	
	  public static synchronized void shutdown() {
		  if(KafkaConfig.enableNess) {
			LOGGER.warn("SHUTDOWN: shutdown={}", shutdown);
			if (shutdown) {
				LOGGER.warn("SHUTDOWN: COMPLETE; Already performeds");
				return;
			}

			shutdown = true;
			FilestoreNessConfig.shutdown();
		 }
	  }
}