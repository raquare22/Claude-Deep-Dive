package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class ProcessorTransactionCoreTest {

    private ProcessorTransactionCore processorTransactionCore;
    private ProcessorSummary mockSummary;
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorTransactionCore.class);

    @Before
    public void setUp() {
        processorTransactionCore = new ProcessorTransactionCore();
        mockSummary = mock(ProcessorSummary.class);
        processorTransactionCore.setSummary(mockSummary);
    }


    @Test
    public void testSetCompleteStatusWithoutErrors() {
        when(mockSummary.getErrorList()).thenReturn(new ArrayList<>());
        MetaDataStatus status = processorTransactionCore.setCompleteStatus();
        assertEquals(MetaDataStatus.COMPLETE, status);
        assertEquals(MetaDataStatus.COMPLETE, processorTransactionCore.getStatus());
    }

}