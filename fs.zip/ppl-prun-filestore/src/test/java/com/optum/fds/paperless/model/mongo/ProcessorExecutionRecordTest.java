package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProcessorExecutionRecordTest {

    private ProcessorExecutionRecord processorExecutionRecord;

    @Before
    public void setUp() {
        processorExecutionRecord = new ProcessorExecutionRecord();
    }

    @Test
    public void testGetSetDescription() {
        String description = "Test description";
        processorExecutionRecord.setDescription(description);
        assertEquals(description, processorExecutionRecord.getDescription());
    }
}