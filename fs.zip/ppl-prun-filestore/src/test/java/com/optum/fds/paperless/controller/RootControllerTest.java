package com.optum.fds.paperless.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

public class RootControllerTest {

    private RootController rootController;

    @Before
    public void setUp() {
        rootController = new RootController();
    }

    @Test
    public void testHealthCheck() {
        String response = rootController.healthCheck();
        assertEquals("ppl prun filestore is up and running", response);
    }
}