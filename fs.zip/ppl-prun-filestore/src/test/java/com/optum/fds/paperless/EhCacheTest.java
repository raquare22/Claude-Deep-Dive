package com.optum.fds.paperless;

import com.optum.fds.paperless.oauth.OauthToken;
import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class EhCacheTest {

    private EhCache ehCache;
    private CacheManager cacheManagerMock;
    private Cache<String, OauthToken> oauthTokenCacheMock;

    @Before
    public void setUp() {
        cacheManagerMock = mock(CacheManager.class);
        oauthTokenCacheMock = mock(Cache.class);

        ehCache = new EhCache() {
            {
                this.cacheManager = cacheManagerMock;
            }
            @Override
            public Cache<String, OauthToken> getOauthTokenCacheFromCacheManager() {
                return oauthTokenCacheMock;
            }
        };
    }


    @Test
    public void testGetOauthTokenCache_ValuePresent() {
        when(oauthTokenCacheMock.containsKey("TOKEN123")).thenReturn(true);
        when(oauthTokenCacheMock.get("TOKEN123")).thenReturn(getOauthToken());
        String result = ehCache.getOauthTokenCache("TOKEN123");
        assertEquals("OAUTH_VALUE", result);
    }

    @Test
    public void testGetOauthTokenCache_ValueAbsent() {
        when(oauthTokenCacheMock.containsKey("TOKEN123")).thenReturn(false);
        String result = ehCache.getOauthTokenCache("TOKEN123");
        assertNull(result);
    }

    @Test
    public void testPutOauthTokenWithExpiry_Valid() {
        ehCache.putOauthTokenWithExpiry("TOKEN123", "OAUTH_VALUE", 2);
        verify(oauthTokenCacheMock, times(1)).put(anyString(), any());
    }

    @Test
    public void testPutOauthTokenWithExpiry_EmptyValue() {
        ehCache.putOauthTokenWithExpiry("TOKEN123", "", 2);
        verify(oauthTokenCacheMock, never()).put(anyString(), any());
    }

    private OauthToken getOauthToken() {
        return new OauthToken("OAUTH_VALUE", 3540);
    }

}

