package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class ProcessorSummaryCoreTest {

    private ProcessorSummaryCore processorSummaryCore;

    @Before
    public void setUp() {
        processorSummaryCore = new ProcessorSummaryCore();
    }

    @Test
    public void testGetSetRunTime() {
        Long runTime = 100L;
        processorSummaryCore.setRunTime(runTime);
        assertEquals(runTime, processorSummaryCore.getRunTime());
    }

    @Test
    public void testGetSetStartTime() {
        Date startTime = new Date();
        processorSummaryCore.setStartTime(startTime);
        assertEquals(startTime, processorSummaryCore.getStartTime());
    }

    @Test
    public void testGetSetEndTime() {
        Date endTime = new Date();
        processorSummaryCore.setEndTime(endTime);
        assertEquals(endTime, processorSummaryCore.getEndTime());
    }

    @Test
    public void testGetSetErrorList() {
        List<ProcessorError> errorList = new ArrayList<>();
        errorList.add(new ProcessorError());
        processorSummaryCore.setErrorList(errorList);
        assertEquals(errorList, processorSummaryCore.getErrorList());
    }

    @Test
    public void testAddError() {
        ProcessorError error = new ProcessorError();
        processorSummaryCore.addError(error);
        assertNotNull(processorSummaryCore.getErrorList());
        assertEquals(1, processorSummaryCore.getErrorList().size());
        assertEquals(error, processorSummaryCore.getErrorList().get(0));
    }

    @Test
    public void testGetSummaryForDBWhenSummaryIsNull() {
        ProcessorCore processorCore = new ProcessorCore();
        assertNull(processorCore.getSummaryForDB());
        ProcessorSummary summary = new ProcessorSummary();
        processorCore.setSummary(summary);

        summary.setErrorList(new ArrayList<>());
        processorCore.setSummary(summary);
        assertNotNull(processorCore.getSummaryForDB());
    }
}