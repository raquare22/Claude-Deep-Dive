package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ProcessingMetricsTest {

    private ProcessingMetrics processingMetrics;

    @Before
    public void setUp() {
        processingMetrics = new ProcessingMetrics();
    }

    @Test
    public void testGetSetAverageRunTime() {
        processingMetrics.setAverageRunTime(100L);
        assertEquals(Long.valueOf(100), processingMetrics.getAverageRunTime());
    }

    @Test
    public void testGetSetAverageFileSize() {
        processingMetrics.setAverageFileSize(200L);
        assertEquals(Long.valueOf(200), processingMetrics.getAverageFileSize());
    }

    @Test
    public void testGetSetFileCount() {
        processingMetrics.setFileCount(10);
        assertEquals(Integer.valueOf(10), processingMetrics.getFileCount());
    }
}