package com.optum.fds.paperless.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.multipart.MultipartFile;

import com.optum.fds.paperless.model.mongo.ProcessorTransaction;

public class FilestoreServiceImplTest {

    @InjectMocks
    private FilestoreServiceImpl filestoreService;

    @Mock
    private ProcessorTransactionService processorTransactionService;

    @Mock
    private MultipartFile file;

    @Mock
    private InputStream inputStream;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(filestoreService, "ingestRoot", "/tmp/ingest");
    }

    @Test
    public void testSaveFileToIngest() throws Exception {
        String fileName = "testFile.txt";
        String spaceId = "space123";
        Path tempPath = Paths.get("/tmp/ingest/filestore/space123/20230101123456789UUID");
        File tempFile = new File(tempPath.toString(), fileName);

        tempFile = mock(File.class);
        when(tempFile.exists()).thenReturn(true);
        when(file.getInputStream()).thenReturn(inputStream);
        doNothing().when(file).transferTo(tempFile);

        String location = filestoreService.saveFileToIngest(fileName, file, spaceId, "optumcid");

        assertNotNull(location);
        assertTrue(location.contains("filestore/space123"));
        verify(file).getInputStream();

        when(file.getInputStream()).thenThrow(new IOException("Test exception"));

        location = filestoreService.saveFileToIngest(fileName, file, spaceId, "optumcid");

        assertNull(location);
    }

    @Test
    public void testProcessFileUpload_Success() throws Exception {
        String fileName = "testFile.txt";
        String spaceId = "space123";
        String cid = "optumcid";
        String location = "/path/to/ingest";
        String processorTransactionId = "transaction123";

        when(file.getOriginalFilename()).thenReturn(fileName);
        when(file.getInputStream()).thenReturn(mock(InputStream.class));

        FilestoreServiceImpl spyService = spy(filestoreService);
        doReturn(location).when(spyService).saveFileToIngest(fileName, file, spaceId, cid);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setId(processorTransactionId);
        when(processorTransactionService.createProcessorTransaction(fileName, location, spaceId))
                .thenReturn(processorTransaction);

        // Call the method under test
        String result = spyService.processFileUpload(fileName, file, spaceId, cid);

        // Verify the result
        assertEquals(processorTransactionId, result);

        // Verify interactions
        verify(spyService).saveFileToIngest(fileName, file, spaceId, cid);
        verify(processorTransactionService).createProcessorTransaction(fileName, location, spaceId);
    }

    @Test
    public void testProcessFileUpload_Failure_NullLocation() throws Exception {
        String fileName = "testFile.txt";
        String spaceId = "space123";
        String cid = "optumcid";
        FilestoreServiceImpl spyService = spy(filestoreService);
        doReturn(null).when(spyService).saveFileToIngest(fileName, file, spaceId, cid);
        String result = spyService.processFileUpload(fileName, file, spaceId, cid);
        assertEquals(null, result);
        verify(spyService).saveFileToIngest(fileName, file, spaceId, cid);
        verifyNoInteractions(processorTransactionService);
    }


}