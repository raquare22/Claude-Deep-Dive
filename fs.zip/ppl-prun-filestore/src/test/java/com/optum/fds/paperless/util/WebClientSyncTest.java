package com.optum.fds.paperless.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import com.optum.fds.paperless.model.FDSCloudDocument;
import com.optum.fds.paperless.oauth.OauthUtil;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import java.io.File;
import java.net.URI;
import com.optum.fds.paperless.model.Doc360Response;


public class WebClientSyncTest {

    @InjectMocks
    private WebClientSync webClientSync;

    @Mock
    private WebClient.Builder webClientBuilder;

    @Mock
    private OauthUtil oauthUtil;

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(webClientSync, "fdsOauthUrl", "https://fds.com");
        ReflectionTestUtils.setField(webClientSync, "fdsCloudAppId", "appId");
        ReflectionTestUtils.setField(webClientSync, "fdsCloudAppSecret", "app123");
        ReflectionTestUtils.setField(webClientSync, "doc360OauthUrl", "https://doc360.com");
        ReflectionTestUtils.setField(webClientSync, "doc360AppId", "appId");
        ReflectionTestUtils.setField(webClientSync, "doc360AppSecret", "app123");
        ReflectionTestUtils.setField(webClientSync, "doc360UploadDocumentScope", "scope");
        ReflectionTestUtils.setField(webClientSync, "doc360UpstreamEnv", "dev");
    }

    @Test
    public void testIncrementAndGetTotalHttpFailureCnt() {
        int initialCount = WebClientSync.totalHttpFailureCnt;
        int newCount = WebClientSync.incrementAndGetTotalHttpFailureCnt();
        assertEquals(initialCount + 1, newCount);
    }

    @Test
    public void testIncrementAndGetTotalFailureCnt() {
        int initialCount = WebClientSync.totalFailureCnt;
        int newCount = WebClientSync.incrementAndGetTotalFailureCnt();
        assertEquals(initialCount + 1, newCount);
    }

    @Test
    public void testGetNewWebClient() {
        WebClient webClient = mock(WebClient.class);
        when(webClientBuilder.clientConnector(any())).thenReturn(webClientBuilder);
        when(webClientBuilder.build()).thenReturn(webClient);

        WebClient result = webClientSync.getNewWebClient();
        assertNotNull(result);
        assertEquals(webClient, result);
    }

    @Test
    public void testGetNewWebClientWhenAlreadyInitialized() {
        WebClient webClient = mock(WebClient.class);
        when(webClientBuilder.clientConnector(any())).thenReturn(webClientBuilder);
        when(webClientBuilder.build()).thenReturn(webClient);

        // Initialize the singleton
        webClientSync.getNewWebClient();

        // Reinitialize the singleton
        WebClient newResult = webClientSync.getNewWebClient();
        assertNotNull(newResult);
        assertEquals(webClient, newResult);
    }

    @Test
    public void testLogStats() {
        WebClientSync.logStats();
    }

    @Test
    public void testSendMultiPartDataWithRetry_Success() throws Exception {
        URI uri = new URI("http://example.com");
        File file = new File("test.txt");
        String document = "testDocument";
        String searchTerms = "testSearchTerms";
        String fdsCloudPostDocumentsUrl = "http://example.com";

        WebClient webClient = mock(WebClient.class);
        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(uri)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.MULTIPART_FORM_DATA)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.header(anyString(), anyString())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(BodyInserters.MultipartInserter.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(FDSCloudDocument.class)).thenReturn(Mono.error(new WebClientResponseException(500, "Internal Server Error", null, null, null)));
        when(oauthUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), any(), anyBoolean())).thenReturn("mockToken");

        ResponseEntity<FDSCloudDocument> response = webClientSync.sendMultiPartDataWithRetry(fdsCloudPostDocumentsUrl, uri, file, document, searchTerms);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertTrue(response.getBody() == null);
    }

    @Test
    public void testSendMultiPartDataWithRetryForDoc360_Success() throws Exception {
        URI uri = new URI("http://example.com/doc360/upload?document-type=testDocClass");
        File file = new File("test.txt");
        String document = "{\"testDocument\": \"test\"}";
        String doc360PostDocumentsUrl = "http://example.com/doc360/upload";

        WebClient webClient = mock(WebClient.class);
        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        Doc360Response doc360Response = new Doc360Response();
        doc360Response.setStatus("201");
        ResponseEntity<Doc360Response> okResponse = new ResponseEntity<>(doc360Response, HttpStatus.CREATED);

        when(webClientBuilder.clientConnector(any())).thenReturn(webClientBuilder);
        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(uri)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.MULTIPART_FORM_DATA)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.header(anyString(), anyString())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(BodyInserters.MultipartInserter.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(Doc360Response.class)).thenReturn(Mono.just(okResponse));

        when(oauthUtil.getOauthToken(
                anyString(), anyString(), anyString(), anyString(), anyString(), any(), anyBoolean()))
                .thenReturn("mockToken");

        ResponseEntity<Doc360Response> response =
                webClientSync.sendMultiPartDataWithRetryForDoc360(doc360PostDocumentsUrl, uri, file, document);

        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("201", response.getBody().getStatus());

        verify(requestBodyUriSpec).header("Authorization", "Bearer mockToken");
    }


    @Test
    public void testGetMultiValueMap() {
        File file = new File("test.txt");
        String document = "testDocument";
        String searchTerms = "testSearchTerms";

        MultiValueMap<String, HttpEntity<?>> result = webClientSync.getMultiValueMap(file, document, searchTerms);

        assertNotNull(result);
        assertTrue(result.containsKey("file"));
        assertTrue(result.containsKey("metadata"));
        assertTrue(result.containsKey("searchTerms"));
        assertEquals("testDocument", result.getFirst("metadata").getBody());
        assertEquals("testSearchTerms", result.getFirst("searchTerms").getBody());
    }

    @Test
    public void testGetMultiValueMapNoSearchTerms() {
        File file = new File("test.txt");
        String document = "{\"test\": \"value\"}";
        String searchTerms = "";

        MultiValueMap<String, HttpEntity<?>> result = webClientSync.getMultiValueMap(file, document, searchTerms);

        assertNotNull(result);
        assertTrue(result.containsKey("file"));
        assertTrue(result.containsKey("metadata"));
        assertFalse(result.containsKey("searchTerms"));
        assertEquals("{\"test\": \"value\"}", result.getFirst("metadata").getBody());
    }


}