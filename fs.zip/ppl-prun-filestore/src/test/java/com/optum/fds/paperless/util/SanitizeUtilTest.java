package com.optum.fds.paperless.util;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

public class SanitizeUtilTest {

    @Test
    public void testSanitizeNumericString(){
        String input = "120722";
        String expected = "120722";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeNumericString(input));
    }

    @Test
    public void testSanitizeFilePath() {
        String input = "one%two@three!four$five%six^seven&8:9*10?1113141516my@project:first&test.txt";
        String sanitized = SanitizeUtil.sanitizeFilePath(input);
        Assert.assertEquals("one_two_three_four_five_six_seven_8_9_10_1113141516my_project_first_test.txt", sanitized);

        input = "User/PPl/Documents/Myfile.txt";
        sanitized = SanitizeUtil.sanitizeFilePath(input);
        Assert.assertEquals("User/PPl/Documents/Myfile.txt", sanitized);

        input = null;
        sanitized = SanitizeUtil.sanitizeFilePath(input);
        Assert.assertEquals(null, sanitized);

        input = "";
        sanitized = SanitizeUtil.sanitizeFilePath(input);
        Assert.assertEquals("", sanitized);
    }

    @Test
    public void testSanitizeString() {
        String input = "{\"key\":\"value\"}";
        String expected = "{\"key\":\"value\"}";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeString(input));

        input = "invalid json";
        expected = "Sanitize Failure";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeString(input));
    }


    @Test
    public void testSanitizeToString() {
        String input = "line1\nline2";
        String expected = "line1line2";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeToString(input));
    }

    @Test
    public void testSanitizeIntegerString() {
        String input = "123abc";
        String expected = "123$$$";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeIntegerString(input));
    }

    @Test
    public void testSanitizeAlphaString() {
        String input = "abc123";
        String expected = "abc$$$";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeAlphaString(input));
    }

    @Test
    public void testSanitizeAlphaNumericString() {
        String input = "abc123!@#";
        String expected = "abc123$$$";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeAlphaNumericString(input));
    }

    @Test
    public void testSanitizeAlphaNumericStringWithHyphen() {
        String input = "abc-123!@#";
        String expected = "abc-123$$$";
        Assert.assertEquals(expected, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(input));
    }

    @Test
    public void testSanitizeResponseEntityBody() {
        ResponseEntity<String> responseEntity = new ResponseEntity<>("response body", HttpStatus.OK);
        String sanitizedBody = SanitizeUtil.sanitizeResponseEntityBody(responseEntity);
        Assert.assertEquals("<200 OK OK,response body,[]>", sanitizedBody);

        responseEntity = new ResponseEntity<>((String) null, HttpStatus.OK);
        sanitizedBody = SanitizeUtil.sanitizeResponseEntityBody(responseEntity);
        Assert.assertNull(sanitizedBody);

        sanitizedBody = SanitizeUtil.sanitizeResponseEntityBody(null);
        Assert.assertNull(sanitizedBody);
    }

}