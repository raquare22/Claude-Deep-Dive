package com.optum.fds.paperless.oauth;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class HttpConstantsTest {

    @Test
    public void testConstants() {
        assertEquals(3, HttpConstants.OAUTH_POST_RETRIES_VALUE);
        assertEquals(3000L, HttpConstants.OAUTH_POST_RETRIES_SLEEP_TIME_VALUE);
        assertEquals(3600000, HttpConstants.LONG_FILE_TIMEOUT_SETTING);
        assertEquals(120000, HttpConstants.TIMEOUT_SETTING);
        assertEquals("multipart/form-data", HttpConstants.CONTENT_TYPE_MULTIPART_FORM_DATA);
        assertEquals("UTF-8", HttpConstants.UTF_8);
        assertEquals("X-Transaction-Id", HttpConstants.X_TRANSACTION_ID_HEADER);
        assertEquals("/v2/oauth2/token.json", HttpConstants.PATH);
        assertEquals("Accept", HttpConstants.HEADER_ACCEPT);
        assertEquals("client_id", HttpConstants.FORM_PARAM_CLIENT_ID);
        assertEquals("client_secret", HttpConstants.FORM_PARAM_CLIENT_SECRET);
        assertEquals("grant_type", HttpConstants.FORM_PARAM_GRANT_TYPE);
        assertEquals("scope", HttpConstants.FORM_PARAM_SCOPE);
        assertEquals("authorization_code", HttpConstants.FORM_VALUE_AUTHORIZATION_CODE);
        assertEquals("responseBody", HttpConstants.RESPONSE_BODY);
        assertEquals("statusCode", HttpConstants.STATUS_CODE);
        assertEquals("https", HttpConstants.HTTPS_PROTOCOL);
    }

    @Test
    public void testPrivateConstructor() throws Exception {
        // Use reflection to access the private constructor
        java.lang.reflect.Constructor<HttpConstants> constructor = HttpConstants.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        HttpConstants instance = constructor.newInstance();
        assertNotNull(instance);
    }
}
