package com.optum.fds.paperless.oauth;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class OauthTokenTest {

    private OauthToken oauthToken;
    private Date obtainedOn;

    @Before
    public void setUp() {
        oauthToken = new OauthToken("appId", "appSecret", "http://test.com", "grantType", "scope");
        obtainedOn = new Date();
        oauthToken.setObtainedOn(obtainedOn);
    }

    @Test
    public void testGettersAndSetters() {
        oauthToken.setAccessToken("accessToken");
        oauthToken.setTokenType("tokenType");
        oauthToken.setExpiresIn(3600);
        oauthToken.setRefreshToken("refreshToken");
        oauthToken.setUrl("http://newurl.com");
        oauthToken.setGrantType("newGrantType");
        oauthToken.setScope("scope");

        assertEquals("accessToken", oauthToken.getAccessToken());
        assertEquals("tokenType", oauthToken.getTokenType());
        assertEquals(Integer.valueOf(3600), oauthToken.getExpiresIn());
        assertEquals("refreshToken", oauthToken.getRefreshToken());
        assertEquals("http://newurl.com", oauthToken.getUrl());
        assertEquals("newGrantType", oauthToken.getGrantType());
        assertEquals("scope", oauthToken.getScope());
        assertEquals(obtainedOn, oauthToken.getObtainedOn());
    }

    @Test
    public void testIsTokenGoingToExpire() {
        oauthToken.setExpiresIn(1); // 1 second
        oauthToken.setObtainedOn(new Date(System.currentTimeMillis() - 1000)); // 1 second ago
        assertTrue(oauthToken.isTokenGoingToExpire());

        oauthToken.setExpiresIn(3600); // 1 hour
        oauthToken.setObtainedOn(new Date());
        assertFalse(oauthToken.isTokenGoingToExpire());
    }

    @Test
    public void testConstructor() {
        OauthToken token = new OauthToken("appId", "appSecret");
        assertEquals("appId", token.getAppId());
        assertEquals("appSecret", token.getAppSecret());
    }

    @Test
    public void testCloneConstructor() {
        OauthToken clonedToken = new OauthToken(oauthToken);
        assertEquals(oauthToken.getAppId(), clonedToken.getAppId());
        assertEquals(oauthToken.getAppSecret(), clonedToken.getAppSecret());
        assertEquals(oauthToken.getUrl(), clonedToken.getUrl());
        assertEquals(oauthToken.getGrantType(), clonedToken.getGrantType());
    }

    @Test
    public void testSetAppSecret() {
        OauthToken token = new OauthToken("appId", "appSecret");
        token.setAppSecret("newAppSecret");
        assertEquals("newAppSecret", token.getAppSecret());
    }

    @Test
    public void testSetAppId() {
        OauthToken token = new OauthToken("initialAppId", "appSecret");
        token.setAppId("newAppId");
        assertEquals("newAppId", token.getAppId());
    }
}