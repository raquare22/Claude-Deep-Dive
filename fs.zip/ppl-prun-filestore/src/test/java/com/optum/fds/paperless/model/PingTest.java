package com.optum.fds.paperless.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class PingTest {

    private Ping ping;

    @Before
    public void setUp() {
        ping = new Ping("build123", "2023-10-01T12:00:00Z");
    }

    @Test
    public void testConstructor() {
        assertNotNull(ping);
        assertEquals("build123", ping.getBuildNumber());
        assertEquals("2023-10-01T12:00:00Z", ping.getTimeStamp());
    }

    @Test
    public void testGettersAndSetters() {
        ping.setBuildNumber("build456");
        ping.setTimeStamp("2023-10-02T12:00:00Z");

        assertEquals("build456", ping.getBuildNumber());
        assertEquals("2023-10-02T12:00:00Z", ping.getTimeStamp());
    }

    @Test
    public void testToString() {
        String expectedString = "buildNumber: build123, timeStamp: 2023-10-01T12:00:00Z";
        assertEquals(expectedString, ping.toString());
    }
}