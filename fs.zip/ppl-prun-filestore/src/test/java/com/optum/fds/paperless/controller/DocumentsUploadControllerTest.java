package com.optum.fds.paperless.controller;


import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.exception.HttpServerException;
import io.github.bucket4j.Bucket;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;

import com.optum.fds.paperless.exception.ProcessException;
import com.optum.fds.paperless.model.FDSCloudDocument;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.service.DocumentsServiceImpl;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
import com.optum.fds.paperless.model.Doc360Response;

@RunWith(MockitoJUnitRunner.class)
public class DocumentsUploadControllerTest {

	@InjectMocks
	DocumentsUploadController documentsUploadController = new DocumentsUploadController(10, 10);
	

	@Mock
	private DocumentsServiceImpl fdsDocumentsService;

	@Mock
	private ConfigData configData;

	String invalidReq = "Invalid request";
	String emptyRequest = "Null or empty request body";
	String serviceCallError = "Error during service call";

	@Before
	public void setUp() throws IOException, ProcessException {
		ResponseEntity<FDSCloudDocument> response = new ResponseEntity<>(new FDSCloudDocument(), HttpStatus.OK);
	}

	@UserStory(references = "US32608")
	@RallyTestCase(references = "TC32790")
	@Test
	public void postDocumentWithAttachmentTestEmptyFile() throws Exception {
		String doc = "Test string";
		String spaceId = "1";
		FileInputStream inputFile = new FileInputStream("src/test/resources/test2.txt");
		BufferedReader br = new BufferedReader(new FileReader("src/test/resources/test2.txt"));
		if (br.readLine() != null) {
			MockMultipartFile file = new MockMultipartFile("file", "NameOfTheFile", "multipart/form-data", inputFile);
			ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment(doc, "searchTerms", "src/test/resources/test2.txt", spaceId, "test-optum-cid-ext");
			assertNotNull(response);
		}
	}

	@UserStory(references = "US32608")
	@RallyTestCase(references = "TC32790")
	@Test
	public void postDocumentWithAttachmentTestEmptyDoc() throws Exception {
		String spaceId = "1";
		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment("", "searchTerms", "src/test/resources/test1.txt", spaceId, "test-optum-cid-ext");
		assertNotNull(response);
		assertEquals(400,response.getStatusCode().value());
	}


	@Test
	public void postDocumentWithAttachmentTestEmptySearchTerms() throws Exception {
		String spaceId = "1";
		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment("doc", "", "src/test/resources/test1.txt", spaceId, "test-optum-cid-ext");
		assertNotNull(response);
		assertEquals(400,response.getStatusCode().value());
	}

	@Test
	public void postDocumentWithAttachmentTestEmptyFilePath() throws Exception {
		String spaceId = "1";
		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment("doc", "searchTerms", "", spaceId, "test-optum-cid-ext");
		assertNotNull(response);
		assertEquals(400,response.getStatusCode().value());
	}

	@UserStory(references = "US32608")
	@RallyTestCase(references = "TC32790")
	@Test
	public void postDocumentWithAttachmentTestNullDoc() throws Exception {
		String payload = null;
		String spaceId = "1";
		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment(payload, "searchTerms", "src/test/resources/test1.txt", spaceId, "test-optum-cid-ext");
		assertNotNull(response);
	}


	@Test
	public void postDocumentWithAttachmentTestRateLimitExceeded() throws Exception {
		String document = "Test document";
		String searchTerms = "searchTerms";
		String filePath = "src/test/resources/test1.txt";
		String spaceId = "1";
		String optumCidExt = "test-optum-cid-ext";

		Bucket mockBucket = mock(Bucket.class);
		when(mockBucket.tryConsume(1)).thenReturn(false);

		ReflectionTestUtils.setField(documentsUploadController, "postRequestBucket", mockBucket);

		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment(document, searchTerms, filePath, spaceId, optumCidExt);

		assertNotNull(response);
		assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
	}


	@Test
	public void testPostDocumentWithAttachment_HttpServerException() throws Exception {
		// Arrange
		String document = "Test document";
		String searchTerms = "searchTerms";
		String filePath = "src/test/resources/test1.txt";
		String spaceId = "1";
		String optumCidExt = "test-optum-cid-ext";

		HttpServerException exception = new HttpServerException("500", HttpStatus.INTERNAL_SERVER_ERROR);
		when(fdsDocumentsService.postDocumentToFDSCloudWithAttachmentRetry(document, searchTerms, filePath, spaceId, optumCidExt))
				.thenThrow(exception);

		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment(document, searchTerms, filePath, spaceId, optumCidExt);

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}


	@Test
	public void postDocumentWithAttachmentTest_HttpClientErrorException() throws Exception {
		// Arrange
		String document = "Test document";
		String searchTerms = "searchTerms";
		String filePath = "src/test/resources/test1.txt";
		String spaceId = "1";
		String optumCidExt = "test-optum-cid-ext";

		HttpClientErrorException exception = new HttpClientErrorException(
				HttpStatus.BAD_REQUEST,
				"Bad Request"
		);

		when(fdsDocumentsService.postDocumentToFDSCloudWithAttachmentRetry(document, searchTerms, filePath, spaceId, optumCidExt))
				.thenThrow(exception);

		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment(
				document, searchTerms, filePath, spaceId, optumCidExt
		);

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("500", response.getBody().getStatusCode());
	}


	@Test
	public void postDocumentWithAttachmentTest_GenericException() throws Exception {
		// Arrange
		String document = "Test document";
		String searchTerms = "searchTerms";
		String filePath = "src/test/resources/test1.txt";
		String spaceId = "1";
		String optumCidExt = "test-optum-cid-ext";


		when(fdsDocumentsService.postDocumentToFDSCloudWithAttachmentRetry(document, searchTerms, filePath, spaceId, optumCidExt))
				.thenThrow(new RuntimeException("Internal Server Error"));

		ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentWithAttachment(
				document, searchTerms, filePath, spaceId, optumCidExt
		);

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals("500", response.getBody().getStatusCode());
		assertEquals("Error during service call", response.getBody().getStatusMessage());
	}

    @Test
    public void postDocumentDoc360WithAttachmentTest_Success() throws Exception {
        String document = "Test document";
        String docClass = "TEST_CLASS";
        String filePath = "src/test/resources/test1.txt";
        String spaceId = "1";
        String optumCidExt = "test-optum-cid-ext";

        Doc360Response doc360Response = new Doc360Response();
        doc360Response.setStatus("SUCCESS");
        doc360Response.setGlobalDocId("g-123");

        when(fdsDocumentsService.postDocumentToDoc360WithAttachmentRetry(document, filePath, docClass, optumCidExt))
                .thenReturn(new ResponseEntity<>(doc360Response, HttpStatus.OK));

        ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentDoc360WithAttachment(
                document, docClass, filePath, spaceId, optumCidExt
        );

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals("200 OK", response.getBody().getStatusMessage());
        verify(fdsDocumentsService, times(1))
                .postDocumentToDoc360WithAttachmentRetry(document, filePath, docClass, optumCidExt);
    }

    @Test
    public void postDocumentDoc360WithAttachmentTest_EmptyDocClass() throws Exception {
        String document = "Test document";
        String filePath = "src/test/resources/test1.txt";
        String spaceId = "1";
        String optumCidExt = "test-optum-cid-ext";

        ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentDoc360WithAttachment(
                document, "", filePath, spaceId, optumCidExt
        );

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        verify(fdsDocumentsService, never())
                .postDocumentToDoc360WithAttachmentRetry(anyString(), anyString(), anyString(), anyString());
    }

    @Test
    public void postDocumentDoc360WithAttachmentTest_RateLimitExceeded() throws Exception {
        String document = "Test document";
        String docClass = "TEST_CLASS";
        String filePath = "src/test/resources/test1.txt";
        String spaceId = "1";
        String optumCidExt = "test-optum-cid-ext";

        Bucket mockDoc360Bucket = mock(Bucket.class);
        when(mockDoc360Bucket.tryConsume(1)).thenReturn(false);

        ReflectionTestUtils.setField(documentsUploadController, "doc360PostRequestBucket", mockDoc360Bucket);

        ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentDoc360WithAttachment(
                document, docClass, filePath, spaceId, optumCidExt
        );

        assertNotNull(response);
        assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
        verify(fdsDocumentsService, never())
                .postDocumentToDoc360WithAttachmentRetry(anyString(), anyString(), anyString(), anyString());
    }

    @Test
    public void postDocumentDoc360WithAttachmentTest_ServiceThrowsException() throws Exception {
        String document = "Test document";
        String docClass = "TEST_CLASS";
        String filePath = "src/test/resources/test1.txt";
        String spaceId = "1";
        String optumCidExt = "test-optum-cid-ext";

        when(fdsDocumentsService.postDocumentToDoc360WithAttachmentRetry(document, filePath, docClass, optumCidExt))
                .thenThrow(new RuntimeException("Doc360 call failed"));

        ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentDoc360WithAttachment(
                document, docClass, filePath, spaceId, optumCidExt
        );

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("500", response.getBody().getStatusCode());
        assertEquals("Error during service call", response.getBody().getStatusMessage());
    }

    @Test
    public void postDocumentDoc360WithAttachmentTest_NullServiceBody() throws Exception {
        String document = "Test document";
        String docClass = "TEST_CLASS";
        String filePath = "src/test/resources/test1.txt";
        String spaceId = "1";
        String optumCidExt = "test-optum-cid-ext";

        when(fdsDocumentsService.postDocumentToDoc360WithAttachmentRetry(document, filePath, docClass, optumCidExt))
                .thenReturn(new ResponseEntity<>(new Doc360Response(), HttpStatusCode.valueOf(500)));

        ResponseEntity<GenericResponse> response = documentsUploadController.postDocumentDoc360WithAttachment(
                document, docClass, filePath, spaceId, optumCidExt
        );

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("500", response.getBody().getStatusCode());
    }


}