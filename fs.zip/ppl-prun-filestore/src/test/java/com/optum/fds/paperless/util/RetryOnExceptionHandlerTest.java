package com.optum.fds.paperless.util;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import com.optum.fds.paperless.exception.OutOfRetriesException;
import com.optum.fds.paperless.util.RetryOnExceptionHandler;

public class RetryOnExceptionHandlerTest {

    private RetryOnExceptionHandler retryHandler;

    @Before
    public void setUp() {
        retryHandler = new RetryOnExceptionHandler();
    }

    @Test
    public void testDefaultConstructor() {
        OutOfRetriesException exception = new OutOfRetriesException();
        assertNull(exception.getMessage());
        assertEquals(4, retryHandler.getNumRetries());
        assertEquals(250L, retryHandler.getTimeToWaitMS());
        assertFalse(retryHandler.isRetry());
    }

    @Test
    public void testParameterizedConstructor() {
        retryHandler = new RetryOnExceptionHandler(3, 500L);
        assertEquals(3, retryHandler.getNumRetries());
        assertEquals(500L, retryHandler.getTimeToWaitMS());
        assertFalse(retryHandler.isRetry());
    }


    @Test
    public void testWaitUntilNextTry() {
        long startTime = System.currentTimeMillis();
        retryHandler.waitUntilNextTry();
        long elapsedTime = System.currentTimeMillis() - startTime;
        assertTrue(elapsedTime >= 250L);
    }

    @Test
    public void testExceptionOccurred() {
        retryHandler.setNumRetries(1);
        try {
            retryHandler.exceptionOccurred();
        } catch (OutOfRetriesException e) {
            fail("OutOfRetriesException should not be thrown");
        }
        assertEquals(0, retryHandler.getNumRetries());
        assertTrue(retryHandler.isRetry());
    }

    @Test(expected = OutOfRetriesException.class)
    public void testExceptionOccurred_OutOfRetries() throws OutOfRetriesException {
        retryHandler.setNumRetries(0);
        retryHandler.exceptionOccurred();
    }

    @Test
    public void testSettersAndGetters() {
        retryHandler.setNumRetries(5);
        assertEquals(5, retryHandler.getNumRetries());

        retryHandler.setTimeToWaitMS(1000L);
        assertEquals(1000L, retryHandler.getTimeToWaitMS());

        retryHandler.setRetry(true);
        assertTrue(retryHandler.isRetry());
    }
}
