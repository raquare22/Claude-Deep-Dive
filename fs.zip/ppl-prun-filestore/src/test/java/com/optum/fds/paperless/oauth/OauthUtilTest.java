package com.optum.fds.paperless.oauth;

import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import org.apache.commons.codec.binary.Base64;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class OauthUtilTest {

	@InjectMocks
	static OauthUtil oauth = new OauthUtil();

	@Mock
	RestTemplate restTemplate = new RestTemplate();
	
	@Mock
	private EhCache ehCache;

	Token nullt = null;

	@UserStory(references = "US32608")
	@RallyTestCase(references = "TC32805")
	@Test(expected = Exception.class)
	public void getTokenTestFail() throws InterruptedException {
		Mockito.lenient().when(restTemplate.exchange(
				anyString(),
				eq(HttpMethod.POST),
				ArgumentMatchers.<HttpEntity<?>>any(),
				eq(Token.class))).thenReturn(new ResponseEntity<Token>(nullt, HttpStatus.OK));

		OauthToken response = oauth.refreshToken(new OauthToken("success", "success", "http://test.com", "client_credentials", "scope"));
		assertNull(response);
	}

	@Test
	public void testcreateAuthHeader()
	{
		String userName = "testUserName";
		String password = "testPassword";
		String auth = userName + ":" + password;
		byte[] encodedAuth = Base64.encodeBase64(
				auth.getBytes(StandardCharsets.US_ASCII));
		assertEquals("Basic " + new String( encodedAuth ), OauthUtil.createAuthHeader(userName, password));
	}


	//@Test
	public void testGetOauthToken_FromCache() {
		// Arrange
		String tokenType = "testTokenType";
		String clientId = "testClientId";
		String clientSecret = "testClientSecret";
		String grantType = "client_credentials";
		String oauthUrl = "http://test-url.com";
		String cachedToken = "cachedAccessToken";


		ehCache.putOauthTokenWithExpiry(tokenType, cachedToken, 3600);


		String result = oauth.getOauthToken(tokenType, clientId, clientSecret, grantType, oauthUrl, "scope", false);


		assertNotNull(result);
		assertEquals(cachedToken, result);
	}
	@Test
	public void testGetOauthTokenExtended_Success() throws InterruptedException {

		String appId = "testAppId";
		String appSecret = "testAppSecret";
		String url = "http://test-url.com";
		String grantType = "client_credentials";

		OauthToken mockToken = new OauthToken(appId, appSecret, url, grantType, "scope");
		mockToken.setAccessToken("testAccessToken");
		mockToken.setExpiresIn(3600);

		OauthUtil spyOauthUtil = spy(oauth);
		doReturn(mockToken).when(spyOauthUtil).refreshToken(any(OauthToken.class));


		Optional<OauthToken> result = spyOauthUtil.getOauthTokenExtended(appId, appSecret, url, grantType, "scope");

		
		assertTrue(result.isPresent());
		assertEquals("testAccessToken", result.get().getAccessToken());
	}

	@Test
	public void testGetOauthTokenExtended_Failure() throws InterruptedException {
		// Arrange
		String appId = "testAppId";
		String appSecret = "testAppSecret";
		String url = "http://test-url.com";
		String grantType = "client_credentials";

		OauthUtil spyOauthUtil = spy(oauth);
		doThrow(new InterruptedException("Test Exception")).when(spyOauthUtil).refreshToken(any(OauthToken.class));

		// Act
		Optional<OauthToken> result = spyOauthUtil.getOauthTokenExtended(appId, appSecret, url, grantType, "scope");

		// Assert
		assertFalse(result.isPresent());
	}

}