package com.optum.fds.paperless;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
public class ConfigDataTest {

    @InjectMocks
    private ConfigData configData;

    @Mock
    private ObjectMapper mapper;

    @Before
    public void setUp() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    	MockitoAnnotations.initMocks(this);
    	
        ReflectionTestUtils.setField(configData, "LETGEN_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "UNET_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "NEXTGEN_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "_1CLICK_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "CCSManual_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "UNET_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "COSMOS_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "COSMOS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "UHC_WEST_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "CSP_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "ODAR_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "MR_APPEALS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "ETS_APPEALS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "USP_CLAIMS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "USP_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "CSP_CLAIMS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "NGSClaims_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "OCM_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "IHR_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "CC_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "CAP_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "TEXAS_GOLD_CARD_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "TRACKIT_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "HouseCalls_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "OTHER_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "MemberPayment_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        ReflectionTestUtils.setField(configData, "PECosmos_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
        Method setCredentialsMethod = ConfigData.class.getDeclaredMethod("setCredentials");
        setCredentialsMethod.setAccessible(true);
        setCredentialsMethod.invoke(configData);
    }

//    @Test
//    public void testGetCredentials() throws Exception {
//        invokeSetCredentials();
//        Map<String, Object> credentials = configData.getCredentials("key1");
//        assertNotNull(credentials);
//        assertEquals("value1", credentials.get("key1"));
//    }

    @Test
    public void testGetCredentials() {
        Map<String, Object> credentials = configData.getCredentials("8935");
        assertNotNull(credentials);
        assertEquals("LETGEN", (String) credentials.get("clientName"));
    }


}