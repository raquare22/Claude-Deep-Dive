package com.optum.fds.paperless.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class FDSCloudAttachmentTest {

    private FDSCloudAttachment attachment;

    @Before
    public void setUp() {
        attachment = new FDSCloudAttachment();
    }

    @Test
    public void testGettersAndSetters() {
        String attachmentId = "12345";
        String contentType = "application/pdf";
        String fileName = "testFile.pdf";
        long fileSize = 1024L;
        Date createdOn = new Date();
        Date modifiedOn = new Date();
        String spaceId = "space123";
        String virusScanStatus = "clean";
        String url = "http://example.com/testFile.pdf";
        String cloudStorageProvider = "AWS";

        attachment.setAttachmentId(attachmentId);
        attachment.setContentType(contentType);
        attachment.setFileName(fileName);
        attachment.setFileSize(fileSize);
        attachment.setCreatedOn(createdOn);
        attachment.setModifiedOn(modifiedOn);
        attachment.setSpaceId(spaceId);
        attachment.setVirusScanStatus(virusScanStatus);
        attachment.setUrl(url);
        attachment.setCloudStorageProvider(cloudStorageProvider);

        assertEquals(attachmentId, attachment.getAttachmentId());
        assertEquals(contentType, attachment.getContentType());
        assertEquals(fileName, attachment.getFileName());
        assertEquals(fileSize, attachment.getFileSize());
        assertEquals(createdOn, attachment.getCreatedOn());
        assertEquals(modifiedOn, attachment.getModifiedOn());
        assertEquals(spaceId, attachment.getSpaceId());
        assertEquals(virusScanStatus, attachment.getVirusScanStatus());
        assertEquals(url, attachment.getUrl());
        assertEquals(cloudStorageProvider, attachment.getCloudStorageProvider());
    }

    @Test
    public void testToString() {
        String attachmentId = "12345";
        attachment.setAttachmentId(attachmentId);
        String expectedString = "FDSCloudAttachment = [ " + attachmentId + " ]";
        assertEquals(expectedString, attachment.toString());
    }
}
