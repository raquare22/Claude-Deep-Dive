package com.optum.fds.paperless.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import com.optum.fds.paperless.model.mongo.MetaDataStatus;
import com.optum.fds.paperless.model.mongo.ProcessorMetaData;
import com.optum.fds.paperless.model.mongo.ProcessorRecordTypes;
import com.optum.fds.paperless.model.mongo.ProcessorTransaction;

public class ProcessorTransactionServiceImplTest {

    @InjectMocks
    private ProcessorTransactionServiceImpl processorTransactionService;

    @Mock
    private MongoTemplate mongoTemplate;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCreateProcessorTransaction() {
        String fileName = "testFile.txt";
        String fileLocation = "/tmp/ingest/filestore/space123/20230101123456789UUID";
        String spaceId = "123";

        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setAppIdentifier("app123");
        processorMetaData.setClientId(123);
        processorMetaData.setConfigSpaceId(123);
        processorMetaData.setId("processor123");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("processor")))
                .thenReturn(Collections.singletonList(processorMetaData));

        ProcessorTransaction processorTransaction = processorTransactionService.createProcessorTransaction(fileName, fileLocation, spaceId);

        assertNotNull(processorTransaction);
        assertEquals("app123", processorTransaction.getAppIdentifier());
        assertEquals(123, processorTransaction.getClientId());
        assertEquals(fileName, processorTransaction.getFileName());
        assertEquals(fileLocation, processorTransaction.getLocation());
        assertEquals((Integer) 123, processorTransaction.getConfigSpaceId());
        assertEquals("processor123", processorTransaction.getProcessorId());
        assertEquals(MetaDataStatus.NEW, processorTransaction.getStatus());
        assertEquals(ProcessorRecordTypes.processorTransaction, processorTransaction.getProcessorRecordType());
        assertNotNull(processorTransaction.getTransactionId());
        assertEquals("1", processorTransaction.getVersion());

        verify(mongoTemplate).save(processorTransaction, "processorTransaction");
    }

    @Test
    public void testFindProcessorTransactionByFileName() {
        String fileName = "testFile.txt";
        Integer configSpaceId = 123;

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setFileName(fileName);
        processorTransaction.setConfigSpaceId(configSpaceId);

        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenReturn(processorTransaction);

        ProcessorTransaction result = processorTransactionService.findProcessorTransactionByFileName(fileName, configSpaceId);

        assertNotNull(result);
        assertEquals(fileName, result.getFileName());
        assertEquals(configSpaceId, result.getConfigSpaceId());
    }

    @Test
    public void testCreateProcessorTransaction_NoProcessorMetaData() {
        String fileName = "testFile.txt";
        String fileLocation = "/tmp/ingest/filestore/space123/20230101123456789UUID";
        String spaceId = "123";
        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("processor")))
                .thenReturn(Collections.emptyList());
        ProcessorTransaction processorTransaction = processorTransactionService.createProcessorTransaction(fileName, fileLocation, spaceId);
        assertNull(processorTransaction);

        verify(mongoTemplate, never()).save(any(ProcessorTransaction.class), anyString());
    }

    @Test(expected = RuntimeException.class)
    public void testGetProcessorMetaDataBySpaceId_Exception() {
        String spaceId = "123";

        Query query = new Query();
        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("processor")))
                .thenThrow(new RuntimeException("Mocked exception"));

        try {
            processorTransactionService.getProcessorMetaDataBySpaceId(spaceId);
        } catch (RuntimeException e) {
            assertEquals("Mocked exception", e.getMessage());
            throw e; // Re-throw to satisfy the `expected` attribute in the test annotation
        }

        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), eq("processor"));
    }


    @Test(expected = RuntimeException.class)
    public void testFindProcessorTransactionByFileName_Exception() {
        String fileName = "testFile.txt";
        Integer configSpaceId = 123;

        Query query = new Query();
        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenThrow(new RuntimeException("Mocked exception"));

        try {
            processorTransactionService.findProcessorTransactionByFileName(fileName, configSpaceId);
        } catch (RuntimeException e) {
            assertEquals("Mocked exception", e.getMessage());
            throw e; // Re-throw to satisfy the `expected` attribute in the test annotation
        }

        verify(mongoTemplate).findOne(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction"));
    }
}