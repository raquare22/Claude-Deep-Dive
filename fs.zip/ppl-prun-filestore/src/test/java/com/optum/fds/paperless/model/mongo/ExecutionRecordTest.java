package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class ExecutionRecordTest {

    private ExecutionRecord executionRecord;

    @Before
    public void setUp() {
        executionRecord = new ExecutionRecord();
    }

    @Test
    public void testGetSetAppIdentifier() {
        executionRecord.setAppIdentifier("app123");
        assertEquals("app123", executionRecord.getAppIdentifier());
    }

    @Test
    public void testGetSetClientId() {
        executionRecord.setClientId(123);
        assertEquals(123, executionRecord.getClientId());
    }

    @Test
    public void testGetSetDateCreated() {
        Date now = new Date();
        executionRecord.setDateCreated(now);
        assertEquals(now, executionRecord.getDateCreated());
    }

    @Test
    public void testGetSetDateModified() {
        Date now = new Date();
        executionRecord.setDateModified(now);
        assertEquals(now, executionRecord.getDateModified());
    }

    @Test
    public void testGetSetMessageList() {
        List<Map<String, String>> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("key", "value");
        messages.add(message);
        executionRecord.setMessageList(messages);
        assertEquals(messages, executionRecord.getMessageList());
    }

    @Test
    public void testGetSetServerName() {
        executionRecord.setServerName("server1");
        assertEquals("server1", executionRecord.getServerName());
    }

    @Test
    public void testGetSetServerIp() {
        executionRecord.setServerIp("192.168.1.1");
        assertEquals("192.168.1.1", executionRecord.getServerIp());
    }

    @Test
    public void testGetSetSpaceId() {
        executionRecord.setSpaceId(456);
        assertEquals(456, executionRecord.getSpaceId());
    }

    @Test
    public void testGetSetStatus() {
        executionRecord.setStatus("active");
        assertEquals("active", executionRecord.getStatus());
    }

    @Test
    public void testGetSetVersion() {
        executionRecord.setVersion("1.0");
        assertEquals("1.0", executionRecord.getVersion());
    }

    @Test
    public void testGetSetActivitiJobId() {
        executionRecord.setActivitiJobId("job123");
        assertEquals("job123", executionRecord.getActivitiJobId());
    }

    @Test
    public void testGetSetActivitiJobStatus() {
        executionRecord.setActivitiJobStatus("completed");
        assertEquals("completed", executionRecord.getActivitiJobStatus());
    }

    @Test
    public void testGetSetActivitiProcessKey() {
        executionRecord.setActivitiProcessKey("process123");
        assertEquals("process123", executionRecord.getActivitiProcessKey());
    }

    @Test
    public void testGetSetDateActivitiJobCompleted() {
        Date now = new Date();
        executionRecord.setDateActivitiJobCompleted(now);
        assertEquals(now, executionRecord.getDateActivitiJobCompleted());
    }

    @Test
    public void testGetSetDateActivitiJobCreated() {
        Date now = new Date();
        executionRecord.setDateActivitiJobCreated(now);
        assertEquals(now, executionRecord.getDateActivitiJobCreated());
    }

    @Test
    public void testGetSetDateActivitiJobModified() {
        Date now = new Date();
        executionRecord.setDateActivitiJobModified(now);
        assertEquals(now, executionRecord.getDateActivitiJobModified());
    }

    @Test
    public void testAddMessage() {
        Map<String, String> message = new HashMap<>();
        message.put("key", "value");
        executionRecord.addMessage(message);
        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals(message, executionRecord.getMessageList().get(0));
    }

    @Test
    public void testUpdateMessage() {
        Map<String, String> message1 = new HashMap<>();
        message1.put("key1", "value1");
        executionRecord.addMessage(message1);

        Map<String, String> message2 = new HashMap<>();
        message2.put("key2", "value2");
        executionRecord.updateMessage(message2);

        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals(message2, executionRecord.getMessageList().get(0));
    }

    @Test
    public void testUpdateMessageWhenMessageListIsNull() {
        ExecutionRecord executionRecord = new ExecutionRecord();
        Map<String, String> message = new HashMap<>();
        message.put("key", "value");

        executionRecord.updateMessage(message);

        assertNotNull(executionRecord.getMessageList());
        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals(message, executionRecord.getMessageList().get(0));
    }
}