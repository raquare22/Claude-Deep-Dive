package com.optum.fds.paperless.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.HttpStatus;

public class HttpServerExceptionTest {
    @Test
    public void testHttpServerException() {
        String errorMessage = "Internal Server Error";
        HttpStatusCode status = HttpStatus.INTERNAL_SERVER_ERROR;

        HttpServerException exception = new HttpServerException(errorMessage, status);

        assertNotNull(exception);
        assertEquals(errorMessage, exception.getMessage());
        assertEquals(status, exception.getStatus());
    }
}
