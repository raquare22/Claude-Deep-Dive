package com.optum.fds.paperless;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.ness.KafkaConfig;

public class KafkaConfigTest {

    private KafkaConfig kafkaConfig;

    @Before
    public void setUp() {
        kafkaConfig = new KafkaConfig();
    }

    @Test
    public void testSetAppAskId() {
        kafkaConfig.setAppAskId("testAppAskId");
        assertEquals("testAppAskId", ReflectionTestUtils.getField(KafkaConfig.class, "appAskid"));
    }

    @Test
    public void testSetAppName() {
        kafkaConfig.setAppName("testAppName");
        assertEquals("testAppName", ReflectionTestUtils.getField(KafkaConfig.class, "appname"));
    }

    @Test
    public void testSetDeviceVendor() {
        kafkaConfig.setDeviceVendor("testDeviceVendor");
        assertEquals("testDeviceVendor", ReflectionTestUtils.getField(KafkaConfig.class, "devicevendor"));
    }

    @Test
    public void testSetDeviceProduct() {
        kafkaConfig.setDeviceProduct("testDeviceProduct");
        assertEquals("testDeviceProduct", ReflectionTestUtils.getField(KafkaConfig.class, "deviceproduct"));
    }

    @Test
    public void testSetTags() {
        kafkaConfig.setTags("testTags");
        assertEquals("testTags", ReflectionTestUtils.getField(KafkaConfig.class, "tag"));
    }

    @Test
    public void testSetBrokerList() {
        kafkaConfig.setBrokerList("testBrokerList");
        assertEquals("testBrokerList", ReflectionTestUtils.getField(KafkaConfig.class, "brokerlist"));
    }

    @Test
    public void testSetKafkaTopic() {
        kafkaConfig.setKafkaTopic("testKafkaTopic");
        assertEquals("testKafkaTopic", ReflectionTestUtils.getField(KafkaConfig.class, "kafkatopic"));
    }

    @Test
    public void testSetKafkaKeyPass() {
        kafkaConfig.setKafkaKeyPass("testKafkaKeyPass");
        assertEquals("testKafkaKeyPass", ReflectionTestUtils.getField(KafkaConfig.class, "kafkaKeypass"));
    }

    @Test
    public void testSetKafkaKeystorePass() {
        kafkaConfig.setKafkaKeystorePass("testKafkaKeystorePass");
        assertEquals("testKafkaKeystorePass", ReflectionTestUtils.getField(KafkaConfig.class, "kafkaKeystorepass"));
    }

    @Test
    public void testSetKafkaClientId() {
        kafkaConfig.setKafkaClientId("testKafkaClientId");
        assertEquals("testKafkaClientId", ReflectionTestUtils.getField(KafkaConfig.class, "kafkaclientId"));
    }

    @Test
    public void testSetKafkaProtocol() {
        kafkaConfig.setKafkaProtocol("testKafkaProtocol");
        assertEquals("testKafkaProtocol", ReflectionTestUtils.getField(KafkaConfig.class, "Kafkaprotocol"));
    }

    @Test
    public void testSetKafkaKeyStorePath() {
        kafkaConfig.setKafkaKeyStorePath("testKafkaKeyStorePath");
        assertEquals("testKafkaKeyStorePath", ReflectionTestUtils.getField(KafkaConfig.class, "kafkaKeyStorepath"));
    }

    @Test
    public void testSetEnableNess() {
        kafkaConfig.setEnableNess(true);
        assertTrue((boolean) ReflectionTestUtils.getField(KafkaConfig.class, "enableNess"));
    }
}
