package com.optum.fds.paperless.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.junit.Test;

public class PrunExceptionTest {

    @Test
    public void testConstructorWithErrorCode() {
        ErrorCode errorCode = ErrorCode.PROCESS;
        PrunException exception = new PrunException(errorCode);
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
        assertEquals(errorCode, exception.getCode());
    }

    @Test
    public void testConstructorWithMessageAndCauseAndErrorCode() {
        String message = "Test message";
        Throwable cause = new Throwable("Test cause");
        ErrorCode errorCode = ErrorCode.PROCESS;
        PrunException exception = new PrunException(message, cause, errorCode);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
        assertEquals(errorCode, exception.getCode());
    }

    @Test
    public void testConstructorWithMessageAndErrorCode() {
        String message = "Test message";
        ErrorCode errorCode = ErrorCode.PROCESS;
        PrunException exception = new PrunException(message, errorCode);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
        assertEquals(errorCode, exception.getCode());
    }

    @Test
    public void testConstructorWithCauseAndErrorCode() {
        Throwable cause = new Throwable("Test cause");
        ErrorCode errorCode = ErrorCode.PROCESS;
        PrunException exception = new PrunException(cause, errorCode);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
        assertEquals(errorCode, exception.getCode());
    }

    @Test
    public void testToString() {
        String message = "Test message";
        ErrorCode errorCode = ErrorCode.PROCESS;
        PrunException exception = new PrunException(message, errorCode);
        assertEquals(errorCode + ": " + message, exception.toString());
    }
}