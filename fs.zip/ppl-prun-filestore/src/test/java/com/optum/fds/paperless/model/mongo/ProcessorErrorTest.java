package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ProcessorErrorTest {

    private ProcessorError processorError;

    @Before
    public void setUp() {
        processorError = new ProcessorError();
    }

    @Test
    public void testDefaultConstructor() {
        assertNull(processorError.getFileName());
        assertNull(processorError.getErrorMessage());
        assertNull(processorError.getErrorCode());
    }

    @Test
    public void testConstructorWithProcessorErrorCode() {
        ProcessorErrorCode errorCode = ProcessorErrorCode.FILE_NOT_FOUND;
        processorError = new ProcessorError(errorCode);
        assertEquals(errorCode.getErrorCode(), processorError.getErrorCode());
        assertEquals(errorCode.getErrorMessage(), processorError.getErrorMessage());
        assertNull(processorError.getFileName());
    }

    @Test
    public void testConstructorWithProcessorErrorCodeAndFileName() {
        ProcessorErrorCode errorCode = ProcessorErrorCode.FILE_NOT_FOUND;
        String fileName = "testFile.txt";
        processorError = new ProcessorError(errorCode, fileName);
        assertEquals(errorCode.getErrorCode(), processorError.getErrorCode());
        assertEquals(errorCode.getErrorMessage(), processorError.getErrorMessage());
        assertEquals(fileName, processorError.getFileName());
    }

    @Test
    public void testConstructorWithErrorMessageAndErrorCode() {
        String errorMessage = "Custom error message";
        Integer errorCode = 999;
        processorError = new ProcessorError(errorMessage, errorCode);
        assertEquals(errorMessage, processorError.getErrorMessage());
        assertEquals(errorCode, processorError.getErrorCode());
        assertNull(processorError.getFileName());
    }

    @Test
    public void testSetAndGetFileName() {
        String fileName = "testFile.txt";
        processorError.setFileName(fileName);
        assertEquals(fileName, processorError.getFileName());
    }

    @Test
    public void testSetAndGetErrorMessage() {
        String errorMessage = "Custom error message";
        processorError.setErrorMessage(errorMessage);
        assertEquals(errorMessage, processorError.getErrorMessage());
    }

}