package com.optum.fds.paperless.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import java.util.HashMap;

import org.junit.Test;

public class Doc360ResponseTest {

    @Test
    public void testDefaultValuesAreNull() {
        Doc360Response response = new Doc360Response();

        assertNull(response.getGlobalDocId());
        assertNull(response.getIndexName());
        assertNull(response.getReceivedDate());
        assertNull(response.getStatus());
        assertNull(response.getMessageMap());
    }

    @Test
    public void testStringFieldGettersAndSetters() {
        Doc360Response response = new Doc360Response();

        response.setGlobalDocId("global-123");
        response.setIndexName("index-a");
        response.setReceivedDate("2026-03-19T10:15:30Z");
        response.setStatus("SUCCESS");

        assertEquals("global-123", response.getGlobalDocId());
        assertEquals("index-a", response.getIndexName());
        assertEquals("2026-03-19T10:15:30Z", response.getReceivedDate());
        assertEquals("SUCCESS", response.getStatus());
    }

    @Test
    public void testMessageMapGetterAndSetter() {
        Doc360Response response = new Doc360Response();
        HashMap<String, Object> messageMap = new HashMap<>();
        messageMap.put("code", "200");
        messageMap.put("detail", "ok");

        response.setMessageMap(messageMap);

        assertSame(messageMap, response.getMessageMap());
        assertEquals("200", response.getMessageMap().get("code"));
        assertEquals("ok", response.getMessageMap().get("detail"));
    }
}
