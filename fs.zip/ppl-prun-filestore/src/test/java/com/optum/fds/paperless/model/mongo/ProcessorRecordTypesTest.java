package com.optum.fds.paperless.model.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProcessorRecordTypesTest {

    @Test
    public void testEnumValues() {
        ProcessorRecordTypes[] expectedValues = {
                ProcessorRecordTypes.processorTextFile,
                ProcessorRecordTypes.processor,
                ProcessorRecordTypes.processorTransaction,
                ProcessorRecordTypes.processorFileTask,
                ProcessorRecordTypes.processorMapping,
                ProcessorRecordTypes.csvProcessorTransaction,
                ProcessorRecordTypes.csvProcessorRowTask,
                ProcessorRecordTypes.processorTransactionMetadata,
                ProcessorRecordTypes.processorSftpSendEmail,
                ProcessorRecordTypes.sftpConvertFileToDocument,
                ProcessorRecordTypes.processorRealTimeAPI
        };

        assertArrayEquals(expectedValues, ProcessorRecordTypes.values());
    }

    @Test
    public void testEnumValueOf() {
        assertEquals(ProcessorRecordTypes.processorTextFile, ProcessorRecordTypes.valueOf("processorTextFile"));
        assertEquals(ProcessorRecordTypes.processor, ProcessorRecordTypes.valueOf("processor"));
        assertEquals(ProcessorRecordTypes.processorTransaction, ProcessorRecordTypes.valueOf("processorTransaction"));
        assertEquals(ProcessorRecordTypes.processorFileTask, ProcessorRecordTypes.valueOf("processorFileTask"));
        assertEquals(ProcessorRecordTypes.processorMapping, ProcessorRecordTypes.valueOf("processorMapping"));
        assertEquals(ProcessorRecordTypes.csvProcessorTransaction, ProcessorRecordTypes.valueOf("csvProcessorTransaction"));
        assertEquals(ProcessorRecordTypes.csvProcessorRowTask, ProcessorRecordTypes.valueOf("csvProcessorRowTask"));
        assertEquals(ProcessorRecordTypes.processorTransactionMetadata, ProcessorRecordTypes.valueOf("processorTransactionMetadata"));
        assertEquals(ProcessorRecordTypes.processorSftpSendEmail, ProcessorRecordTypes.valueOf("processorSftpSendEmail"));
        assertEquals(ProcessorRecordTypes.sftpConvertFileToDocument, ProcessorRecordTypes.valueOf("sftpConvertFileToDocument"));
        assertEquals(ProcessorRecordTypes.processorRealTimeAPI, ProcessorRecordTypes.valueOf("processorRealTimeAPI"));
    }
}