package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Test;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import java.util.Date;

public class ProcessorMetaDataTest {

    private ProcessorMetaData processorMetaData;

    @Before
    public void setUp() {
        processorMetaData = new ProcessorMetaData();
    }

    @Test
    public void testGetSetPriority() {
        Integer priority = 5;
        processorMetaData.setPriority(priority);
        assertEquals(priority, processorMetaData.getPriority());
    }

    @Test
    public void testGetSetStartDate() {
        Date startDate = new Date();
        processorMetaData.setStartDate(startDate);
        assertEquals(startDate, processorMetaData.getStartDate());
    }

    @Test
    public void testGetSetEndDate() {
        Date endDate = new Date();
        processorMetaData.setEndDate(endDate);
        assertEquals(endDate, processorMetaData.getEndDate());
    }

    @Test
    public void testGetSetCleanupWorkflow() {
        String cleanupWorkflow = "Cleanup Workflow";
        processorMetaData.setCleanupWorkflow(cleanupWorkflow);
        assertEquals(cleanupWorkflow, processorMetaData.getCleanupWorkflow());
    }

    @Test
    public void testGetSetLastRun() {
        Date lastRun = new Date();
        processorMetaData.setLastRun(lastRun);
        assertEquals(lastRun, processorMetaData.getLastRun());
    }

    @Test
    public void testGetSetLastCleanUpRun() {
        Date lastCleanUpRun = new Date();
        processorMetaData.setLastCleanUpRun(lastCleanUpRun);
        assertEquals(lastCleanUpRun, processorMetaData.getLastCleanUpRun());
    }

    @Test
    public void testIsSetLocked() {
        processorMetaData.setLocked(true);
        assertTrue(processorMetaData.isLocked());
    }

    @Test
    public void testGetSetRetryCount() {
        int retryCount = 3;
        processorMetaData.setRetryCount(retryCount);
        assertEquals(retryCount, processorMetaData.getRetryCount());
    }

    @Test
    public void testGetSetResolveIncompleteProcessorTransactionLastRun() {
        Date lastRun = new Date();
        processorMetaData.setResolveIncompleteProcessorTransactionLastRun(lastRun);
        assertEquals(lastRun, processorMetaData.getResolveIncompleteProcessorTransactionLastRun());
    }

    @Test
    public void testGetSetResolveIncompleteProcessorTransactionLocked() {
        processorMetaData.setResolveIncompleteProcessorTransactionLocked(true);
        assertTrue(processorMetaData.getResolveIncompleteProcessorTransactionLocked());
    }


    @Test
    public void testSetEndDateString() {
        String endDateString = "2023-10-10T10:10:10.000Z";
        processorMetaData.setEndDate(endDateString);
        assertEquals(endDateString, processorMetaData.getEndDateString());
    }

    @Test
    public void testConvertISOStringToDate() {
        String isoDate = "2023-10-10T10:10:10.000Z";
        Date date = processorMetaData.convertISOStringToDate(isoDate);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        assertEquals(isoDate, sdf.format(date));
    }


    @Test
    public void testGetSetProcessConfig() {
        Map<String, Object> process = new HashMap<>();
        Map<String, Object> config = new HashMap<>();
        config.put("key", "value");
        process.put("config", config);
        processorMetaData.setProcess(process);
        assertEquals(config, processorMetaData.getProcessConfig());
    }

    @Test
    public void testAddRevision() {
        ProcessorRevision revision = new ProcessorRevision();
        processorMetaData.addRevision(revision);
        assertTrue(processorMetaData.getRevisions().contains(revision));
    }

    @Test
    public void testConvertISOStringToDateInvalidFormat() {
        String invalidIsoDate = "invalid-date";
        Date date = processorMetaData.convertISOStringToDate(invalidIsoDate);
        assertNull(date);
    }

    @Test
    public void testSetStartDateWithDate() {
        Date startDate = new Date();
        processorMetaData.setStartDate(startDate);
        assertEquals(startDate, processorMetaData.getStartDate());
    }

    @Test
    public void testGetSetProcessorType() {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        String processorType = "TestProcessorType";
        processorMetaData.setProcessorType(processorType);
        assertEquals(processorType, processorMetaData.getProcessorType());
    }

    @Test
    public void testGetProcess() {
        Map<String, Object> process = new HashMap<>();
        process.put("key1", "value1");
        process.put("key2", "value2");

        processorMetaData.setProcess(process);
        assertEquals(process, processorMetaData.getProcess());
    }

}