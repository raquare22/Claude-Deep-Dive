package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ProcessorTransactionTest {

    private ProcessorTransaction processorTransaction;

    @Before
    public void setUp() {
        processorTransaction = new ProcessorTransaction();
    }

    @Test
    public void testGetAndSetDocumentIds() {
        List<String> documentIds = new ArrayList<>();
        documentIds.add("doc1");
        processorTransaction.setDocumentIds(documentIds);
        assertEquals(documentIds, processorTransaction.getDocumentIds());
    }

    @Test
    public void testGetAndSetFileCount() {
        processorTransaction.setFileCount(5);
        assertEquals(Integer.valueOf(5), processorTransaction.getFileCount());
    }

    @Test
    public void testGetAndSetMissingFileList() {
        List<String> missingFiles = new ArrayList<>();
        missingFiles.add("file1");
        processorTransaction.setMissingFileList(missingFiles);
        assertEquals(missingFiles, processorTransaction.getMissingFileList());
    }

    @Test
    public void testGetAndSetExtraFileList() {
        List<String> extraFiles = new ArrayList<>();
        extraFiles.add("file2");
        processorTransaction.setExtraFileList(extraFiles);
        assertEquals(extraFiles, processorTransaction.getExtraFileList());
    }

    @Test
    public void testGetAndSetFileToProcessList() {
        List<String> filesToProcess = new ArrayList<>();
        filesToProcess.add("file3");
        processorTransaction.setFileToProcessList(filesToProcess);
        assertEquals(filesToProcess, processorTransaction.getFileToProcessList());
    }

    @Test
    public void testAddMissingFile() {
        processorTransaction.addMissingFile("file1");
        assertNotNull(processorTransaction.getMissingFileList());
        assertEquals(1, processorTransaction.getMissingFileList().size());
        assertEquals("file1", processorTransaction.getMissingFileList().get(0));
    }

    @Test
    public void testAddExtraFile() {
        processorTransaction.addExtraFile("file2");
        assertNotNull(processorTransaction.getExtraFileList());
        assertEquals(1, processorTransaction.getExtraFileList().size());
        assertEquals("file2", processorTransaction.getExtraFileList().get(0));
    }

    @Test
    public void testAddFileToProcess() {
        processorTransaction.addFileToProcess("file3");
        assertNotNull(processorTransaction.getFileToProcessList());
        assertEquals(1, processorTransaction.getFileToProcessList().size());
        assertEquals("file3", processorTransaction.getFileToProcessList().get(0));
    }

    @Test
    public void testGetAndSetAckStatus() {
        processorTransaction.setAckStatus(AckStatus.COMPLETE);
        assertEquals(AckStatus.COMPLETE, processorTransaction.getAckStatus());
    }
}