package com.optum.fds.paperless;

import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.event.ContextClosedEvent;
import org.mockito.MockedStatic;

import com.optum.fds.paperless.service.DocumentsServiceImpl;

public class FilestoreApplicationListenerTest {

    private FilestoreApplicationListener listener;
    private ContextClosedEvent event;

    @Before
    public void setUp() {
        listener = new FilestoreApplicationListener();
        event = mock(ContextClosedEvent.class);
    }

    @Test
    public void testOnApplicationEvent() {
        try (MockedStatic<DocumentsServiceImpl> documentsServiceMock = mockStatic(DocumentsServiceImpl.class);
             MockedStatic<FilestoreApplication> filestoreApplicationMock = mockStatic(FilestoreApplication.class)) {

            // Call the method under test
            listener.onApplicationEvent(event);

            // Verify that the static methods were called
            documentsServiceMock.verify(DocumentsServiceImpl::shutdown);
            filestoreApplicationMock.verify(FilestoreApplication::shutdown);
            
        }
    }
}