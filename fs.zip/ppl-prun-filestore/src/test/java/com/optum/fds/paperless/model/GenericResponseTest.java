package com.optum.fds.paperless.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class GenericResponseTest {

    private GenericResponse response;

    @Before
    public void setUp() {
        response = new GenericResponse();
    }

    @Test
    public void testDefaultConstructor() {
        assertNotNull(response);
    }

    @Test
    public void testParameterizedConstructor() {
        String statusCode = "200";
        String statusMessage = "OK";
        Object responseObject = new Object();

        response = new GenericResponse(statusCode, statusMessage, responseObject);

        assertEquals(statusCode, response.getStatusCode());
        assertEquals(statusMessage, response.getStatusMessage());
        assertEquals(responseObject, response.getResponse());
    }

    @Test
    public void testFromMethod() {
        String statusCode = "200";
        String statusMessage = "OK";
        Object responseObject = new Object();

        response = GenericResponse.from(statusCode, statusMessage, responseObject);

        assertEquals(statusCode, response.getStatusCode());
        assertEquals(statusMessage, response.getStatusMessage());
        assertEquals(responseObject, response.getResponse());
    }

    @Test
    public void testGettersAndSetters() {
        String statusCode = "200";
        String statusMessage = "OK";
        Object responseObject = new Object();

        response.setStatusCode(statusCode);
        response.setStatusMessage(statusMessage);
        response.setResponse(responseObject);

        assertEquals(statusCode, response.getStatusCode());
        assertEquals(statusMessage, response.getStatusMessage());
        assertEquals(responseObject, response.getResponse());
    }

    @Test
    public void testToString() {
        String statusCode = "200";
        String statusMessage = "OK";
        Object responseObject = new Object();

        response.setStatusCode(statusCode);
        response.setStatusMessage(statusMessage);
        response.setResponse(responseObject);

        String expectedString = "GenericResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", response=" + responseObject + "]";
        assertEquals(expectedString, response.toString());
    }
}