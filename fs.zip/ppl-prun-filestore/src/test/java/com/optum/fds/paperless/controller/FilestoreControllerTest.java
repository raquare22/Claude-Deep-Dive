package com.optum.fds.paperless.controller;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.optum.fds.paperless.ness.KafkaProducer;
import com.optum.fds.paperless.service.FilestoreService;
import io.github.bucket4j.Bucket;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.lang.reflect.Method;

public class FilestoreControllerTest {

    private FilestoreController filestoreController;

    private MockMvc mockMvc;

    @Mock
    private FilestoreService fileStoreService;

    @Before
    public void setUp() {
        filestoreController = new FilestoreController(10L);
        fileStoreService = mock(FilestoreService.class);
        mockMvc = MockMvcBuilders.standaloneSetup(filestoreController).build();
        KafkaProducer.setUpOff();
    }

    @Test
    public void testGetSpaceIdValid() throws Exception {
        Method method = FilestoreController.class.getDeclaredMethod("getSpaceId", String.class);
        method.setAccessible(true);
        Integer spaceId = (Integer) method.invoke(filestoreController, "123");
        assertNotNull(spaceId);
        assertEquals(Integer.valueOf(123), spaceId);
    }

    @Test
    public void testGetSpaceIdInvalid() throws Exception {
        Method method = FilestoreController.class.getDeclaredMethod("getSpaceId", String.class);
        method.setAccessible(true);
        Integer spaceId = (Integer) method.invoke(filestoreController, "abc");
        assertNull(spaceId);
    }

    @Test
    public void testGetSpaceIdNull() throws Exception {
        Method method = FilestoreController.class.getDeclaredMethod("getSpaceId", String.class);
        method.setAccessible(true);
        Integer spaceId = (Integer) method.invoke(filestoreController, (String) null);
        assertNull(spaceId);
    }

    @Test
    public void testGetSpaceIdNumberFormatException() throws Exception {
        Method method = FilestoreController.class.getDeclaredMethod("getSpaceId", String.class);
        method.setAccessible(true);
        Integer spaceId = (Integer) method.invoke(filestoreController, "invalidNumber");
        assertNull(spaceId);
    }

    @Test
    public void testSendFileInvalidRequest() throws Exception {
        // Act & Assert
        mockMvc.perform(multipart("/api/services/v1/filestore/sendFile/{spaceId}", "123")
                        .contentType(MediaType.MULTIPART_FORM_DATA))
                .andExpect(status().isBadRequest());
    }


    @Test
    public void testSendFileGenericException() throws Exception {
        String spaceId = "123";
        String optumCidExt = "test-cid";
        MockMultipartFile mockFile = new MockMultipartFile("file", "testFile.txt", MediaType.TEXT_PLAIN_VALUE, "test content".getBytes());

        doThrow(new RuntimeException("Unexpected error"))
                .when(fileStoreService).processFileUpload(anyString(), any(MultipartFile.class), eq(spaceId), eq(optumCidExt));

        mockMvc.perform(multipart("/api/services/v1/filestore/sendFile/{spaceId}", spaceId)
                        .file(mockFile)
                        .header("optum-cid-ext", optumCidExt)
                        .contentType(MediaType.MULTIPART_FORM_DATA))
                .andExpect(status().isUnsupportedMediaType());
    }

    @Test
    public void testSendFileNumberFormatException() throws Exception {
        String spaceId = "invalidSpaceId";
        String optumCidExt = "test-cid";
        MockMultipartFile mockFile = new MockMultipartFile("file", "testFile.txt", MediaType.TEXT_PLAIN_VALUE, "test content".getBytes());

        mockMvc.perform(multipart("/api/services/v1/filestore/sendFile/{spaceId}", spaceId)
                        .file(mockFile)
                        .header("optum-cid-ext", optumCidExt)
                        .contentType(MediaType.MULTIPART_FORM_DATA))
                .andExpect(status().isBadRequest());

    }

    @Test
    public void testSendFileRateLimitExceeded() throws Exception {
        String spaceId = "123";
        String optumCidExt = "test-cid";
        MockMultipartFile mockFile = new MockMultipartFile("file", "testFile.txt", MediaType.TEXT_PLAIN_VALUE, "test content".getBytes());

        Bucket mockBucket = mock(Bucket.class);
        when(mockBucket.tryConsume(1)).thenReturn(false);
        ReflectionTestUtils.setField(filestoreController, "postRequestBucket", mockBucket);

        mockMvc.perform(multipart("/api/services/v1/filestore/sendFile/{spaceId}", spaceId)
                        .file(mockFile)
                        .header("optum-cid-ext", optumCidExt)
                        .contentType(MediaType.MULTIPART_FORM_DATA))
                .andExpect(status().isTooManyRequests());
    }
}
