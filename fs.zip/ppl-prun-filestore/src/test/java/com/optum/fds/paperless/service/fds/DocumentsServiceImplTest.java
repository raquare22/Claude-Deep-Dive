package com.optum.fds.paperless.service.fds;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.exception.OutOfRetriesException;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.model.FDSCloudDocument;
import com.optum.fds.paperless.oauth.OauthUtil;
import com.optum.fds.paperless.service.DocumentsServiceImpl;
import com.optum.fds.paperless.util.RestTemplateClient;
import com.optum.fds.paperless.util.WebClientSync;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import com.optum.fds.paperless.model.Doc360Response;


@RunWith(MockitoJUnitRunner.class)
public class DocumentsServiceImplTest {

	@InjectMocks
	private DocumentsServiceImpl documentService;
	
	@Mock 
	private OauthUtil oauthUtil;
	
	@Mock
	private RestTemplate restTemplate;

	@Mock
	private WebClientSync webClientSync;
	
	@Mock
	private RestTemplateClient restTemplateClient;
	
	@InjectMocks
	private ConfigData config;

	public static final String FDS_DOCUMENTS_URL = "FDSDocumentsUrl";

	private final String PATH_TEST_FILE = "test1.txt";

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(documentService, "fdsDocumentsUrl", "url");
		ReflectionTestUtils.setField(documentService, "fileStoreUseWebClient", true);
        ReflectionTestUtils.setField(documentService, "doc360DocumentsUrl", "https://doc360.example.com/documents-upload");

		Map<String, Object> creds = new HashMap<>();
		creds.put("fdsCloudSpaceId", "1234");
		Map<String, Map<String, Object>> credentials = new HashMap<>();
		credentials.put("3007", creds);
		config = new ConfigData();
		config = mock(ConfigData.class);


		String letGenCreds = "{\"3007\": {\"appIdentifier\":\"123\",\"appSecret\":\"123\", \"clientId\":685,\"123\":\"123\", \"clientName\": \"CAP\"}, \"11501\": {\"appIdentifier\":\"123\",\"appSecret\":\"123\", \"clientId\":685,\"fdsCloudSpaceId\":\"123\", \"clientName\": \"CAP\"}, \"11502\": {\"appIdentifier\":\"123\",\"appSecret\":\"123\", \"clientId\":685,\"fdsCloudSpaceId\":\"123\", \"clientName\": \"CAP\"}, \"11503\": {\"appIdentifier\":\"123\",\"appSecret\":\"123\", \"clientId\":685,\"fdsCloudSpaceId\":\"123\", \"clientName\": \"CAP\"}}";
		ReflectionTestUtils.setField(config, "LETGEN_configcredentials", letGenCreds);
		ReflectionTestUtils.setField(config, "UNET_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "NEXTGEN_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "_1CLICK_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "CCSManual_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "UNET_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "COSMOS_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "COSMOS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "UHC_WEST_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "CSP_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "ODAR_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "MR_APPEALS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "ETS_APPEALS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "USP_CLAIMS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "USP_PRA_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "CSP_CLAIMS_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "NGSClaims_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "OCM_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "IHR_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "CC_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "CAP_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "TEXAS_GOLD_CARD_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "TRACKIT_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "HouseCalls_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");
		ReflectionTestUtils.setField(config, "OTHER_configcredentials", "{\"8935\": {\"clientName\": \"LETGEN\"}}");

		ReflectionTestUtils.setField(documentService, "config", config);
	}

    @Test
    public void postDocumentToDoc360WithAttachmentRetryTest() throws Exception {
        String document = "\"{\\\"test\\\": \\\"value\\\"}\"";
        String filePath = "src/test/resources/test1.txt";
        String doc360DocClass = "u_doc_class";
        String cid = "cid";

        Doc360Response doc360 = new Doc360Response();
        doc360.setStatus("SUCCESS");
        ResponseEntity<Doc360Response> response = new ResponseEntity<>(doc360, HttpStatus.OK);

        when(webClientSync.sendMultiPartDataWithRetryForDoc360(anyString(), any(), any(), any()))
                .thenReturn(response);

        ResponseEntity<Doc360Response> realResponse =
                documentService.postDocumentToDoc360WithAttachmentRetry(document, filePath, doc360DocClass, cid);

        assertNotNull(realResponse);
        assertTrue(realResponse.getStatusCode().is2xxSuccessful());
        assertNotNull(realResponse.getBody());
        assertEquals("SUCCESS", realResponse.getBody().getStatus());

        verify(webClientSync, times(1))
                .sendMultiPartDataWithRetryForDoc360(anyString(), any(), any(), any());
    }

	
	@UserStory(references = "")
	@RallyTestCase(references = "")
	@Test
	public void postDocumentToFDSCloudWithAttachmentTest() throws Exception {
		String document="test doc";
		String spaceId="3007";
		
		FDSCloudDocument doc = new FDSCloudDocument();
		ResponseEntity<FDSCloudDocument> response = new ResponseEntity<>(doc, HttpStatus.OK);
		
		when(webClientSync.sendMultiPartDataWithRetry(anyString(), any(), any(), any(), any()) ).thenReturn(response);

		ResponseEntity<FDSCloudDocument> realResponse = documentService.postDocumentToFDSCloudWithAttachmentRetry(document, "searchTerms", "src/test/resources/test1.txt", spaceId, "cid");
		assertNotNull(realResponse);
		assertTrue(realResponse.getStatusCode().is2xxSuccessful());
	}
	
	@UserStory(references = "US32608")
	@RallyTestCase(references = "TC32803")
	@Test
	public void validateResponseStatusCodeTest() {
		Boolean response=documentService.validateResponseStatusCode(500);
		Boolean response2=documentService.validateResponseStatusCode(502);
		Boolean response3=documentService.validateResponseStatusCode(503);
		Boolean response4=documentService.validateResponseStatusCode(504);

		assertEquals(true, response);
		assertEquals(true, response2);
		assertEquals(true, response3);
		assertEquals(true, response4);

	}

	@Test
	public void testPostDocumentToFDSCloudWithAttachmentRetry_ExceptionHandling() throws OutOfRetriesException, OutOfRetriesException {
		// Arrange
		String document = "test doc";
		String searchTerms = "searchTerms";
		String filePath = "src/test/resources/test1.txt";
		String spaceId = "3007";
		String cid = "cid";

		Map<String, Object> creds = new HashMap<>();
		creds.put("fdsCloudSpaceId", "1234");
		when(config.getCredentials(spaceId)).thenReturn(creds);

		when(webClientSync.sendMultiPartDataWithRetry(anyString(), any(), any(), any(), any()))
				.thenThrow(new RuntimeException("Test exception"));

		ResponseEntity<FDSCloudDocument> response = documentService.postDocumentToFDSCloudWithAttachmentRetry(
				document, searchTerms, filePath, spaceId, cid);

		assertNull(response); // Ensure the response is null due to the exception
	}

		@Test
		public void testShutdown() {

		ReflectionTestUtils.setField(DocumentsServiceImpl.class, "shutdown", false);
		ReflectionTestUtils.setField(DocumentsServiceImpl.class, "totalOutstandingRequests", new AtomicInteger(5));
		ReflectionTestUtils.setField(DocumentsServiceImpl.class, "maxShutdownLoop", 2L);

		DocumentsServiceImpl.shutdown();
		assertTrue((Boolean) ReflectionTestUtils.getField(DocumentsServiceImpl.class, "shutdown"));

		assertEquals(5, ((AtomicInteger) ReflectionTestUtils.getField(DocumentsServiceImpl.class, "totalOutstandingRequests")).get());
	}

}