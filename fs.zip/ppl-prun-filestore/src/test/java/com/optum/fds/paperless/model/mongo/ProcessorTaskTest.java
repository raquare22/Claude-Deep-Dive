package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;

public class ProcessorTaskTest {

    private ProcessorTask processorTask;

    @Before
    public void setUp() {
        processorTask = new ProcessorTask();
    }

    @Test
    public void testGetSetProcessorId() {
        String processorId = "processor123";
        processorTask.setProcessorId(processorId);
        assertEquals(processorId, processorTask.getProcessorId());
    }

    @Test
    public void testGetSetFileName() {
        String fileName = "file.txt";
        processorTask.setFileName(fileName);
        assertEquals(fileName, processorTask.getFileName());
    }

    @Test
    public void testGetSetLocation() {
        String location = "location123";
        processorTask.setLocation(location);
        assertEquals(location, processorTask.getLocation());
    }

    @Test
    public void testGetSetProcessedByHost() {
        String processedByHost = "host123";
        processorTask.setProcessedByHost(processedByHost);
        assertEquals(processedByHost, processorTask.getProcessedByHost());
    }

    @Test
    public void testGetSetServerType() {
        String serverType = "serverType123";
        processorTask.setServerType(serverType);
        assertEquals(serverType, processorTask.getServerType());
    }

    @Test
    public void testGetSetProcessorExecutionRecordList() {
        List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
        processorTask.setProcessorExecutionRecordList(processorExecutionRecordList);
        assertEquals(processorExecutionRecordList, processorTask.getProcessorExecutionRecordList());
    }

    @Test
    public void testAddProcessorExecutionRecord() {
        ProcessorExecutionRecord record = new ProcessorExecutionRecord();
        processorTask.addProcessorExecutionRecord(record);
        assertNotNull(processorTask.getProcessorExecutionRecordList());
        assertEquals(1, processorTask.getProcessorExecutionRecordList().size());
        assertEquals(record, processorTask.getProcessorExecutionRecordList().get(0));
    }

    @Test
    public void testGetSetUnprocessedRecordList() {
        List<UnprocessedRecord> unprocessedRecordList = new ArrayList<>();
        processorTask.setUnprocessedRecordList(unprocessedRecordList);
        assertEquals(unprocessedRecordList, processorTask.getUnprocessedRecordList());
    }

    @Test
    public void testSetStartTime() {
        processorTask.setStartTime();
        assertNotNull(processorTask.getSummary().getStartTime());
    }

    @Test
    public void testSetEndTime() {
        processorTask.setEndTime();
        assertNotNull(processorTask.getSummary().getEndTime());
        assertTrue(processorTask.getSummary().getRunTime() >= 0);
        assertEquals(Optional.of(processorTask.getSummary().getRunTime()),
                Optional.of(processorTask.getSummary().getEndTime().getTime() - processorTask.getSummary().getStartTime().getTime()));
    }


    @Test
    public void testGetProcessorExecutionRecordListInitializesList() {
        processorTask.setProcessorExecutionRecordList(null);
        List<ProcessorExecutionRecord> result = processorTask.getProcessorExecutionRecordList();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

}