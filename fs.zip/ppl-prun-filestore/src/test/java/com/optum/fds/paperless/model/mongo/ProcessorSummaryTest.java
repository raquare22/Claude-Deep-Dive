package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.*;

public class ProcessorSummaryTest {

    private ProcessorSummary processorSummary;

    @Before
    public void setUp() {
        processorSummary = new ProcessorSummary();
    }

    @Test
    public void testGetSetXmlObject() {
        Object xmlObject = new Object();
        processorSummary.setXmlObject(xmlObject);
        assertEquals(xmlObject, processorSummary.getXmlObject());
    }

    @Test
    public void testGetSetProcessingMetrics() {
        ProcessingMetrics processingMetrics = new ProcessingMetrics();
        processingMetrics.setAverageFileSize(100L);
        processingMetrics.setBytesProcessed(200L);
        processingMetrics.setFileCount(10);
        processingMetrics.setTotalBytes(300L);
        processingMetrics.setTotalRunTime(400L);
        processingMetrics.setErrorCount(new HashMap<>());

        processorSummary.setProcessingMetrics(processingMetrics);
        assertEquals(processingMetrics, processorSummary.getProcessingMetrics());
    }

    @Test
    public void testGetProcessingMetricsInitialization() {
        ProcessingMetrics processingMetrics = processorSummary.getProcessingMetrics();
        assertNotNull(processingMetrics);
        assertEquals(Long.valueOf(0L), processingMetrics.getAverageFileSize());
        assertEquals(Long.valueOf(0L), processingMetrics.getBytesProcessed());
        assertEquals(Integer.valueOf(0), processingMetrics.getFileCount());
        assertEquals(Long.valueOf(0L), processingMetrics.getTotalBytes());
        assertEquals(Long.valueOf(0L), processingMetrics.getTotalRunTime());
        assertNotNull(processingMetrics.getErrorCount());
    }

    @Test
    public void testGetProcessingMetricsElseCondition() {
        // Create a ProcessorSummary instance
        ProcessorSummary processorSummary = new ProcessorSummary();

        // Set a partially initialized ProcessingMetrics object
        ProcessingMetrics processingMetrics = new ProcessingMetrics();
        processingMetrics.setAverageFileSize(null);
        processingMetrics.setBytesProcessed(null);
        processingMetrics.setFileCount(null);
        processingMetrics.setTotalBytes(null);
        processingMetrics.setTotalRunTime(null);
        processingMetrics.setErrorCount(null);
        processorSummary.setProcessingMetrics(processingMetrics);

        // Call the method to trigger the else condition
        ProcessingMetrics result = processorSummary.getProcessingMetrics();

        // Assert that all fields are initialized correctly
        assertNotNull(result);
        assertEquals(Long.valueOf(0L), result.getAverageFileSize());
        assertEquals(Long.valueOf(0L), result.getBytesProcessed());
        assertEquals(Integer.valueOf(0), result.getFileCount());
        assertEquals(Long.valueOf(0L), result.getTotalBytes());
        assertEquals(Long.valueOf(0L), result.getTotalRunTime());
        assertNotNull(result.getErrorCount());
    }


}