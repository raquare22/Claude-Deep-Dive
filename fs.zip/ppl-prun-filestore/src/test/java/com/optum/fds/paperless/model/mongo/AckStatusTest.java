package com.optum.fds.paperless.model.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class AckStatusTest {

    @Test
    public void testAckStatusValues() {
        AckStatus[] expectedValues = {AckStatus.IN_PROCESS, AckStatus.COMPLETE};
        AckStatus[] actualValues = AckStatus.values();
        assertArrayEquals(expectedValues, actualValues);
    }

    @Test
    public void testAckStatusValueOf() {
        assertEquals(AckStatus.IN_PROCESS, AckStatus.valueOf("IN_PROCESS"));
        assertEquals(AckStatus.COMPLETE, AckStatus.valueOf("COMPLETE"));
    }
}