package com.optum.fds.paperless.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class FDSCloudDocumentTest {

    private FDSCloudDocument document;
    private FDSCloudAttachment attachment;

    @Before
    public void setUp() {
        document = new FDSCloudDocument();
        attachment = new FDSCloudAttachment();
        attachment.setAttachmentId("12345");
        attachment.setContentType("application/pdf");
        attachment.setFileName("testFile.pdf");
        attachment.setFileSize(1024L);
        attachment.setCreatedOn(new Date());
        attachment.setModifiedOn(new Date());
        attachment.setSpaceId("space123");
        attachment.setVirusScanStatus("clean");
        attachment.setUrl("http://example.com/testFile.pdf");
        attachment.setCloudStorageProvider("AWS");
    }

    @Test
    public void testGettersAndSetters() {
        String documentId = "doc123";
        String spaceId = "space123";
        String metadata = "metadata";
        List<String> searchTerms = Arrays.asList("term1", "term2");
        Date createdOn = new Date();
        Date modifiedOn = new Date();
        String createdBy = "user1";
        String modifiedBy = "user2";
        List<FDSCloudAttachment> attachments = Arrays.asList(attachment);

        document.setDocumentId(documentId);
        document.setSpaceId(spaceId);
        document.setMetadata(metadata);
        document.setSearchTerms(searchTerms);
        document.setCreatedOn(createdOn);
        document.setModifiedOn(modifiedOn);
        document.setCreatedBy(createdBy);
        document.setModifiedBy(modifiedBy);
        document.setAttachments(attachments);

        assertEquals(documentId, document.getDocumentId());
        assertEquals(spaceId, document.getSpaceId());
        assertEquals(metadata, document.getMetadata());
        assertEquals(searchTerms, document.getSearchTerms());
        assertEquals(createdOn, document.getCreatedOn());
        assertEquals(modifiedOn, document.getModifiedOn());
        assertEquals(createdBy, document.getCreatedBy());
        assertEquals(modifiedBy, document.getModifiedBy());
        assertEquals(attachments, document.getAttachments());
    }

    @Test
    public void testToString() {
        document.setDocumentId("doc123");
        document.setSpaceId("space123");
        document.setMetadata("metadata");
        document.setSearchTerms(Arrays.asList("term1", "term2"));
        document.setCreatedOn(new Date());
        document.setModifiedOn(new Date());
        document.setCreatedBy("user1");
        document.setModifiedBy("user2");
        document.setAttachments(Arrays.asList(attachment));

        String expectedString = "FDSCloudDocument [documentId=doc123, spaceId=space123, metadata=metadata, searchTerms=[term1, term2], createdOn=" + document.getCreatedOn() + ", modifiedOn=" + document.getModifiedOn() + ", createdBy=user1, modifiedBy=user2, attachments=" + document.getAttachments().toString() + "]";
        assertEquals(expectedString, document.toString());
    }
}