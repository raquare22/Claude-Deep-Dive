package com.optum.fds.paperless;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.restclient.RestTemplateBuilder;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

public class FilestoreApplicationConfigTest {

    private FilestoreApplicationConfig config;

    @Before
    public void setUp() {
        config = new FilestoreApplicationConfig();
        config.chunkSize = 5000000; // Directly setting the chunkSize value
    }

    @Test
    public void testRestTemplate() {
        RestTemplateBuilder builder = mock(RestTemplateBuilder.class);
        RestTemplate restTemplate = new RestTemplate();
        when(builder.build()).thenReturn(restTemplate);

        RestTemplate result = config.restTemplate(builder);
        assertNotNull(result);
        assertEquals(restTemplate, result);
    }

    @Test
    public void testHttpHeaders() {
        HttpHeaders headers = config.httpHeaders();
        assertNotNull(headers);
    }

    @Test
    public void testGetConfigData() {
        ConfigData configData = config.getConfigData();
        assertNotNull(configData);
    }

    @Test
    public void testRestTemplateChuck() {
        SimpleClientHttpRequestFactory factory = mock(SimpleClientHttpRequestFactory.class);
        RestTemplate restTemplate = new RestTemplate(factory);
        assertNotNull(restTemplate);
        assertTrue(restTemplate.getRequestFactory() instanceof SimpleClientHttpRequestFactory);

        SimpleClientHttpRequestFactory actualFactory = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
        assertSame(factory, actualFactory);
    }
}