package com.optum.fds.paperless.model.mongo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class RevisionTest {

    private Revision revision;

    @Before
    public void setUp() {
        revision = new Revision();
    }

    @Test
    public void testGetSetAppIdentifier() {
        String appIdentifier = "app123";
        revision.setAppIdentifier(appIdentifier);
        assertEquals(appIdentifier, revision.getAppIdentifier());
    }

    @Test
    public void testGetSetClientId() {
        int clientId = 123;
        revision.setClientId(clientId);
        assertEquals(clientId, revision.getClientId());
    }

    @Test
    public void testGetSetDateCreated() {
        Date date = new Date();
        revision.setDateCreated(date);
        assertEquals(date, revision.getDateCreated());
    }

    @Test
    public void testGetSetDateModified() {
        Date date = new Date();
        revision.setDateModified(date);
        assertEquals(date, revision.getDateModified());
    }

    @Test
    public void testGetSetName() {
        String name = "testName";
        revision.setName(name);
        assertEquals(name, revision.getName());
    }

    @Test
    public void testGetSetSpaceId() {
        int spaceId = 456;
        revision.setSpaceId(spaceId);
        assertEquals(spaceId, revision.getSpaceId());
    }

    @Test
    public void testGetSetStatus() {
        MetaDataStatus status = MetaDataStatus.ACTIVE;
        revision.setStatus(status);
        assertEquals(status, revision.getStatus());
    }

    @Test
    public void testGetSetTransactionId() {
        String transactionId = "trans123";
        revision.setTransactionId(transactionId);
        assertEquals(transactionId, revision.getTransactionId());
    }

    @Test
    public void testGetSetVersion() {
        String version = "1.0";
        revision.setVersion(version);
        assertEquals(version, revision.getVersion());
    }

    @Test
    public void testSetSpaceIdFromString() {
        String spaceId = "789";
        revision.setSpaceId(spaceId);
        assertEquals(789, revision.getSpaceId());
    }

    @Test(expected = NumberFormatException.class)
    public void testSetSpaceIdFromStringInvalid() {
        revision.setSpaceId("invalid");
    }

    @Test
    public void testSetStatusFromString() {
        String status = "ACTIVE";
        revision.setStatus(status);
        assertEquals(MetaDataStatus.ACTIVE, revision.getStatus());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetStatusFromStringInvalid() {
        revision.setStatus("INVALID");
    }
}