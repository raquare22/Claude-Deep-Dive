package com.optum.fds.paperless.model.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProcessorErrorCodeTest {

    @Test
    public void testGetErrorCode() {
        assertEquals(Integer.valueOf(1), ProcessorErrorCode.FILE_NOT_FOUND.getErrorCode());
        assertEquals(Integer.valueOf(2), ProcessorErrorCode.FILE_COULD_NOT_BE_PARSED.getErrorCode());
        // Add more assertions for other error codes as needed
    }

    @Test
    public void testGetErrorMessage() {
        assertEquals("File not found", ProcessorErrorCode.FILE_NOT_FOUND.getErrorMessage());
        assertEquals("File could not be parsed", ProcessorErrorCode.FILE_COULD_NOT_BE_PARSED.getErrorMessage());
        // Add more assertions for other error messages as needed
    }
}