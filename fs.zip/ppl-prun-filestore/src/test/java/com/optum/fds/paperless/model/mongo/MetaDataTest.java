package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class MetaDataTest {

    private MetaData metaData;

    @Before
    public void setUp() {
        metaData = new MetaData();
    }

    @Test
    public void testGetSetId() {
        metaData.setId("id123");
        assertEquals("id123", metaData.getId());
    }

    @Test
    public void testGetSetAppIdentifier() {
        metaData.setAppIdentifier("app123");
        assertEquals("app123", metaData.getAppIdentifier());
    }

    @Test
    public void testGetSetClientId() {
        metaData.setClientId(123);
        assertEquals(123, metaData.getClientId());
    }

    @Test
    public void testGetSetDateCreated() {
        Date now = new Date();
        metaData.setDateCreated(now);
        assertEquals(now, metaData.getDateCreated());
    }

    @Test
    public void testGetSetDateModified() {
        Date now = new Date();
        metaData.setDateModified(now);
        assertEquals(now, metaData.getDateModified());
    }

    @Test
    public void testGetSetName() {
        metaData.setName("name");
        assertEquals("name", metaData.getName());
    }

    @Test
    public void testGetSetRevisions() {
        List<String> revisions = List.of("rev1", "rev2");
        metaData.setRevisions(revisions);
        assertEquals(revisions, metaData.getRevisions());
    }

    @Test
    public void testGetSetStatus() {
        metaData.setStatus(MetaDataStatus.ACTIVE);
        assertEquals(MetaDataStatus.ACTIVE, metaData.getStatus());
    }

    @Test
    public void testSetStatusString() {
        metaData.setStatus("ACTIVE");
        assertEquals(MetaDataStatus.ACTIVE, metaData.getStatus());
    }

    @Test
    public void testGetSetTransactionId() {
        metaData.setTransactionId("txn123");
        assertEquals("txn123", metaData.getTransactionId());
    }

//    @Test
//    public void testGetSetVersion() {
//        metaData.setVersion("1.0");
//        assertEquals("1.0", metaData.getVersion());
//    }

    @Test
    public void testIncrementVersion() {
        metaData.setVersion("1");
        metaData.incrementVersion();
        assertEquals("2", metaData.getVersion());
    }

    @Test(expected = NumberFormatException.class)
    public void testSetVersionInvalid() {
        metaData.setVersion("invalid");
    }

    @Test(expected = NumberFormatException.class)
    public void testIncrementVersionInvalid() {
        metaData.setVersion("invalid");
        metaData.incrementVersion();
    }
}