package com.optum.fds.paperless.model.mongo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class UnprocessedRecordTest {

    private UnprocessedRecord unprocessedRecord;

    @Before
    public void setUp() {
        unprocessedRecord = new UnprocessedRecord("testRecord", 1);
    }

    @Test
    public void testGetSetUnprocessRecord() {
        String record = "newRecord";
        unprocessedRecord.setUnprocessRecord(record);
        assertEquals(record, unprocessedRecord.getUnprocessRecord());
    }

    @Test
    public void testGetSetIndex() {
        int index = 2;
        unprocessedRecord.setIndex(index);
        assertEquals(index, unprocessedRecord.getIndex());
    }
}