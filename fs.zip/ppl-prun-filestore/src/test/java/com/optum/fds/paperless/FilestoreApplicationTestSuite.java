package com.optum.fds.paperless;


import com.optum.fds.paperless.controller.DocumentsUploadControllerTest;
import com.optum.fds.paperless.controller.FilestoreControllerTest;
import com.optum.fds.paperless.controller.RootControllerTest;
import com.optum.fds.paperless.exception.ErrorCodeTest;
import com.optum.fds.paperless.exception.HttpServerExceptionTest;
import com.optum.fds.paperless.exception.ProcessExceptionTest;
import com.optum.fds.paperless.exception.PrunExceptionTest;
import com.optum.fds.paperless.model.*;
import com.optum.fds.paperless.model.mongo.*;
import com.optum.fds.paperless.ness.KafkaProducerTest;
import com.optum.fds.paperless.oauth.HttpConstantsTest;
import com.optum.fds.paperless.oauth.OauthTokenTest;
import com.optum.fds.paperless.oauth.OauthUtilTest;
import com.optum.fds.paperless.oauth.TokenTest;
import com.optum.fds.paperless.service.FilestoreServiceImplTest;
import com.optum.fds.paperless.service.FilestoreServiceTest;
import com.optum.fds.paperless.service.ProcessorTransactionServiceImplTest;
import com.optum.fds.paperless.service.fds.DocumentsServiceImplTest;
import com.optum.fds.paperless.util.*;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import junit.framework.TestCase;


@RunWith(Suite.class)

@Suite.SuiteClasses({
	ConfigDataTest.class,
		EhCacheTest.class,
	FilestoreApplicationConfigTest.class,
	FilestoreApplicationListenerTest.class,
	//FilestoreApplicationTest.class,
	KafkaConfigTest.class,
	//existing
	//controler
	DocumentsUploadControllerTest.class,
	FilestoreControllerTest.class,
	RootControllerTest.class,
	//exception
	ErrorCodeTest.class,
	HttpServerExceptionTest.class,
	ProcessExceptionTest.class,
	PrunExceptionTest.class,
	//model
	FDSCloudAttachmentTest.class,
	FDSCloudDocumentTest.class,
	GenericResponseTest.class,
	PingTest.class,
    Doc360ResponseTest.class,
	//mongo
	AckStatusTest.class,
	ExecutionRecordTest.class,
	MetaDataStatusTest.class,
	MetaDataTest.class,
	ProcessingMetricsCoreTest.class,
	ProcessingMetricsTest.class,
	ProcessorErrorCodeTest.class,
	ProcessorErrorTest.class,
	ProcessorExecutionRecordTest.class,
	ProcessorMetaDataTest.class,
	ProcessorRecordTypesTest.class,
	ProcessorRevisionTest.class,
	ProcessorSummaryCoreTest.class,
	ProcessorSummaryTest.class,
	ProcessorTaskTest.class,
	ProcessorTaskTest.class,
	ProcessorTransactionCoreTest.class,
	ProcessorTransactionTest.class,
	RevisionTest.class,
	UnprocessedRecordTest.class,
	//ness
	KafkaProducerTest.class,
	//oauth
	HttpConstantsTest.class,
	OauthTokenTest.class,
	OauthUtilTest.class,
	TokenTest.class,
	//service
	FilestoreServiceImplTest.class,
	FilestoreServiceTest.class,
	ProcessorTransactionServiceImplTest.class,
	//fds
	DocumentsServiceImplTest.class,
	//util
	HttpUtilsTest.class,
	RestTemplateChunkClientTest.class,
	RestTemplateClientTest.class,
	RetryOnExceptionHandlerTest.class,
	SanitizeUtilTest.class,
	WebClientSyncTest.class


})

public class FilestoreApplicationTestSuite extends TestCase {}
