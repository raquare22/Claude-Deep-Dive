package com.optum.fds.paperless.oauth;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class TokenTest {

    private Token token;

    @Before
    public void setUp() {
        token = new Token();
    }

    @Test
    public void testGettersAndSetters() {
        token.setGrantType("authorization_code");
        token.setAccessToken("access_token_value");
        token.setRefreshToken("refresh_token_value");
        token.setTokenType("Bearer");
        token.setExpiresIn(3600);
        token.setClientId("client_id_value");
        token.setClientSecret("client_secret_value");

        assertEquals("authorization_code", token.getGrantType());
        assertEquals("access_token_value", token.getAccessToken());
        assertEquals("refresh_token_value", token.getRefreshToken());
        assertEquals("Bearer", token.getTokenType());
        assertEquals(3600, token.getExpiresIn());
        assertEquals("client_id_value", token.getClientId());
        assertEquals("client_secret_value", token.getClientSecret());
    }

    @Test
    public void testToString() {
        token.setGrantType("authorization_code");
        token.setAccessToken("access_token_value");
        token.setRefreshToken("refresh_token_value");
        token.setTokenType("Bearer");
        token.setExpiresIn(3600);
        token.setClientId("client_id_value");
        token.setClientSecret("client_secret_value");

        String expected = "Token [grantType=authorization_code, accessToken=access_token_value, refreshToken=refresh_token_value, tokenType=Bearer, expiresIn=3600, clientId=client_id_value, clientSecret=client_secret_value]";
        assertEquals(expected, token.toString());
    }

    @Test
    public void testNotNull() {
        assertNotNull(token);
    }
}
