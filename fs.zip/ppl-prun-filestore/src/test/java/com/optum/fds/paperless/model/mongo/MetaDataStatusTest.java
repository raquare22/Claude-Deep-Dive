package com.optum.fds.paperless.model.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class MetaDataStatusTest {

    @Test
    public void testMetaDataStatusValues() {
        MetaDataStatus[] expectedValues = {
                MetaDataStatus.ACTIVE, MetaDataStatus.AVAILABLE, MetaDataStatus.CLEANING, MetaDataStatus.COMPLETE,
                MetaDataStatus.COMPLETE_WITH_ERRORS, MetaDataStatus.CONVERSION_ERROR, MetaDataStatus.DELETED, MetaDataStatus.DONE,
                MetaDataStatus.EXPIRED, MetaDataStatus.FATAL_ERROR, MetaDataStatus.IN_PROCESS, MetaDataStatus.NEW,
                MetaDataStatus.OK, MetaDataStatus.READY, MetaDataStatus.SHUTDOWN, MetaDataStatus.ERROR,
                MetaDataStatus.PURGING, MetaDataStatus.STORAGE_ERROR, MetaDataStatus.READY_HEALTH_CHECK, MetaDataStatus.SEVERE_ERROR,
                MetaDataStatus.AUTOMATIC, MetaDataStatus.MANUAL
        };
        MetaDataStatus[] actualValues = MetaDataStatus.values();
        assertArrayEquals(expectedValues, actualValues);
    }

    @Test
    public void testMetaDataStatusValueOf() {
        assertEquals(MetaDataStatus.ACTIVE, MetaDataStatus.valueOf("ACTIVE"));
        assertEquals(MetaDataStatus.COMPLETE, MetaDataStatus.valueOf("COMPLETE"));
        assertEquals(MetaDataStatus.ERROR, MetaDataStatus.valueOf("ERROR"));
    }
}