package com.optum.fds.paperless.util;

import static org.junit.Assert.*;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;

public class HttpUtilsTest {

    @Test
    public void testValidateStatusCode_InternalServerError() {
        HttpStatusCode statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        assertTrue(HttpUtils.validateStatusCode(statusCode));
    }

    @Test
    public void testValidateStatusCode_BadGateway() {
        HttpStatusCode statusCode = HttpStatus.BAD_GATEWAY;
        assertTrue(HttpUtils.validateStatusCode(statusCode));
    }

    @Test
    public void testValidateStatusCode_ServiceUnavailable() {
        HttpStatusCode statusCode = HttpStatus.SERVICE_UNAVAILABLE;
        assertTrue(HttpUtils.validateStatusCode(statusCode));
    }

    @Test
    public void testValidateStatusCode_GatewayTimeout() {
        HttpStatusCode statusCode = HttpStatus.GATEWAY_TIMEOUT;
        assertTrue(HttpUtils.validateStatusCode(statusCode));
    }

    @Test
    public void testValidateStatusCode_OtherStatus() {
        HttpStatusCode statusCode = HttpStatus.OK;
        assertFalse(HttpUtils.validateStatusCode(statusCode));
    }
}