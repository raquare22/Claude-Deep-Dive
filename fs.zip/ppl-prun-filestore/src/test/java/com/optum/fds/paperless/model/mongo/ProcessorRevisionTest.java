package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

public class ProcessorRevisionTest {

    private ProcessorRevision processorRevision;

    @Before
    public void setUp() {
        processorRevision = new ProcessorRevision();
    }

    @Test
    public void testGetSetConfigSpaceId() {
        int configSpaceId = 123;
        processorRevision.setConfigSpaceId(configSpaceId);
        assertEquals(configSpaceId, processorRevision.getConfigSpaceId());
    }

    @Test
    public void testGetSetEndDate() {
        Date endDate = new Date();
        processorRevision.setEndDate(endDate);
        assertEquals(endDate, processorRevision.getEndDate());
    }

    @Test
    public void testGetSetProcess() {
        Map<String, Object> process = Map.of("key", "value");
        processorRevision.setProcess(process);
        assertEquals(process, processorRevision.getProcess());
    }

    @Test
    public void testGetSetStartDate() {
        Date startDate = new Date();
        processorRevision.setStartDate(startDate);
        assertEquals(startDate, processorRevision.getStartDate());
    }

    @Test
    public void testGetSetErrors() {
        List<String> errors = List.of("Error1", "Error2");
        processorRevision.setErrors(errors);
        assertEquals(errors, processorRevision.getErrors());
    }
}