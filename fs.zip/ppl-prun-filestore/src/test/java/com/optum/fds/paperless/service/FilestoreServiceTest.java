package com.optum.fds.paperless.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.web.multipart.MultipartFile;

public class FilestoreServiceTest {

    private FilestoreService filestoreService;
    private MultipartFile file;

    @Before
    public void setUp() {
        filestoreService = mock(FilestoreService.class);
        file = mock(MultipartFile.class);
    }

    @Test
    public void testSaveFileToIngest() {
        String fileName = "testFile.txt";
        String spaceId = "space123";
        String expectedResponse = "File saved successfully";

        when(filestoreService.saveFileToIngest(anyString(), any(), anyString(), anyString())).thenReturn(expectedResponse);

        String actualResponse = filestoreService.saveFileToIngest(fileName, file, spaceId, "optumcid");
        assertEquals(expectedResponse, actualResponse);

        verify(filestoreService).saveFileToIngest(fileName, file, spaceId,"optumcid");
    }

    @Test
    public void testProcessFileUpload() {
        String fileName = "testFile.txt";
        String spaceId = "space123";
        String expectedResponse = "File processed successfully";

        when(filestoreService.processFileUpload(anyString(), any(), anyString(), anyString())).thenReturn(expectedResponse);

        String actualResponse = filestoreService.processFileUpload(fileName, file, spaceId, "optumcid");
        assertEquals(expectedResponse, actualResponse);

        verify(filestoreService).processFileUpload(fileName, file, spaceId,"optumcid");
    }
}