package com.optum.fds.paperless.model.mongo;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class ProcessingMetricsCoreTest {

    private ProcessingMetricsCore processingMetricsCore;

    @Before
    public void setUp() {
        processingMetricsCore = new ProcessingMetricsCore();
    }

    @Test
    public void testGetSetTotalRunTime() {
        processingMetricsCore.setTotalRunTime(1000L);
        assertEquals(Long.valueOf(1000), processingMetricsCore.getTotalRunTime());
    }

    @Test
    public void testGetSetTotalBytes() {
        processingMetricsCore.setTotalBytes(5000L);
        assertEquals(Long.valueOf(5000), processingMetricsCore.getTotalBytes());
    }

    @Test
    public void testGetSetBytesProcessed() {
        processingMetricsCore.setBytesProcessed(3000L);
        assertEquals(Long.valueOf(3000), processingMetricsCore.getBytesProcessed());
    }

    @Test
    public void testGetSetErrorCount() {
        Map<Integer, Integer> errorCount = new HashMap<>();
        errorCount.put(404, 1);
        processingMetricsCore.setErrorCount(errorCount);
        assertEquals(errorCount, processingMetricsCore.getErrorCount());
    }

    @Test
    public void testIncrementErrorCodeCount() {
        Map<Integer, Integer> errorCount = new HashMap<>();
        errorCount.put(404, 1);
        processingMetricsCore.setErrorCount(errorCount);
        processingMetricsCore.incrementErrorCodeCount(404);
        assertEquals(Integer.valueOf(2), processingMetricsCore.getErrorCount().get(404));
    }
}