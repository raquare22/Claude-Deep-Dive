# Gradle Wrapper README

ESRO mandated in early 2025 that all jars, including `gradle-wrapper.jar`, cannot be committed to GitHub repos. See [their documentation](https://appsec.optum.com/blocking/jar-blocking) for more information. 

In this project, the gradle wrapper jar has been gitignored, and will be downloaded each time the CI pipeline runs. 

## Updating Gradle 

When updating Gradle with `gradle wrapper --gradle-version <version>`, you'll need to re-insert these download instructions into [`gradlew`](../../gradlew). See [this example](https://github.com/uhc-tech-community-state-data/oc-security-gradle-wrapperless-example/blob/e1b775b50dc0bd340b31a42769806381874d64cb/gradlew#L117-L135) of where this block of code must be inserted. 

## Updating Gradle For JFrog SaaS

In order to use a gradle wrapper, you will need to update the [`gradle-wrapper.properties`](./gradle-wrapper.properties) file. This file needs to have the `distributionUrl` to be updated to point at the corresponding Gradle version from [https\://edgeinternal1uhg.optum.com/artifactory/glb-gradle-distributions-rem/](https\://edgeinternal1uhg.optum.com/artifactory/glb-gradle-distributions-rem/).

```
distributionUrl=https\://edgeinternal1uhg.optum.com/artifactory/glb-gradle-distributions-rem/distributions/gradle-8.14.2-bin.zip
```

### Updating the Gradlew Script

Gradle wrapper jars can be pulled from JFrog SaaS. In order to pull a gradle wrapper jar from JFrog SaaS, you'll need to pass in a username and password for authentication. If you are using the [java-gradle-ci reusable workflow](https://github.com/uhg-pipelines/ci-workflows/blob/main/docs/java-gradle-ci.md), this is already automatically done for you using OIDC authentication. 

Because `jar` files are not allowed to be stored in GitHub, you will have to add a script to your `gradlew` file that will pull the `gradle-wrapper.jar` from artifactory, just before the gradle build. The following script will change the version being downloaded here, to whatever version of Gradle you are updating to. A complete list of versions is available at [https://edgeinternal1uhg.optum.com/artifactory/glb-generic-github-rem/gradle/gradle/raw/refs/tags/](https://edgeinternal1uhg.optum.com/artifactory/glb-generic-github-rem/gradle/gradle/raw/refs/tags/). This block of code pulls the gradle wrapper jar from the edgeinternal artifactory server while using the `JFROG_USERNAME` and `JFROG_PASSWORD` environment variables for authentication.

This will use either the `jf` cli, `curl` or `wget`, depending on what is installed on the machine that the gradle wrapper is building on. It also automatically extracts the version from the `distributionURL` of the `gradle-wrapper.properties` file, which makes it easier because then you only have to define the version in the `gradle-wrapper.properties` file. Then it also sets the gradle wrapper username and password in the `JAVA_OPTS` environment variable as well, so that you don't have to set that manually either.

```bash
# Download gradle-wrapper.jar from Artifactory if it does not exist
if [ ! -f "$APP_HOME/gradle/wrapper/gradle-wrapper.jar" ]; then
  echo "Downloading gradle-wrapper.jar from Artifactory..."

  gradle_version=$(grep distributionUrl gradle/wrapper/gradle-wrapper.properties | sed -E 's/.*gradle-([0-9]+\.[0-9]+\.[0-9]+)-bin\.zip/\1/')
  echo "Gradle version: $gradle_version"

  artifactory_url="https://edgeinternal1uhg.optum.com/artifactory"
  artifactory_location="glb-generic-github-rem-cache/gradle/gradle/raw/refs/tags/v${gradle_version}/gradle/wrapper/gradle-wrapper.jar"
  gradle_url="${artifactory_url}/${artifactory_location}"
  echo "Gradle download url: ${gradle_url}"

  if command -v jf >/dev/null 2>&1; then
    if jf c show jfrog-core-edge >/dev/null 2>&1; then
      server_id="jfrog-core-edge"
    elif jf c show jf-edge >/dev/null 2>&1; then
      server_id="jf-edge"
    else
      echo "jfrog config does not exist"
      exit 1
    fi

    echo "Using jf server: ${server_id} to download gradle-wrapper.jar"
    jf rt dl --url="${artifactory_url}" --server-id="${server_id}" --user="${JFROG_USERNAME}" --access-token="${JFROG_PASSWORD}" "${artifactory_location}" --flat=true "$APP_HOME/gradle/wrapper/gradle-wrapper.jar" || die "Failed to download gradle-wrapper.jar using jf"
  elif command -v curl >/dev/null 2>&1; then
    echo "Using curl to download gradle-wrapper.jar"
    curl -u"${JFROG_USERNAME}:${JFROG_PASSWORD}" -o "$APP_HOME/gradle/wrapper/gradle-wrapper.jar" "${gradle_url}" || die "Failed to download gradle-wrapper.jar using curl"
  elif command -v wget >/dev/null 2>&1; then
    echo "Using wget to download gradle-wrapper.jar"
    wget --user="${JFROG_USERNAME}" --password="${JFROG_PASSWORD}" -O "$APP_HOME/gradle/wrapper/gradle-wrapper.jar" "${gradle_url}" || die "Failed to download gradle-wrapper.jar using wget"
  else
    die "Neither curl nor wget is available. Please install one of them to proceed."
  fi
fi

# If env vars are set, add as JVM args
if [ -n "$JFROG_USERNAME" ]; then
  JAVA_OPTS="$JAVA_OPTS -Dgradle.wrapperUser=$JFROG_USERNAME"
fi
if [ -n "$JFROG_PASSWORD" ]; then
  JAVA_OPTS="$JAVA_OPTS -Dgradle.wrapperPassword=$JFROG_PASSWORD"
fi

CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar
```

If you are trying to build your gradle application locally and you need to pull the gradle jar file, please follow [this local set up instructions](https://github.com/uhg-pipelines/ci-workflows-demos/blob/main/products/java-gradle/ARTIFACTORY_GRADLE_SETUP.md) before proceeding. You will need the `JFROG_USERNAME` and `JFROG_PASSWORD` environment variables set in order to pull that wrapper jar file locally.

When using this gradle wrapper jar with the `epl-gradle/build-scan` action, the `epl-jf/saas-setup` action step must run beforehand, and then the OIDC user and access token must be passed in as the `jfrog-username` and `jfrog-password` parameters. Here’s [example documentation](https://github.com/uhg-pipelines/epl-gradle/tree/main/build-scan#example-usage-for-jfrog-saas) that illustrates this.


## Updating Gradle For Repo1

Gradle wrapper jars can also be pulled from repo1. The configurations are very similar to the above, with only minor differences. 

Change the version being downloaded here to whatever version of Gradle you are updating to. A complete list of versions is available at [https://repo1.uhc.com/artifactory/github-generic/gradle/gradle/raw/refs/tags/](https://repo1.uhc.com/artifactory/github-generic/gradle/gradle/raw/refs/tags/). 

```bash
GRADLE_WRAPPER_URL="https://repo1.uhc.com/artifactory/github-generic/gradle/gradle/raw/refs/tags/v8.7.0/gradle/wrapper/gradle-wrapper.jar"

for attempt in 1 2 3; do
    if [ ! -e "$APP_HOME/gradle/wrapper/gradle-wrapper.jar" ]; then
        if ! curl --retry 3 -L -o "$APP_HOME/gradle/wrapper/gradle-wrapper.jar" "$GRADLE_WRAPPER_URL"; then
            rm -f "$APP_HOME/gradle/wrapper/gradle-wrapper.jar"
            # Pause for a bit before looping in case the server throttled us.
            sleep 5
            if [ $attempt -eq 3 ]; then
                echo "ERROR: Failed to download gradle-wrapper.jar after 3 attempts."
                exit 1
            fi
            continue
        else
            echo "SUCCESS: gradle-wrapper.jar downloaded successfully."
            break
        fi
    fi
done
```

Additionally, [`gradle-wrapper.properties`](./gradle-wrapper.properties) needs to be updated to point at the corresponding Gradle version from [https://repo1.uhc.com/artifactory/services-gradle/](https://repo1.uhc.com/artifactory/services-gradle/).