# Configuring a Gradle Project to Use Artifactory SaaS

This guide provides instructions on how to configure a Gradle project to use Artifactory SaaS (also known as Enterprise Registry).

## Prerequisites

Ensure you have the following environment variables set:
- `JFROG_USERNAME`
- `JFROG_PASSWORD`
- `JFROG_PROJECT_KEY`
- `JFROG_BUILD_NAME`
- `JFROG_BUILD_NUMBER`

When using an EPL Action or Workflow these will be set automatically.  

### Local Development 

#### Setting up the JFrog Servers

You will need to install the `jf` CLI to follow this process. Follow the directions from https://jfrog.com/getcli/.

To set up the central and edge nodes for use on a local environment within the UHG network, run the following commands.  You will be prompted to login via your browser.

```sh
  jf config add jf-central --url https://centraluhg.jfrog.io
  jf config add jf-edge --url https://edgeinternal1uhg.optum.com
```

Locally, you can use [the script found in ci-workflows-demos](https://github.com/uhg-pipelines/ci-workflows-demos/blob/main/products/java-gradle/set_gradle_jfrog_env.sh) to set your environment or do it manually.

An example of the command you would call to set 

```sh
chmod +x ./set_gradle_jfrog_env.sh
. ./set_gradle_jfrog_env.sh jf-central your-project-key
```

## Configuring Your `settings.gradle` for Plugin Resolution

Your `settings.gradle` should look something like the following file.  Replace APP_NAME with the name of your Gradle project/artifact.

```groovy
pluginManagement {
    repositories {
        maven {
            url = uri('https://edgeinternal1uhg.optum.com/artifactory/glb-gradle-plugins-rem-cache/')
            credentials {
                username = System.getenv("JFROG_USERNAME")
                password = System.getenv("JFROG_PASSWORD")
            }
        }
    }
}
rootProject.name = 'APP_NAME'
```

## Configuring Your `build.gradle`

### Version and Group

You should have both a `version` and `group` defined within your `build.gradle` to provide the Artifactory plugin the necessary information for deploying your artifact(s).  If you wish to use the `gradle-deploy-version` override from the `java-gradle-ci` workflow, you should specify your version as follows:

```groovy
  version = findProperty 'newVersion' ?: '1.0.0' # 1.0.0 is just an example, replace with your default version
```

### Plugins

Add the following plugins to your `build.gradle` file:

```groovy
plugins {
    id 'jacoco'
    id 'com.jfrog.artifactory' version '5.2.5'
    id 'maven-publish'
}
```

### SonarQube Support
```groovy
jacocoTestReport {
    reports {
        xml.required = true
    }
}

test {
    useJUnitPlatform()
}

test.finalizedBy jacocoTestReport

tasks.named('sonarqube').configure {
    dependsOn test
}
```

### Artifactory Publishing Support

Add the following to support publishing your Gradle artifacts to Artifactory:

```groovy
publishing {
    publications {
        mavenJava(MavenPublication) {
            from components.java
            version version
            groupId group
        }
    }
}

artifactory {
    publish {
        // Define the Artifactory URL for publishing artifacts
        contextUrl = 'https://centraluhg.jfrog.io/artifactory'
        // Define the project repository to which the artifacts will be published
        repository {
            releaseRepoKey = "${System.getenv('JFROG_PROJECT_KEY')}-maven-np-releases-loc"
            snapshotRepoKey = "${System.getenv('JFROG_PROJECT_KEY')}-maven-np-snapshots-loc"
            username = System.getenv('JFROG_USERNAME')
            password = System.getenv('JFROG_PASSWORD')
        }
        // Include all configured publications for all the modules
        defaults {
            publications('ALL_PUBLICATIONS')
        }
        publishBuildInfo = true
        buildInfo {
            // Set specific build and project information for the build-info
            buildName = "${System.getenv('JFROG_BUILD_NAME')}-gradle"
            buildNumber = System.getenv('JFROG_BUILD_NUMBER')
            project = System.getenv('JFROG_PROJECT_KEY')
        }
    }
}
```

### Dependency Resolution

To allow your gradle project to resolve both SNAPSHOT and release dependencies from Artifactory SaaS, add the following:

```groovy

repositories {
    maven {
        url = "https://edgeinternal1uhg.optum.com/artifactory/${System.getenv('JFROG_PROJECT_KEY')}-maven-releases-vir"
        credentials {
            username = System.getenv('JFROG_USERNAME')
            password = System.getenv('JFROG_PASSWORD')
        }
    }
    maven {
        url = "https://edgeinternal1uhg.optum.com/artifactory/${System.getenv('JFROG_PROJECT_KEY')}-maven-snapshots-vir"
        credentials {
            username = System.getenv('JFROG_USERNAME')
            password = System.getenv('JFROG_PASSWORD')
        }
    }
}
```
