package com.uhg.epl.APP_NAME;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;

import static org.assertj.core.api.Assertions.assertThat;
/**
 * This test asserts the behavior of this application.
 * This test starts the application and listens for a
 * connection (as it would in production).
 * and then sends an HTTP request and asserts the response.
 */
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HttpRequestTest {
    /**
     * The port of the application to test.
     */
    @LocalServerPort
    private int port;
    /**
     * The test rest template.
     */
    @Autowired
    private TestRestTemplate restTemplate;
    /**
     * The test that confirms the application receives HTTP requests.
     * @throws Exception If an error occurs while performing
     *             the test.
     */
    @Test
    public void greetingShouldReturnDefaultMessage()
        throws Exception {
        assertThat(this.restTemplate.getForObject(
            "http://localhost:" + port + "/healthz",
            String.class)).contains("OK");
    }
}
