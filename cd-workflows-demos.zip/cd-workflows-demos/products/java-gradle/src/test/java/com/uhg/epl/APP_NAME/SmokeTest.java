package com.uhg.epl.APP_NAME;

import com.uhg.epl.APP_NAME.controller.HealthController;
import com.uhg.epl.APP_NAME.model.Health;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

/**
 * Verify that the context is creating the controller.
 */
@SpringBootTest
public class SmokeTest {
    /**
     * The HealthController to test.
     */
    @Autowired
    private HealthController controller;
    /**
     * Tests that the HealthController returns a valid health message.
     * @throws Exception If an error occurs while performing
     *             the test.
     */
    @Test
    public void contextLoads() throws Exception {
        assertThat(controller).isNotNull();
    }
    /**
     * Tests that the setMsg() returns a valid value.
     * @throws Exception If an error occurs while performing
     *             the test.
     */
    @Test
    public void constructure_setMsg() throws Exception {
        final String message = "dog";
        Health health = new Health();
        health.setMsg(message);
        assertEquals(health.getMsg(), message);
    }
    /**
     * Tests that the setProject() returns a valid value.
     * @throws Exception If an error occurs while performing
     *             the test.
     */
    @Test
    public void constructure_setProject() throws Exception {
        final String message = "dog";
        Health health = new Health();
        health.setProject(message);
        assertEquals(health.getProject(), message);
    }
    /**
     * Tests that the setStatus() returns a valid value.
     * @throws Exception If an error occurs while performing
     *             the test.
     */
    @Test
    public void constructure_setStatus() throws Exception {
        final HttpStatus status = HttpStatus.OK;
        Health health = new Health();
        health.setStatus(status);
        assertEquals(health.getStatus(), status);
    }

}
