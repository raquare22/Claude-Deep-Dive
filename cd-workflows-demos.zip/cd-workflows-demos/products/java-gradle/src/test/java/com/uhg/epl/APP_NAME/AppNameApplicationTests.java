/**
 * The QualityMeasurementSampleApplicationTests class contains JUnit tests
 * for the QualityMeasurementSampleApplication class.
 */
package com.uhg.epl.APP_NAME;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppNameApplicationTests {
    /**
     * Tests that the Spring context loads successfully.
     */
    @Test
    void contextLoads() {
        // This is just a sample test case for demos
    }
}
