/**
 * The HealthService class is called by the HealthController. It
 * returns a returns simple message indicating that the service is healthy.
 */
package com.uhg.epl.APP_NAME.service;

import com.uhg.epl.APP_NAME.model.Health;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class HealthService {

    /**
     * @return a Health object containing simple message indicating
     *          that the service is healthy.
     */
    public ResponseEntity<Health> healthz() {
        Health health = new Health("testapi", "server is healthy",
            HttpStatus.OK);
        return new ResponseEntity<Health>(health, HttpStatus.OK);
    }
}
