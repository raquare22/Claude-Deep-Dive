/**
 * The HealthController class is a REST controller that handles requests for
 * the '/healthz' endpoint. It returns a simple message indicating that the
 * service is healthy.
 */
package com.uhg.epl.APP_NAME.controller;

import com.uhg.epl.APP_NAME.model.Health;
import com.uhg.epl.APP_NAME.service.HealthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HealthController {

    /**
     * healthService the health status that's returned.
     */
    @Autowired
    private HealthService healthService;

    /**
     * Takes the healthService and maps it to the /healthz path.
     * @return healthService.healthz() the health status that's returned
     */
    @GetMapping("/healthz")
    public ResponseEntity<Health> healthz() {
        return healthService.healthz();
    }
}
