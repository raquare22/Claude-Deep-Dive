/**
 * The Health class is a object class datastructure for the HealthService
 * class.
 */
package com.uhg.epl.APP_NAME.model;
import org.springframework.http.HttpStatus;

public class Health {
    /**
     * The message of the health status.
     */
    private String msg;
    /**
     * The project of the health status.
     */
    private String project;
    /**
     * The http status of the health status.
     */
    private HttpStatus status;
    /**
     * This method is the public constructor for the Health class data
     * structure. Parameters passed in will be assigned
     * to the newly constructed instance of the class.
     * @param pMsg - the message of the Health class
     * @param pProject - the project of the Health class
     * @param pStatus - the http status of the Health response
     */
    public Health(final String pMsg, final String pProject,
        final HttpStatus pStatus) {
        this.msg = pMsg;
        this.project = pProject;
        this.status = pStatus;
    }
    /**
     * This method is the no argument default public constructor for the Health
     * class data structure.
     */
    public Health() {
    }
    /**
     * @return the message of the Health object
     */
    public String getMsg() {
        return msg;
    }
    /**
     * Sets the message value.
     * @param pMsg - the message of the Health class
     */
    public void setMsg(final String pMsg) {
        this.msg = pMsg;
    }
    /**
     * @return the project of the Health object
     */
    public String getProject() {
        return project;
    }
    /**
     * Sets the project value.
     * @param pProject - the project of the Health class
     */
    public void setProject(final String pProject) {
        this.project = pProject;
    }
    /**
     * @return the http status of the Health object
     */
    public HttpStatus getStatus() {
        return status;
    }
    /**
     * Sets the http status value.
     * @param pStatus - the http status of the Health response
     */
    public void setStatus(final HttpStatus pStatus) {
        this.status = pStatus;
    }
}
