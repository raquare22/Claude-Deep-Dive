/**
 * The AppNameApplication class is the entry point for the
 * application. It uses the Spring Boot framework to start the application
 * and configure the necessary components.
 */
package com.uhg.epl.APP_NAME;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SuppressWarnings("checkstyle:hideutilityclassconstructor")
@SpringBootApplication
class AppNameApplication {
    /**
     * The main method is the entry point for the application.
     * It starts the Spring Boot application by calling
     * SpringApplication.run() method.
     * @param args The command line arguments passed to the application.
     */
    public static void main(final String[] args) {
        SpringApplication.run(AppNameApplication.class, args);
    }
}
