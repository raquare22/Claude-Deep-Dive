# Java Gradle CI Demo

* The Java Gradle demo workflow lives in the `.github/workflows` directory of this repository [here](https://github.com/uhg-pipelines/ci-workflows-demos/blob/main/.github/workflows/java-gradle-ci-demo.yml).
* View [`ci-workflows/.github/workflows/java-gradle-ci.yml` here](https://github.com/uhg-pipelines/ci-workflows/blob/main/.github/workflows/java-gradle-ci.yml).
* For workflow setup and more in-depth information on the Java Gradle CI workflow, please see the setup documentation [here](https://github.com/uhg-pipelines/ci-workflows/blob/main/docs/java-gradle-ci.md).

---

## Example Java Gradle App Implementing EPL Actions

A Java API application using the [Java Spring Boot Framework](https://docs.spring.io/spring-boot/docs/current/reference/htmlsingle/#getting-started), [Gradle](https://docs.gradle.org/current/userguide/getting_started.html), and [EPL GitHub Actions](https://github.com/optum-eeps/epl-actions).

[![CI](https://github.com/optum-eeps/epl-example-java-gradle-app-actions/actions/workflows/main.yml/badge.svg)](https://github.com/optum-eeps/epl-example-java-gradle-app-actions/actions/workflows/main.yml)

Example Version 0.1.2!

## Run Application Locally

### Requirements

* Java 17

### Installing the Project

* `git clone https://github.com/uhg-pipelines/ci-workflows-demos`
* `cd ci-workflows-demos/products/java-gradle`

### Building the App

```bash
./gradlew build
```

### Running the App

```bash
./gradlew bootRun
```

### Health Check Endpoint

```bash
curl http://localhost:8080/healthz
```

### Directory Structure

```text
APP_NAME
├── .github
│   ├── workflows
│   │   └── main.yml
│   │   └── mega-linter.yml
│   └── linters
│       ├── actionlint.yml
│       └── google-checkstyle-rules.xml
├── src
│   ├── main
│   │   ├── resources
│   │   │   └── application.properties
│   │   └── java/APP_NAME
│   │            └── application
│   │                ├── controller
│   │                ├── service
│   │                ├── model
│   │                └── AppNameApplication.java
│   └── test/java/com/optum/APP_NAME
│                           ├── AppNameApplicationTests.java
│                           ├── HttpRequestTestjava
│                           └── SmokeTest.java
├── README.md
├── build.gradle
├── settings.gradle
├── gradlew
└── .mega-linter.yml
```
