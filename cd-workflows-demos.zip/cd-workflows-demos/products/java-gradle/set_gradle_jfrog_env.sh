#!/bin/bash

# Check if the server ID and project key are provided
if [ -z "$1" ] || [ -z "$2" ]; then
  echo "Usage: $0 <server-id> <project-key>"
  exit 1
fi

SERVER_ID=$1
PROJECT_KEY=$2

# Export the configuration for the provided server ID
config_output=$(jf config export "$SERVER_ID")

# Base64 decode the output
decoded_output=$(echo "$config_output" | base64 --decode)

# Extract user and accessToken from the decoded JSON
JFROG_USERNAME=$(echo "$decoded_output" | jq -r '.user')
JFROG_PASSWORD=$(echo "$decoded_output" | jq -r '.accessToken')

# Set the environment variables
export JFROG_USERNAME
export JFROG_PASSWORD
export JFROG_PROJECT_KEY=$PROJECT_KEY

# Print the environment variables to verify
echo "JFROG_USERNAME: $JFROG_USERNAME"
echo "JFROG_PASSWORD: [hidden]"
echo "JFROG_PROJECT_KEY: $JFROG_PROJECT_KEY"

