# Test Helm App

A simple Helm chart for testing the `epl-helm/upgrade-install` action.

## Chart Structure

```
test-app/
├── Chart.yaml           # Chart metadata
├── values.yaml          # Default configuration values
└── templates/
    ├── deployment.yaml  # Kubernetes Deployment
    └── service.yaml     # Kubernetes Service
```

## Testing Locally

```bash
# Validate the chart
helm lint ./test-app

# Dry run to see rendered templates
helm install test-release ./test-app --dry-run --debug

# Install the chart
helm install test-release ./test-app -n default

# Upgrade the chart
helm upgrade test-release ./test-app -n default

# Uninstall
helm uninstall test-release -n default
```

## Testing with epl-helm/upgrade-install Action

```yaml
- name: Deploy Test App
  uses: uhg-pipelines/epl-helm/upgrade-install@v2
  with:
    release-name: test-app
    namespace: default
    environment: dev
    chart-folder: ./helm/test-app
    kube-config: ${{ secrets.KUBE_CONFIG }}
```

## Customizing Values

Override values during deployment:

```yaml
- name: Deploy with Custom Values
  uses: uhg-pipelines/epl-helm/upgrade-install@v2
  with:
    release-name: test-app
    namespace: default
    chart-folder: ./helm/test-app
    kube-config: ${{ secrets.KUBE_CONFIG }}
    image-tag: "1.22"
    inline-values: |
      replicaCount=2
      service.type=LoadBalancer
```

## Resources

- Deploys a simple nginx container
- Creates a ClusterIP service
- Configurable via values.yaml
