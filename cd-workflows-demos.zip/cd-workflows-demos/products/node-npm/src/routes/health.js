import express from 'express'
import { appHealth } from '../services/healthService.js'

const router = express.Router()

router.get('/healthz', (req, res) => res.status(200).json(appHealth()))

export default router
