import { appHealth } from '../services/healthService'

describe('App health', () => {
  it('should return app health', () => {
    const expected = {
      project: 'example-node-app',
      status: 200,
      msg: 'server is healthy!'
    }

    const health = appHealth()
    expect(health).toEqual(expect.objectContaining(expected))
  })
})
