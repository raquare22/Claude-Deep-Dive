export function appHealth () {
  const health = {
    project: 'example-node-app',
    status: 200,
    date: Date.now(),
    msg: 'server is healthy!'
  }
  return health
}
