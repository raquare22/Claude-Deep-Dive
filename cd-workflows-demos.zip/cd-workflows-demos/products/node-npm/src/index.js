import express from 'express'
import dotenv from 'dotenv'
import healthRoute from './routes/health.js'
dotenv.config()

const app = express()

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.use('/', healthRoute)

const port = parseInt(process.env.PORT) || 8080
app.listen(port, () => console.log(`Server is running on port: ${port}`))
