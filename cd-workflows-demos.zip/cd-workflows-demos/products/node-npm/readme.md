# Node NPM Demo

* The Node NPM demo workflow lives in the `.github/workflows` directory of this repository [here](https://github.com/uhg-pipelines/ci-workflows-demos/blob/main/.github/workflows/node-npm-ci-demo.yml).
* View [`ci-workflows/.github/workflows/node-npm-ci.yml` here](https://github.com/uhg-pipelines/ci-workflows/blob/main/.github/workflows/node-npm-ci.yml).
* For workflow setup and more in-depth information on the Java Maven CI workflow, please see the setup documentation [here](https://github.com/uhg-pipelines/ci-workflows/blob/main/docs/node-npm-ci.md).



## Prerequisites

- `jf` CLI - [Installation instructions](https://jfrog.com/getcli/)
- `npm`
- `git`

To set up and start the Node NPM example app, follow these steps:

1. **Clone the repository**:

    ```sh
    git clone https://github.com/uhg-pipelines/ci-workflows-demos.git
    cd ci-workflows-demos/products/node-npm
    ```

2. **Configure Artifactory connection**:
   
   If you haven't configured the Artifactory connection on your local machine:
   ```sh
   jf config add jf-central --url https://centraluhg.jfrog.io #This adds the central server for scans and deployment
   jf config add jf-edge --url https://edgeinternal1uhg.optum.com
   ```

   To configure your npm project to use Artifactory.  Replace PROJECT_KEY with your Artifactory Project key:
   ```sh
   PROJECT_KEY=yourprojectkey; \
   jf npm-config \
     --server-id-resolve jf-edge \
     --repo-resolve $PROJECT_KEY-npm-vir \
     --server-id-deploy jf-central \
     --repo-deploy $PROJECT_KEY-npm-np-loc
   ```
   

4. **Install dependencies and unit test**:

    ```sh
    jf npm install
    jf npm run test
    ```
    

5. **Start the application in development mode**:

    ```sh
    jf npm run start:dev
    ```

6. **Start the application in production mode**:

    ```sh
    jf npm run start
    ```

Make sure you have [Node.js](https://nodejs.org/) installed on your machine.
