# CD Workflows Demos

This repository features a collection of demos for the [`cd-workflows`](https://github.com/uhg-pipelines/cd-workflows-demos) repository, created by the Immerse team.

The demo workflows live in the `.github/workflows` directory, and the demo application code live in the `products` directory of this repository.

These demos use starter workflows from [CI workflows](https://github.com/uhg-pipelines/ci-workflows) and are attached to deployments via [Immerse Deployments](https://immerse.uhg.com/deployments).

For examples of workflows using other languages, see [CI Workflows Demos](https://github.com/uhg-pipelines/ci-workflows)

## Demos

| **Starter Workflow** | **Demo** | **Runs** |
|---|---|---|
| [Java Lambda CD Workflow](.github/workflows/java-aws-lambda-cd-demo.yml) | [Java Lambda CD Demo](products/java-lambda/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/java-aws-lambda-cd-demo.yml) |
| [Node AWS EKS CD Workflow](.github/workflows/java-aws-lambda-cd-demo.yml) | [Node NPM CD Demo](products/node-npm/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-aws-eks-cd-demo.yml) |
| [Node AWS Fargate CD Workflow](.github/workflows/node-aws-fargate-cd-demo.yml) | [Node NPM CD Demo](products/node-npm/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-aws-fargate-cd-demo.yml) |
| [Node AWS S3 CD Workflow](.github/workflows/node-aws-s3-cd-demo.yml) | [Node Static CD Demo](products/node-docusaurus/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-aws-s3-cd-demo.yml) |
| [Node Azure ACI CD Workflow](.github/workflows/node-azure-aci-cd-demo.yml) | [Node NPM CD Demo](products/node-npm/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-azure-aci-cd-demo.yml) |
| [Node Azure Blob CD Workflow](.github/workflows/node-azure-blob-cd-demo.yml) | [Node Static CD Demo](products/node-docusaurus/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-azure-blob-cd-demo.yml) |
| [Node Azure Static Webapp CD Workflow](.github/workflows/node-azure-static-cd-demo.yml) | [Node Static CD Demo](products/node-docusaurus/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-azure-static-cd-demo.yml) |
| [Node Azure Webapp CD Workflow](.github/workflows/node-azure-webapp-cd-demo.yml) | [Node NPM CD Demo](products/node-npm/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-azure-webapp-cd-demo.yml) |
| [Node HCC K8s CD Workflow](.github/workflows/node-hcc-k8s-cd-demo.yml) | [Node NPM CD Demo](products/node-npm/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-hcc-k8s-cd-demo.yml) |
| [Node OOSS CD Workflow](.github/workflows/node-ooss-cd-demo.yml) | [Node Static CD Demo](products/node-docusaurus/) | [Workflow Runs](https://github.com/uhg-pipelines/cd-workflows-demos/actions/workflows/node-ooss-cd-demo.yml) |

## Viewing Deployment Demos

- The key difference here is that each starter workflow uses the `webhook-api-url: immerse-cloud.uhg.com/api/actions/deployments/deploy` input to call Immerse's deployment API.

- All deployments are managed in the uhg-config-repos org. The repo containing deployments for this repository is: https://github.com/uhg-config-repos/uhgwm110-026366-cHJvZDpkZWZhdWx0 

- To view the deployment associated with a specific workflow run, open up the workflow. You can find the link to the workflow run in your config repo in the workflow summary. Click **View Logs** to view the run.
![Deployment Summary](/docs/images/deployment-summary.png)
Alternatively, you can open up the **Trigger Build Completion Webhook** step and view the status of your deployment as it is deploying. Click `deploymentURL` to view the run.
![Webhook Summary](/docs/images/webhook-summary.png)
