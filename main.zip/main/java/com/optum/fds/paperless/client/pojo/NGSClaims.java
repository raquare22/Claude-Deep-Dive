package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.CustomizeDateDeserializer;
import com.optum.fds.paperless.client.ErrorMessage;

import java.io.Serial;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class NGSClaims extends ClientMetadata {

    @Serial
    private static final long serialVersionUID = 4152993441880407752L;

    @JsonProperty("ngsId")
    @JsonAlias("NGSID")
    private String ngsId;

    @JsonProperty("subCategory")
    @JsonAlias("subCategory")
    private String subCategory;

    @JsonProperty("tin")
    @JsonAlias("TIN")
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("MPIN")
    private String mpin="";

    @JsonProperty("npi")
    @JsonAlias("NPI")
    private String npi;

    @JsonProperty("emailAlertReq")
    @JsonAlias("isPrintSuppressed")
    private String emailAlertReq;

    @JsonProperty("dateOfService")
    @JsonAlias("DateOFService")
    @JsonDeserialize(using = CustomizeDateDeserializer.class)
    @CustomDateFormat(dateFormat = "MM/dd/yyyy")
    private Date dateOfService;

    @JsonProperty("providerName")
    @JsonAlias("ProviderName")
    private String providerName;

    @JsonProperty("memberId")
    @JsonAlias("MemberID")
    private String memberId;

    @JsonProperty("memberName")
    @JsonAlias("MemberName")
    private String memberName;

    @JsonProperty("patientDOB")
    @JsonAlias("MemberDOB")
    private String patientDOB;

    @JsonProperty("policyNumber")
    @JsonAlias("GroupNumber")
    private String policyNumber;

    @JsonProperty("patientAccountNumber")
    @JsonAlias("PatientAccountNumber")
    private String patientAccountNumber;

    @JsonProperty("claimNumber")
    @JsonAlias("ClaimNumber")
    private String claimNumber;

    @JsonProperty("PassThruData")
    private String PassThruData;

    @JsonProperty("originalPrintTrail")
    private String originalPrintTrail;

    @JsonProperty("ConfigKey")
    private String CONFIGKEY;

    @JsonProperty("MailToAddress1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    private String MailToAddress4;
    
    @JsonProperty("MailToAddress5")
    private String MailToAddress5;
    
    @JsonProperty("MailToAddress6")
    private String MailToAddress6;

    public NGSClaims() {
        this.category = "Claim";
        this.fileDescription = "Claim Letter";
        this.fileType = "Letter";
        this.privilege = "Claim Status";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.tenant = "Link";
        this.subCategory = "RR";
        NGSClaims.Subcategory subCat = NGSClaims.Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
        this.expiryDate = calculateExpiryDate(createdDate); // Update expiryDate whenever createdDate is set
    }

    private String calculateExpiryDate(Date createdDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(createdDate);
        calendar.add(Calendar.MONTH, 24); // Add 24 months
        Date expiryDate = calendar.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return formatter.format(expiryDate);
    }
    public String getProviderName() {
        return providerName;
    }

    public String getTin() {return tin;}
    public String getMpin() {return mpin;}
    public String getNpi() {return npi;}
    public String getEmailAlertReq() {return emailAlertReq;}

    public String getNgsId() { return ngsId;}
    public String getSubCategory() { return subCategory;}
    public Date getDateOfService() { return dateOfService;}
    public String getMemberName() { return memberName;}
    public String getPatientDOB() { return patientDOB;}
    public String getPolicyNumber() { return policyNumber;}
    public String getMemberId() { return memberId;}
    public String getPatientAccountNumber() { return patientAccountNumber;}
    public String getClaimNumber() { return claimNumber;}
    public String getPassThruData() { return PassThruData;}
    public String getOriginalPrintTrail() { return originalPrintTrail;}
    public String getCONFIGKEY() { return CONFIGKEY;}
    public String getMailToAddress1() { return MailToAddress1;}
    public String getMailToAddress2() { return MailToAddress2;}
    public String getMailToAddress3() { return MailToAddress3;}
    public String getMailToAddress4() { return MailToAddress4;}

    public void setProviderName(String providerName) {
    	this.providerName = providerName;
    }
    public void setTin(String tin) { this.tin = tin;}
    public void setMpin(String mpin) {
        if(mpin != null){
            this.mpin = mpin;
        }
    }
    public void setNpi(String npi) {
        this.npi = npi;
    }
    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }
    public void setNgsId(String ngsId) {
        this.ngsId = ngsId;
    }
    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "RR";
            this.setFilePath(NGSClaims.Subcategory.RR.getFilePath());
        } else {
            this.subCategory = subCategory;
            Subcategory subCat = null;
            try {
                subCat = NGSClaims.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = Subcategory.RR;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }
    public void setDateOfService(Date dateOfService) {
        this.dateOfService = dateOfService;
    }
    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }
    public void setPatientDOB(String patientDOB) {
        this.patientDOB = patientDOB;
    }
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
    public void setPatientAccountNumber(String patientAccountNumber) {
        this.patientAccountNumber = patientAccountNumber;
    }
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }
    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }
    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }
    public void setCONFIGKEY(String cONFIGKEY) {
        CONFIGKEY = cONFIGKEY;
    }

    public void setMailToAddress1(String mailToAddress1) {
    	this.MailToAddress1 = mailToAddress1;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}
	



	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}




	public enum ErrorMsg implements ErrorMessage {

        CreatedDate (12, "Missing or invalid data: CreatedDate"),
        SubCategory (12, "Missing or invalid data: LETTERTYPE"),
        TIN (12, "Missing or invalid data: Provider TIN"),
        MPIN (12, "Missing or invalid data: ProviderMPIN"),
        NPI (12, "Missing or invalid data: NPI"),
        isPrintSuppressed(12, "Missing or invalid data: isPrintSuppressed"),
        MemberID (12, "Missing or invalid data: memberId"),
        PatientAccountNumber (12, "Missing or invalid data: patientAccountNumber"),
        ClaimNumber (12, "Missing or invalid data: Claim Number"),

        ProviderName (12, "Missing or invalid data: ProviderName"),
        PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"),//"emailAlertReq==\"Y\""
        originalPrintTrail (22, "Missing or invalid data: originalPrintTrail (SEVERE)"), //"emailAlertReq==\"Y\""
        ConfigKey (22, "Missing or invalid data: ConfigKey(SEVERE)"),
        MailToAddress1 (22, "Missing or invalid data: MailToAddress1 (SEVERE)"), // emailAlertReq == \"Y\"
        MailToAddress2 (22, "Missing or invalid data: MailToAddress2 (SEVERE)"), // emailAlertReq == \"Y\"
        MailToAddress4 (22, "Missing or invalid data: MailToAddress4 (SEVERE)"); // emailAlertReq == \"Y\"

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {
        // NGS Claims
        R1 ("R1", "Medicare/Action Required"),
        R2 ("R2", "Medicare/Claim Reconsideration"),
        R3 ("R3", "Medicare/Balance Billing"),
        R7 ("R7", "Medicare/Denials"),
        R8 ("R8", "Medicare/Approvals"),
        R9 ("R9", "Medicare/Please Review (FYI)"),
        R0 ("R0", "Medicare/Copy of Member Letters"),
        RR ("RR", "Medicare/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}
