/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2014.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When           Who           Why
 * Dec 25 2014    Vinata Gangolli	 Initial version
 ****************************************************************/

////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.domain.revision.AttachmentRevision;
import com.optum.fds.paperless.mongo.processors.MetaData;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

/**
 * The Mongo file metadata.
 */
@Document(collection = "attachment")
public class AttachmentMetaData extends MetaData {
    private static final long serialVersionUID = 1L;

    private String adapterId;
    private String adapterTypeId;
    private String adapterName;
    private String contentType;
    private Date expires;
    private String externalId;
    private long fileSize;
    private String fileName;
    private String fsId;
    boolean isAsync;
    private String stAdapterDocId;
    private String sourceSystemName;
    private Date sourceSystemDateCreated;
    private int spaceId;
    private String cloudSpaceId;
    private String attachmentId;

    private String doc360DocumentId;

    private String doc360DocClass;

    public String getDoc360DocumentId() {
        return doc360DocumentId;
    }

    public void setDoc360DocumentId(String doc360DocumentId) {
        this.doc360DocumentId = doc360DocumentId;
    }

    public String getDoc360DocClass() {
        return doc360DocClass;
    }

    public void setDoc360DocClass(String doc360DocClass) {
        this.doc360DocClass = doc360DocClass;
    }
    public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public String getCloudSpaceId() {
		return cloudSpaceId;
	}

	public void setCloudSpaceId(String cloudSpaceId) {
		this.cloudSpaceId = cloudSpaceId;
	}

	public AttachmentMetaData() {
        super();
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public boolean isAsync() {
        return isAsync;
    }

    public void setAsync(boolean isAsync) {
        this.isAsync = isAsync;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Date getExpires() {
        return expires == null ? null : (Date) expires.clone();

    }

    public void setExpires(Date expires) {
        this.expires = expires == null ? null : (Date) expires.clone();
    }

    public String getAdapterId() {
        return adapterId;
    }

    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    public String getAdapterName() {
        return adapterName;
    }

    public void setAdapterName(String adapterName) {
        this.adapterName = adapterName;

    }

    public String getFsId() {
        return fsId;
    }

    public void setFsId(String fsId) {
        this.fsId = fsId;
    }

    public String getStAdapterDocId() {
        return stAdapterDocId;
    }

    public void setStAdapterDocId(String stAdapterDocId) {
        this.stAdapterDocId = stAdapterDocId;
    }

    public String getAdapterTypeId() {
        return adapterTypeId;
    }

    public void setAdapterTypeId(String adapterTypeId) {
        this.adapterTypeId = adapterTypeId;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public Date getSourceSystemDateCreated() {
        return sourceSystemDateCreated == null ? null : (Date) sourceSystemDateCreated.clone();
    }

    public void setSourceSystemDateCreated(Date sourceSystemDateCreated) {
        this.sourceSystemDateCreated = sourceSystemDateCreated == null ? null : (Date) sourceSystemDateCreated.clone();
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(Integer spaceId) {
            this.spaceId = spaceId==null ? 0 : spaceId;
    }

    @Override
    public List<AttachmentRevision> getRevisions() {
        return revisions;
    }

}