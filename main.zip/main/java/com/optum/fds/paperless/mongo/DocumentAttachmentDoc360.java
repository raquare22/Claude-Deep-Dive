package com.optum.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;
import java.util.Arrays;

/**
 * POJO representing a Doc360 document attachment.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentAttachmentDoc360 implements Serializable {

    private static final long serialVersionUID = 1L;
    private String mimeType;
    private byte[] contentStream;
    private long contentLength;
    private String fileName;

    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMimeType() {
        return mimeType;
    }
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public byte[] getContentStream() {
        return contentStream;
    }
    public void setContentStream(byte[] contentStream) {
        this.contentStream = contentStream;
    }

    public long getContentLength() {
        return contentLength;
    }
    public void setContentLength(long contentLength) {
        this.contentLength = contentLength;
    }

@Override
public String toString() {
    return "DocumentAttachmentDoc360{" +
            "mimeType='" + mimeType + '\'' +
            ", contentLength=" + contentLength +
            ", fileName='" + fileName + '\'' +
            '}';
}
}
