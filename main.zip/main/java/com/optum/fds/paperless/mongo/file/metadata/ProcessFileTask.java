package com.optum.fds.paperless.mongo.file.metadata;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.optum.fds.paperless.template.java.impl.Doc360MetadataTemplate;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.optum.fds.paperless.client.ClientJson;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorErrorCode;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.processing.bean.Document;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.impl.FDSCloudSearchTermsTemplate;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorSummary;
import com.optum.fds.paperless.mongo.processors.ProcessorTargetType;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.ProcessorError;
import com.optum.fds.paperless.util.ProcessorTaskUtil;
import com.optum.fds.paperless.util.StringUtils;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorTransactionService;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.util.Parser;

import com.optum.fds.paperless.domain.service.SendQueueService;
import com.optum.fds.paperless.domain.service.TransactionService;

@Component
public class ProcessFileTask {
	
	@Value("${FDSRetentionPeriod}")
	protected Integer fDSRetentionPeriod;
	
	@Value("${FDSDocumentsUrl}")
	private String fDSDocumentsUrl;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessFileTask.class);
	private static final String OUTCOME_KEY = "outcome";
	private static final String ERROR_KEY = "error";	
	private static final String EXPIRY_DATE = "expiryDate";
	private static final String CREATED_DATE = "createdDate";
	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	private static final String IDENTIFIER = "ProcessFileTask";
	private static final String CALLBACK = "processMetadataFilesCallback";
	private static final String REST_API_CALLBACK = "callRestApiWithMsgServiceOnErrorCallback";
	private static final String PRE_REST_API_EXCEPTION = "REST_API: Exception spaceId={}, identifier={}, targetId={}, documentId={}, msg={}";
	private static final String REST_API_EXCEPTION = "REST_API: Exception sendRequestToQueue; spaceId={}, queue={}, identifier={}, targetId={}, documentId={}, msg={}";
	private static final String PRUN_DOCUMENT_ID = "prunDocumentId";

	private static final Gson gson = new GsonBuilder().setDateFormat(DATE_FORMAT).create();

	protected String schemaFileBasePath = File.separator + "schemas" + File.separator;

	@Autowired
	ObjectMapper mapper;

	@Autowired
	ProcessorService processorService;
	
	@Autowired
	ProcessorFileTaskService processorFileTaskService;
	
	@Autowired
	DocumentMetaDataService documentMetaDataService;

	@Autowired
	ErrorMetaDataService errorMetaDataService;

	@Autowired
	SendQueueService sendQueueService;
	
	@Autowired
	ProcessorTransactionService processorTransactionService;

	DelegateExecution tempExecution;
	
	@Autowired
	PostCardInd postCardInd; 
	
	@Autowired
	FDSCloudSearchTermsTemplate fdsCloudSearchTermsTemplate;

    @Autowired
    Doc360MetadataTemplate doc360MetadataTemplate;

    public void processFileTaskWithRequiredFields(DelegateExecution execution, ProcessorFileTask processorFileTask) {
		Objects.requireNonNull(processorFileTask);

		tempExecution = execution;
		
		LOGGER.info("ProcessFileTaskService -- processFileTaskWithRequiredFields -- ENTER processorFileTask id = {}", processorFileTask.getId());

        var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Initializing File Task variables");
		initProcessorFileTask(processorFileTask);
        if(isProcessFileTaskStatusFatalError(processorFileTask)){
        	addErrorCodeAndEndTime(processorFileTask,"initProcessorFileTask", ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS);
            return;
       }


        String filePath = processorFileTask.getLocation();
        Path location = Paths.get(filePath);
        LOGGER.info("ProcessFileTask -- processorFileTask location {} exists = {}", location, Files.exists(location));
        String pdfFilePath = filePath + File.separator + processorFileTask.getFileName();
        File fileToProcess = new File(location.toFile(), processorFileTask.getFileName());
        File metadataFile = new File(location.toFile(), Utilities.stripFileExtension(processorFileTask.getFileName())+".metadata");
        LOGGER.info("ProcessorFileTask->processFileTaskWithRequiredFields processorFileTaskId={}, fileName={}", processorFileTask.getId(), processorFileTask.getFileName());
        
        // Are the needed files present?
        checkIfFilesExist(processorFileTask, executionRecord, fileToProcess, metadataFile);
        if (isProcessFileTaskStatusFatalError(processorFileTask)) {
			LOGGER.error("processFileTaskWithRequiredFields -- Metadata file or pdf does not exist for ID{} and pdf{}", processorFileTask.getId(), processorFileTask.getFileName());
			return;
        }


        if(checkMetadataFileIsEmpty(processorFileTask, metadataFile, executionRecord)){
            return;
        }

        ProcessorTaskUtil.updateFileMetrics(processorFileTask, fileToProcess, processorFileTaskService);

        executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Parsing metadata file");
		HashMap<String,String> message = new HashMap<>();

		ProcessorMetaData pmd = processorService.getProcessorMetaData(processorFileTask.getProcessorId(), processorFileTask.getAppIdentifier());
        
        Set<String> errors = new HashSet<>();
        String clientName = (String) pmd.getProcessConfig().get("clientName");
        if (clientName == null || clientName.isEmpty()) {
        	LOGGER.error("processFileTaskWithRequiredFields: Parse metadata file failed; clientName={}", clientName);
        	message.put(OUTCOME_KEY, "Parse metadata file failed");
        	message.put(ERROR_KEY, "clientName missing in processor config");
        	updateDbWithProcessorError(processorFileTask, executionRecord, message, ProcessorErrorCode.MISSING_PROCESSOR_CONFIGURATION);
        	return;
        }

		JSONObject jsonMetadata = convertMetadata(processorFileTask, metadataFile, errors, clientName, executionRecord, message);
		if (jsonMetadata == null) {
			LOGGER.error("processFileTask fatal error while parsing metadata file; jsonMetadata == null");
        	return;
		}
        LOGGER.info("converted json metadata={}", jsonMetadata);
        Map<String, Object> convertedMetaData = convertJsonMetadataToMap(processorFileTask, jsonMetadata, message, executionRecord);
        if (isProcessFileTaskStatusFatalError(processorFileTask)) {
        	LOGGER.error("processFileTask fatal error while parsing metadata file");
        	return;
        }

        // convert JSONArray errors to processorFileTask format
        
        executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Validating metadata file");
        message = new HashMap<>();
		validateMetadataFileErrors(processorFileTask, errors, convertedMetaData, message, executionRecord);
        if (processorFileTask.getStatus() == MetaDataStatus.FATAL_ERROR) {
        	LOGGER.error("processFileTask fatal error while parsing metadata file");
        	return;
        }
        
		setCreatedAndExpiryDate(convertedMetaData);

        // set fileName, fileSize and fileType in metadata to pass to DocLib later
		convertedMetaData.put("fileName", processorFileTask.getFileName());
        convertedMetaData.put("fileSize", processorFileTask.getFileSize());
        convertedMetaData.put("fileType", processorFileTask.getFileType());

		if(clientName.equals("USPClaims"))
		{
			String transactionId=processorFileTask.getProcessorTransactionId();
			
			ProcessorTransaction processorTranction=processorTransactionService.getProcessTransactionInfoByTransactionId(transactionId);
			convertedMetaData.put("zipFileName", processorTranction.getFileName());
			convertedMetaData.put("zipFileCreatedDate", processorTranction.getDateCreated());
			
		}
		
	    
		processorFileTask.setMetadata(convertedMetaData);

		if (processorFileTask.getStatus() != MetaDataStatus.FATAL_ERROR) {
			executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Posting document to prun mongo");
			message = new HashMap<>();

			Document document = setDocumentStatus(processorFileTask, convertedMetaData);
			
			// save document to mongo
			DocumentMetaData insertedDocument = saveDocumentToMongo(processorFileTask, document, pmd);
			processorFileTask.setTargetId(insertedDocument.getId());
			processorFileTask.setTargetType(ProcessorTargetType.documents);
			
			if ((processorFileTask.getStatus() != MetaDataStatus.FATAL_ERROR
					&& processorFileTask.getStatus() != MetaDataStatus.SEVERE_ERROR
					&& processorFileTask.getStatus() != MetaDataStatus.COMPLETE_WITH_ERRORS)) {
				message.put(OUTCOME_KEY, "MetaData Posted Sucessfully to Mongo");
			} else if (processorFileTask.getStatus() == MetaDataStatus.FATAL_ERROR) {
				LOGGER.error("Metadata file process Error out for ID{} and pdf{}", processorFileTask.getId(), processorFileTask.getFileName());
				if (((processorFileTask.getSummary() == null) || (processorFileTask.getSummary() != null && processorFileTask.getSummary().getErrorList() == null))) {
					processorFileTask.getSummary().addError(new ProcessorError(ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS));
				}
			}
			processorFileTaskService.updateProcessorFileTask(processorFileTask);
			
			updateProcessorFileTaskWithPostDocumentToMongoResult(processorFileTask, insertedDocument, executionRecord, message);
			
			// post document to Doc360
			if(Boolean.TRUE.equals(pmd.getProcessConfig().get("sendToDoc360"))) {
				postDocumentToDoc360(processorFileTask, pdfFilePath, insertedDocument, pmd);
			}
			// post document to fds
			else {
				postDocumentToFDS(processorFileTask, pdfFilePath, insertedDocument, pmd);
			}
			 
		}
			
		LOGGER.info("ProcessorFileTask -- processFileTaskWithRequiredFields -- EXIT processorFileTask id = {}", processorFileTask.getId());
			
	}

	public boolean checkMetadataFileIsEmpty(ProcessorFileTask processorFileTask, File metadataFile, ProcessorExecutionRecord executionRecord) {
		if(metadataFile.length() == 0){
			LOGGER.debug("ProcessorFileTask->processFileTaskWithRequiredFields->empty metadata file-{}", processorFileTask.getId());

			HashMap<String, String> message = new HashMap<>();
			message.put(OUTCOME_KEY, "metadata file was empty");
			message.put(ERROR_KEY, "Metadata is Null");
			processorFileTask.getSummary().addError(new ProcessorError(ProcessorErrorCode.EMPTY_METADATA_FILE));
			processorFileTask.setStatus(MetaDataStatus.FATAL_ERROR);
			processorFileTask.setEndTime();
			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask, executionRecord, message);

			return true;
		} else {
			return false;
		}
	}

	public void initProcessorFileTask(ProcessorFileTask processorFileTask) {
		processorFileTask.setStartTime();
		processorFileTask.setStatus(MetaDataStatus.IN_PROCESS);
		LOGGER.info("ProcessFileTask-->status = {}", MetaDataStatus.IN_PROCESS);
		ProcessorTaskUtil.updateServerMetrics(processorFileTask, processorFileTaskService);
	}
	
	public void setCreatedAndExpiryDate(Map<String, Object> convertedMetaData) {
		LOGGER.debug("ProcessorFileTask->setCreatedAndExpiryDate->ENTER");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
		ZonedDateTime currentDate = ZonedDateTime.now(ZoneOffset.UTC);
		
		LOGGER.debug("before created date={}", convertedMetaData.get(CREATED_DATE));
		
		if (convertedMetaData.get(CREATED_DATE) == null || StringUtils.isNullOrEmpty(convertedMetaData.get(CREATED_DATE).toString())) {
			convertedMetaData.put(CREATED_DATE, currentDate.format(formatter));
			LOGGER.debug("Converting created date={}", convertedMetaData.get(CREATED_DATE));
		}
		
		LOGGER.debug("created date={}", convertedMetaData.get(CREATED_DATE));
		
		if (convertedMetaData.get(EXPIRY_DATE) == null || StringUtils.isNullOrEmpty(convertedMetaData.get(EXPIRY_DATE).toString())) {
			ZonedDateTime expiryDate = currentDate.plusDays(fDSRetentionPeriod);
			convertedMetaData.put(EXPIRY_DATE, expiryDate.format(formatter));
		}
		LOGGER.debug("ProcessorFileTask->setCreatedAndExpiryDate->EXIT");
	}

	public void validateMetadataFileErrors(ProcessorFileTask processorFileTask, Set<String> errors, Map<String, Object> convertedMetaData, Map<String, String> message, ProcessorExecutionRecord executionRecord) {
		if (errors.isEmpty()) {
			message.put(OUTCOME_KEY, "Metadata Validated sucessfully.");
			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
					executionRecord, message);
		} else {

			boolean hasSevereError = updateProcessorFileTaskWithCriteriaError(processorFileTask, errors);
			message.put(OUTCOME_KEY, "Metadata validation failed.");
			message.put(ERROR_KEY, ProcessorErrorCode.REQUIRED_METADATA_FIELDS_MISSING.getErrorMessage());

			if (hasSevereError && processorFileTask.getStatus() != MetaDataStatus.FATAL_ERROR) {
				processorFileTask.setStatus(MetaDataStatus.SEVERE_ERROR);
				convertedMetaData.put("stopProcessing", true);
			} else {
				processorFileTask.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS);
			}

			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
					executionRecord, message);
			LOGGER.debug("ProcessorFileTask->validateMetadataWithCriteria->Error List-{}:{}", processorFileTask.getId(), errors);

		}
	}

	public Map<String, Object> convertJsonMetadataToMap(ProcessorFileTask processorFileTask, JSONObject jsonMetadata, Map<String, String> message, ProcessorExecutionRecord executionRecord) {
		if (jsonMetadata != null) {
			// convert JsonObject to Map<String, Object> and update processorFileTask
			Map<String, Object> convertedMetaData = gson.fromJson(jsonMetadata.get("metadata").toString(), HashMap.class);
			message.put(OUTCOME_KEY, "Parse metadata file successfull.");
			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
					executionRecord, message);

			return convertedMetaData;

		} else {
			if (processorFileTask.getSummary().getErrorList().isEmpty()) {
				message = new HashMap<>();
				message.put(OUTCOME_KEY, "Parse metadata file failed.");
				message.put(ERROR_KEY, "convertMetadata returned null");
				updateDbWithProcessorError(processorFileTask, executionRecord, message, ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE);
			}
			return null;
		}
	}

	public DocumentMetaData saveDocumentToMongo(ProcessorFileTask processorFileTask, Document document, ProcessorMetaData pmd) {
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setMetadata(new org.bson.Document(document.getMetadata()));
		documentMetaData.setSpaceId(document.getSpaceId());
		documentMetaData.setClientId(processorFileTask.getClientId());
		documentMetaData.setAppIdentifier(processorFileTask.getAppIdentifier());
        Object docClass = pmd.getProcessConfig().get("docClass");
        if (docClass != null && docClass instanceof String) {
            documentMetaData.setDoc360DocClass((String) docClass);
        }
		if (processorFileTask.getStatus().equals(MetaDataStatus.SEVERE_ERROR)) {
			documentMetaData.setStatus(MetaDataStatus.SEVERE_ERROR);
		} else {
			documentMetaData.setStatus(MetaDataStatus.AVAILABLE);
		}
		return documentMetaDataService.saveDocumentMetaData(documentMetaData);
	}

	public void updateProcessorFileTaskWithPostDocumentToMongoResult(ProcessorFileTask processorFileTask, DocumentMetaData insertedDocument, ProcessorExecutionRecord executionRecord, Map<String, String> message) {
		if (insertedDocument.getId() == null || insertedDocument.getId().isEmpty()) {
			message.put(OUTCOME_KEY, "Failed to post document to prun mongo");
			message.put(ERROR_KEY, "Target id is null or empty");
			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
					executionRecord, message);
		} else {
			message.put(OUTCOME_KEY, "Document posted to prun mongo successfully");
			message.put(PRUN_DOCUMENT_ID, insertedDocument.getId());
			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
					executionRecord, message);
		}
		setEndTime(processorFileTask, processorFileTaskService);
	}

	public void postDocumentToFDS(ProcessorFileTask processorFileTask, String filePath, DocumentMetaData insertedDocument, ProcessorMetaData pmd) {
		String targetId = processorFileTask.getId();
		String appIdentifier = processorFileTask.getAppIdentifier();
		String documentId = insertedDocument.getId();

		Map<String, Object> callbackMap = new HashMap<>();
		callbackMap.put("processorFileTaskId", targetId);
		callbackMap.put(PRUN_DOCUMENT_ID, documentId);
		callbackMap.put("appIdentifier", appIdentifier);

		String documentString = "";
		Integer spaceId = pmd.getConfigSpaceId();

		try {
			documentString = mapper.writeValueAsString(insertedDocument.getMetadata());
		} catch (JsonProcessingException e) {
			// This needs to do Engine reconciliation
			LOGGER.error(PRE_REST_API_EXCEPTION, spaceId, IDENTIFIER, targetId, documentId, ExceptionUtils.getStackTrace(e));
			return;
		}
		String searchTermsString = "";
		try {
			searchTermsString = fdsCloudSearchTermsTemplate.getSearchTermsString(insertedDocument.getMetadata());
		} catch (Exception e) {
			LOGGER.error("Error getting search terms string e={}", ExceptionUtils.getStackTrace(e));
			return;
		}

		
		MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
		requestMap.add("filePath", filePath);
		requestMap.add("documents", documentString);
		requestMap.add("searchTerms", searchTermsString);

		Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();
		restApiMsgServiceCallbackMap.put("processorFileTaskId", targetId);
		restApiMsgServiceCallbackMap.put(PRUN_DOCUMENT_ID, documentId);
		restApiMsgServiceCallbackMap.put("appIdentifier", appIdentifier);
		restApiMsgServiceCallbackMap.put("filePath", filePath);
		restApiMsgServiceCallbackMap.put("documents", documentString);
		restApiMsgServiceCallbackMap.put("searchTerms", searchTermsString);
		restApiMsgServiceCallbackMap.put("restApiId", "addSendDocumentRequestToFds");
		restApiMsgServiceCallbackMap.put("spaceId", spaceId);
		restApiMsgServiceCallbackMap.put("delegate", CALLBACK);
		restApiMsgServiceCallbackMap.put("identifier", IDENTIFIER);
		restApiMsgServiceCallbackMap.put("targetId", targetId);
		restApiMsgServiceCallbackMap.put("retryCnt", 0);

		try {
			LOGGER.info("Calling addSendDocumentRequestToFds: spaceId={}, identifier={}, targetId={}, documentId={}, callback={}, requestMap={}, callbackMap={}, restApiMsgServiceCallbackMap={}",
				spaceId, IDENTIFIER, targetId, CALLBACK, documentId, requestMap, callbackMap, restApiMsgServiceCallbackMap);
			if (sendQueueService.addSendDocumentRequestToFds(spaceId, IDENTIFIER, targetId, CALLBACK, requestMap, callbackMap, restApiMsgServiceCallbackMap)) {
				LOGGER.info("SUCCESS: addSendDocumentRequestToFds: spaceId={}, identifier={}, targetId={}, documentId={}, callback={}",
					spaceId, IDENTIFIER, targetId, documentId, CALLBACK);
			} else {
				LOGGER.error("FAILURE: addSendDocumentRequestToFds QUEUED: spaceId={}, identifier={}, targetId={}, documentId={}, callback={}",
					spaceId, IDENTIFIER, targetId, documentId, CALLBACK);
			}
		} catch (HttpServerException e) {
			// MessageService will process appError
			String queue = sendQueueService.getPriorityQueue(spaceId);
			LOGGER.error(REST_API_EXCEPTION, spaceId, queue, REST_API_CALLBACK, targetId, documentId, e.getMessage());
			errorMetaDataService.writeToMessageServiceErrorCollection(queue, REST_API_CALLBACK, targetId, spaceId, restApiMsgServiceCallbackMap, e.getMessage(), MetaDataStatus.AUTOMATIC);
		}
	}
	
	public void postDocumentToDoc360(ProcessorFileTask processorFileTask, String pdfFilePath,
			DocumentMetaData insertedDocument, ProcessorMetaData pmd) {
		
		String targetId = processorFileTask.getId();
		String appIdentifier = processorFileTask.getAppIdentifier();
		String documentId = insertedDocument.getId();

		Map<String, Object> callbackMap = new HashMap<>();
		callbackMap.put("processorFileTaskId", targetId);
		callbackMap.put(PRUN_DOCUMENT_ID, documentId);
		callbackMap.put("appIdentifier", appIdentifier);
		
		String documentString = "";
		Integer spaceId = pmd.getConfigSpaceId();
		
		String docClass = (String) pmd.getProcessConfig().get("docClass");

		try {
            documentString = doc360MetadataTemplate.getDoc360MetadataString(insertedDocument.getMetadata());
		} catch (Exception e) {
			// This needs to do Engine reconciliation
			LOGGER.error(PRE_REST_API_EXCEPTION, spaceId, IDENTIFIER, targetId, documentId, ExceptionUtils.getStackTrace(e));
			return;
		}
		
		
		MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
		
		requestMap.add("documents", documentString);
		requestMap.add("docClass", docClass);
		requestMap.add("filePath", pdfFilePath);
		
		
		Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();
		restApiMsgServiceCallbackMap.put("processorFileTaskId", targetId);
		restApiMsgServiceCallbackMap.put(PRUN_DOCUMENT_ID, documentId);
		restApiMsgServiceCallbackMap.put("appIdentifier", appIdentifier);
		restApiMsgServiceCallbackMap.put("filePath", pdfFilePath);
		restApiMsgServiceCallbackMap.put("document", documentString);
		restApiMsgServiceCallbackMap.put("docClass", docClass);
		restApiMsgServiceCallbackMap.put("restApiId", "addSendDocumentRequestToDoc360");
		restApiMsgServiceCallbackMap.put("spaceId", spaceId);
		restApiMsgServiceCallbackMap.put("delegate", CALLBACK);
		restApiMsgServiceCallbackMap.put("identifier", IDENTIFIER);
		restApiMsgServiceCallbackMap.put("targetId", targetId);
		restApiMsgServiceCallbackMap.put("retryCnt", 0);
		
		try {
			LOGGER.info("Calling addSendDocumentRequestToDoc360: spaceId={}, identifier={}, targetId={}, documentId={}, callback={}, requestMap={}, callbackMap={}, restApiMsgServiceCallbackMap={}",
				spaceId, IDENTIFIER, targetId, CALLBACK, documentId, requestMap, callbackMap, restApiMsgServiceCallbackMap);
			if (sendQueueService.addSendDocumentRequestToDoc360(spaceId, IDENTIFIER, targetId, CALLBACK, requestMap, callbackMap, restApiMsgServiceCallbackMap)) {
				LOGGER.info("SUCCESS: addSendDocumentRequestToDoc360: spaceId={}, identifier={}, targetId={}, documentId={}, callback={}",
					spaceId, IDENTIFIER, targetId, documentId, CALLBACK);
			} else {
				LOGGER.error("FAILURE: addSendDocumentRequestToDoc360 QUEUED: spaceId={}, identifier={}, targetId={}, documentId={}, callback={}",
					spaceId, IDENTIFIER, targetId, documentId, CALLBACK);
			}
		} catch (HttpServerException e) {
			// MessageService will process appError
			String queue = sendQueueService.getPriorityQueue(spaceId);
			LOGGER.error(REST_API_EXCEPTION, spaceId, queue, REST_API_CALLBACK, targetId, documentId, e.getMessage());
			errorMetaDataService.writeToMessageServiceErrorCollection(queue, REST_API_CALLBACK, targetId, spaceId, restApiMsgServiceCallbackMap, e.getMessage(), MetaDataStatus.AUTOMATIC);
		}
		
	}

	public Document setDocumentStatus(ProcessorFileTask processorFileTask, Map<String, Object> convertedMetaData) {
		Document document = new Document();
		ProcessorMetaData processor = processorService.getProcessorMetaData(processorFileTask.getProcessorId(), processorFileTask.getAppIdentifier());
		document.setSpaceId(processor.getConfigSpaceId());
		document.setMetadata(convertedMetaData);
		if (processorFileTask.getStatus() == MetaDataStatus.SEVERE_ERROR) {
			document.setStatus(MetaDataStatus.SEVERE_ERROR.toString());

		}
		return document;
	}
	
	public void addErrorCodeAndEndTime(ProcessorFileTask processorFileTask, String logMsg, ProcessorErrorCode errorCode){
        LOGGER.debug("parseMetadata Error out at {} for ID{} and pdf{}",logMsg, processorFileTask.getId(), processorFileTask.getFileName());
        processorFileTask.getSummary().addError(new ProcessorError(errorCode));
        setEndTime(processorFileTask, processorFileTaskService);
	}
	
	private static void setEndTime(ProcessorFileTask processorFileTask, ProcessorFileTaskService processorFileTaskService) {
		processorFileTask.setEndTime();
		processorFileTaskService.updateProcessorFileTask(processorFileTask);
	}

    @SuppressWarnings("rawtypes")
	public void getErrors(String errMsg, Set<String> errors, Class enumClass) {
    	
    	ErrorMessage err = null;
    	String key = "";
    	// #: required key [SubCategory] not found
    	// #/DATEOFSERVICE: subject must not be valid against schema "enum":["00000000"]
    	// #/CreatingApp: expected minLength: 1, actual: 0
    	// #/isPrintSuppressed: blah is not a valid enum value
    	
    	if (errMsg.contains("[") && errMsg.contains("required key")) {
    		key = errMsg.substring(errMsg.indexOf("[")+1, errMsg.indexOf("]"));		
    	} else if (errMsg.contains("minLength") || errMsg.contains("enum")) {
    		key = errMsg.substring(errMsg.indexOf("#/")+2, errMsg.indexOf(":"));
    	}
    	
    	try {
        	err = (ErrorMessage) Enum.valueOf(enumClass, key.replaceAll("\\s",""));
    		LOGGER.debug("getErrors -- errorCode={}, errorMessage={}", err.getErrorCode(), err.getErrorMessage());
    		errors.add(err.getErrorMessage());
    	} catch (Exception e) {
    		LOGGER.info("No enum value for key={}", key);
    		errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> getErrors: " + e.getMessage());
    	}
     }
    
    @SuppressWarnings("rawtypes")
	public Class getClassFromClientName(String clientName) {
	    	String className = "com.optum.fds.paperless.client.pojo." + clientName;
    	try {
        	return Class.forName(className);
    	} catch (ClassNotFoundException e) {
    		LOGGER.error("getClassFromClientName -- class not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
    		errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> getClassFromClientName: " + e.getMessage());
    		return null;
    	}    	
    }
    
    @SuppressWarnings("rawtypes")
	public Class getErrEnumFromClientName(String clientName) {
	    	String enumName = "com.optum.fds.paperless.client.pojo." + clientName + "$ErrorMsg";
    	try {
    		return Class.forName(enumName);
		} catch (ClassNotFoundException e) {
    		LOGGER.error("getClassFromClientName -- ErrorMsg enum not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
    		errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> getClassFromClientName, ErrorMsg enum not found: " + e.getMessage());
			return null;
		}
    }
    
    public JSONTokener getClientSchema(String clientName) {
	    	if (ProcessFileTask.class.getResourceAsStream(schemaFileBasePath + clientName + "_client_schema.json") == null) {
	    		return null;
	    	}
	    	return new JSONTokener(ProcessFileTask.class.getResourceAsStream(schemaFileBasePath + clientName + "_client_schema.json"));
    }
	
	public JSONObject convertMetadata(ProcessorFileTask processorFileTask, File metadataFile, Set<String> errors, String clientName, ProcessorExecutionRecord executionRecord, Map<String, String> message) {
		Map<String, String> map = convertMetadataToMap(processorFileTask, metadataFile, executionRecord, message);
		if (map.isEmpty()) {
			return null;
		}

		JSONObject metadata = new JSONObject(); 
		String clientJson = gson.toJson(map);
		JSONObject clientJsonObj = new JSONObject( clientJson );

		LOGGER.debug("convertMetadata -- client json clientName={}, object={}", clientName, clientJsonObj);
		try {
			JSONTokener tokener = getClientSchema(clientName);
			if (tokener == null) {
				LOGGER.error("jsonSchema does not exist clientName={}", clientName);
				message.put(OUTCOME_KEY, "Could not parse metadata file, error converting xml file to string");
				message.put(ERROR_KEY, "jsonSchema does not exist clientName=" + clientName);
				updateDbWithProcessorError(processorFileTask, executionRecord, message, ProcessorErrorCode.FILE_COULD_NOT_BE_PARSED);
				errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> convertMetadata, error converting xml to json: jsonSchema does not exist clientName=" + clientName);
				return null;
			}
			JSONObject jsonSchema = new JSONObject(tokener);

			SchemaLoader loader = SchemaLoader.builder().schemaJson(jsonSchema).build();
			Schema schema = loader.load().build();
			schema.validate(clientJsonObj);
		} catch (org.everit.json.schema.ValidationException e) {
			@SuppressWarnings("rawtypes")
			Class enumClass = getErrEnumFromClientName(clientName);
			for (String errMsg : e.getAllMessages()) {
				getErrors(errMsg, errors, enumClass);
			}
		}
		LOGGER.debug("convertMetadata -- clientName={}, errors={}", clientName, errors);
		ClientMetadata convertedMetadata = (ClientMetadata) mapper.convertValue(map, getClassFromClientName(clientName));
		convertedMetadata.setPostCardInd(postCardInd.getPostCardInd(clientName));
		String convertedMetadataJson = gson.toJson(convertedMetadata);
		JSONObject convertedMetadatajsonObj = new JSONObject( convertedMetadataJson );
		metadata.put("metadata", convertedMetadatajsonObj);
		return metadata;
	}

	protected Map<String, String> convertMetadataToMap(ProcessorFileTask processorFileTask, File metadataFile, ProcessorExecutionRecord executionRecord, Map<String, String> message) {
		XmlMapper xmlMapper = new XmlMapper();
		Map<String, String> map = new HashMap<>();
		String xml = "";
		try {
			xml = Parser.inputStreamToString(new FileInputStream(metadataFile));
			xml = xml.replaceAll("&(?![^&]{2,4};)", "&#038;");
		} catch (Exception e) {
			LOGGER.error("convertMetadata -- error converting metadata file to string, err={}", ExceptionUtils.getStackTrace(e));
			message.put(OUTCOME_KEY, "Could not parse metadata file, error converting xml file to string");
			message.put(ERROR_KEY, e.getMessage());
			updateDbWithProcessorError(processorFileTask, executionRecord, message, ProcessorErrorCode.FILE_COULD_NOT_BE_PARSED);
			errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> convertMetadata, error converting xml file to string: " + e.getMessage());
			return map;
		}

		ClientJson value = null;
		try {
			value = xmlMapper.readValue(xml, ClientJson.class);
		} catch (IOException e) {
			LOGGER.error("convertMetadata -- error parsing xml string to json, metadataFile={}, err={}", metadataFile, ExceptionUtils.getStackTrace(e));
			message = new HashMap<>();
			message.put(OUTCOME_KEY, "Could not convert metadata file, error converting xml to json");
			message.put(ERROR_KEY, e.getMessage());
			updateDbWithProcessorError(processorFileTask, executionRecord, message, ProcessorErrorCode.XML_COULD_NOT_BE_MAPPED);
			errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> convertMetadata, error converting xml to json: " + e.getMessage());
			return map;
		}

		processorFileTask.getSummary().setXmlObject(value);
		processorFileTaskService.updateProcessorFileTask(processorFileTask);

		try {
			if (value == null || value.Indices == null || value.Indices.IndexField == null) {
				LOGGER.error("value.Indices.IndexField=null");
				message.put(OUTCOME_KEY, "Parse metadata file failed");
				message.put(ERROR_KEY, "value.Indices.IndexField=null");
				updateDbWithProcessorError(processorFileTask, executionRecord, message, ProcessorErrorCode.XML_COULD_NOT_BE_MAPPED);
				errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> convertMetadata, error converting xml to json: value.Indices.IndexField=null");
				return map;
			}
			for (int i = 0; i < value.Indices.IndexField.size(); i++) {
				String val = value.Indices.IndexField.get(i).idxValue;
				if (val != null && org.apache.commons.lang3.StringUtils.isBlank(val)) {
					val = val.replaceAll("\\s","");
				}
				map.put(value.Indices.IndexField.get(i).idxName, val);
			}
		} catch(Exception e) {
			LOGGER.error("convertMetadata -- error parsing xml string to json, err={}", ExceptionUtils.getStackTrace(e));
			message = new HashMap<>();
			message.put(OUTCOME_KEY, "Could not convert metadata file, error converting xml to json; map=" + map);
			message.put(ERROR_KEY, e.getMessage());
			updateDbWithProcessorError(processorFileTask, executionRecord, message, ProcessorErrorCode.XML_COULD_NOT_BE_MAPPED);
			errorMetaDataService.writeToErrorCollection(tempExecution, "ProcessFileTask --> convertMetadata, error converting xml to json: " + e.getMessage());
			return new HashMap<>();
		}
		LOGGER.debug("convertMetadata -- client metadata map={}", map);
		return map;
	}

	public final void checkIfFilesExist(ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord,
			File fileToProcess, File metadataFile) {
		Map<String, String> message = new HashMap<>();
		
		LOGGER.info("ProcessFileTask -- checkIfFilesExist -- ENTER processorFileTask id = {}", processorFileTask.getId());
		
		LOGGER.info("checkIfFilesExist fileToPocess={}, exists={}", fileToProcess, fileToProcess.exists());
		LOGGER.info("checkIfFilesExist metadataFile={}, exists={}", metadataFile, metadataFile.exists());
		
		if (!fileToProcess.exists() || !metadataFile.exists()) {
			StringBuilder fileMissing = new StringBuilder();

			if (!fileToProcess.exists()) {
				fileMissing.append(fileToProcess.getName());
			}
			if (!metadataFile.exists()) {
				if (fileMissing.toString().length() > 0) {
					fileMissing.append(" and ");
				}
				fileMissing.append(metadataFile.getName());
			}

			if (!fileToProcess.exists() && !metadataFile.exists()) {
				fileMissing.append(" are");
			} else {
				fileMissing.append(" is");
			}

			fileMissing.append(" missing.");

			message.put(OUTCOME_KEY, "File not found");
			message.put(ERROR_KEY, fileMissing.toString());

			processorFileTask.setStatus(MetaDataStatus.FATAL_ERROR);
			LOGGER.info("ProcessFileTask-->status = {}", MetaDataStatus.FATAL_ERROR);
			processorFileTask.getSummary().addError(new ProcessorError(ProcessorErrorCode.FILE_NOT_FOUND));
			
			LOGGER.info("ProcessorFileTask->checkIfFilesExists->ERROR-metadatafile not found-{}", processorFileTask.getId());
			
		} else {
			message.put(OUTCOME_KEY, "Files needed are present.");
		}

		ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask, executionRecord,
				message);
		
		LOGGER.info("ProcessFileTask -- checkIfFilesExist -- EXIT processorFileTask id = {}", processorFileTask.getId());
	}
	

	void updateDbWithProcessorError(ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord, Map<String, String> message, ProcessorErrorCode errorCode) {
		if (processorFileTask.getSummary() != null) {
			processorFileTask.getSummary().addError(new ProcessorError(errorCode));
		} else {
			ProcessorSummary summary = new ProcessorSummary();
			summary.addError(new ProcessorError(errorCode));
			processorFileTask.setSummary(summary);
		}
		processorFileTask.setStatus(MetaDataStatus.FATAL_ERROR);
		LOGGER.info("ProcessFileTask-->status = {}", MetaDataStatus.FATAL_ERROR);
		processorFileTask.setEndTime();
		ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask, executionRecord, message);

	}
	
	
	boolean updateProcessorFileTaskWithCriteriaError(ProcessorFileTask processorFileTask, Set<String> errorList) {
		boolean hasSevereError = false;
		if (processorFileTask.getSummary() != null) {
			for (String error : errorList) {
				if(error.contains("SEVERE")){
					hasSevereError = true;
					processorFileTask.getSummary().addError(
							new ProcessorError(error, ProcessorErrorCode.REQUIRED_METADATA_FIELDS_MISSING_SEVERE_ERROR.getErrorCode()));
				}else {
					processorFileTask.getSummary().addError(
							new ProcessorError(error, ProcessorErrorCode.REQUIRED_METADATA_FIELDS_MISSING.getErrorCode()));
				}
			}
		}
		return hasSevereError;
	}
	
	
	protected String getProcessorFileTaskId(ProcessorFileTask processorFileTask) {
		return processorFileTask != null ? processorFileTask.getId() : "NULL";
	}

	public static boolean isProcessFileTaskStatusFatalError(ProcessorFileTask processorFileTask) {
		return processorFileTask.getStatus() == MetaDataStatus.FATAL_ERROR;
	}

}