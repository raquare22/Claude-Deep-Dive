package com.optum.fds.paperless;

import static com.optum.fds.paperless.workflow.constants.Workflow.ADDRESS_BLOCK_X;
import static com.optum.fds.paperless.workflow.constants.Workflow.ADDRESS_BLOCK_Y;
import static com.optum.fds.paperless.workflow.constants.Workflow.APP_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.APP_SECRET;
import static com.optum.fds.paperless.workflow.constants.Workflow.BOUNCE_EMAIL_CHECK_EFT_IND;
import static com.optum.fds.paperless.workflow.constants.Workflow.CREATE_ORIGINAL_COMPANION_FILE;
import static com.optum.fds.paperless.workflow.constants.Workflow.DOCUMENT_FORMAT_FIELD;
import static com.optum.fds.paperless.workflow.constants.Workflow.IDENTIFIER_FONT_SIZE;
import static com.optum.fds.paperless.workflow.constants.Workflow.MAX_DOCUMENTS_OCCURS;
import static com.optum.fds.paperless.workflow.constants.Workflow.ORIGINAL_PRINT_TRAIL;
import static com.optum.fds.paperless.workflow.constants.Workflow.RECEIVER_IDENTIFIER;
import static com.optum.fds.paperless.workflow.constants.Workflow.SFTP_ARCHIVE_DIRECTORY;
import static com.optum.fds.paperless.workflow.constants.Workflow.SFTP_DIRECTORY;
import static com.optum.fds.paperless.workflow.constants.Workflow.SFTP_HOSTNAME;
import static com.optum.fds.paperless.workflow.constants.Workflow.SFTP_PW;
import static com.optum.fds.paperless.workflow.constants.Workflow.SFTP_PW_ARC;
import static com.optum.fds.paperless.workflow.constants.Workflow.SFTP_USERNAME;
import static com.optum.fds.paperless.workflow.constants.Workflow.SFTP_USERNAME_ARC;
import static com.optum.fds.paperless.workflow.constants.Workflow.SKIP_MANIPULATE_PDF_FILE;
import static com.optum.fds.paperless.workflow.constants.Workflow.SPACE_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.START_DATE_IN_DAYS;
import static com.optum.fds.paperless.workflow.constants.Workflow.WRITE_ENCRYPTED_PDF;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngines;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.openjson.JSONArray;
import com.google.gson.Gson;
import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class FDSHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(FDSHelper.class);

    private static final String PROCESSOR_ID = "processorId";

    public static ObjectMapper mapper = new ObjectMapper();
	
    public static ProcessInstance runProcess(String processKey, Map<String, Object> variables) {
        ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
        RuntimeService runtimeService = processEngine.getRuntimeService();
        ProcessInstance pi = runtimeService.createProcessInstanceBuilder()
        					.processDefinitionKey(processKey)
        					.transientVariables(variables)
        					.start();
        return pi;
    }


	    public static ProcessInstance sftpRunProcess(String processKey, String processObj) throws JsonMappingException, JsonProcessingException {
	        Map<String, Object> variableMap = new HashMap<>();
	        variableMap.put(ProcessKeys.PROCESS_METADATA, getProcessorMetadata(processObj));
	        variableMap.put(Workflow.PROCESS_KEY, processKey);
	        return runProcess(processKey, variableMap);
	    }
	    public static ProcessInstance zipFileRunProcess(String processKey, String processObj, String appIdentifier, String processorId) throws JsonMappingException, JsonProcessingException {
	        Map<String, Object> variableMap = new HashMap<>();
	        variableMap.put(ProcessKeys.PROCESS_METADATA, getProcessorMetadata(processObj));
	        variableMap.put(Workflow.PROCESS_KEY, processKey);
	        variableMap.put(Workflow.APP_IDENTIFIER, appIdentifier);
	        variableMap.put(PROCESSOR_ID, processorId);
	        return runProcess(processKey, variableMap);
	    }

	    public static ProcessInstance runProcess(String processKey, String processObj, String response) {
	        Map<String, Object> variableMap = new HashMap<>();
	        variableMap.put(ProcessKeys.PROCESS_METADATA, getProcessorMetadata(processObj));
	        variableMap.put("response", getProcessorMetadata(response));
	        variableMap.put(Workflow.PROCESS_KEY, processKey);
	        return runProcess(processKey, variableMap);
	    }

	    public static ProcessInstance runProcess(String processKey, Map<String, Object> variableMap, GenericResponse response) {
	        variableMap.put("response", response);
	        variableMap.put(Workflow.PROCESS_KEY, processKey);
	        return runProcess(processKey, variableMap);
	    }

	    public static ProcessInstance runProcessConfig(String processKey, String processObj) {
	        Map<String, Object> variableMap = new HashMap<>();
	        variableMap.put(ProcessKeys.PROCESS_METADATA, getProcessorMetadata("{\"config\" : " + processObj + "}"));
	        variableMap.put(Workflow.PROCESS_KEY, processKey);
	        return runProcess(processKey, variableMap);
	    }

	    public static ProcessInstance runProcess(String processKey, ProcessorMetaData processorMetaData) {
	        Map<String, Object> variableMap = new HashMap<>();
	        variableMap.put(ProcessKeys.PROCESS_METADATA, processorMetaData);
	        variableMap.put(Workflow.PROCESS_KEY, processKey);
	        return runProcess(processKey, variableMap);
	    }
	
	    
	    @SuppressWarnings("rawtypes")
		public static void processTextFile(ProcessorMetaData processorMetaData) throws IOException {
			try {
				Map process = processorMetaData.getProcess();
				Map config = processorMetaData.getProcessConfig();
				
				String processKey = (String) process.get(Workflow.PROCESS_KEY);
				
				var variablesWithValue = new Document().append(Workflow.PROCESSOR_METADATA, processorMetaData)
						.append(Workflow.TEMPLATE_NAME, config.get(Workflow.TEMPLATE_NAME))
						.append(Workflow.SPACE_ID, config.get(Workflow.SPACE_ID))
						.append(Workflow.APP_IDENTIFIER, config.get(Workflow.APP_IDENTIFIER))
						.append(Workflow.MATCH_CRITERIA, config.get(Workflow.MATCH_CRITERIA))
						.append(Workflow.SEARCH_WINDOW, config.get(Workflow.SEARCH_WINDOW))
						.append(Workflow.DOCLIB_PUT_URL, config.get(Workflow.DOCLIB_PUT_URL))
						.append(Workflow.DOCLIB_OAUTH_URL, config.get(Workflow.DOCLIB_OAUTH_URL))
						.append(Workflow.DOCLIB_CLIENT_ID, config.get(Workflow.DOCLIB_CLIENT_ID))
						.append(Workflow.DOCLIB_CLIENT_SECRET, config.get(Workflow.DOCLIB_CLIENT_SECRET));
		
				runProcess(processKey, variablesWithValue);
			} catch (Exception e) {
				LOGGER.error("Error to run processTextFile workflow e={}", ExceptionUtils.getStackTrace(e));
			}
		}
	   
	    public static void sftpConvertFileToDocument(ProcessorMetaData processorMetaData) throws IOException {
			try {
				Map process = processorMetaData.getProcess();
				Map config = processorMetaData.getProcessConfig();

				String processKey = (String) process.get(Workflow.PROCESS_KEY);

				var variablesWithValue = new Document().append(Workflow.PROCESSOR_METADATA, processorMetaData)
						.append(Workflow.TEMPLATE_NAME, config.get(Workflow.TEMPLATE_NAME))
						.append(Workflow.SPACE_ID, config.get(Workflow.SPACE_ID))
						.append(Workflow.APP_IDENTIFIER, config.get(Workflow.APP_IDENTIFIER))
						.append(Workflow.SEARCH_WINDOW, config.get(Workflow.SEARCH_WINDOW))
						.append(Workflow.CLIENT_NAME, config.get(Workflow.CLIENT_NAME))
						.append("process_key", processKey); 

				runProcess(processKey, variablesWithValue);
			} catch (Exception e) {
				LOGGER.error("Error to run sftpConvertFileToDocument workflow e={}", ExceptionUtils.getStackTrace(e));
			}
		}

	
	    
	    public static void retrieveAndSendEmailProcess(Map<String, Object> variables) throws IOException {
	    	try {
				Map hook = (Map) variables.get("hook");
				Map action = (Map) hook.get("action");
				Map objConfig = (Map) action.get("config");
				String task = objConfig.get(Workflow.PROCESS_KEY).toString();
				
				if (ProcessKeys.RETRIEVE_AND_SEND_EMAIL_PROCESS.equalsIgnoreCase(task)) {
					
					var variablesWithValue = new Document()
							.append(Workflow.HOOK_ID, variables.get("id"))
							.append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
							.append(Workflow.SPACE_ID, variables.get(Workflow.SPACE_ID))
							.append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
			                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
			                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
			                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
			                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
			                .append(Workflow.CLIENT_NAME, objConfig.get(Workflow.CLIENT_NAME))
			                .append("appName", objConfig.get("appName"))
			                .append("provSearchUrl", objConfig.get("provSearchUrl"))
			                .append("attributeSet", objConfig.get("attributeSet"))
			                .append("count", objConfig.get("count"))
			                .append(Workflow.UNIQUEFIELDTOGROUPDOCS, objConfig.get(Workflow.UNIQUEFIELDTOGROUPDOCS))
							.append(Workflow.SKIP_DOCUMENT_GROUPING, objConfig.get(Workflow.SKIP_DOCUMENT_GROUPING))
			                .append(Workflow.PES_APP_ID, objConfig.get(Workflow.PES_APP_ID))
			                .append(Workflow.PES_APP_SECRET, objConfig.get(Workflow.PES_APP_SECRET))
			                .append(Workflow.PES_OAUTH_URL, objConfig.get(Workflow.PES_OAUTH_URL))
			                .append(Workflow.PES_GRANT_TYPE, objConfig.get(Workflow.PES_GRANT_TYPE))
			                .append("validateCorprateMPIN", objConfig.get("validateCorprateMPIN"))
			                .append("PPCUrl", objConfig.get("PPCUrl"))
			                .append("enableRetriveAdmissionDischargePreferences", objConfig.get("enableRetriveAdmissionDischargePreferences"))
			                .append(Workflow.NUM_RETRIES, objConfig.get(Workflow.NUM_RETRIES))
			                .append(Workflow.TIME_TO_WAIT, objConfig.get(Workflow.TIME_TO_WAIT))
							.append(Workflow.PROCESS_KEY, ProcessKeys.RETRIEVE_AND_SEND_EMAIL_PROCESS);
					
					runProcess(task, variablesWithValue);
				}
			} catch (Exception ex) {
				LOGGER.error("Error to process required field rule: {}", ex.getMessage());
			}
	    }

	public static void sendBatchDynamicEmailRequestToPEN(Map<String, Object> variables) throws IOException {
		try {
			Map hook = (Map) variables.get("hook");
			Map action = (Map) hook.get("action");
			Map objConfig = (Map) action.get("config");
			String task = objConfig.get(Workflow.PROCESS_KEY).toString();

			if (ProcessKeys.SEND_BATCH_DYNAMIC_REQUEST_TO_PEN.equalsIgnoreCase(task)) {

				var variablesWithValue = new Document()
						.append(Workflow.HOOK_ID, variables.get("id"))
						.append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
						.append(Workflow.SPACE_ID, variables.get(Workflow.SPACE_ID))
						.append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
						.append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
						.append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
						.append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
						.append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
						.append(Workflow.CLIENT_NAME, objConfig.get(Workflow.CLIENT_NAME))
						.append(Workflow.PROCESS_KEY, ProcessKeys.SEND_BATCH_DYNAMIC_REQUEST_TO_PEN)
						.append(Workflow.PEN_APP_ID, objConfig.get(Workflow.PEN_APP_ID))
						.append(Workflow.PEN_APP_SECRET, objConfig.get(Workflow.PEN_APP_SECRET))
						.append(Workflow.PEN_OAUTH_URL, objConfig.get(Workflow.PEN_OAUTH_URL))
						.append(Workflow.PEN_GRANT_TYPE, objConfig.get(Workflow.PEN_GRANT_TYPE))
						.append(Workflow.UNIQUEFIELDTOGROUPDOCS, objConfig.get(Workflow.UNIQUEFIELDTOGROUPDOCS))
						.append(Workflow.IS_SECONDARY_EMAIL, objConfig.get(Workflow.IS_SECONDARY_EMAIL))
						.append(Workflow.SKIP_DOCUMENT_GROUPING, objConfig.get(Workflow.SKIP_DOCUMENT_GROUPING))
						.append(Workflow.NO_OF_BUSINESS_DAYS, objConfig.get(Workflow.NO_OF_BUSINESS_DAYS))
                        .append(Workflow.NO_OF_DAYS, objConfig.get(Workflow.NO_OF_DAYS))
                        .append(Workflow.PEN_SCOPE, objConfig.get(Workflow.PEN_SCOPE))
						.append(Workflow.EMAIL_TERMINATION_WINDOW, objConfig.get(Workflow.EMAIL_TERMINATION_WINDOW));

				runProcess(task, variablesWithValue);
			}
		} catch (Exception ex) {
			LOGGER.error("Error to process required field rule: {}", ex.getMessage());
		}
	}
	    
	public static void sftpSendEmailProcess(ProcessorMetaData processorMetaData) throws IOException {
		try {
			Map process = processorMetaData.getProcess();
			Map config = processorMetaData.getProcessConfig();

			String processKey = (String) process.get(Workflow.PROCESS_KEY);

			var variablesWithValue = new Document().append(Workflow.PROCESSOR_METADATA, processorMetaData)
					.append(Workflow.TEMPLATE_NAME, config.get(Workflow.TEMPLATE_NAME))
					.append(Workflow.SPACE_ID, config.get(Workflow.SPACE_ID))
					.append(Workflow.APP_IDENTIFIER, config.get(Workflow.APP_IDENTIFIER))
					.append(Workflow.MATCH_CRITERIA, config.get(Workflow.MATCH_CRITERIA))
					.append(Workflow.SEARCH_WINDOW, config.get(Workflow.SEARCH_WINDOW))
					.append(Workflow.PES_APP_ID, config.get(Workflow.PES_APP_ID))
					.append(Workflow.PES_APP_SECRET, config.get(Workflow.PES_APP_SECRET))
					.append(Workflow.PES_OAUTH_URL, config.get(Workflow.PES_OAUTH_URL))
					.append(Workflow.PES_GRANT_TYPE, config.get(Workflow.PES_GRANT_TYPE))
					.append(Workflow.CATEGORY, config.get(Workflow.CATEGORY))
					.append(Workflow.CLIENT_NAME, config.get(Workflow.CLIENT_NAME))
					.append("process_key", processKey); 

			runProcess(processKey, variablesWithValue);
		} catch (Exception e) {
			LOGGER.error("Error to run sftpSendEmailProcess workflow e={}", ExceptionUtils.getStackTrace(e));
		}
	}	
	
	public static void realTimeAPISendEmailProcess(ProcessorMetaData processorMetaData, Map<String, Object> processorTransaction) throws IOException
	{
		try {
			Map process = processorMetaData.getProcess();
			Map config = processorMetaData.getProcessConfig();
			String fileName = (String) processorTransaction.get(Workflow.FILE_NAME);
			String filePath = (String) processorTransaction.get(Workflow.LOCATION) + "/" + fileName;
			
			String processKey = (String) process.get(Workflow.PROCESS_KEY);
			
			var variablesWithValue = new Document().append(Workflow.PROCESSOR_METADATA, processorMetaData)
					.append(Workflow.TEMPLATE_NAME, config.get(Workflow.TEMPLATE_NAME))
					.append(Workflow.SPACE_ID, config.get(Workflow.SPACE_ID))
					.append(Workflow.APP_IDENTIFIER, config.get(Workflow.APP_IDENTIFIER))
					.append(Workflow.MATCH_CRITERIA, config.get(Workflow.MATCH_CRITERIA))
					.append(Workflow.SEARCH_WINDOW, config.get(Workflow.SEARCH_WINDOW))
					.append(Workflow.PES_APP_ID, config.get(Workflow.PES_APP_ID))
					.append(Workflow.PES_APP_SECRET, config.get(Workflow.PES_APP_SECRET))
					.append(Workflow.PES_OAUTH_URL, config.get(Workflow.PES_OAUTH_URL))
					.append(Workflow.PES_GRANT_TYPE, config.get(Workflow.PES_GRANT_TYPE))
					.append(Workflow.CATEGORY, config.get(Workflow.CATEGORY))
					.append(Workflow.CLIENT_NAME,config.get(Workflow.CLIENT_NAME))
					.append(Workflow.FILE_NAME,processorTransaction.get("fileName"))
					.append(Workflow.PROCESSOR_TRANSACTION_ID, processorTransaction.get("id"))
					.append("filePath", filePath)
					.append("process_key", processKey);

			runProcess(processKey, variablesWithValue);
		} catch (Exception e) {
			LOGGER.error("Error to run realTimeAPISendEmailProcess workflow e={}", ExceptionUtils.getStackTrace(e));
		}
	}
	    
	@SuppressWarnings("rawtypes")
	public static void processRequiredFieldRule(Map<String, Object> variables) throws IOException {
		try {
			Map hook = (Map) variables.get("hook");
			Map action = (Map) hook.get("action");
			Map objConfig = (Map) action.get("config");
			Map objRequiredFieldRuleConfig = (Map) objConfig.get("requiredFieldRule");
			String task = objRequiredFieldRuleConfig.get(Workflow.PROCESS_KEY).toString();
			if (ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY.equalsIgnoreCase(task)) {
				Gson gson = new Gson();
				String json = gson.toJson(objRequiredFieldRuleConfig.get(Workflow.RULES));

				ArrayList<Document> rulesList = new ArrayList<>();
				JSONArray jsonArray = new JSONArray(json);

				for (int i = 0; i < jsonArray.length(); i++) {
					rulesList.add(Document.parse(jsonArray.getString(i)));
				}

				var variablesWithValue = new Document().append(Workflow.DOCID, variables.get(Workflow.DOCID))
						.append(Workflow.HOOK_ID, variables.get("id"))
						.append(Workflow.HOOK_TRANSACTION_METADATA_ID,
								variables.get(Workflow.HOOK_TRANSACTION_METADATA_ID))
						.append(Workflow.RULES, rulesList)
						.append(Workflow.PROCESS_KEY, ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY);
				runProcess(task, variablesWithValue);
			}
		} catch (Exception ex) {
			LOGGER.error("Error to process required field rule: {}", ex.getMessage());
		}
	}

	@SuppressWarnings("rawtypes")
	public static void retrieveProviderEmailAddress(Map<String, Object> variables) throws IOException {
		try {
			Map hook = (Map) variables.get("hook");
			Map action = (Map) hook.get("action");
			Map objConfig = (Map) action.get("config");
			Map objProviderEmailConfig = (Map) objConfig.get("providerEmailAddress");
			String task = objProviderEmailConfig.get(Workflow.PROCESS_KEY).toString();
			if (ProcessKeys.RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY.equalsIgnoreCase(task)) {
				var variablesWithValue = new Document().append(Workflow.DOCID, variables.get(Workflow.DOCID))
						.append(Workflow.HOOK_ID, variables.get("id"))
						.append(Workflow.HOOK_TRANSACTION_METADATA_ID,
								variables.get(Workflow.HOOK_TRANSACTION_METADATA_ID))
						.append(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2,
								objProviderEmailConfig.get(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2))
						.append(Workflow.SKIP_EFT_IND, objProviderEmailConfig.get(Workflow.SKIP_EFT_IND))
						.append(Workflow.PROCESS_KEY, task)
						.append(Workflow.USE_FDS_CLOUD, objProviderEmailConfig.get(Workflow.USE_FDS_CLOUD))
                        .append(Workflow.PDOCLIENTID, objProviderEmailConfig.get(Workflow.PDOCLIENTID))
                        .append(Workflow.PDOCLIENTSECRET, objProviderEmailConfig.get(Workflow.PDOCLIENTSECRET))
                        .append(Workflow.PDO_FETCH_PREFERENCES_URL, objProviderEmailConfig.get(Workflow.PDO_FETCH_PREFERENCES_URL))
                        .append(Workflow.PDO_TOKEN_URL, objProviderEmailConfig.get(Workflow.PDO_TOKEN_URL))
						.append(Workflow.FDS_CLOUD_AUTH_URL, objProviderEmailConfig.get(Workflow.FDS_CLOUD_AUTH_URL))
						.append(Workflow.CLOUD_CLIENT_ID, objProviderEmailConfig.get(Workflow.CLOUD_CLIENT_ID))
						.append(Workflow.CLOUD_CLIENT_SECRET, objProviderEmailConfig.get(Workflow.CLOUD_CLIENT_SECRET))
						.append(Workflow.FDS_CLOUD_GET_DOCUMENT_URL,
								objProviderEmailConfig.get(Workflow.FDS_CLOUD_GET_DOCUMENT_URL))
						.append(Workflow.CLOUD_GRANT_TYPE, objProviderEmailConfig.get(Workflow.CLOUD_GRANT_TYPE));
				runProcess(task, variablesWithValue);
							}
		} catch (Exception ex) {
			LOGGER.error("Error to process retrieve provider emailAddress: {}", ex.getMessage());
		}
	}

	    @SuppressWarnings("rawtypes")
	    public static void responseFileProcess(Map<String, Object> variables) throws IOException {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        var variablesWithValue = new Document()
	                .append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
	                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.SFTP_HOSTNAME, objConfig.get(Workflow.SFTP_HOSTNAME))
	                .append(Workflow.SFTP_USERNAME, objConfig.get(Workflow.SFTP_USERNAME))
	                .append(Workflow.SFTP_PW, objConfig.get(Workflow.SFTP_PW))
	                .append(Workflow.SFTP_DIRECTORY, objConfig.get(Workflow.SFTP_DIRECTORY))
	                .append(Workflow.SFTP_ARCHIVE_DIRECTORY, objConfig.get(Workflow.SFTP_ARCHIVE_DIRECTORY))
	                .append(Workflow.SFTP_PW_ARC, objConfig.get(Workflow.SFTP_PW_ARC))
	                .append(Workflow.SFTP_USERNAME_ARC, objConfig.get(Workflow.SFTP_USERNAME_ARC))
	                .append(Workflow.SFTP_FILENAME, objConfig.get(Workflow.SFTP_FILENAME))
	                .append(Workflow.ENVIRONMENT, objConfig.get(Workflow.ENVIRONMENT))
	                .append(Workflow.DOCUMENT_FORMAT_FIELD, objConfig.get(Workflow.DOCUMENT_FORMAT_FIELD))
	                .append(Workflow.DOC_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOC_UPDATE_FLAG_PATH))
	                .append(Workflow.DOC_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOC_UPDATE_FLAG_VALUE))
	                .append(Workflow.ADD_ORIGINAL_ZIP_FILENAME, objConfig.get(Workflow.ADD_ORIGINAL_ZIP_FILENAME))
	                .append(Workflow.FDS_DOCUMENTS_URL, objConfig.get(Workflow.FDS_DOCUMENTS_URL))
	                .append(Workflow.FILE_FORMAT, objConfig.get(Workflow.FILE_FORMAT))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.RESPONSEFILE_PROCESS_KEY)
                    .append(Workflow.ACK_FILE_DATA, objConfig.get(Workflow.ACK_FILE_DATA))
	                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS));

	        runProcess(ProcessKeys.RESPONSEFILE_PROCESS_KEY, variablesWithValue);

	    }
	    
	    @SuppressWarnings("rawtypes")
	    public static void responseMessageProcess(Map<String, Object> variables) throws IOException {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        var variablesWithValue = new Document()
	                .append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
                    .append(Workflow.KAFKA_TOPIC_NAME, objConfig.get(Workflow.KAFKA_TOPIC_NAME))
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
	                .append(Workflow.DOCUMENT_FORMAT_FIELD, objConfig.get(Workflow.DOCUMENT_FORMAT_FIELD))
	                .append(Workflow.DOC_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOC_UPDATE_FLAG_PATH))
	                .append(Workflow.DOC_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOC_UPDATE_FLAG_VALUE))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.RESPONSE_MESSAGE_PROCESS_KEY);

	        runProcess(ProcessKeys.RESPONSE_MESSAGE_PROCESS_KEY, variablesWithValue);

	    }

    @SuppressWarnings("rawtypes")
    public static void convertMetadataProcess(Map<String, Object> variables) throws IOException {
        Map hook = (Map) variables.get("hook");
        Map action = (Map) hook.get("action");
        Map objConfig = (Map) action.get("config");

        var variablesWithValue = new Document()
                .append(Workflow.HOOK_ID, variables.get("id"))
                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
                .append(Workflow.CLIENT_NAME, objConfig.get(Workflow.CLIENT_NAME))
                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
                .append(Workflow.PROCESS_KEY, ProcessKeys.PROCESS_CONVERT_METADATA);

        runProcess(ProcessKeys.PROCESS_CONVERT_METADATA, variablesWithValue);

    }
	    
	    @SuppressWarnings("rawtypes")
	    public static void responseFileProcessUSPClaims(Map<String, Object> variables) throws IOException {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        var variablesWithValue = new Document()
	                .append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
	                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.SFTP_HOSTNAME, objConfig.get(Workflow.SFTP_HOSTNAME))
	                .append(Workflow.SFTP_USERNAME, objConfig.get(Workflow.SFTP_USERNAME))
	                .append(Workflow.SFTP_PW, objConfig.get(Workflow.SFTP_PW))
	                .append(Workflow.SFTP_DIRECTORY, objConfig.get(Workflow.SFTP_DIRECTORY))
	                .append(Workflow.SFTP_ARCHIVE_DIRECTORY, objConfig.get(Workflow.SFTP_ARCHIVE_DIRECTORY))
	                .append(Workflow.SFTP_PW_ARC, objConfig.get(Workflow.SFTP_PW_ARC))
	                .append(Workflow.SFTP_USERNAME_ARC, objConfig.get(Workflow.SFTP_USERNAME_ARC))
	                .append(Workflow.SFTP_FILENAME, objConfig.get(Workflow.SFTP_FILENAME))
	                .append(Workflow.ENVIRONMENT, objConfig.get(Workflow.ENVIRONMENT))
	                .append(Workflow.DOCUMENT_FORMAT_FIELD, objConfig.get(Workflow.DOCUMENT_FORMAT_FIELD))
	                .append(Workflow.DOC_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOC_UPDATE_FLAG_PATH))
	                .append(Workflow.DOC_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOC_UPDATE_FLAG_VALUE))
	                .append(Workflow.ADD_ORIGINAL_ZIP_FILENAME, objConfig.get(Workflow.ADD_ORIGINAL_ZIP_FILENAME))
	                .append(Workflow.FDS_DOCUMENTS_URL, objConfig.get(Workflow.FDS_DOCUMENTS_URL))
	                .append(Workflow.FILE_FORMAT, objConfig.get(Workflow.FILE_FORMAT))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.RESPONSEFILE_PROCESS_KEY_USP_CLAIMS)
	                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
	                .append(Workflow.USPCLAIMS_REST_URL, objConfig.get(Workflow.USPCLAIMS_REST_URL))
	                .append(Workflow.NOTIFY_API_OAUTH_URL, objConfig.get(Workflow.NOTIFY_API_OAUTH_URL))
	                .append(Workflow.NOTIFY_API_CLIENT_ID, objConfig.get(Workflow.NOTIFY_API_CLIENT_ID))
	                .append(Workflow.NOTIFY_API_CLIENT_SECRET, objConfig.get(Workflow.NOTIFY_API_CLIENT_SECRET))
	                .append(Workflow.NUM_RETRIES, objConfig.get(Workflow.NUM_RETRIES))
	                .append(Workflow.TIME_TO_WAIT, objConfig.get(Workflow.TIME_TO_WAIT));

	        runProcess(ProcessKeys.RESPONSEFILE_PROCESS_KEY_USP_CLAIMS, variablesWithValue);

	    }
	    @SuppressWarnings("rawtypes")
	    public static void retrieveAndCreateMetadataFilesProcess(Map<String, Object> variables) throws IOException {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        var variablesWithValue = new Document()
	                .append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
	                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.PROV_SEARCH_URL, objConfig.get(Workflow.PROV_SEARCH_URL))
	                .append(Workflow.PES_GRANT_TYPE, objConfig.get(Workflow.PES_GRANT_TYPE))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.RETRIEVE_AND_SEND_METADATA_PROCESS)
	                .append(Workflow.PROV_APP_NAME, objConfig.get(Workflow.PROV_APP_NAME))
	                .append(Workflow.PROV_ATTRIBUTE_SET, objConfig.get(Workflow.PROV_ATTRIBUTE_SET))
	                .append(Workflow.PES_APP_ID, objConfig.get(Workflow.PES_APP_ID))
	                .append(Workflow.PES_APP_SECRET, objConfig.get(Workflow.PES_APP_SECRET))
	                .append(Workflow.PES_OAUTH_URL, objConfig.get(Workflow.PES_OAUTH_URL))
	                .append(Workflow.ADR_TYPE_CD, objConfig.get(Workflow.ADR_TYPE_CD))
	                .append(Workflow.ST_CD, objConfig.get(Workflow.ST_CD))
	                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
	                .append(Workflow.PROVIDERPROVINCE, objConfig.get(Workflow.PROVIDERPROVINCE))
	                .append(Workflow.PROVIDERCOUNTRY, objConfig.get(Workflow.PROVIDERCOUNTRY))
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.SFTP_HOSTNAME, objConfig.get(Workflow.SFTP_HOSTNAME))
	                .append(Workflow.SFTP_USERNAME, objConfig.get(Workflow.SFTP_USERNAME))
	                .append(Workflow.SFTP_PW, objConfig.get(Workflow.SFTP_PW))
	                .append(Workflow.SFTP_DIRECTORY, objConfig.get(Workflow.SFTP_DIRECTORY))
	                .append(Workflow.SFTP_ARCHIVE_DIRECTORY, objConfig.get(Workflow.SFTP_ARCHIVE_DIRECTORY))
	                .append(Workflow.SFTP_USERNAME_ARC, objConfig.get(Workflow.SFTP_USERNAME_ARC))
	                .append(Workflow.SFTP_PW_ARC, objConfig.get(Workflow.SFTP_PW_ARC));
	        

	        runProcess(ProcessKeys.RETRIEVE_AND_SEND_METADATA_PROCESS, variablesWithValue);

	    }

	    public static void processCleanUp(String processKey, String processorTransactionId, String appIdentifier) throws IOException {
	        //  String task = "processCleanupFilesCreateACK";
	        var variables = new Document()
	                .append(Workflow.PROCESSOR_TRANSACTION_ID, processorTransactionId)
	                .append(Workflow.APP_IDENTIFIER, appIdentifier)
	                .append(Workflow.PROCESS_KEY, processKey);
	        runProcess(processKey, variables);

	    }


	    private static void emailProcessorTransactionMetadataProcess() throws IOException {
	        String task = "emailProcessorTransactionMetadataProcess";
	        String searchWindow = "{\"start_date_offset\" : {\"time_window\" : \"30\", \"format\" : \"Days\" },\"end_date_offset\":{\"time_window\":\"0\",\"format\":\"Minutes\" } }";
	        var variables = new Document()
	                .append(Workflow.SEARCH_CRITERIA, "{\"configSpaceId\": 10068 }")
	                .append(Workflow.SEARCH_WINDOW, searchWindow)
	                .append(Workflow.EMAIL_RECEIVER, "ankur_kumar90@optum.com")
	                .append(Workflow.EMAIL_SENDER, "test@1test.com")
	                .append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, "addedToCosmosPraResponseFile")
	                .append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, "true")
	                .append(Workflow.EMAIL_SUBJECT, "Companion File Alert")
	                .append(Workflow.REST_CONFIG_SPACE_ID, 10068)
	                .append(Workflow.TEMPLATE_ID, "6086b96433d354ccfdf89396")
	                .append(Workflow.ENVIRONMENT, "test")
	                .append(Workflow.PROCESS_KEY, ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY);

	        runProcess(task, variables);

	    }
	    
	    public static ProcessInstance fileUnziprunProcess(String processKey, Map<String, Object> variables) {
	        ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
	        RuntimeService runtimeService = processEngine.getRuntimeService();
	        ProcessInstance pi = runtimeService.startProcessInstanceByKey(processKey, variables);
	        return pi;
	    }
	    
	    public static void postDocumentDocLibForELGSProcess(Map<String, Object> variables){

	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        String task = "postDocumentDocvaultForElgsProcess";
	      
	        if (ProcessKeys.POST_DOCUMENT_DOCLIB_FOR_ELGS_PROCESS_KEY.equalsIgnoreCase(task)) {

	            var variablesWithValue = new Document()
	                    .append(Workflow.HOOK_ID, variables.get("id"))
	                    .append(Workflow.DOCLIB_OAUTH_URL, objConfig.get(Workflow.DOCLIB_OAUTH_URL))
	                    .append(Workflow.DOCLIB_CLIENT_ID, objConfig.get(Workflow.DOCLIB_CLIENT_ID))
	                    .append(Workflow.DOCLIB_CLIENT_SECRET, objConfig.get(Workflow.DOCLIB_CLIENT_SECRET))
	                    .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                    .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                    .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
	                    .append(Workflow.PROCESS_KEY, objConfig.get(Workflow.PROCESS_KEY))
	                    .append(Workflow.REST_ACCESS_TOKEN, objConfig.get(Workflow.REST_ACCESS_TOKEN))
	                    .append(Workflow.DOCLIB_REST_URL, objConfig.get(Workflow.DOCLIB_REST_URL))
	                    .append(Workflow.SLA_TIME, objConfig.get(Workflow.SLA_TIME)) // SLA time in hours
	                    .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                    .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                    .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
	            		.append(Workflow.BATCH_SIZE,objConfig.get(Workflow.BATCH_SIZE));
	          
	            runProcess(task, variablesWithValue);
	        }
	    }
	    
	  @SuppressWarnings("rawtypes")
	    public static void providerEmailNotificationProcess(Map<String, Object> variables) {

	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	      //  Map objproviderEmailNotificationProcessConfig = (Map) objConfig.get("providerEmailNotificationProcess");
	      //  String task = objproviderEmailNotificationProcessConfig.get(Workflow.PROCESS_KEY).toString();
	        String task ="providerEmailNotificationProcess";

	        if (ProcessKeys.PROVIDER_EMAIL_NOTIFICATION_PROCESS_KEY.equalsIgnoreCase(task)) {

	            var variablesWithValue = new Document()
	            		.append(Workflow.HOOK_ID, variables.get("id"))
	            		.append(Workflow.CLIENT_ID, variables.get("clientId"))
	                    .append(Workflow.PEN_API_URL, objConfig.get(Workflow.PEN_API_URL))
	                    .append(Workflow.APP_ID, objConfig.get(Workflow.APP_ID))
	                    .append(Workflow.APP_SECRET, objConfig.get(Workflow.APP_SECRET))
	                    .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                    .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                    .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                    .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                    .append(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_VALUE))
	                    .append(Workflow.DOCUMENT_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_PATH))
	                    .append(Workflow.MAX_RETRIES, objConfig.get(Workflow.MAX_RETRIES))
	                    .append(Workflow.RETRY_SLEEP_TIME, objConfig.get(Workflow.RETRY_SLEEP_TIME))
	                    .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
	                    .append(Workflow.FDS_DOCUMENTS_URL, objConfig.get(Workflow.FDS_DOCUMENTS_URL))
	                    .append(Workflow.PEN_API_MULTI_CLOUD_URL, objConfig.get(Workflow.PEN_API_MULTI_CLOUD_URL))
	                    .append(Workflow.PEN_OAUTH_URL, objConfig.get(Workflow.PEN_OAUTH_URL))
	                    .append(Workflow.PEN_APP_ID, objConfig.get(Workflow.PEN_APP_ID))
	                    .append(Workflow.PEN_APP_SECRET, objConfig.get(Workflow.PEN_APP_SECRET))
	                    .append(Workflow.PEN_GRANT_TYPE, objConfig.get(Workflow.PEN_GRANT_TYPE))
                        .append(Workflow.PEN_SCOPE, objConfig.get(Workflow.PEN_SCOPE))
	                    .append(Workflow.PROCESS_KEY, ProcessKeys.PROVIDER_EMAIL_NOTIFICATION_PROCESS_KEY);

	            runProcess(task, variablesWithValue);
	        }
	    }
	  public static void createStatusFileAndAckProcess(Map<String, Object> variables) throws IOException {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        var variablesWithValue = new Document()
	                .append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
	                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.SFTP_HOSTNAME, objConfig.get(Workflow.SFTP_HOSTNAME))
	                .append(Workflow.SFTP_USERNAME, objConfig.get(Workflow.SFTP_USERNAME))
	                .append(Workflow.SFTP_PW, objConfig.get(Workflow.SFTP_PW))
	                .append(Workflow.SFTP_DIRECTORY, objConfig.get(Workflow.SFTP_DIRECTORY))
	                .append(Workflow.SFTP_ARCHIVE_DIRECTORY, objConfig.get(Workflow.SFTP_ARCHIVE_DIRECTORY))
	                .append(Workflow.SFTP_PW_ARC, objConfig.get(Workflow.SFTP_PW_ARC))
	                .append(Workflow.SFTP_USERNAME_ARC, objConfig.get(Workflow.SFTP_USERNAME_ARC))
	                .append(Workflow.JSON_FILE, objConfig.get(Workflow.JSON_FILE))
	                .append(Workflow.OUTPUT_FILE_DIR, objConfig.get(Workflow.OUTPUT_FILE_DIR))
	                .append(Workflow.OUTPUT_FILE_EXTENSION, objConfig.get(Workflow.OUTPUT_FILE_EXTENSION))
	                .append(Workflow.ZIP_OUTPUT_FILE, objConfig.get(Workflow.ZIP_OUTPUT_FILE))
	                .append(Workflow.SFTP_FILE_LIST, objConfig.get(Workflow.SFTP_FILE_LIST))
	                .append(Workflow.DOC_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOC_UPDATE_FLAG_PATH))
	                .append(Workflow.DOC_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOC_UPDATE_FLAG_VALUE))
	                .append(Workflow.FDS_DOCUMENTS_URL, objConfig.get(Workflow.FDS_DOCUMENTS_URL))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.STATUSFILE_PROCESS_KEY);

	        runProcess(ProcessKeys.STATUSFILE_PROCESS_KEY, variablesWithValue);
	    }
	  private static Map<String, Object> getProcess(String processObj) {
	        return org.bson.Document.parse(processObj);
	    }

	    private static ProcessorMetaData getProcessorMetadata(String processObj) {
	        ProcessorMetaData processor = new ProcessorMetaData();
	        processor.setProcess(getProcess(processObj));
	        processor.setStatus(MetaDataStatus.ACTIVE);
	        return processor;
	    }


	    @SuppressWarnings("rawtypes")
	    public static void bounceEmailWorkflow(Map<String, Object> variables) {
	        Map bounceEmailHook = (Map) variables.get("hook");
	        Map hook = (Map) bounceEmailHook.get("hook");
	        Map action = (Map) hook.get("action");
	        Map config = (Map) action.get("config");

	        DocumentMetaData bounceEmailDoc = mapper.convertValue(variables.get("document"), DocumentMetaData.class);

	        var variablesWithValue = new Document()
					.append(Workflow.HOOK_ID, bounceEmailHook.get("id"))
					.append(Workflow.CLIENT_ID, bounceEmailHook.get(Workflow.CLIENTID))
					.append(Workflow.DOCUMENT, bounceEmailDoc)
	                .append(APP_ID, config.get(APP_ID))
	                .append(APP_SECRET, config.get(APP_SECRET))
	                .append(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL, config.get(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL))
	                .append(Workflow.FDS_CLOUD_AUTH_URL, config.get(Workflow.FDS_CLOUD_AUTH_URL))
	                .append(Workflow.CLOUD_CLIENT_ID, config.get(Workflow.CLOUD_CLIENT_ID))
	                .append(Workflow.CLOUD_CLIENT_SECRET, config.get(Workflow.CLOUD_CLIENT_SECRET))
	                .append(Workflow.CLOUD_GRANT_TYPE, config.get(Workflow.CLOUD_GRANT_TYPE))
	                .append(Workflow.TEMPLATE_NAME, config.get(Workflow.TEMPLATE_NAME))
					.append(Workflow.SEARCH_WINDOW, config.get(Workflow.SEARCH_WINDOW))
	                .append(SFTP_USERNAME, config.get(SFTP_USERNAME))
	                .append(SFTP_PW, config.get(SFTP_PW))
	                .append(SFTP_USERNAME_ARC, config.get(SFTP_USERNAME_ARC))
	                .append(SFTP_PW_ARC, config.get(SFTP_PW_ARC))
	                .append(SFTP_DIRECTORY, config.get(SFTP_DIRECTORY))
	                .append(SFTP_HOSTNAME, config.get(SFTP_HOSTNAME))
	                .append(SFTP_ARCHIVE_DIRECTORY, config.get(SFTP_ARCHIVE_DIRECTORY))
	                .append(SPACE_ID, config.get(SPACE_ID))
	                .append(MAX_DOCUMENTS_OCCURS, config.get(MAX_DOCUMENTS_OCCURS))
	                .append(START_DATE_IN_DAYS, config.get(START_DATE_IN_DAYS))
	                .append(ADDRESS_BLOCK_X, config.get(ADDRESS_BLOCK_X))
	                .append(ADDRESS_BLOCK_Y, config.get(ADDRESS_BLOCK_Y))
	                .append(IDENTIFIER_FONT_SIZE, config.get(IDENTIFIER_FONT_SIZE))
	                .append(ORIGINAL_PRINT_TRAIL, config.get(ORIGINAL_PRINT_TRAIL))
	                .append(RECEIVER_IDENTIFIER, config.get(RECEIVER_IDENTIFIER))
	                .append(SKIP_MANIPULATE_PDF_FILE, config.get(SKIP_MANIPULATE_PDF_FILE))
	                .append(CREATE_ORIGINAL_COMPANION_FILE, config.get(CREATE_ORIGINAL_COMPANION_FILE))
	                .append(BOUNCE_EMAIL_CHECK_EFT_IND, config.get(BOUNCE_EMAIL_CHECK_EFT_IND))
	                .append(DOCUMENT_FORMAT_FIELD, config.get(DOCUMENT_FORMAT_FIELD))
	                .append(WRITE_ENCRYPTED_PDF, config.get(WRITE_ENCRYPTED_PDF))
	                .append(Workflow.SKIP_SEND_TO_SHUTTERFLY, config.get(Workflow.SKIP_SEND_TO_SHUTTERFLY))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.BOUNCE_PROCESS_KEY)
					.append(Workflow.DOC360_SCOPE, config.get(Workflow.DOC360_SCOPE))
					.append(Workflow.DOC360_APP_ID, config.get(Workflow.DOC360_APP_ID))
					.append(Workflow.DOC360_APP_SECRET, config.get(Workflow.DOC360_APP_SECRET))
					.append(Workflow.DOC360_SCOPE, config.get(Workflow.DOC360_SCOPE))
					.append(Workflow.DOC360_OAUTH_URL, config.get(Workflow.DOC360_OAUTH_URL))
					.append(Workflow.DOC360_GET_ATTACHMENT_URL, config.get(Workflow.DOC360_GET_ATTACHMENT_URL))
					.append(Workflow.USE_DOC360, config.get(Workflow.USE_DOC360))
					.append(Workflow.X_UPSTREAM_ENV, config.get(Workflow.X_UPSTREAM_ENV));;

	        runProcess(ProcessKeys.BOUNCE_PROCESS_KEY, variablesWithValue);
	    }
	    
	    @SuppressWarnings("rawtypes")
	    public static void storageErrorShutterflyWorkflow(Map<String, Object> variables) {
	    	Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        var variablesWithValue = new Document()
	        		.append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.APP_ID, objConfig.get(Workflow.APP_ID))
	                .append(Workflow.APP_SECRET, objConfig.get(Workflow.APP_SECRET))
	                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))                
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.SPACE_ID, objConfig.get(Workflow.SPACE_ID))
	                .append(Workflow.SKIP_MANIPULATE_PDF_FILE, objConfig.get(Workflow.SKIP_MANIPULATE_PDF_FILE))
	                .append(Workflow.ADDRESS_BLOCK_X, objConfig.get(Workflow.ADDRESS_BLOCK_X))
	                .append(Workflow.ADDRESS_BLOCK_Y, objConfig.get(Workflow.ADDRESS_BLOCK_Y))
	                .append(Workflow.IDENTIFIER_FONT_SIZE, objConfig.get(Workflow.IDENTIFIER_FONT_SIZE))
	                .append(Workflow.RECEIVER_IDENTIFIER, objConfig.get(Workflow.RECEIVER_IDENTIFIER))
	                .append(SFTP_USERNAME, objConfig.get(Workflow.SFTP_USERNAME))
	                .append(SFTP_PW, objConfig.get(SFTP_PW))
	                .append(SFTP_USERNAME_ARC, objConfig.get(Workflow.SFTP_USERNAME_ARC))
	                .append(SFTP_PW_ARC, objConfig.get(Workflow.SFTP_PW_ARC))
	                .append(SFTP_DIRECTORY, objConfig.get(Workflow.SFTP_DIRECTORY))
	                .append(SFTP_HOSTNAME, objConfig.get(SFTP_HOSTNAME))
	                .append(SFTP_ARCHIVE_DIRECTORY, objConfig.get(SFTP_ARCHIVE_DIRECTORY))
	                .append(Workflow.DOCUMENT_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_PATH))
	                .append(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_VALUE))
	                .append(Workflow.FDS_DOCUMENT_URL, objConfig.get(Workflow.FDS_DOCUMENT_URL))
	                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
	                .append(Workflow.CREATE_ORIGINAL_COMPANION_FILE, objConfig.get(Workflow.CREATE_ORIGINAL_COMPANION_FILE))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.STORAGE_ERROR_SHUTTERFLY_PROCESS_KEY);

	        runProcess(ProcessKeys.STORAGE_ERROR_SHUTTERFLY_PROCESS_KEY, variablesWithValue);
	    }

	    @SuppressWarnings("rawtypes")
	    public static void shutterflyWorkflow(Map<String, Object> variables) {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");

	        var variablesWithValue = new Document()
	        		.append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.APP_ID, objConfig.get(Workflow.APP_ID))
	                .append(Workflow.APP_SECRET, objConfig.get(Workflow.APP_SECRET))
	                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
	                .append(Workflow.FDS_CLOUD_AUTH_URL, objConfig.get(Workflow.FDS_CLOUD_AUTH_URL))
	                .append(Workflow.CLOUD_CLIENT_ID, objConfig.get(Workflow.CLOUD_CLIENT_ID))
	                .append(Workflow.CLOUD_CLIENT_SECRET, objConfig.get(Workflow.CLOUD_CLIENT_SECRET))
	                .append(Workflow.CLOUD_GRANT_TYPE, objConfig.get(Workflow.CLOUD_GRANT_TYPE))
	                .append(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL, objConfig.get(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL))	                
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.SPACE_ID, objConfig.get(Workflow.SPACE_ID))
	                .append(Workflow.SKIP_MANIPULATE_PDF_FILE, objConfig.get(Workflow.SKIP_MANIPULATE_PDF_FILE))
	                .append(Workflow.ADDRESS_BLOCK_X, objConfig.get(Workflow.ADDRESS_BLOCK_X))
	                .append(Workflow.ADDRESS_BLOCK_Y, objConfig.get(Workflow.ADDRESS_BLOCK_Y))
	                .append(Workflow.IDENTIFIER_FONT_SIZE, objConfig.get(Workflow.IDENTIFIER_FONT_SIZE))
	                .append(Workflow.RECEIVER_IDENTIFIER, objConfig.get(Workflow.RECEIVER_IDENTIFIER))
	                .append(SFTP_USERNAME, objConfig.get(Workflow.SFTP_USERNAME))
	                .append(SFTP_PW, objConfig.get(SFTP_PW))
	                .append(SFTP_USERNAME_ARC, objConfig.get(Workflow.SFTP_USERNAME_ARC))
	                .append(SFTP_PW_ARC, objConfig.get(Workflow.SFTP_PW_ARC))
	                .append(SFTP_DIRECTORY, objConfig.get(Workflow.SFTP_DIRECTORY))
	                .append(SFTP_HOSTNAME, objConfig.get(SFTP_HOSTNAME))
	                .append(SFTP_ARCHIVE_DIRECTORY, objConfig.get(SFTP_ARCHIVE_DIRECTORY))
	                .append(Workflow.DOCUMENT_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_PATH))
	                .append(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_VALUE))
	                .append(Workflow.FDS_DOCUMENT_URL, objConfig.get(Workflow.FDS_DOCUMENT_URL))
	                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
	                .append(Workflow.CREATE_ORIGINAL_COMPANION_FILE, objConfig.get(Workflow.CREATE_ORIGINAL_COMPANION_FILE))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.SHUTTERFLY_PROCESS_KEY)
					.append(Workflow.DOC360_SCOPE, objConfig.get(Workflow.DOC360_SCOPE))
					.append(Workflow.DOC360_APP_ID, objConfig.get(Workflow.DOC360_APP_ID))
					.append(Workflow.DOC360_APP_SECRET, objConfig.get(Workflow.DOC360_APP_SECRET))
					.append(Workflow.DOC360_OAUTH_URL, objConfig.get(Workflow.DOC360_OAUTH_URL))
					.append(Workflow.DOC360_GET_ATTACHMENT_URL, objConfig.get(Workflow.DOC360_GET_ATTACHMENT_URL))
					.append(Workflow.USE_DOC360, objConfig.get(Workflow.USE_DOC360))
					.append(Workflow.X_UPSTREAM_ENV, objConfig.get(Workflow.X_UPSTREAM_ENV));

			runProcess(ProcessKeys.SHUTTERFLY_PROCESS_KEY, variablesWithValue);
	    }

	    @SuppressWarnings("rawtypes")
		public static void matchAndMergeWorkflow(Map<String, Object> variables) {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");
	        var variablesWithValue = new Document()
	                .append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
	                .append(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER))
	                .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.MATCH_CRITERIA, objConfig.get(Workflow.MATCH_CRITERIA))
	                .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                .append(Workflow.DOCUMENT_UPDATE_FLAG_PATH, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_PATH))
	                .append(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, objConfig.get(Workflow.DOCUMENT_UPDATE_FLAG_VALUE))
	                .append(Workflow.EFT_IND, objConfig.get(Workflow.EFT_IND))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.MATCH_AND_MERGE_PROCESS_KEY);
	        runProcess(ProcessKeys.MATCH_AND_MERGE_PROCESS_KEY, variablesWithValue);
	    }

	    @SuppressWarnings("rawtypes")
	    public static void emailProcessorTransactionMetadataWorkflow(Map<String, Object> variables) {
	        Map hook = (Map) variables.get("hook");
	        Map action = (Map) hook.get("action");
	        Map objConfig = (Map) action.get("config");
	        var variablesWithValue = new Document()
	                .append(Workflow.HOOK_ID, variables.get("id"))
	                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
	                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
	                .append(Workflow.TEMPLATE_ID, objConfig.get(Workflow.TEMPLATE_ID))
	                .append(Workflow.TEMPLATE_NAME, objConfig.get(Workflow.TEMPLATE_NAME))
	                .append(Workflow.EMAIL_SENDER, objConfig.get(Workflow.EMAIL_SENDER))
	                .append(Workflow.EMAIL_RECEIVER, objConfig.get(Workflow.EMAIL_RECEIVER))
	                .append(Workflow.EMAIL_SUBJECT, objConfig.get(Workflow.EMAIL_SUBJECT))
	                .append(Workflow.ENVIRONMENT, objConfig.get(Workflow.ENVIRONMENT))
	                .append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, objConfig.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH))
	                .append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, objConfig.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE))
	                .append(Workflow.PROCESS_KEY, ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY);
	        runProcess(ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY, variablesWithValue);
	    }

	@SuppressWarnings("rawtypes")
	public static void corpMPIN(Map<String, Object> variables) {
		try {

			Map hook = (Map) variables.get("hook");
			Map action = (Map) hook.get("action");
			Map objConfig = (Map) action.get("config");
			Map objCorpMPINConfig = (Map) objConfig.get("corporateMPIN");
			String task = objCorpMPINConfig.get(Workflow.PROCESS_KEY).toString();

			if (ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY.equalsIgnoreCase(task)) {
				Map<String, Object> variablesWithValue = new HashMap<String, Object>();
				variablesWithValue.put(Workflow.APP_IDENTIFIER, variables.get(Workflow.APP_IDENTIFIER));
				variablesWithValue.put("appName", objCorpMPINConfig.get("appName"));
				variablesWithValue.put("attributeSet", objCorpMPINConfig.get("attributeSet"));
				variablesWithValue.put("provSearchUrl", objCorpMPINConfig.get("provSearchUrl"));
				variablesWithValue.put(Workflow.HOOK_ID, variables.get("id"));
				variablesWithValue.put("count", objCorpMPINConfig.get("count"));
				variablesWithValue.put(Workflow.SPACE_ID, variables.get(Workflow.SPACE_ID));
				variablesWithValue.put(Workflow.DOCID, variables.get(Workflow.DOCID));
				variablesWithValue.put(Workflow.PES_APP_ID, objCorpMPINConfig.get(Workflow.PES_APP_ID));
				variablesWithValue.put(Workflow.PES_APP_SECRET, objCorpMPINConfig.get(Workflow.PES_APP_SECRET));
				variablesWithValue.put(Workflow.PES_OAUTH_URL, objCorpMPINConfig.get(Workflow.PES_OAUTH_URL));
				variablesWithValue.put(Workflow.PES_GRANT_TYPE, objCorpMPINConfig.get(Workflow.PES_GRANT_TYPE));
				variablesWithValue.put("validateCorprateMPIN", objCorpMPINConfig.get("validateCorprateMPIN"));
				variablesWithValue.put(Workflow.PROCESS_KEY, ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY);
			    runProcess(ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY, variablesWithValue);

			}
		} catch (Exception ex) {
			LOGGER.error("Error to process corporate mpin: {}", ex.getMessage());
		}
	}
		
		@SuppressWarnings("rawtypes")
		public static void retrieveCorporateMPINv2Process(Map<String, Object> variables) {

		    Map hook = (Map) variables.get("hook");
		    Map action = (Map) hook.get("action");
		    Map objConfig = (Map) action.get("config");
		    String task = "retrieveCorporateMPINv2Process";
		    if (ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY.equalsIgnoreCase(task)) {

		        var variablesWithValue = new Document()
		                .append(Workflow.HOOK_ID, variables.get("id"))
		                .append(Workflow.APP_ID, objConfig.get(Workflow.APP_ID))
		                .append(Workflow.APP_SECRET, objConfig.get(Workflow.APP_SECRET))
		                .append(Workflow.SPACE_ID, variables.get(Workflow.SPACE_ID))
		                .append(Workflow.OAUTH_URL, objConfig.get(Workflow.OAUTH_URL))
		                .append(Workflow.GRANT_TYPE, objConfig.get(Workflow.GRANT_TYPE))
		                .append(Workflow.OAUTH_TOKEN, objConfig.get(Workflow.OAUTH_TOKEN))
		                .append(Workflow.PROV_APP_NAME, objConfig.get(Workflow.PROV_APP_NAME))
		                .append(Workflow.PROV_ATTRIBUTE_SET, objConfig.get(Workflow.PROV_ATTRIBUTE_SET))
		                .append(Workflow.PROV_COUNT, objConfig.get(Workflow.PROV_COUNT))
		                .append(Workflow.PROV_SEARCH_URL, objConfig.get(Workflow.PROV_SEARCH_URL))
		                .append(Workflow.PROV_PROCESS_KEY, objConfig.get(Workflow.PROV_PROCESS_KEY))
		                .append(Workflow.DOCID, variables.get("docId"))
		                .append(Workflow.PROCESS_KEY, ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY);
		        runProcess(task, variablesWithValue);
		    }
		}

    @SuppressWarnings("rawtypes")
    public static void updateDocsWithSecondaryEmailWorkflow(Map<String, Object> variables) {
        Map hook = (Map) variables.get("hook");
        Map action = (Map) hook.get("action");
        Map objConfig = (Map) action.get("config");

        var variablesWithValue = new Document()
                .append(Workflow.HOOK_ID, variables.get("id"))
                .append(Workflow.CLIENT_ID, variables.get(Workflow.CLIENTID))
                .append(Workflow.SPACE_ID, variables.get(Workflow.SPACE_ID))
                .append(Workflow.PDO_OAUTH_URL, objConfig.get(Workflow.PDO_OAUTH_URL))
                .append(Workflow.PDO_API_URL, objConfig.get(Workflow.PDO_API_URL))
                .append(Workflow.PDO_CLIENT_ID, objConfig.get(Workflow.PDO_CLIENT_ID))
                .append(Workflow.PDO_CLIENT_SECRET, objConfig.get(Workflow.PDO_CLIENT_SECRET))
                .append(Workflow.SEARCH_CRITERIA, objConfig.get(Workflow.SEARCH_CRITERIA))
                .append(Workflow.MAX_RETRIES, objConfig.get(Workflow.MAX_RETRIES))
                .append(Workflow.RETRY_SLEEP_TIME, objConfig.get(Workflow.RETRY_SLEEP_TIME))
                .append(Workflow.SEARCH_WINDOW, objConfig.get(Workflow.SEARCH_WINDOW))
                .append(Workflow.MAX_DOCUMENTS_OCCURS, objConfig.get(Workflow.MAX_DOCUMENTS_OCCURS))
                .append(Workflow.PROCESS_KEY, ProcessKeys.UPDATE_DOCS_WITH_SECONDARY_EMAIL_PROCESS_KEY);

        runProcess(ProcessKeys.UPDATE_DOCS_WITH_SECONDARY_EMAIL_PROCESS_KEY, variablesWithValue);
    }
		
//		@SuppressWarnings("rawtypes")
//		public static void retrieveCorporateMPINv2EhCacheLoadTestProcess(Map<String, Object> variables) {
//		    Map hook = (Map) variables.get("hook");
//		    Map action = (Map) hook.get("action");
//		    Map objConfig = (Map) action.get("config");
//		    String task = "retrieveCorporateMPINv2EhCacheLoadTestProcess";
//		        var variablesWithValue = new Document()
//		                .append("oauthTokenCache", variables.get("oauthTokenCache"))
//		                .append("randomMax", variables.get("randomMax"))
//		                .append("loopMax", variables.get("loopMax"))
//		                .append("statistics", variables.get("statistics"))
//		                .append("removeAll", variables.get("removeAll"))
//		                .append("getMpinFromSvcs", variables.get("getMpinFromSvcs"))
//		                .append("useMpinPesTps", variables.get("useMpinPesTps"))
//		                .append(Workflow.PES_APP_ID, variables.get(Workflow.PES_APP_ID))
//		                .append(Workflow.PES_APP_SECRET, variables.get(Workflow.PES_APP_SECRET))
//		                .append(Workflow.PES_OAUTH_URL, variables.get(Workflow.PES_OAUTH_URL))
//		                .append(Workflow.PES_GRANT_TYPE, variables.get(Workflow.PES_GRANT_TYPE))
//		                .append(Workflow.SPACE_ID, variables.get(Workflow.SPACE_ID))
//		                .append(Workflow.HOOK_ID, variables.get("id"))
//		                .append(Workflow.APP_ID, objConfig.get(Workflow.APP_ID))
//		                .append(Workflow.APP_SECRET, objConfig.get(Workflow.APP_SECRET))
//		                .append(Workflow.OAUTH_URL, objConfig.get(Workflow.OAUTH_URL))
//		                .append(Workflow.GRANT_TYPE, objConfig.get(Workflow.GRANT_TYPE))
//		                .append(Workflow.OAUTH_TOKEN, objConfig.get(Workflow.OAUTH_TOKEN))
//		                .append(Workflow.PROV_APP_NAME, objConfig.get(Workflow.PROV_APP_NAME))
//		                .append(Workflow.PROV_ATTRIBUTE_SET, objConfig.get(Workflow.PROV_ATTRIBUTE_SET))
//		                .append(Workflow.PROV_COUNT, objConfig.get(Workflow.PROV_COUNT))
//		                .append(Workflow.PROV_SEARCH_URL, objConfig.get(Workflow.PROV_SEARCH_URL))
//		                .append(Workflow.PROV_PROCESS_KEY, objConfig.get(Workflow.PROV_PROCESS_KEY))
//		                .append(Workflow.DOCID, variables.get("docId"))
//		                .append(Workflow.PROCESS_KEY, "retrieveCorporateMPINv2EhCacheLoadTestProcess");
//		        runProcess(task, variablesWithValue);
//		}
}
