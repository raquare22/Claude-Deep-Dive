package com.optum.fds.paperless.constants;

public final class ProcessKeys {
    private ProcessKeys() {
        throw new AssertionError("cannot instantiate");
    }

    public static final String PROCESS_METADATA = "processorMetaData";
    public static final String SFTP_PROCESS_KEY = "sftpProcess";
    public static final String SFTP_ZIP_UNZIP_PROCESS_KEY = "sftpZipUnzipProcess";
    public static final String UNZIP_FILE_PROCESS_KEY = "processFileUnzip";
    public static final String PROCESS_CONVERT_METADATA = "processConvertMetadata";
    public static final String PROCESS_METADATA_PROCESS_KEY = "processMetadataFiles";
    public static final String PROCESS_METADATA_CALLBACK_PROCESS_KEY = "processMetadataFilesCallback"; 
    public static final String CSV_SFTP_PROCESS_KEY = "csvSftpProcess"; 
    public static final String STATUSFILE_PROCESS_KEY = "createStatusFileAndAckProcess";
    public static final String SHUTTERFLY_PROCESS_KEY = "sendDocumentsToShutterflyProcess";
    public static final String STORAGE_ERROR_SHUTTERFLY_PROCESS_KEY = "sendStorageErrorToShutterfly";
    public static final String RESPONSEFILE_PROCESS_KEY = "createResponseFileProcess";
    public static final String RESPONSEFILE_PROCESS_KEY_USP_CLAIMS="createResponseFileProcessUSPClaims";
    public static final String BOUNCE_PROCESS_KEY = "bouncedProviderEmailAddressProcess";
    public static final String RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY = "retrieveProviderEmailAddressProcess";
    public static final String REQUIRED_FIELD_RULE_PROCESS_KEY = "requiredFieldRuleProcess";
    public static final String RETRIEVE_CORPORATE_MPIN_PROCESS_KEY = "retrieveCorporateMPINv2Process";
    public static final String PROVIDER_EMAIL_NOTIFICATION_PROCESS_KEY = "providerEmailNotificationProcess";
    public static final String MATCH_AND_MERGE_PROCESS_KEY = "matchAndMergeDocumentsFromDbProcess";
    public static final String EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY = "emailProcessorTransactionMetadataProcess";
    public static final String CLEANUP_PROCESS_KEY = "processCleanupFilesCreateACK";
    public static final String DOCLIB_PROCESS_KEY = "postDocumentDocvaultForElgsProcess";
    public static final String CSV_CLEANUP_PROCESS_KEY = "csvCleanupFilesProcess";
    public static final String GENERIC_WORKFLOW_PROCESS_KEY = "GENERIC_WORKFLOW_PROCESS_KEY";
    public static final String POST_DOCUMENT_DOCLIB_FOR_ELGS_PROCESS_KEY = "postDocumentDocvaultForElgsProcess";
    public static final String CALL_REST_API_WITH_MSG_SERVICE_ON_ERROR_CALLBACK_PROCESS_KEY = "callRestApiWithMsgServiceOnErrorCallback"; 
    public static final String PROCESS_TEXT_FILE = "processTextFile"; 
    public static final String PROCESS_SFTP_SEND_EMAIL = "sftpSendEmailProcess";
    public static final String RETRIEVE_AND_SEND_METADATA_PROCESS = "retrieveAndSendMetadataProcess";
    public static final String RESPONSE_MESSAGE_PROCESS_KEY = "createResponseMessageProcess";
    public static final String RETRIEVE_AND_SEND_EMAIL_PROCESS = "retrieveAndSendEmailProcess";
    public static final String SEND_BATCH_DYNAMIC_REQUEST_TO_PEN = "sendBatchDynamicEmailRequestToPEN";
    public static final String UPDATE_DOCS_WITH_SECONDARY_EMAIL_PROCESS_KEY = "updateDocsWithSecondaryEmailProcess";


}
