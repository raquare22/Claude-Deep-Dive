package com.optum.fds.paperless.template.java.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.document.util.Attachment;
import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilterReqFieldForDocvaultTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(FilterReqFieldForDocvaultTemplate.class);
    private static final String PIPE_DELIMITER = "|";
    private static final String PATIENT_ACCOUNT_NUMBER = "patientAccountNumber";
    private static final String PAYMENT_TYPE = "paymentType";

    ObjectMapper mapper = new ObjectMapper();

    public String filterDuplicates(String inputString) {
        String joinedInputString = "";

        try {
            if (!StringUtils.isEmpty(inputString)) {
                joinedInputString = (Arrays.asList(Arrays.stream(inputString.split("\\|"))
                        .filter(x -> !StringUtils.isBlank(x)).toArray(String[]::new)).stream()
                        .collect(Collectors.toSet())).stream()
                        .collect(Collectors.joining(PIPE_DELIMITER, PIPE_DELIMITER, PIPE_DELIMITER));
            }
        } catch (Exception e) {
            LOGGER.error("getting exception to filter duplicates {} {} ", inputString, ExceptionUtils.getStackTrace(e));
            joinedInputString = "";
        }

        return joinedInputString;
    }
    
	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT);
		
		LOGGER.debug("string template loaded, st={}", st);

		DocumentResponse document = (DocumentResponse) pojo;
		Attachment[] attachment = document.getAttachments();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        mapper.setDateFormat(df);

        String attachments;
        try {
			attachments = mapper.writeValueAsString(attachment);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}

//        String docClass = document.getDoc360DocClass();
        String createApplication = (String) document.getMetadata().get("createApplication");
        Map<String, String> metadataMap = new HashMap<>();

//        if (docClass != null && !docClass.isEmpty()) {
//            metadataMap.put("docClass", docClass);
//        }

        switch (createApplication) {
            case "CSP-PRA":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "multClaimNumber");
                removeSpecialCharacters(metadataMap, document, "memberId", "multMemberId");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "paymentNumber", "paymentNumber");
                removeSpecialCharacters(metadataMap, document, "checkId", "CheckTraceNumber");
                removeSpecialCharacters(metadataMap, document, "checkAmount", "checkAmt");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                break;
            case "PmntEng":
            case "USP-COM-PRS":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "multClaimNumber");
                removeSpecialCharacters(metadataMap, document, "memberId", "multMemberId");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "paymentNumber", "paymentNumber");
                removeSpecialCharacters(metadataMap, document, "checkId", "CheckTraceNumber");
                removeSpecialCharacters(metadataMap, document, "checkAmount", "CheckAmt");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                removeSpecialCharacters(metadataMap, document, "paymentDate", "paymentDate");
                removeSpecialCharacters(metadataMap, document, PAYMENT_TYPE, PAYMENT_TYPE);
                break;
            case "CheckWrite":
            case "CDC":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "multClaimNumber");
                removeSpecialCharacters(metadataMap, document, "memberId", "multMemberId");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "paymentNumber", "paymentNumber");
                removeSpecialCharacters(metadataMap, document, "checkId", "CheckTraceNumber");
                removeSpecialCharacters(metadataMap, document, "checkAmount", "CheckAmt");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                break;
            case "ODAR":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                filterAndRemoveSpecialCharacters(metadataMap, document, "memberName", "multMemberName");
                filterAndRemoveSpecialCharacters(metadataMap, document, "claimNumber", "multClaimNumber");
                filterAndRemoveSpecialCharacters(metadataMap, document, "memberId", "multMemberId");

                String dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
            break;
            case "ELGS":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "physicianName", "providerName");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                if (document.getMetadata().get("MemberAltID") != null) {
                    metadataMap.put("memberId", (String) document.getMetadata().get("MemberAltID"));
                } else {
                    metadataMap.put("memberId", (String) document.getMetadata().get("memberId"));
                }
                break;
            case "CIRRUS":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
            	removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "physicianName", "providerName");
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                break;
            case "LETGEN":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                if (document.getMetadata().get("MemberAltID") != null) {
                    removeSpecialCharacters(metadataMap, document, "memberId", "MemberAltID");
                } else {
                    removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                }
                break;
            case "Bottomline":
                removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "CheckTraceNumber", "CheckTraceNumber");
                break;
            case "NGS":
            case "MnR":
            case "ENI":
            case "CnS":
            case "NGSCNS":
            case "ATS":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
                removeSpecialCharacters(metadataMap, document, "notificationNumber", "notificationNumber");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
                removeSpecialCharacters(metadataMap, document, "caseId", "caseId");
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");

                if (document.getMetadata().get("physicianName") != null) {
                    removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                } else {
                    removeSpecialCharacters(metadataMap, document, "physicianName", "providerName");
                }

                break;
            case "ETS":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
            	removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
            	removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
            	removeSpecialCharacters(metadataMap, document, "caseId", "caseId");
            	removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
            	removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
            	break;
            	
            case "NICE":
            	removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
            	removeSpecialCharacters(metadataMap, document, "checkAmount", "CheckAmt");
                removeSpecialCharacters(metadataMap, document, "paymentNumber", "CheckTraceNumber");
                removeSpecialCharacters(metadataMap, document, "checkId", "CheckTraceNumber");
            	break;
            	
            case "1Click":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
                removeSpecialCharacters(metadataMap, document, "notificationId", "notificationNumber");
                
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && !dateOfService.isEmpty()) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                break;
            case "CCSManual":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
            	removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
                removeSpecialCharacters(metadataMap, document, "notificationId", "notificationNumber");
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                break;
            case "NextGen":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, "physicianName", "providerName");
                removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
                removeSpecialCharacters(metadataMap, document, "notificationId", "notificationNumber");
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                break;
            case "DOC1":
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "policyNumber", "policyNumber");
                removeSpecialCharacters(metadataMap, document, "memberName", "memberName");
                removeSpecialCharacters(metadataMap, document, "patientAccountNumber", "patientAccountNumber");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                
                if (document.getMetadata().get("MemberAltID") != null) {
                    removeSpecialCharacters(metadataMap, document, "memberId", "MemberAltID");
                } else {
                    removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                }
                break;
            case "MACESS":
            	removeSpecialCharacters(metadataMap, document, "organization", "providerName");
            	removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
            	removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, PATIENT_ACCOUNT_NUMBER, PATIENT_ACCOUNT_NUMBER);
            	removeSpecialCharacters(metadataMap, document, "Macess_SF_ID", "Macess_SF_ID");
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                	removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                break;
            case "TXGC":
            	String providerName = document.getMetadata().getString("providerName");
            	if (providerName == null || providerName.isEmpty()) {
            		providerName = document.getMetadata().getString("providerGroupName");
            	}
            	break;
            case "CAP":
                removeSpecialCharacters(metadataMap, document, "memberId", "multMemberId");
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "multClaimNumber");
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                break;
            case "HouseCalls":
                removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName");
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                break;
            case "MemberPayout":
                removeSpecialCharacters(metadataMap, document, "memberId", "memberId");
                removeSpecialCharacters(metadataMap, document, "providerName", "providerName");
                removeSpecialCharacters(metadataMap, document, "patientAccountNumber", "patientAccountNumber");
                removeSpecialCharacters(metadataMap, document, "npi", "npi");
                removeSpecialCharacters(metadataMap, document, "claimNumber", "claimNumber");
                removeSpecialCharacters(metadataMap, document, "checkAmount", "CheckAmt");
                removeSpecialCharacters(metadataMap, document, "checkId", "CheckTraceNumber");
                dateOfService = (String) document.getMetadata().get("dateOfService");
                if (dateOfService != null && dateOfService.length() == 24) {
                    removeSpecialCharacters(metadataMap, document, "dateOfService", "dateOfService");
                }
                break;
        }
        metadataMap.put("source", "PRUN");
		if (document.getMetadata().get("createdDate") != null
				&& document.getMetadata().get("createdDate").toString().length() != 24) {
			metadataMap.put("sourceCreatedDate", df.format(new Date()));
		} else {
			metadataMap.put("sourceCreatedDate", (String) document.getMetadata().get("createdDate"));
		}
        
		LOGGER.debug("document={}", document);

        return st.add("document", document)
                .add("map", metadataMap)
                .add("attachments", attachments)
                .render();
	}

    @Override
    public String convertWithTemplate(String jsonString) {
        DocumentResponse document;
        try {
            document = WorkFlowUtil.readDocumentResponseFromJsonString(jsonString);
        } catch (IOException | JSONException e) {
        	throw new RuntimeException(e);
        }
        
        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        
        DocumentResponse document;
        try {
            document = WorkFlowUtil.readDocumentResponseFromJsonFile(filePath);
        } catch (IOException | JSONException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
    }


    public void filterAndRemoveSpecialCharacters(Map<String, String> metadataMap, DocumentResponse document, String toTag, String fromTag) {
        metadataMap.put(toTag, removeSpecialCharacters(filterDuplicates((String) document.getMetadata().get(fromTag))));
    }

    public void removeSpecialCharacters(Map<String, String> metadataMap, DocumentResponse document, String toTag, String fromTag) {
        metadataMap.put(toTag, removeSpecialCharacters((String) document.getMetadata().get(fromTag)));
    }

    public String removeSpecialCharacters(String string){
        return (StringUtils.isNotEmpty(string)) ? string.replaceAll("[^a-zA-Z0-9-:,._| ]", "") : string;
    }
}
