package com.optum.fds.paperless.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.google.common.base.Strings;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.FDSHelper;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.FilestoreService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.service.ServiceBase;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

import org.flowable.engine.ProcessEngines;

import org.apache.commons.lang3.StringUtils;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Component
@RestController
@RequestMapping("/api/services")
public class FDSServicesController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FDSServicesController.class);
    private static final String PROCESSOR_ID = "processorId";
    private static final String INVALID_REQUEST = "Invalid request";
    private static final String EMPTY_REQUEST_BODY = "Null or empty request body";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
    private static final String CLEANUP_ERROR_LOG = "Error to process cleanup for the processor transaction:{} and error {}";
    private static final String PROCESS_PROCESSOR_ERROR_LOG = "Error to process processor: {} and error {}";
    private static final String SKIP_RETRIEVE_EMAIL = "skipRetrieveEmail";

	@Autowired
	private ConfigData config;
	
    @Autowired
    private CsvProcessorsService csvProcessorsService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private DocumentMetaDataService documentMetaDataService;
    
    @Autowired
    private FilestoreService fileStoreService;
    
    @Autowired
    private ProcessorsService processorsService;

    @Value("${MessageServiceResponseUrl}")
	protected String messageServiceResponseUrl;

    public static ObjectMapper mapper = new ObjectMapper();

    @Autowired
	ServiceBase serviceBase;

    @GetMapping("/test")
    public String test(@RequestBody Map<String, Object> json) {
    	System.out.println(json);
    	String fileName = (String) json.get("fileName");
    	String filePath = (String) json.get("filePath");
//        LOGGER.debug("Entering: name={}", fileName);
        byte[] byteArray = fileStoreService.downloadFile(filePath, fileName);
        System.out.println(byteArray);
        return "Hello file is downloading";
    }

    @PostMapping(value = "/run/dequeue/{queue}")
    public GenericResponse runDequeue(@PathVariable String queue) {
        return GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase());
    }

    @SuppressWarnings("unchecked")
    @PostMapping(value = "/run/delegate", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runDelegate(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            LOGGER.error("jsonStr empty: Throwing INVALID_REQUEST");
            return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
        }

        Map<String, Object> requestMap;
//        LOGGER.debug("jsonStr={}", jsonStr);
        try {
            String url;
            String request;
            requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            var urlArrayList = (ArrayList<String>) requestMap.get("url");
            if (CollectionUtils.isNotEmpty(urlArrayList)) {
                url = urlArrayList.get(0);
//                LOGGER.debug("urlArrayList[0]={}", url);
            }
            String callbackDelegate = null;
            Map<String, Object> delegateParamsMap = null;
            var delegateArrayList = (ArrayList<String>) requestMap.get("delegate");
            if (CollectionUtils.isNotEmpty(delegateArrayList)) {
                callbackDelegate = delegateArrayList.get(0);
//                LOGGER.debug("delegateArrayList[0]={}", callbackDelegate);
            }
            var requestArrayList = (ArrayList<String>) requestMap.get("request");
            if (CollectionUtils.isNotEmpty(requestArrayList)) {
                request = requestArrayList.get(0);
//                LOGGER.debug("requestArrayList[0]={}", request);
            }
            var callbackArrayList = (ArrayList<Map<String,Object>>) requestMap.get("callbackMap");
            if (CollectionUtils.isNotEmpty(callbackArrayList)) {
                delegateParamsMap = callbackArrayList.get(0);
//                LOGGER.debug("callbackArrayList[0]={}", callbackArrayList.get(0));
            }
            return invokeWorkflow(jsonStr, callbackDelegate, delegateParamsMap, requestMap);
        } catch (JsonProcessingException e) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/delegate, jsonStr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), e.getMessage());
            return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    protected ResponseEntity<GenericResponse> invokeWorkflow(String jsonStr, String callbackDelegate, Map<String, Object> delegateParamsMap, Map<String, Object> requestMap) {
        var responseEntity = getGenericResponse(requestMap);
        if (callbackDelegate == null || delegateParamsMap == null) {
            return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, "Null or empty processKey or callbackMap"),HttpStatus.BAD_REQUEST);
        }
        var id = "NONE";
        if (responseEntity != null ) {
            var responseMsg = (String) responseEntity.getResponse();
            if (responseMsg != null && responseMsg.startsWith("SVC_MSG") && responseMsg.indexOf(':') >= 0) {
                int index = responseMsg.indexOf(':');
                id = responseMsg.substring(index+1);
            }
        }

        try {
            LOGGER.debug("Calling FDSPaperlessMain.runProcess: callbackDelegate={}, id={}", Encode.forJava(callbackDelegate), Encode.forJava(id));
            FDSHelper.runProcess(callbackDelegate, delegateParamsMap, responseEntity);
            LOGGER.debug("Called FDSPaperlessMain.runProcess: callbackDelegate={}, id={}", Encode.forJava(callbackDelegate), Encode.forJava(id));
            if (! id.equals("NONE") ) {
                sendRequestToQueue(new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), id), HttpStatus.OK));
            }
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), id), HttpStatus.OK);
        } catch (HttpServerErrorException e) {
            LOGGER.error("Called FDSPaperlessMain.runProcess: callbackDelegate={}, id={}, jsonStr={}; {}",
                    Encode.forJava(callbackDelegate), Encode.forJava(id), Encode.forJava(jsonStr), e.getMessage());
            if (! id.equals("NONE") ) {
                sendRequestToQueue(new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), id + ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR));
            }
            return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, id + ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch(Exception e) {
            LOGGER.error("Called FDSPaperlessMain.runProcess: callbackDelegate={}, id={}, jsonStr={}; {}",
                    Encode.forJava(callbackDelegate), Encode.forJava(id), Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(e));
            if (! id.equals("NONE") ) {
                sendRequestToQueue(new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), id + ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR));
            }
            return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, id + ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @SuppressWarnings("unchecked")
	@PostMapping(value = "/run/workflow", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runWorkflow(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),HttpStatus.BAD_REQUEST);
        }

        Map<String, Object> requestMap;
        try {
            requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            var urlArrayList = (ArrayList<String>) requestMap.get("url");
            
            String url;
            if (CollectionUtils.isNotEmpty(urlArrayList)) {
                url = urlArrayList.get(0);
            }
            Map<String, Object> delegateParamsMap = (Map<String,Object>) requestMap.get("callbackMap");
            var processKey = (String) requestMap.get("processKey");

            if (processKey != null && delegateParamsMap != null) {
                var responseEntity = getGenericResponse(requestMap);
                LOGGER.debug("Calling FDSHelper.runProcess: processKey={}", Encode.forJava(processKey));
                FDSHelper.runProcess(processKey, delegateParamsMap, responseEntity);
            } else {
                LOGGER.debug("Not calling FDSPaperlessMain.runProcess");
                return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, "Null or empty processKey or callbackMap"),HttpStatus.BAD_REQUEST);
            }
        } catch (JsonProcessingException e) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/workflow, jsonStr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), e.getMessage());
            return new ResponseEntity<>(GenericResponse.from("500", "Error processing json string", e.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
        }

        var response = StringUtils.EMPTY;
        return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), response), HttpStatus.OK);
    }
    
    private boolean validateDocumentRequest(Map<String, String> request) {
    	return request == null || 
    			StringUtils.isEmpty(request.get("fdsCloudDocumentId")) || StringUtils.isEmpty(request.get("fdsCloudSpaceId"));
    }

	@PostMapping(value = "/run/csvProcessId/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public GenericResponse runCsvProcessId(@PathVariable String id) {
		LOGGER.info("Entering: runCsvProcessId request id={}", Encode.forJava(id));
		var processorMetaData = csvProcessorsService.findProcessorMetaDataById(id);
		FDSHelper.runProcess("csvSftpProcess", processorMetaData);
		return GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase());
	} 
       
	
	@PostMapping(value = "/run/prePost/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> prePost(@PathVariable String id, @RequestBody String jsonConfigStr) {

		var response = "OK";
		var appIdentifier = "";

		if (jsonConfigStr == null || jsonConfigStr.isEmpty() || StringUtils.isEmpty(id)) {
			return new ResponseEntity<>(
					new GenericResponse("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
					HttpStatus.BAD_REQUEST);
		}
		try {
            JSONObject jsonObject = new JSONObject(jsonConfigStr);
            String hookId = (String) jsonObject.get("id");
            LOGGER.info("Entering Run prePost docId={}, hookId={}", Encode.forJava(id), Encode.forJava(hookId));

			Map<String, Object> requestMap;
			requestMap = new ObjectMapper().readValue(jsonConfigStr, HashMap.class);
			requestMap.put(Workflow.DOCID, id);
			appIdentifier = requestMap.get(Workflow.APP_IDENTIFIER).toString();
			if (!Strings.isNullOrEmpty(appIdentifier)) {
				FDSHelper.corpMPIN(requestMap);
				FDSHelper.retrieveProviderEmailAddress(requestMap);
				FDSHelper.processRequiredFieldRule(requestMap);

				return new ResponseEntity<>(new GenericResponse("200", "OK", response), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
						new GenericResponse("400", INVALID_REQUEST, "appIdentifier is empty in request body"),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception ex) {

			LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/prePost/{}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(id), ExceptionUtils.getStackTrace(ex));
			return new ResponseEntity<>(
					new GenericResponse("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(value = "/run/prePost", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> prePost(@RequestBody String jsonConfigStr) {

        JSONObject jsonObject = new JSONObject(jsonConfigStr);
        String hookId = (String) jsonObject.get("id");
        LOGGER.info("Entering Run prePost hookId={}", Encode.forJava(hookId));

		var response = "OK";
		var appIdentifier = "";

		if (jsonConfigStr == null || jsonConfigStr.isEmpty()) {
			return new ResponseEntity<>(
					new GenericResponse("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
					HttpStatus.BAD_REQUEST);
		}
		try {
			Map<String, Object> requestMap;
			requestMap = new ObjectMapper().readValue(jsonConfigStr, HashMap.class);
            boolean skipRetrieveEmail = (boolean) requestMap.getOrDefault(SKIP_RETRIEVE_EMAIL, false);
			appIdentifier = requestMap.get(Workflow.APP_IDENTIFIER).toString();
			if (!Strings.isNullOrEmpty(appIdentifier)) {
				FDSHelper.corpMPIN(requestMap);
                if(!skipRetrieveEmail)
				    FDSHelper.retrieveProviderEmailAddress(requestMap);
				FDSHelper.processRequiredFieldRule(requestMap);

				return new ResponseEntity<>(new GenericResponse("200", "OK", response), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
						new GenericResponse("400", INVALID_REQUEST, "appIdentifier is empty in request body"),
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception ex) {
			LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/prePost, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonConfigStr),
					ExceptionUtils.getStackTrace(ex)); 
			return new ResponseEntity<>(
					new GenericResponse("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    @PostMapping(value = "/run/prePostRealTime", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> prePostRealTime(@RequestBody String jsonConfigStr) {
        var response = "OK";
        var appIdentifier = "";

        if (jsonConfigStr == null || jsonConfigStr.isEmpty()) {
            return new ResponseEntity<>(
                    new GenericResponse("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap;
            requestMap = new ObjectMapper().readValue(jsonConfigStr, HashMap.class);
            appIdentifier = requestMap.get(Workflow.APP_IDENTIFIER).toString();
            if (!Strings.isNullOrEmpty(appIdentifier)) {
                FDSHelper.retrieveProviderEmailAddress(requestMap);
                FDSHelper.processRequiredFieldRule(requestMap);

                return new ResponseEntity<>(new GenericResponse("200", "OK", response), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        new GenericResponse("400", INVALID_REQUEST, "appIdentifier is empty in request body"),
                        HttpStatus.BAD_REQUEST);
            }
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/prePostRealTime, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonConfigStr),
                    ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    new GenericResponse("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/postDocumentDocLibForELGS", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postDocumentDocLibForELGSProcess(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper.postDocumentDocLibForELGSProcess(requestMap);
           
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/postDocumentDocLibForELGS, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/processConvertMetadata", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> processConvertMetadata(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper.convertMetadataProcess(requestMap);

            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/processConvertMetadata, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/csvProcessConfig", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE,
            MediaType.APPLICATION_JSON_VALUE})
    public GenericResponse runCsvProcessConfig(@RequestBody DocumentRecord documentRecord) {
        FDSHelper.runProcessConfig("csvSftpProcess", documentRecord.getDocuments());
        return GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase());
    }

    @SuppressWarnings("unchecked")
    @PostMapping(value = "/run/runCleanUp", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runCleanUp(@RequestBody String jsonStr) {

        var processorTransactionId = StringUtils.EMPTY;
        String appIdentifier;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap;
            requestMap = objectMapper.readValue(jsonStr, HashMap.class);
            processorTransactionId = requestMap.get(Workflow.PROCESSOR_TRANSACTION_ID).toString();
            appIdentifier = requestMap.get(Workflow.APP_IDENTIFIER).toString();
            if (StringUtils.isNotEmpty(processorTransactionId) && StringUtils.isNotEmpty(appIdentifier)) {
            	FDSHelper.processCleanUp(Workflow.CLEANUP_PROCESS_KEY, processorTransactionId, appIdentifier);
                return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST,
                                "processorTransactionId or appIdentifier is empty in request body"),
                        HttpStatus.BAD_REQUEST);
            }
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/runCleanUp, processor transaction:{}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(processorTransactionId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
	/*
	 * Controller to automatically reprocess processorTransactions stuck in NEW status
	 * RequestBody must contain processorId, appIdentifier, and a list of processorTransactionIds
	 */
    @PostMapping(value = "/run/fileUnzip", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runFileUnzip(@RequestBody String json) {
    	try {
    		Map<String, Object> requestMap = objectMapper.readValue(json, HashMap.class);
    		// remove locked.txt
    		
    		List<String> processorTransactionIds = (List<String>) requestMap.get("processorTransactionIds");
    		
    		String processorTransactionId = processorTransactionIds.get(0);
    		ProcessorTransaction processorTransaction = processorsService.getTransactionProcessorById(processorTransactionId);
    		
    		String location = processorTransaction.getLocation();
    		String lockedFilePath = location + "/locked.txt";
    		
    		File lockedFile = new File(lockedFilePath);
    		if (lockedFile.exists()) {
    			// remove
    			LOGGER.debug("Removing locked.txt file from location={}", lockedFilePath);
    			FileUtils.forceDelete(lockedFile);
    		}
    		
    		FDSHelper.fileUnziprunProcess(Workflow.UNZIP_FILE_PROCESS_KEY, requestMap);
    		return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
    	} catch (Exception e) {
    		LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/fileUnzip, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(json), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	
    }

    @PostMapping(value = "/run/runProcessor", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runProcessor(@RequestBody String jsonProcessConfigStr) {

        String appIdentifier;
        String processorId;
        if (StringUtils.isEmpty(jsonProcessConfigStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonProcessConfigStr, new TypeReference<>() {});
            processorId = requestMap.get("id").toString();
            appIdentifier = requestMap.get(Workflow.APP_IDENTIFIER).toString();
            if (StringUtils.isNotEmpty(appIdentifier)) {
                var sftpProcessInstance = FDSHelper.sftpRunProcess(Workflow.SFTP_PROCESS_KEY,
                        jsonProcessConfigStr);
                var processEngine = ProcessEngines.getDefaultProcessEngine();
                ArrayNode objProTranList = (ArrayNode) processEngine.getRuntimeService()
                        .getVariable(sftpProcessInstance.getId(), Workflow.PROCESSOR_TRANSACTION_LIST_ID);

                for (Object proTran : objProTranList) {
                    Map<String, Object> requestMapUnZip = new HashMap<>();
                    requestMapUnZip.put(Workflow.PROCESSOR_TRANSACTION_ID, proTran.toString().trim().replace("\"", StringUtils.EMPTY));
                    requestMapUnZip.put(Workflow.APP_IDENTIFIER, appIdentifier);
                    requestMapUnZip.put(PROCESSOR_ID, processorId);
                    
                    FDSHelper.fileUnziprunProcess(Workflow.UNZIP_FILE_PROCESS_KEY, requestMapUnZip);
                }
                return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST,
                                "processorTransactionId or appIdentifier is empty in request body"),
                        HttpStatus.BAD_REQUEST);
            }
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/runProcessor, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonProcessConfigStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/run/processZipFile", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> processZipFile(@RequestBody String jsonProcessConfigStr) {

        String appIdentifier;
        String processorId;
        if (StringUtils.isEmpty(jsonProcessConfigStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonProcessConfigStr, new TypeReference<>() {});
            processorId = requestMap.get("id").toString();
            appIdentifier = requestMap.get(Workflow.APP_IDENTIFIER).toString();
            if (StringUtils.isNotEmpty(appIdentifier)) {
                FDSHelper.zipFileRunProcess(Workflow.SFTP_ZIP_FILE_PROCESS_KEY,
                        jsonProcessConfigStr, appIdentifier, processorId);
                return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST,
                                "processorTransactionId or appIdentifier is empty in request body"),
                        HttpStatus.BAD_REQUEST);
            }
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/processZipFile, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonProcessConfigStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "run/processTextFile", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> processTextFile(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            ProcessorMetaData pmd = objectMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class);
            if (pmd == null) {
            	return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                        HttpStatus.BAD_REQUEST);
            }
            FDSHelper.processTextFile(pmd);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/processTextFile, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "run/sftpSendEmailProcess", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> sftpSendEmailProcess(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            ProcessorMetaData pmd = objectMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class);
            if (pmd == null) {
                return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                        HttpStatus.BAD_REQUEST);
            }
            FDSHelper.sftpSendEmailProcess(pmd);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=run/sftpSendEmailProcess, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    @PostMapping(value = "run/realTimeAPISendEmailProcess", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> realTimeAPISendEmailProcess(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            ProcessorMetaData pmd = objectMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class);
            Map<String, Object> processorTransaction = objectMapper.convertValue(requestMap.get(Workflow.PROCCESSOR_TRANSACTION), Map.class);
            if (pmd == null && processorTransaction == null) {
                return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                        HttpStatus.BAD_REQUEST);
            }
            FDSHelper.realTimeAPISendEmailProcess(pmd,processorTransaction);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=run/realTimeAPISendEmailProcess, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "run/retrieveAndSendEmailProcess", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> retrieveAndSendEmailProcess(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        String id = "";
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            id = (String) requestMap.get("id");
            FDSHelper.retrieveAndSendEmailProcess(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=run/retrieveAndSendEmailProcess, hook Id={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(id), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "run/sendBatchDynamicEmailRequestToPEN", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> sendBatchDynamicEmailRequestToPEN(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        String id = "";
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            id = (String) requestMap.get("id");
            FDSHelper.sendBatchDynamicEmailRequestToPEN(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=run/sendBatchDynamicEmailRequestToPEN, hook Id={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(id), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/run/statusFile", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runStatusFile(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper. createStatusFileAndAckProcess(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/statusFile, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/responseFile", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runResponseFile(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper.responseFileProcess(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/responseFile, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/run/responseFile/USPClaims", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runResponseFileUSPClaims(@RequestBody String jsonStr) {
    	
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper.responseFileProcessUSPClaims(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
        	LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/responseFile/USPClaims, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/shutterfly", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runShutterfly(@RequestBody String jsonStr) {
        var hookId = StringUtils.EMPTY;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            hookId = requestMap.get("id").toString();
            FDSHelper.shutterflyWorkflow(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/shutterfly, hookId={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(hookId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/run/storageErrorShutterfly", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runStorageErrorShutterfly(@RequestBody String jsonStr) {
        var hookId = StringUtils.EMPTY;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            hookId = requestMap.get("id").toString();
            FDSHelper.storageErrorShutterflyWorkflow(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/storageErrorShutterfly, hookId={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR,
            		Encode.forJava(hookId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    

    @PostMapping(value = "/run/bounceEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> insertDocumentForBouncedEmail(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            LOGGER.info("apiPath=/run/bounceEmail, 400 BAD REQUEST invalid json");
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        LOGGER.info("insertDocumentForBouncedEmail apiPath=/run/bounceEmail, requestBody={}", Encode.forJava(jsonStr));
        try {
            var documentMetaData = objectMapper.readValue(jsonStr, DocumentMetaData.class);
            appendDefaultValues(documentMetaData);
            documentMetaDataService.saveDocumentMetaData(documentMetaData);
            LOGGER.info("insertDocumentForBouncedEmail apiPath=/run/bounceEmail, bounce email doc inserted docId={}", documentMetaData.getId());
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(),
                    "DocumentMetaData inserted with id = " + documentMetaData.getId()));
        }
        catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/bounceEmail, jsonstr={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR,
            		Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/bounceProvEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runBounceProvEmail(@RequestBody String jsonStr) {
        var hookId = StringUtils.EMPTY;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, HashMap.class);
            Map<String,Object> hook = (Map) requestMap.get("hook");
            hookId = hook.get("id").toString();
            FDSHelper.bounceEmailWorkflow(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/bounceProvEmail, hookId={}, error={}", 
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(hookId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @SuppressWarnings("unchecked")
	@PostMapping(value = "/run/matchAndMerge", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runMatchAndMerge(@RequestBody String jsonStr) {
        var hookId = StringUtils.EMPTY;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, HashMap.class);
            hookId = requestMap.get("id").toString();
            FDSHelper.matchAndMergeWorkflow(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/matchAndMerge, hookId={}, error={}",	
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(hookId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @SuppressWarnings("unchecked")
	@PostMapping(value = "/run/emailProcessorTransactionMetadata", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runEmailProcessorTransactionMetadata(@RequestBody String jsonStr) {
        var hookId = StringUtils.EMPTY;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, HashMap.class);
            hookId = requestMap.get("id").toString();
            FDSHelper.emailProcessorTransactionMetadataWorkflow(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/emailProcessorTransactionMetadata, hookId={}, error={}",	
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(hookId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/providerEmailNotification", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> providerEmailNotification(@RequestBody String jsonStr) {
        var hookId = StringUtils.EMPTY;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            hookId = requestMap.get("id").toString();
            FDSHelper.providerEmailNotificationProcess(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/providerEmailNotification, hookId={}, error={}",
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(hookId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/run/retrieveCorporateMPINv2", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> retrieveCorporateMPINv2(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper.retrieveCorporateMPINv2Process(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/retrieveCorporateMPINv2, jsonstr={}, error={}",
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
//    @PostMapping(value = "/run/retrieveCorporateMPINv2EhCacheLoadTest", consumes = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<GenericResponse> retrieveCorporateMPINv2EhCacheLoadTest(@RequestBody String jsonStr) {
//        if (StringUtils.isEmpty(jsonStr)) {
//            return new ResponseEntity<>(
//                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
//                    HttpStatus.BAD_REQUEST);
//        }
//        try {
//            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
//            LOGGER.debug("Calling FDSHelper.retrieveCorporateMPINv2EhCacheLoadTestProcess");
//            FDSHelper.retrieveCorporateMPINv2EhCacheLoadTestProcess(requestMap);
//            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
//        } catch (Exception ex) {
//            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/retrieveCorporateMPINv2EhCacheLoadTest, jsonstr={}, error={}",
//            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
//            return new ResponseEntity<>(
//                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
//                    HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
    
    @PostMapping(value = "/run/retrieveAndCreateMetadataFiles", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runCreateMetadataFiles(@RequestBody String jsonStr) {

         LOGGER.info("Entering retrieveAndSendMetadataProcess jsonStr={}", Encode.forJava(jsonStr));
    	
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper.retrieveAndCreateMetadataFilesProcess(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/retrieveAndCreateMetadataFiles, jsonstr={}, error={}",
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
	private void appendDefaultValues(DocumentMetaData documentMetaData) {
		documentMetaData.setTransactionId(UUID.randomUUID().toString());
		documentMetaData.setStatus(MetaDataStatus.AVAILABLE);
		if (documentMetaData.getSpaceId() == 0) {
			throw new NullPointerException("spaceId cannot be null");
		}
		var clientId = config.getCredentials(documentMetaData.getSpaceId()).get("clientId").toString();
		var appIdentifier = config.getCredentials(documentMetaData.getSpaceId()).get("appIdentifier").toString();
		
		documentMetaData.setClientId(Integer.parseInt(clientId));
		documentMetaData.setAppIdentifier(appIdentifier);
	}
	

	@PostMapping(value = "/run/sftpConvertFileToDocument", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> sftpConvertFileToDocument(@RequestBody String jsonStr) {
        LOGGER.info("Entering sftpConvertFileToDocument process for jsonProcessConfigStr={}", Encode.forJava(jsonStr));
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            ProcessorMetaData pmd = objectMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class);
            if (pmd == null) {
                return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                        HttpStatus.BAD_REQUEST);
            }
            FDSHelper.sftpConvertFileToDocument(pmd);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/sftpConvertFileToDocument, jsonstr={}, error={}",
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

	
	@PostMapping(value = "/run/responseMessageProcess", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runResponseMessageProcess(@RequestBody String jsonStr) {
        LOGGER.info("Entering response message process");

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
            FDSHelper.responseMessageProcess(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);

        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/responseMessageProcess, error={}",
            		HttpStatus.INTERNAL_SERVER_ERROR, ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

	protected GenericResponse getGenericResponse(Map<String, Object> requestMap) {
		@SuppressWarnings("unchecked")
		Map<String, Object> response = (Map<String, Object>) requestMap.get("response");
		if (response == null) {
			return GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), "No Response returned defaulting to OK");
		}
		try {
			String statusCode = (String) response.get("statusCode");
			String statusMessage = (String) response.get("statusMessage");
			String responseMsg = (String) response.get("responseMsg");
			LOGGER.info("statusCode={}, statusMessage={}, responseMsg={}", Encode.forJava(statusCode), Encode.forJava(statusMessage), Encode.forJava(responseMsg));
			return new GenericResponse(statusCode, statusMessage, responseMsg);
		} catch(ClassCastException e) {
			LOGGER.error("GenericResponse Error: {}", ExceptionUtils.getStackTrace(e));
			return GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), e.getMessage());
		}
	}

    @PostMapping(value = "/run/updateDocsWithSecondaryEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> runUpdateDocsWithSecondaryEmail(@RequestBody String jsonStr) {
        var hookId = StringUtils.EMPTY;
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            Map<String, Object> requestMap = objectMapper.readValue(jsonStr, HashMap.class);
            hookId = requestMap.get("id").toString();
            FDSHelper.updateDocsWithSecondaryEmailWorkflow(requestMap);
            return new ResponseEntity<>(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.getReasonPhrase()), HttpStatus.OK);
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/run/updateDocsWithSecondaryEmail, hookId={}, error={}",
                    HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(hookId), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

	protected void sendRequestToQueue(ResponseEntity<GenericResponse> responseEntity) {
		String jsonString = new Gson().toJson(responseEntity.getBody());
		LOGGER.info("sendRequestToQueue jsonString={}", Encode.forJava(jsonString));
		serviceBase.postRequestToSvc(messageServiceResponseUrl, jsonString, null);
	}

    private String sanitiseString(String jsonStr){
            return JsonParser.parseString(jsonStr).toString();
    }

}
