package com.optum.fds.paperless.java.delegate.docvault;


import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import com.google.common.util.concurrent.RateLimiter;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.document.response.util.DocumentResponseUtil;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.java.delegate.OptumJavaDelegateBase;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.util.HookTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;


@Service("PostDocumentDataDocvault")
public class PostDocumentDataDocvault extends OptumJavaDelegateBase {


	static final String DUPLICATE_ENTRY_RESPONSE = "Duplicate entry";
	static final String DOCLIB_DUPLICATE_ENTRY_RESPONSE = "fileId already exists";
	static final String UNABLE_TO_PROCESS_REQUEST = "we are unable to process your request at this time";
	private static final String ERROR = "ERROR";

	private static final String COMPLETE = "COMPLETE";
	private static final String STATUS = "STATUS";
	private static final String FAILURE_MSG = "failure_message";
	private static final String SUCCESS_MSG = "success_message";
	private static final String FAILURE_SHUTTERFLY_MSG = "failure_shutterfly_message";
	private static final String METADATA_PREFIX = "metadata.";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PostDocumentDataDocvault.class);
	private static final List<String> REQ_VARS = List.of(
			Workflow.DOCUMENT_IDS_MESSAGE,
			Workflow.DOCLIB_REST_URL, 
			Workflow.OUTPUT_FILE_DIR, 
			Workflow.JSON_FILE, 
			Workflow.SLA_TIME,
			Workflow.TEMPLATE_NAME,
			Workflow.DOCLIB_OAUTH_URL,
            Workflow.DOCLIB_CLIENT_ID,
            Workflow.DOCLIB_CLIENT_SECRET
	);
	private final DateFormat df;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private DocumentMetaDataService documentMetaDataService;
    
    @Autowired
    private HookService hookService;
    
    @Autowired
	private OauthManagerUtil oauthManagerUtil;

    @Autowired
    private HookTransaction hookTransaction;

	@Value("${DOCLIB_TPS:25}")
	private int DOCLIB_TPS;


	public PostDocumentDataDocvault() {
		super(REQ_VARS);
		df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));
	}

	@Override
	protected void doExecute(DelegateExecution execution) {
		try {
			postDocument(execution);
		} catch (Exception e) {
			LOGGER.error("msg: {}", e.getMessage());
			setExitNow(execution);
		}
	}

	@SuppressWarnings("unchecked")
	void postDocument(DelegateExecution execution) throws OutOfRetriesException {
		RateLimiter rateLimiter = RateLimiter.create(DOCLIB_TPS);

		List<String> successDocumentList = new ArrayList<>();
		List<String> failureDocumentList = new ArrayList<>();
		List<String> failureShutterflyDocumentList = new ArrayList<>();
		List<DocumentMetaData> documentList = null;
		DocumentMetaData document = null;

		String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);

		try {
			documentList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			} catch (IOException e) {
			LOGGER.error("doExecute Unable to get DocumentMetadata {}={}, {}={} {}", "delegateExecutionId",
					getDelegateExecutionId(execution), "jsonFile", jsonFile, ExceptionUtils.getStackTrace(e));
			addErrorMsg("TransformJsonAndGenerateFile-->doExecute-->Unable to get DocumentMetadata",
					WorkFlowUtil.getStackTrace(e));
			return;
		}
		try {
			String localUploadTime = df.format(new Date());

			Map<String, Object> successUpdateMap = new HashMap<>(
					Map.of(METADATA_PREFIX + Workflow.METADATA_DOCLIB_API_RESPONSE, true,
							METADATA_PREFIX + Workflow.METADATA_DOCLIB_UPLOAD_DATE, localUploadTime,
							METADATA_PREFIX + Workflow.METADATA_DOCSENTTO_FIELD, Workflow.METADATA_DOCSENTTO_DOCLIB));
			
			
			// emailAlertReq == N or emailAlertReq == Y and SLA not passed
			Map<String, Object> failureUpdateMap = new HashMap<>(
					Map.of(METADATA_PREFIX + Workflow.METADATA_DOCLIB_API_RESPONSE, false
					));
			
			 
			// emailAlertReq == Y and SLA passed
			Map<String, Object> failureUpdateMapShutterfly = new HashMap<>(
					Map.of(METADATA_PREFIX + Workflow.METADATA_DOCLIB_API_RESPONSE, false,
//							METADATA_PREFIX + Workflow.SEND_TO_DOCVAULT, false,
							METADATA_PREFIX + Workflow.SEND_TO_SHUTTERFLY, true
					));

			execution.setTransientVariable("successUpdateMap", successUpdateMap);
			execution.setTransientVariable("failureUpdateMap", failureUpdateMap);
			
			processMetadata(execution, documentList, successDocumentList, failureDocumentList, failureShutterflyDocumentList, rateLimiter);
			
			
			// Mongo multi update for sendToShutterfly true
			if (!failureShutterflyDocumentList.isEmpty()) {
				documentMetaDataService.saveDocumentMetaDataMulti(failureShutterflyDocumentList, failureUpdateMapShutterfly);
			}
			
			execution.setTransientVariable("successDocumentList", successDocumentList);
			execution.setTransientVariable("failureDocumentList", failureDocumentList);

		} catch (Exception e) {
			LOGGER.error("exception to post docLib exception {}", ExceptionUtils.getStackTrace(e));
			addErrorMsg("Exception", e.getMessage());
		} finally {
			execution.setTransientVariable("successDocumentList", successDocumentList);
			execution.setTransientVariable("failureDocumentList", failureDocumentList);
			updateHookTransaction(execution, successDocumentList, failureDocumentList, failureShutterflyDocumentList);
			
		}

	}

	public void processMetadata(DelegateExecution execution, List<DocumentMetaData> documentList,
			List<String> successDocumentList, List<String> failureDocumentList, List<String> failureShutterflyDocumentList, RateLimiter rateLimiter) {
		
		Integer slaTime = execution.getVariable(Workflow.SLA_TIME, Integer.class);
		Map<String, Object> successUpdateMap = (Map<String, Object>) execution.getVariable("successUpdateMap");
		Map<String, Object> failureUpdateMap = (Map<String, Object>) execution.getVariable("failureUpdateMap");
		Map<String, String> message = new HashMap<>();
		long countSuccessUpdated = 0;
    	long countFailureUpdated = 0;
    	
	    HookTransactionMetaData hookTransactionMetaData = null;
		hookTransactionMetaData = execution.getVariable(Workflow.HOOK_TRANSACTION_METADATA, HookTransactionMetaData.class);
		for (DocumentMetaData document : documentList) {
			try {
				// if document already has docLibAPIResponse: true, skip sending to DocLib
				var documentFromDB = documentMetaDataService.getDocumentMetaData(document.getId());
				if (documentFromDB != null && documentFromDB.getMetadata() != null 
						&& Boolean.TRUE.equals( documentFromDB.getMetadata().getBoolean(Workflow.METADATA_DOCLIB_API_RESPONSE, false) )) {
					LOGGER.info("Document already uploaded to DocLib id={}", document.getId());
					continue;
				}
				
				var endpoint = execution.getVariable(Workflow.DOCLIB_REST_URL, String.class);
				var attachments = new ArrayList<AttachmentMetaData>();
				var attachmentMetaData = new AttachmentMetaData();

				attachmentMetaData.setFsId(document.getDocumentAttachments().get(0).getFsId());
				attachmentMetaData.setFileName(document.getDocumentAttachments().get(0).getName());
				attachmentMetaData.setDateCreated(document.getDateCreated());
				attachmentMetaData.setSpaceId(document.getSpaceId());
				attachmentMetaData.setCloudSpaceId(document.getDocumentAttachments().get(0).getSpaceId());

				attachmentMetaData.setAttachmentId(document.getDocumentAttachments().get(0).getAttachmentId());
				attachmentMetaData.setFileSize(document.getDocumentAttachments().get(0).getFileSize());
				attachmentMetaData.setContentType(document.getDocumentAttachments().get(0).getContentType());
                attachmentMetaData.setDoc360DocumentId(document.getDoc360DocumentId());
				attachments.add(attachmentMetaData);

				var documentJsonStr = DocumentResponseUtil.buildDocumentResponseInJson(document, attachments);

				var templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);

				documentJsonStr = TemplateFactory.getInstance(templateName).convertWithTemplate(documentJsonStr);

				LOGGER.info("docId={}, documentJsonStr={}", document.getId(), documentJsonStr);


				var jsonToDocLib = List.of(documentJsonStr).toString();

				if (jsonToDocLib.charAt(0) == '[' && jsonToDocLib.charAt(jsonToDocLib.length() - 1) == ']') {
					jsonToDocLib = jsonToDocLib.substring(1, jsonToDocLib.length() - 1);
				}

				ResponseEntity<String> response = null;

				response = postDocumentToDocLibWithRetry(endpoint, jsonToDocLib, execution,
						document.getId(), rateLimiter);

				int responseStatus = response.getStatusCode().value();

				if (responseStatus == 200) {
					if (!ObjectUtils.defaultIfNull(response.getBody(), StringUtils.EMPTY)
							.contains(UNABLE_TO_PROCESS_REQUEST) && isResponseSuccess(response.getBody())) {
						LOGGER.info("getting success response and response body {} and payload {}", Encode.forJava(response.getBody()),
								jsonToDocLib);

						var msg = String.format("Success response %s, for payload %s", response.getBody(),
								jsonToDocLib);
						execution.setTransientVariable(Workflow.DOCLIB_API_RESPONSE_SUCCESS_MESSAGE, msg);
						execution.setTransientVariable(STATUS, COMPLETE);

						successDocumentList.add(document.getId());
                        documentMetaDataService.updateDocumentMetadataFields(successUpdateMap, document.getId());
                        countSuccessUpdated++;
                        LOGGER.info("Success Document updated {} ", countSuccessUpdated);

					} else {
						var msg = String.format("Error response %s, for payload %s", response.getBody(), jsonToDocLib);

						execution.setTransientVariable(Workflow.DOCLIB_API_RESPONSE_ERROR_MESSAGE, msg);
						execution.setTransientVariable(STATUS, ERROR);

						if (checkShutterflyCriteria(document, slaTime)) {
							failureShutterflyDocumentList.add(document.getId());
						} else {
							failureDocumentList.add(document.getId());
                            documentMetaDataService.updateDocumentMetadataFields(failureUpdateMap, document.getId());
                            countFailureUpdated++;
                            LOGGER.info("Failure Document updated {} ", countFailureUpdated);
						}
						
					}

				} else {

					if (ObjectUtils.defaultIfNull(response.getBody(), StringUtils.EMPTY)
							.contains(DUPLICATE_ENTRY_RESPONSE)
							|| ObjectUtils.defaultIfNull(response.getBody(), StringUtils.EMPTY)
									.contains(DOCLIB_DUPLICATE_ENTRY_RESPONSE)) {
						LOGGER.info("getting error response and response body {} and payload {}", Encode.forJava(response.getBody()),
								jsonToDocLib);

						var msg = String.format("DocLib Error response %s, for payload %s", response.getBody(),
								jsonToDocLib);

						

						execution.setTransientVariable(Workflow.DOCLIB_API_RESPONSE_ERROR_MESSAGE, msg);
						execution.setTransientVariable(STATUS, ERROR);
						successDocumentList.add(document.getId());
                        documentMetaDataService.updateDocumentMetadataFields(successUpdateMap, document.getId());
                        countSuccessUpdated++;
                        LOGGER.info("Success Document updated {} ", countSuccessUpdated);
					} else {
						var msg = String.format("Error response %s, for payload %s", response.getBody(), jsonToDocLib);
						execution.setTransientVariable(Workflow.DOCLIB_API_RESPONSE_ERROR_MESSAGE, msg);
						execution.setTransientVariable(STATUS, ERROR);

						if (checkShutterflyCriteria(document, slaTime)) {
							failureShutterflyDocumentList.add(document.getId());
						} else {
							failureDocumentList.add(document.getId());
                            documentMetaDataService.updateDocumentMetadataFields(failureUpdateMap, document.getId());
                            countFailureUpdated++;
                            LOGGER.info("Failure Document updated {} ", countFailureUpdated);
						}
					}
				}
			} catch (OutOfRetriesException e) {
				failureDocumentList.add(document.getId());
				LOGGER.error("OutOfRetriesException to post docLib exception {}", ExceptionUtils.getStackTrace(e));
				addErrorMsg("Exception", e.getMessage());
			} catch (Exception e) {
				failureDocumentList.add(document.getId());
				LOGGER.error("Error to post doclib for documentId {} {}", document.getId(),
						ExceptionUtils.getStackTrace(e));

			}
		}
		message.put("count_success_documents_updated", Long.toString(countSuccessUpdated));
    	message.put("count_failure_documents_updated", Long.toString(countFailureUpdated));
    	
    	hookTransaction.updateHookTransaction(execution, hookTransactionMetaData, message);
	}

	
	ResponseEntity<String> postDocumentToDocLibWithRetry(String endpoint, String jsonToDocLib,
			DelegateExecution execution, String docId, RateLimiter rateLimiter) throws OutOfRetriesException {
		rateLimiter.acquire();
		ResponseEntity<String> response = null;

    	var docLibUrl = execution.getVariable(Workflow.DOCLIB_OAUTH_URL, String.class);
        var docLibClientId = execution.getVariable(Workflow.DOCLIB_CLIENT_ID, String.class);
        var docLibClientSecret = execution.getVariable(Workflow.DOCLIB_CLIENT_SECRET, String.class);
      
		
		var numRetries = execution.getVariable(Workflow.NUM_RETRIES, Number.class);
		var timeToWaitMS = execution.getVariable(Workflow.TIME_TO_WAIT, Number.class);
		

		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		String msg;
		while (retryHandler.shouldRetry()) {
			try {
				try {
					if (retryHandler.isRetry()) {
						String newToken = oauthManagerUtil.getOauthToken("tokenStargate", docLibClientId, docLibClientSecret, "client_credentials", docLibUrl, true, null);
						String newAccessToken = "Bearer " + newToken;
						LOGGER.info("postDocumentToDocLibWithRetry retrying doclib call with new token");

						response = postDocumentToDocLib(endpoint, newAccessToken, jsonToDocLib);
					} else {
						String token = oauthManagerUtil.getOauthToken("tokenStargate", docLibClientId, docLibClientSecret, "client_credentials", docLibUrl, false, null);
						var accessToken = "Bearer " + token;
						response = postDocumentToDocLib(endpoint, accessToken, jsonToDocLib);
					}
					break;
				} catch (HttpClientErrorException.Unauthorized e) {
					LOGGER.error("HttpClientErrorException Unauthorized for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());

					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				}catch (HttpClientErrorException e) {
					LOGGER.error("HttpClientErrorException for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());

					return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());					
				} catch (HttpServerErrorException e) {
					if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
						LOGGER.error("HttpClientErrorException for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());


						retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
						retryHandler.exceptionOccurred();
					}
					else {
						LOGGER.error("{} exception for documentId={}, responseBody={}, statusCode={}", e.getClass().getSimpleName(), docId, e.getResponseBodyAsString(), e.getStatusCode());

						return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
					}
				} catch (RestClientException e) {
					LOGGER.error("RestClientException for document {} and exception {} ", docId,
							ExceptionUtils.getStackTrace(e));

					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				} catch(RuntimeException  e) {
					LOGGER.error("{} for document {} and exception {} ", e.getClass().getSimpleName(), docId,
							ExceptionUtils.getStackTrace(e));

					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				}
				
			} catch (OutOfRetriesException e) {
				msg = String.format(
						"RestClientException to endpoint %s and exhausted %s retries with retry time %s millis",
						endpoint, retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS());
				LOGGER.error(Encode.forJava(msg));

				addErrorMsg("RestClientException", msg);
				throw new OutOfRetriesException(msg);
			}
		}
		return response;
	}

	ResponseEntity<String> postDocumentToDocLib(String endpoint, String accessToken, String document)
			throws RestClientException {
		var headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("accept", "application/json");
		headers.set("Authorization", accessToken);
		HttpEntity<String> request = new HttpEntity<>(document, headers);
		
		return restTemplate.postForEntity(Encode.forJava(endpoint), request, String.class);
	}

	private String getDelegateExecutionId(DelegateExecution execution) {
		return execution != null ? execution.getId() : "NULL";
	}
	
	protected boolean checkShutterflyCriteria(DocumentMetaData doc, Integer slaTime) {
		Document metadata = doc.getMetadata();
		
		if (metadata.get("emailAlertReq").equals("Y")) {
			Date dateCreated = doc.getDateCreated();
			ZonedDateTime zdtDateCreated = ZonedDateTime.ofInstant(dateCreated.toInstant(),
                    ZoneId.systemDefault());
			ZonedDateTime createDatePlusSLA = zdtDateCreated.plusMinutes(slaTime * 60);
			// if sla is passed, return TRUE
			return createDatePlusSLA.isBefore(ZonedDateTime.now());
		} else {
			return false;
		}
		
	}
	
	public void updateHookTransaction(DelegateExecution execution, List<String> successList, List<String> failureList, List<String> failureShutterflyList) {
		HookTransactionMetaData hookTransactionMetaData = null;
		hookTransactionMetaData = execution.getVariable(Workflow.HOOK_TRANSACTION_METADATA, HookTransactionMetaData.class);
		var hookExecutionList = hookTransactionMetaData.getHookExecutionList();

    	Map<String, String> hookExecutionMessage = null;
    	if (hookExecutionList != null && !hookExecutionList.isEmpty() && hookExecutionList.get(0) != null
    			&& hookExecutionList.get(0).getMessageList() != null && !hookExecutionList.get(0).getMessageList().isEmpty() 
    			&& hookExecutionList.get(0).getMessageList().get(0) != null) {
    		
    		hookExecutionMessage = hookTransactionMetaData.getHookExecutionList().get(0).getMessageList().get(0);
    		hookExecutionMessage.put(SUCCESS_MSG, successList.toString());
    		hookExecutionMessage.put(FAILURE_MSG, failureList.toString());
    		hookExecutionMessage.put(FAILURE_SHUTTERFLY_MSG, failureShutterflyList.toString());
    		
    		hookTransactionMetaData.getHookExecutionList().get(0).updateMessage(hookExecutionMessage);
        	hookTransactionMetaData.setStatus(execution.getVariable(STATUS).toString());
        	hookService.updateHookTransaction(hookTransactionMetaData);
    	} else {
    		hookExecutionMessage = new HashMap<>();
    		hookExecutionMessage.put(SUCCESS_MSG, successList.toString());
    		hookExecutionMessage.put(FAILURE_MSG, failureList.toString());
    		hookExecutionMessage.put(FAILURE_SHUTTERFLY_MSG, failureShutterflyList.toString());
    	}
	}
	
	public boolean isResponseSuccess(String responseBody) {
		boolean isSuccess = false;
		try {
			Map<String, Object> responseMap = new ObjectMapper().readValue(responseBody, HashMap.class);
			Map metadata = (Map) responseMap.get("metadata");
			int count = Integer.parseInt(metadata.get(Workflow.COMMON_SUCCESS).toString());
			isSuccess = (count > 0);
		} catch (JsonProcessingException e) {
			LOGGER.error("Error to parse response object {}", ExceptionUtils.getStackTrace(e));
		}
		return isSuccess;
	}
}

