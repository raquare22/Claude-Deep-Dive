package com.optum.fds.paperless.java.delegate;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import com.optum.fds.paperless.mongo.DocumentAttachmentDoc360;
import com.optum.fds.paperless.util.*;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.cxf.common.util.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;


@Service("IdentifyShutterflyDocuments")
public class IdentifyShutterflyDocuments extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(IdentifyShutterflyDocuments.class);

	@Value("${INGEST_ROOT}")
	private String ingestRoot;

	private static final String DATE_FORMAT = "yyyyMMddHHmmssSSS";
	private static final String FILENAME = "fileName";
	private static final String PROCESS_KEY = "sendDocumentsToShutterflyProcess";

	@Value("${POSTCARD_ONLY_CLIENT_LIST}")
    public String postCardOnlyClientList;

	@Autowired
	private ConfigData config;

	@Autowired
	DocumentMetaDataService documentMetaDataService;

	@Autowired
	private OauthManagerUtil oauthManagerUtil;

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	private RetryUtil retryUtil;
	
    @Autowired
    HookService hookService;

	private static final List<String> REQ_VARS = Arrays.asList(
			Workflow.APP_ID, 
			Workflow.SPACE_ID,
			Workflow.CLIENT_ID,		
			Workflow.FDS_CLOUD_GET_ATTACHMENT_URL,
			Workflow.SEARCH_CRITERIA, 
			Workflow.SEARCH_WINDOW, 
			Workflow.MAX_DOCUMENTS_OCCURS
	);

	public IdentifyShutterflyDocuments() {
		super(REQ_VARS);
	}
	
	@Override
	public void doExecute(DelegateExecution execution) {
		LOGGER.debug("IdentifyShutterflyDocuments-->doExecute-->Enter");
        Map<String, String> correlationIds = new HashMap<>();
	    String documentId = "";
        List<String> documentIds = new ArrayList<>();
		try {
			var appIdentifier = "";
			Set<String> metadataFileSet = new HashSet<>();
			String documentSearchCriteria = execution.getVariable(Workflow.SEARCH_CRITERIA,String.class);           
			String documentSearchWindow = execution.getVariable(Workflow.SEARCH_WINDOW,String.class);
			Integer maxDocumentsOccurs = execution.getVariable(Workflow.MAX_DOCUMENTS_OCCURS, Integer.class);
			Integer clientId = execution.getVariable(Workflow.CLIENT_ID, Integer.class);
			String hookId = execution.getVariable(Workflow.HOOK_ID, String.class);

			HashMap<String,Object> windowMap = validateInput(documentSearchWindow, execution);
			if(windowMap==null) {
            	addErrorMsg("IdentifyShutterflyDocuments-->doExecute-->documentSearchWindow variable is null or invalid", "documentSearchWindow object is null or invalid");
            	return;
            }
			var documentCriteriaFilter = WorkFlowUtil.getSearchWindowCriteria(documentSearchWindow);
        	if(documentCriteriaFilter == null) {
    			LOGGER.error("IdentifyShutterflyDocuments-->doExecute-->search_window is invalid");
    			addErrorMsg("IdentifyShutterflyDocuments-->doExecute-->search_window is invalid", "search_window is invalid");
    			return;
    		}
        	LOGGER.debug("search criteria: {}", documentSearchCriteria);
        	
			List<DocumentMetaData> listDocumentMetaDataDB = documentMetaDataService
					.getDocumentMetaData(documentSearchCriteria, documentCriteriaFilter, maxDocumentsOccurs);
			if (CollectionUtils.isEmpty(listDocumentMetaDataDB)) {
				LOGGER.debug(
						"IdentifyShutterflyDocuments-->doExecute-->listDocumentMetaDataDB is null or empty; delegateExecutionId={}, documentSearchCriteria={}",
						execution.getId(), documentSearchCriteria);
				String messgeKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
				 execution.setTransientVariable(messgeKey, "IdentifyShutterflyDocuments documentList is null or empty");
				setExitNow(execution);
				return;
			}
			
			// add list of documentIds to execution bus for reconciliation error message 
			List<String> docIds = new ArrayList<>();
			listDocumentMetaDataDB.forEach(e -> docIds.add(e.getId()));
			 execution.setTransientVariable("documentIds", docIds);
			 if(listDocumentMetaDataDB.size() > 0) {
				LOGGER.debug("IdentifyShutterflyDocuments -> size: {}", listDocumentMetaDataDB.size());
				listDocumentMetaDataDB = listDocumentMetaDataDB.stream()
					.filter(e -> metadataFileSet.add(e.getMetadata().get(FILENAME).toString()))
					.collect(Collectors.toList());
			 }
			List<DocumentMetaData> listDocumentMetaData ;
				
			String spaceId = execution.getVariable(Workflow.SPACE_ID, String.class);
			String appId = execution.getVariable(Workflow.APP_ID, String.class);
			appIdentifier = appId;
			String currentDateFormatted = getCurrentDateFormatted(DATE_FORMAT);
			String ingestWorkingDir = ingestRoot;

			try {
				Boolean useDoc360 = execution.getVariable(Workflow.USE_DOC360, Boolean.class);
				String url = (String) execution.getVariable(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL);
				 //Creates Working Directory

				var tempWorkingPath = Utilities.createWorkingDirectoryWithParams(Workflow.DEFAULT_FILE_SEPARATOR,
						ingestWorkingDir, "shutterfly", appId, spaceId, currentDateFormatted, StringUtils.EMPTY);

				listDocumentMetaData = listDocumentMetaDataDB
						.stream()
						.map(x -> updateDocumentMetaDataAndDownloadAttachMents(x, useDoc360, tempWorkingPath, execution, correlationIds))
						.collect(Collectors.toList());
				
				 execution.setTransientVariable(Workflow.CORRELATION_IDS, correlationIds);
				 execution.setTransientVariable(Workflow.LIST_DOCUMENT_METADATA, listDocumentMetaData);
				 execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR_SHUTTERFLY, tempWorkingPath.toString() + Workflow.DEFAULT_FILE_SEPARATOR);
				 execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR_MESSAGE , tempWorkingPath.toString() + Workflow.DEFAULT_FILE_SEPARATOR);
				documentIds = listDocumentMetaData.stream().map(DocumentMetaData::getId).collect(Collectors.toList());
				var hookExecutionMessage = new HashMap<>(Map.of(
						Workflow.UPDATE_DOCUMENT_WITH_API_SUCCESS_MESSAGE, documentIds.toString()
	            ));
				var hookExecutionRecord = new HashMap<>(Map.of(
	                    Workflow.SPACE_ID, spaceId,
	                    Workflow.HOOK_ID, hookId,
	                    Workflow.APP_IDENTIFIER, appIdentifier,
	                    Workflow.CLIENTID, clientId.toString()
	            ));
				var hookExecutionRecordMetaData = HookTransactionUtil
						.getHookExecutionRecord(hookExecutionRecord, hookExecutionMessage, PROCESS_KEY);
				var hookTransactionMetaData = hookService
						.saveHookTransaction(HookTransactionUtil.createCronHookTransaction(hookExecutionRecordMetaData));
				 execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA, hookTransactionMetaData);
				LOGGER.debug("IdentifyShutterflyDocuments set outputFileDir for CorrelationIDs {}", correlationIds);

								
			} catch(FileSystemException fse){
				LOGGER.error("IdentifyShutterflyDocuments-->doExecute-->FileSystemException while executing IdentifyShutterflyDocuments task for documentId: {} and error: {}", documentId, WorkFlowUtil.getStackTrace(fse));
				LOGGER.error("IdentifyShutterflyDocuments-->doExecute-->FileSystemException for CorrelationID {} and error:{}",
						Optional.ofNullable(correlationIds).map(o -> o.get(documentId)).orElse(""), fse.getMessage());
				addErrorMsg("IdentifyShutterflyDocuments-->doExecute-->FileSystemException", WorkFlowUtil.getStackTrace(fse));
			}
			
		} catch (Exception e) {
			LOGGER.error("IdentifyShutterflyDocuments-->doExecute-->Exception while executing IdentifyShutterflyDocuments task for documentId: {} and error: {}", documentId, WorkFlowUtil.getStackTrace(e));
			LOGGER.error("IdentifyShutterflyDocuments-->doExecute-->Exception while executing IdentifyShutterflyDocuments task for CorrelationID {} and error: {}",
					Optional.ofNullable(correlationIds).map(o -> o.get(documentId)).orElse(""), e.getMessage());
			addErrorMsg("IdentifyShutterflyDocuments-->doExecute-->Exception while executing IdentifyShutterflyDocuments task", WorkFlowUtil.getStackTrace(e));

		} finally {
			if (newErrors() && errorMap.size() > 1) {
				var warningErrorMap =  errorMap.get(0).toString();
				LOGGER.error("IdentifyShutterflyDocuments delegates finished with error {}",warningErrorMap);
			}
		}
		
		LOGGER.debug("IdentifyShutterflyDocuments-->doExecute-->EXIT");
	}

	protected boolean checkLoadPDF(Document metadata, int spaceId) {
		var loadPDF = false;
		boolean isPostCard = true;
		
		String spaceIdStr = Integer.toString(spaceId);	
		if (postCardOnlyClientList.contains(spaceIdStr)) {
			// if document is from CAP or other postcard only client, we do not send PDF to shutterfly, only postcard
			metadata.put(Workflow.IS_POST_CARD, isPostCard);
			LOGGER.info("loadPDF={} for pdf={}", loadPDF, metadata.getString(Workflow.FILE_NAME));
			return loadPDF;
		}
		
		if (BooleanUtils.isTrue(metadata.getBoolean(Workflow.POST_CARD_IND)) ) {
			if (Strings.isBlank(metadata.getString(Workflow.PROV_CORP_MPIN)) || 
					Strings.isBlank(metadata.getString(Workflow.TIN)) || 
					Strings.isBlank(metadata.getString(Workflow.MPIN)) || 
					CommonConstants.DEFAULT_SUBCATEGORY_LIST.contains(metadata.getString(Workflow.SUBCATEGORY)) ) {
				loadPDF = true;
				isPostCard = false;
			}
		}
		else {
			/*
			* Provider email can be not empty and can have incorrect email when postCardInd is false. ex: ankur.kumar1993@optumtest.com-
			* These doc's should also be sent to shutterfly,so adding the regex validation to verify if it falls in this category. 
			* */
			if(Strings.isBlank(metadata.getString(Workflow.PROV_CORP_MPIN)) || 
					Strings.isBlank(metadata.getString(Workflow.PROVIDER_EMAIL_ID)) ||
					!Utilities.validateProviderEmail(metadata.getString(Workflow.PROVIDER_EMAIL_ID)) ||
					Strings.isBlank(metadata.getString(Workflow.TIN)) || 
					Strings.isBlank(metadata.getString(Workflow.MPIN)) || 
					CommonConstants.DEFAULT_SUBCATEGORY_LIST.contains(metadata.getString(Workflow.SUBCATEGORY)) ) {
				loadPDF = true;
				isPostCard =false;
			}
		}
		metadata.put(Workflow.IS_POST_CARD, isPostCard);
		LOGGER.info("loadPDF={} for pdf={}", loadPDF, metadata.getString(Workflow.FILE_NAME));
		
		return loadPDF;
	}

	private DocumentMetaData updateDocumentMetaDataAndDownloadAttachMents(DocumentMetaData document, Boolean useDoc360, Path tempWorkingPath, DelegateExecution execution, Map<String, String> correlationIds) {
		String documentId = document.getId();
		var metadata = document.getMetadata();
		// Add absolutePath metadata field --> formerly done in ConnectAndRetrieveDocuments
		correlationIds.put(document.getId(), document.getId() + "_" + document.getSpaceId());
		metadata.put(Workflow.DOCUMENT_ABSOLUTE_PATH, tempWorkingPath.toString() + Workflow.DEFAULT_FILE_SEPARATOR);
		
		int spaceId = document.getSpaceId();
		String fdsDocumentId = document.getFdsDocumentId();
		String doc360DocumentId = document.getDoc360DocumentId();
		String doc360Class = document.getDoc360DocClass();

		String fdsCloudUrl = (String) execution.getVariable(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL);
		String doc360Url = execution.getVariable(Workflow.DOC360_GET_ATTACHMENT_URL, String.class);

		// get documentAttachment from API and store in temp dir
		Optional.ofNullable(document.getDocumentAttachments())
				.orElseGet(Collections::emptyList)
				.stream()
				.filter(x -> x.getAttachmentId() != null)
				.forEach(attachmentMetaData -> {
					if (Boolean.TRUE.equals(useDoc360)) {
						downloadAttachMentsDoc360(metadata, doc360Url, tempWorkingPath, execution, spaceId, doc360DocumentId, doc360Class);
					} else {
						downloadAttachMents(attachmentMetaData, metadata, fdsCloudUrl, tempWorkingPath, execution, spaceId, fdsDocumentId);
					}
				});
		LOGGER.info("IdentifyShutterflyDocuments-->updateDocumentMetaDataAndDownloadAttachMents-->Document Id = {}", documentId);
		return document;
	}

	private void downloadAttachMents(DocumentAttachmentMetaData attachmentMetaData, Document metadata, String url, Path tempWorkingPath, DelegateExecution execution, int spaceId, String fdsDocumentId) {
		// download pdf files when corporateMpin and tin is missing
		if (checkLoadPDF(metadata, spaceId)) {
			
			String fdsCloudOauthUrl = (String) execution.getVariable(Workflow.FDS_CLOUD_AUTH_URL);
			String clientId = (String) execution.getVariable(Workflow.CLOUD_CLIENT_ID);
			String clientSecret = (String) execution.getVariable(Workflow.CLOUD_CLIENT_SECRET);
			String grantType = (String) execution.getVariable(Workflow.CLOUD_GRANT_TYPE);
		
			String token = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", clientId, clientSecret, grantType, fdsCloudOauthUrl, false, null);
			
			ResponseEntity<byte[]> response = null;
			try {
				response = getAttachment(token, url, fdsDocumentId, attachmentMetaData.getAttachmentId(), spaceId, fdsCloudOauthUrl, clientId, clientSecret, grantType);
			} catch (URISyntaxException | InterruptedException e) {
				LOGGER.error("IdentifyShutterflyDocuments-->downloadAttachMents --> error: {}", ExceptionUtils.getStackTrace(e));
			}
			if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
				try {
					try (OutputStream output = new BufferedOutputStream(Files.newOutputStream(Paths.get(tempWorkingPath +
							Workflow.DEFAULT_FILE_SEPARATOR + attachmentMetaData.getName()))))  {
						IOUtils.write(response.getBody(), output);
					}
				} catch (IOException e) {
					LOGGER.error("IdentifyShutterflyDocuments-->downloadAttachMents --> error: {}", ExceptionUtils.getStackTrace(e));
				}
			}
		} else {
		    // skip the pdfs in ManipulatePdfFile class
			metadata.putIfAbsent(Workflow.SKIP_MANIPULATE_PDF_FILE, true);
		}
	}

	/**
	 * Downloads attachments from Doc360 and writes them to the temp working path.
	 *
	 * @param metadata         The document metadata
	 * @param doc360Url        The Doc360 attachment URL
	 * @param tempWorkingPath  The temporary working directory
	 * @param execution        The workflow execution context
	 * @param spaceId          The space ID
	 * @param doc360DocumentId The Doc360 document ID
	 * @param doc360Class
	 */
	private void downloadAttachMentsDoc360(Document metadata, String doc360Url, Path tempWorkingPath, DelegateExecution execution, int spaceId, String doc360DocumentId, String doc360Class) {
		// download pdf files when corporateMpin and tin is missing
		if (checkLoadPDF(metadata, spaceId)) {
			var doc360AppId = execution.getVariable(Workflow.DOC360_APP_ID, String.class);
			var doc360AppSecret = execution.getVariable(Workflow.DOC360_APP_SECRET, String.class);
			var oauthUrl = execution.getVariable(Workflow.DOC360_OAUTH_URL, String.class);
			var doc360GrantType = execution.getVariable(Workflow.CLOUD_GRANT_TYPE, String.class); //Same grant type as fdsCloud call
			var doc360Scope = execution.getVariable(Workflow.DOC360_SCOPE, String.class);
			var xUpstreamEnv = execution.getVariable(Workflow.X_UPSTREAM_ENV, String.class);

			String newToken = oauthManagerUtil.getOauthToken("doc360", doc360AppId, doc360AppSecret, doc360GrantType, oauthUrl, false, doc360Scope);
			String newAccessToken = "Bearer " + newToken;

			ResponseEntity<DocumentAttachmentDoc360> response = null;
			try {
				response = getAttachmentDoc360(newAccessToken, doc360Url, doc360DocumentId, xUpstreamEnv, oauthUrl, doc360AppId, doc360AppSecret, doc360GrantType, doc360Scope, doc360Class);
			} catch (Exception e) {
			if (e instanceof InterruptedException) {
				Thread.currentThread().interrupt();
			}
			LOGGER.error("IdentifyShutterflyDocuments-->downloadAttachments from Doc360 --> error: {}", ExceptionUtils.getStackTrace(e));
			}
			if (response != null) {
				try {
					byte[] content = Objects.requireNonNull(response.getBody()).getContentStream();
					String fileName = Objects.requireNonNull(response.getBody().getFileName(), "Attachment filename must not be null");
					Path filePath = Paths.get(tempWorkingPath + Workflow.DEFAULT_FILE_SEPARATOR + fileName);

					if (!filePath.normalize().startsWith(tempWorkingPath.normalize())) {
						String sanitizedFileName = fileName.replace('\n', '_').replace('\r', '_');
						LOGGER.error("IdentifyShutterflyDocuments-->downloadAttachments --> invalid attachment filename outside working directory: {}", sanitizedFileName);
					} else {
						try (OutputStream output = new BufferedOutputStream(Files.newOutputStream(filePath))) {
							IOUtils.write(content, output);
						}
					}
				} catch (IOException e) {
					LOGGER.error("IdentifyShutterflyDocuments-->downloadAttachments --> error: {}", ExceptionUtils.getStackTrace(e));
				}
			}
		} else {
			// skip the pdfs in ManipulatePdfFile class
			metadata.putIfAbsent(Workflow.SKIP_MANIPULATE_PDF_FILE, true);
		}
	}

	
    @SuppressWarnings("unchecked")
	private HashMap<String,Object> validateInput(String executionBusData, DelegateExecution execution) { 
        HashMap<String,Object> map = null;
        try {
			map = Parser.parseJson(executionBusData, HashMap.class);
		} catch (IOException e) {
      		LOGGER.error("validateInput Input format is incorrect for the variable {}={} {}",
					"executionBusData", executionBusData,
					ExceptionUtils.getStackTrace(e));
    		addErrorMsg("IdentifyShutterflyDocuments-->validateInput-->Input format is incorrect for the variable " + executionBusData, WorkFlowUtil.getStackTrace(e));
		}
        return map;
    }
    
	private String getCurrentDateFormatted(String format) {
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern(format);
		return now.format(formatter);
	}
	
	private ResponseEntity<byte[]> getAttachment(String token, String url, String fdsDocumentId, String attachmentId, int spaceId, String fdsCloudOauthUrl, String clientId, String clientSecret, String grantType) throws URISyntaxException, InterruptedException {	
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", token);
		HttpEntity<?> entity = new HttpEntity<>(headers);
		
		String fdsCloudSpaceId = (String) config.getCredentials(spaceId).get("fdsCloudSpaceId");
		
		Map<String, String> pathParams = new HashMap<>();
		pathParams.put("spaceId", fdsCloudSpaceId);
		pathParams.put("documentId", fdsDocumentId);
		pathParams.put("attachmentId", attachmentId);
				
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(url);

		URI uri = uriBuilder.buildAndExpand(pathParams).encode().toUri();
		
		ResponseEntity<DocumentAttachmentMetaData> response;
		
		long startTime = System.nanoTime();
		try {
			response = restTemplate.exchange(uri, HttpMethod.GET, entity, DocumentAttachmentMetaData.class);
			long latency = (System.nanoTime() - startTime) / 1000000;
			
			LOGGER.info("getFDSCloudDocumentAttachment fdsCloudDocumentId={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
					fdsDocumentId, Encode.forJava(url), HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
			
			
		} catch (HttpStatusCodeException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;
			LOGGER.error("getFDSCloudDocumentAttachment HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
					fdsDocumentId, Encode.forJava(url), HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );			
			
			String newAccessToken = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", clientId, clientSecret, grantType, fdsCloudOauthUrl, true, null);
			
			response = retryUtil.retryFDSCloudCall(uri, newAccessToken, restTemplate);
		} catch (Exception e) {
			LOGGER.error("getFDSCloudDocumentAttachment Exception Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, err={}", 
					fdsDocumentId, ExceptionUtils.getStackTrace(e) );			
			response = null;
		}
		
		DocumentAttachmentMetaData attachment = response != null ? response.getBody() : null;
		if (attachment == null) {
			throw new URISyntaxException("attachment", "null");
		}
		String attachmentUrl = attachment.getUrl();
		String attachmentUrlToken = attachment.getUrlToken();
		var attachmentHeaders = new HttpHeaders();
		attachmentHeaders.set("Authorization", attachmentUrlToken);
		HttpEntity<?> attachmentEntity = new HttpEntity<>(attachmentHeaders);
		
		ResponseEntity<byte[]> attachmentResponse = null;
		
		startTime = System.nanoTime();
		try {
			attachmentResponse = restTemplate.exchange(new URI(Encode.forJava(attachmentUrl)), HttpMethod.GET, attachmentEntity, byte[].class);
			long latency = (System.nanoTime() - startTime) / 1000000;
			
			LOGGER.info("downloadFDSCloudDocumentAttachment fdsCloudDocumentId={}, Consumer=fds.paperless, ServiceName=fds.cloud, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
					fdsDocumentId, HttpMethod.GET.toString(), attachmentResponse.getStatusCode().value(), latency );
			
		} catch (HttpStatusCodeException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;
			LOGGER.error("downloadFDSCloudDocumentAttachment HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
					fdsDocumentId, HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );			
			
			attachmentResponse = retryUtil.retryGetAttachment(SanitizeUtil.sanitizeAttachmentURL(uri), attachmentUrlToken, restTemplate);
			
		} catch (Exception e) {
			LOGGER.error("downloadFDSCloudDocumentAttachment Exception Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, err={}", 
					fdsDocumentId, ExceptionUtils.getStackTrace(e) );
		}
		
		return attachmentResponse;
	}

	private ResponseEntity<DocumentAttachmentDoc360> getAttachmentDoc360(String token, String doc360Url, String doc360DocumentId, String x_upstream_env, String oauthUrl, String clientId, String clientSecret, String grantType, String scope, String doc360Class) throws URISyntaxException, InterruptedException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set(Workflow.AUTHORIZATION, token);
		headers.set(Workflow.X_UPSTREAM_ENV, x_upstream_env);
		HttpEntity<?> entity = new HttpEntity<>(headers);

		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(doc360Url)
				.pathSegment(doc360DocumentId)
				.queryParam("type-name", doc360Class)
				.queryParam("enable-base64-output", true);
		URI uri = uriBuilder.build().encode().toUri();

		ResponseEntity<DocumentAttachmentDoc360> response;

		long startTime = System.nanoTime();
		try {
			response = restTemplate.exchange(uri, HttpMethod.GET, entity, DocumentAttachmentDoc360.class);
			long latency = (System.nanoTime() - startTime) / 1000000;

			LOGGER.info("getDoc360DocumentAttachment Doc360DocumentId={}, Consumer=fds.paperless, ServiceName=Doc360, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}",
					Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, response.getStatusCode().value(), latency );

		} catch (HttpClientErrorException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;

			if (e.getStatusCode() == HttpStatus.UNAUTHORIZED) {
				LOGGER.error("getDoc360DocumentAttachment HttpClientErrorException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
						Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
				String 			newAccessToken = oauthManagerUtil.getOauthToken("doc360", clientId, clientSecret, grantType, oauthUrl, true, scope);
			 				response = retryUtil.retryDoc360Call(uri, newAccessToken, restTemplate, x_upstream_env);
			}
			else {
				LOGGER.error("getDoc360DocumentAttachment HttpClientErrorException Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
						Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
				return new ResponseEntity<>(e.getStatusCode());
			}
		} catch (HttpServerErrorException e){
			long latency = (System.nanoTime() - startTime) / 1000000;

			if (e.getStatusCode() == HttpStatus.BAD_GATEWAY || e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
				LOGGER.error("getDoc360DocumentAttachment HttpServerErrorException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
						Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );

				String newAccessToken = oauthManagerUtil.getOauthToken("doc360", clientId, clientSecret, grantType, oauthUrl, true, scope);
				response = retryUtil.retryDoc360Call(uri, newAccessToken, restTemplate, x_upstream_env);
			}
			else {
				 LOGGER.error("getDoc360DocumentAttachment HttpServerErrorException Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
							Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
				return new ResponseEntity<>(e.getStatusCode());
			 }
		}
		catch (Exception e) {
			LOGGER.error("getDoc360DocumentAttachment Exception Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, err={}",
					Encode.forJava(doc360DocumentId), ExceptionUtils.getStackTrace(e) );
			response = null;
		}
		return response;
	}

	
}