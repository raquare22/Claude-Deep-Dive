package com.optum.fds.paperless.java.delegate;

import java.util.HashMap;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.SendQueueService;
import com.optum.fds.paperless.exception.HttpServerException;

@Service("CallRestApiWithMsgServiceOnErrorCallback")
public class CallRestApiWithMsgServiceOnErrorCallback extends OptumJavaDelegateBase {
	private static final Logger LOGGER = LoggerFactory.getLogger(CallRestApiWithMsgServiceOnErrorCallback.class);

	private static final String PROCESS_FILE_TASK_ID = "processorFileTaskId";
	private static final String PRUN_DOCUMENT_ID = "prunDocumentId";
	private static final String APP_IDENTIFIER = "appIdentifier";
	private static final String FILE_PATH = "filePath";
	private static final String DOCUMENTS = "documents";
    private static final String DOC_CLASS = "docClass";
	private static final String SEARCH_TERMS = "searchTerms";

	private static final String CALLBACK_EXCEPTION = "CALLBACK: Exception while sendRequestToQueue; spaceId={}, queue={}, identifier={}, targetId={}, documentId={}, msg={}, delegate={}; {}";

	@Autowired
	ErrorMetaDataService errorMetaDataService;

	@Autowired
	SendQueueService sendQueueService;

	@Override
	public void doExecute(DelegateExecution execution) {
		// This can support multiple restApi endPoints using restApiId do not specify REQ_VARS
		String restApiId = null;
		Integer spaceId = null;
		String identifier = null;
		String targetId = null;
		String delegate = null;
		Integer retryCnt = null;
		String processorFileTaskId = null;
		String documentId = null;
		String appIdentifier = null;
		String filePath = null;
		String documents = null;
		String searchTerms = null;
        String docClass = null;
		try {
			restApiId = (String) execution.getVariable("restApiId");
			spaceId = (Integer) execution.getVariable("spaceId");
			identifier = (String) execution.getVariable("identifier");
			targetId = (String) execution.getVariable("targetId");
			delegate = (String) execution.getVariable("delegate");
			retryCnt = (Integer) execution.getVariable("retryCnt");
			processorFileTaskId = (String) execution.getVariable(PROCESS_FILE_TASK_ID);
			documentId = (String) execution.getVariable(PRUN_DOCUMENT_ID);
			appIdentifier = (String) execution.getVariable(APP_IDENTIFIER);
			filePath = (String) execution.getVariable(FILE_PATH);
            docClass = (String) execution.getVariable(DOC_CLASS);
			documents = (String) execution.getVariable(DOCUMENTS);
			searchTerms = (String) execution.getVariable(SEARCH_TERMS);
		} catch (Exception e) {
			LOGGER.error("Failure: {}", ExceptionUtils.getStackTrace(e));
			return;
		}

		LOGGER.debug("CALLBACK: restApiId={}, spaceId={}, identifier={}, targetId={}, delegate={}, retryCnt={}, processorFileTaskId={}, prunDocumentId={}, appIdentifier={}, filePath={}, documents={}, searchTerms={}",
			restApiId, spaceId, identifier, targetId, delegate, retryCnt, processorFileTaskId, documentId, appIdentifier, filePath, documents, searchTerms);

        if (restApiId.equals("addSendDocumentRequestToDoc360")) {

            if (spaceId == null || identifier == null || targetId == null || delegate == null || processorFileTaskId == null || documentId == null || appIdentifier == null || filePath == null || documents == null || docClass == null) {
                LOGGER.error("CALLBACK: Params not valid exiting; restApiId={}, spaceId={}, identifier={}, targetId={}, delegate={}, retryCnt={}, processorFileTaskId={}, prunDocumentId={}, appIdentifier={}, filePath={}, documents={}, searchTerms={}",
                        restApiId, spaceId, identifier, targetId, delegate, retryCnt, processorFileTaskId, documentId, appIdentifier, filePath, documents, searchTerms);
                return;
            }

            Map<String, Object> callbackMap = new HashMap<>();
            callbackMap.put(PROCESS_FILE_TASK_ID, processorFileTaskId);
            callbackMap.put(PRUN_DOCUMENT_ID, documentId);
            callbackMap.put(APP_IDENTIFIER, appIdentifier);

            MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
            requestMap.add(FILE_PATH, filePath);
            requestMap.add(DOCUMENTS, documents);
            requestMap.add(DOC_CLASS, docClass);

            Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();
            restApiMsgServiceCallbackMap.put(PROCESS_FILE_TASK_ID, targetId);
            restApiMsgServiceCallbackMap.put(PRUN_DOCUMENT_ID, documentId);
            restApiMsgServiceCallbackMap.put(APP_IDENTIFIER, appIdentifier);
            restApiMsgServiceCallbackMap.put(FILE_PATH, filePath);
            restApiMsgServiceCallbackMap.put(DOCUMENTS, documents);
            restApiMsgServiceCallbackMap.put(DOC_CLASS, docClass);
            restApiMsgServiceCallbackMap.put("restApiId", "addSendDocumentRequestToDoc360");
            restApiMsgServiceCallbackMap.put("spaceId", spaceId);
            restApiMsgServiceCallbackMap.put("delegate", delegate);
            restApiMsgServiceCallbackMap.put("identifier", identifier);
            restApiMsgServiceCallbackMap.put("targetId", targetId);

            retryCnt = retryCnt == null ? 0 : retryCnt + 1;
            restApiMsgServiceCallbackMap.put("retryCnt", retryCnt);

            try {
                LOGGER.info("CALLBACK: Calling addSendDocumentRequestToDoc360; retryCnt={}, spaceId={}, identifier={}, targetId={}, documentId={}, delegate={}, requestMap={}, callbackMap={}, restApiMsgServiceCallbackMap={}",
                        retryCnt, spaceId, identifier, targetId, documentId, delegate, requestMap, callbackMap, restApiMsgServiceCallbackMap);
                if (sendQueueService.addSendDocumentRequestToDoc360(spaceId, identifier, targetId, delegate, requestMap, callbackMap, restApiMsgServiceCallbackMap, retryCnt)) {
                    LOGGER.info("SUCCESS: addSendDocumentRequestToDoc360: retryCnt={}, spaceId={}, identifier={}, targetId={}, documentId={}, callback={}", retryCnt, spaceId, identifier, targetId, documentId, delegate);
                } else {
                    LOGGER.warn("FAILURE: addSendDocumentRequestToDoc360: retryCnt={}, spaceId={}, identifier={}, targetId={}, documentId={}, callback={}", retryCnt, spaceId, identifier, targetId, documentId, delegate);
                }
            } catch (HttpServerException e) {
                // MessageService will process appError
                String queue = sendQueueService.getPriorityQueue(spaceId);
                LOGGER.error(CALLBACK_EXCEPTION, spaceId, queue, identifier, targetId, documentId, e.getMessage(), "callRestApiWithMsgServiceOnErrorCallback", restApiMsgServiceCallbackMap);
                ErrorMetaData errorMetaData = errorMetaDataService.writeToMessageServiceErrorCollection(queue, "callRestApiWithMsgServiceOnErrorCallback", targetId, spaceId, restApiMsgServiceCallbackMap, e.getMessage(), MetaDataStatus.AUTOMATIC);
            }

        } else if (restApiId.equals("addSendDocumentRequestToFds")) {

            if (spaceId == null || identifier == null || targetId == null || delegate == null || processorFileTaskId == null || documentId == null || appIdentifier == null || filePath == null || documents == null || searchTerms == null) {
                LOGGER.error("CALLBACK: Params not valid exiting; restApiId={}, spaceId={}, identifier={}, targetId={}, delegate={}, retryCnt={}, processorFileTaskId={}, prunDocumentId={}, appIdentifier={}, filePath={}, documents={}, searchTerms={}",
                        restApiId, spaceId, identifier, targetId, delegate, retryCnt, processorFileTaskId, documentId, appIdentifier, filePath, documents, searchTerms);
                return;
            }

            Map<String, Object> callbackMap = new HashMap<>();
            callbackMap.put(PROCESS_FILE_TASK_ID, processorFileTaskId);
            callbackMap.put(PRUN_DOCUMENT_ID, documentId);
            callbackMap.put(APP_IDENTIFIER, appIdentifier);

            MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
            requestMap.add(FILE_PATH, filePath);
            requestMap.add(DOCUMENTS, documents);
            requestMap.add(SEARCH_TERMS, searchTerms);

            Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();
            restApiMsgServiceCallbackMap.put(PROCESS_FILE_TASK_ID, targetId);
            restApiMsgServiceCallbackMap.put(PRUN_DOCUMENT_ID, documentId);
            restApiMsgServiceCallbackMap.put(APP_IDENTIFIER, appIdentifier);
            restApiMsgServiceCallbackMap.put(FILE_PATH, filePath);
            restApiMsgServiceCallbackMap.put(DOCUMENTS, documents);
            restApiMsgServiceCallbackMap.put(SEARCH_TERMS, searchTerms);
            restApiMsgServiceCallbackMap.put("restApiId", "addSendDocumentRequestToFds");
            restApiMsgServiceCallbackMap.put("spaceId", spaceId);
            restApiMsgServiceCallbackMap.put("delegate", delegate);
            restApiMsgServiceCallbackMap.put("identifier", identifier);
            restApiMsgServiceCallbackMap.put("targetId", targetId);

            retryCnt = retryCnt == null ? 0 : retryCnt + 1;
            restApiMsgServiceCallbackMap.put("retryCnt", retryCnt);

            try {
                LOGGER.info("CALLBACK: Calling addSendDocumentRequestToFds; retryCnt={}, spaceId={}, identifier={}, targetId={}, documentId={}, delegate={}, requestMap={}, callbackMap={}, restApiMsgServiceCallbackMap={}",
                        retryCnt, spaceId, identifier, targetId, documentId, delegate, requestMap, callbackMap, restApiMsgServiceCallbackMap);
                if (sendQueueService.addSendDocumentRequestToFds(spaceId, identifier, targetId, delegate, requestMap, callbackMap, restApiMsgServiceCallbackMap, retryCnt)) {
                    LOGGER.info("SUCCESS: addSendDocumentRequestToFds: retryCnt={}, spaceId={}, identifier={}, targetId={}, documentId={}, callback={}", retryCnt, spaceId, identifier, targetId, documentId, delegate);
                } else {
                    LOGGER.warn("FAILURE: addSendDocumentRequestToFds: retryCnt={}, spaceId={}, identifier={}, targetId={}, documentId={}, callback={}", retryCnt, spaceId, identifier, targetId, documentId, delegate);
                }
            } catch (HttpServerException e) {
                // MessageService will process appError
                String queue = sendQueueService.getPriorityQueue(spaceId);
                LOGGER.error(CALLBACK_EXCEPTION, spaceId, queue, identifier, targetId, documentId, e.getMessage(), "callRestApiWithMsgServiceOnErrorCallback", restApiMsgServiceCallbackMap);
                ErrorMetaData errorMetaData = errorMetaDataService.writeToMessageServiceErrorCollection(queue, "callRestApiWithMsgServiceOnErrorCallback", targetId, spaceId, restApiMsgServiceCallbackMap, e.getMessage(), MetaDataStatus.AUTOMATIC);
            }

        } else {
            LOGGER.error("CALLBACK: Failure restApiId={} is not supported", restApiId);
            return;
        }




	}
}
