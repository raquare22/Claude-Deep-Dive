/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/30/17.
 */

package com.optum.fds.paperless.util;

import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.ProcessorTransactionCore;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;

import org.mvel2.MVEL;
import org.mvel2.PropertyAccessException;

import java.io.File;
import java.util.Date;
import java.util.Map;
import java.util.Set;


public class ProcessorTaskUtil {
    private ProcessorTaskUtil() {throw new AssertionError("cannot instantiate");}

    public static void addMessageToProcessorExecutionRecordToProcessorTransaction(
            ProcessorTransactionCore processorTransaction, ProcessorExecutionRecord executionRecord,
            Map<String, String> message) {
        executionRecord.setDateModified(new Date());
        executionRecord.addMessage(message);
        processorTransaction.addProcessorExecutionRecord(executionRecord);
    }

    public static void addMessageToProcessorExecutionRecordToProcessorFileTask(
            ProcessorService processorService, ProcessorFileTask processorFileTask,
            ProcessorExecutionRecord executionRecord, Map<String, String> message) {
        executionRecord.setDateModified(new Date());
        executionRecord.addMessage(message);
        processorFileTask.addProcessorExecutionRecord(executionRecord);
        processorService.updateProcessorFileTask(processorFileTask);

    }

    public static String getFileName(String documentId, String appIdentifier, ProcessorFileTaskService processorFileTaskService, ProcessorsService processorsService) {
        var zipFileName = "";
        var processorFileTask = processorFileTaskService.getProcessorFileTaskForTargetId(documentId, "documents", appIdentifier);
        if (processorFileTask != null) {
            var processorTransaction = processorsService.getProcessorTransactionById(processorFileTask.getProcessorTransactionId());
            zipFileName = processorTransaction.getFileName();
        }
        return zipFileName;
    }

    public static void addMessageToProcessorExecutionRecordToProcessorTransactionMetadata(
            ProcessorTransactionMetadata processorTransactionMetadata, ProcessorExecutionRecord executionRecord,
            Map<String, String> message) {
        executionRecord.setDateModified(new Date());
        executionRecord.addMessage(message);
        processorTransactionMetadata.addProcessorExecutionRecord(executionRecord);
    }

    public static void addMessageToProcessorExecutionRecord(
            ProcessorExecutionRecord executionRecord, Map<String, String> message) {
        executionRecord.setDateModified(new Date());
        executionRecord.addMessage(message);
    }

    public static void addMiscellaneousToProcessorExecutionRecord(
            ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord) {

        executionRecord.setClientId(processorFileTask.getClientId());
        executionRecord.setSpaceId(processorFileTask.getConfigSpaceId());
    }

    public static ProcessorExecutionRecord createProcessorExecutionRecord(String description) {
        var processorExecutionRecord = createBlankAudit();
        processorExecutionRecord.setDescription(description);

        return processorExecutionRecord;
    }

    public static boolean validateCriteriaMatch(String expression, Map<String, Object> rootNodeMap) {
        Boolean result = false;
        try {
            result = (Boolean) MVEL.eval(expression, rootNodeMap);

        } catch (PropertyAccessException ex) {
            result = false;
        }
        return result;
    }

    public static boolean findDuplicateError(String errormsg, Set<String> errorList) {
        return errorList.stream().anyMatch(o -> o.contains(errormsg));
    }

    public static ProcessorExecutionRecord createProcessorExecutionRecord(String description,
                                                                          ProcessorTransactionCore processorTransaction) {
        var processorExecutionRecord = createBlankAudit();
        processorExecutionRecord.setDescription(description);
        processorExecutionRecord.setClientId(processorTransaction.getClientId());
        processorExecutionRecord.setSpaceId(processorTransaction.getConfigSpaceId());

        return processorExecutionRecord;
    }

    public static ProcessorExecutionRecord createProcessorExecutionRecord(String description, Map<String, String> message) {
        var processorExecutionRecord = createProcessorExecutionRecord(description);
        processorExecutionRecord.addMessage(message);
        return processorExecutionRecord;
    }

    public static void updateFileMetrics(ProcessorFileTask processorFileTask, File fileToProcess,
                                         ProcessorFileTaskService processorFileTaskService) {
        // Updating metric information
        var fileInfo = Utilities.getFileInformation(fileToProcess);
        processorFileTask.setFileSize((Long) fileInfo.get("size"));
        processorFileTask.setFileType((String) fileInfo.get("type"));

        processorFileTaskService.updateProcessorFileTask(processorFileTask);
    }


    public static void updateServerMetrics(ProcessorFileTask processorFileTask, ProcessorFileTaskService processorFileTaskService) {
        processorFileTask.setProcessedByHost(FileUtil.getInstance().getLocalHostName());

        processorFileTaskService.updateProcessorFileTask(processorFileTask);
    }

//	public static  void updateServerMetrics(CsvProcessorTransaction csvProcessorTransaction,
//			CsvProcessorService csvProcessorService) {
//		csvProcessorService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
//	}

    public static void updateProcessFileTaskWithExecutionRecord(ProcessorFileTaskService processorFileTaskService,
                                                                ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord) {
        processorFileTask.addProcessorExecutionRecord(executionRecord);
        processorFileTaskService.updateProcessorFileTask(processorFileTask);
    }

    public static void updateProcessFileTaskWithExecutionRecord(ProcessorFileTaskService processorFileTaskService,
                                                                ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord,
                                                                Map<String, String> message) {
        addMessageToProcessorExecutionRecord(executionRecord, message);
        addMiscellaneousToProcessorExecutionRecord(processorFileTask, executionRecord);
        updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask, executionRecord);
    }

    public static void updateProcessTransactionWithExecutionRecord(ProcessorService processorService,
                                                                   ProcessorTransaction processorTransaction, ProcessorExecutionRecord executionRecord) {
        processorTransaction.addProcessorExecutionRecord(executionRecord);
        processorService.updateProcessorTransactionMetaData(processorTransaction);
    }

    public static void updateProcessTransactionWithExecutionRecord(ProcessorService processorService,
                                                                   ProcessorTransaction processorTransaction, ProcessorExecutionRecord executionRecord,
                                                                   Map<String, String> message) {
        addMessageToProcessorExecutionRecord(executionRecord, message);
        updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord);
    }

//	public static  void updateProcessTransactionWithExecutionRecord(CsvProcessorService csvProcessorService,
//			ProcessorTransactionCore processorTransaction, ProcessorExecutionRecord executionRecord) {
//		processorTransaction.addProcessorExecutionRecord(executionRecord);
//		if (processorTransaction instanceof CsvProcessorTransaction) {
//			csvProcessorService.updateCsvProcessorTransactionMetaData((CsvProcessorTransaction) processorTransaction);
//		}
//	}

//	public static  void updateProcessTransactionWithUnprocessedRecord(CsvProcessorService csvProcessorService,
//			ProcessorTransactionCore processorTransaction, List<UnprocessedRecord> unprocessedRecord) {
//		processorTransaction.setUnprocessedRecordList(unprocessedRecord);
//		if (processorTransaction instanceof CsvProcessorTransaction) {
//			csvProcessorService.updateCsvProcessorTransactionMetaData((CsvProcessorTransaction) processorTransaction);
//		}
//	}

//	public static  void updateProcessTransactionWithExecutionRecord(CsvProcessorService csvProcessorService,
//			ProcessorTransactionCore processorTransaction, ProcessorExecutionRecord executionRecord,
//			Map<String, String> message) {
//		addMessageToProcessorExecutionRecord(executionRecord, message);
//		updateProcessTransactionWithExecutionRecord(csvProcessorService, processorTransaction, executionRecord);
//	}

    private static ProcessorExecutionRecord createBlankAudit() {
        var processorExecutionRecord = new ProcessorExecutionRecord();
        processorExecutionRecord.setServerName(FileUtil.getInstance().getLocalHostName());
        processorExecutionRecord.setServerIp(FileUtil.getInstance().getLocalHostIP());
        processorExecutionRecord.setDateCreated(new Date());
        processorExecutionRecord.setDateModified(processorExecutionRecord.getDateCreated());
        return processorExecutionRecord;
    }

    public static ProcessorExecutionRecord createRecordWithDelegateName(Class<?> clazz) {
        var processorExecutionRecord = new ProcessorExecutionRecord();
        processorExecutionRecord.setActivitiProcessKey(clazz.getSimpleName());
        processorExecutionRecord.setDateActivitiJobCompleted(new Date());
        return processorExecutionRecord;
    }

}
