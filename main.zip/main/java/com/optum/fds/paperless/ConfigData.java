package com.optum.fds.paperless;

import java.util.Collections;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;

public class ConfigData {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigData.class);
	private Map<String, Object> allClientCredentials = new java.util.HashMap<>();
    private static final String DEFAULT_UPLOAD_PROVIDER = "FDS_CLOUD";
	
	@Value("${printTrailMap}")
	private String printTrailMap;

	@Value("${LETGEN.credentials}")
	private String LETGEN_configcredentials;

	@Value("${UNET.credentials}")
	private String UNET_configcredentials;

	@Value("${NEXTGEN.credentials}")
	private String NEXTGEN_configcredentials;

	@Value("${1CLICK.credentials}")
	private String _1CLICK_configcredentials;

	@Value("${CCSManual.credentials}")
	private String CCSManual_configcredentials;

	@Value("${UNET_PRA.credentials}")
	private String UNET_PRA_configcredentials;

	@Value("${COSMOS_PRA.credentials}")
	private String COSMOS_PRA_configcredentials;

	@Value("${COSMOS.credentials}")
	private String COSMOS_configcredentials;

	@Value("${UHC_WEST.credentials}")
	private String UHC_WEST_configcredentials;

	@Value("${CSP_PRA.credentials}")
	private String CSP_PRA_configcredentials;

	@Value("${ODAR.credentials}")
	private String ODAR_configcredentials;

	@Value("${MR_APPEALS.credentials}")
	private String MR_APPEALS_configcredentials;

	@Value("${ETS_APPEALS.credentials}")
	private String ETS_APPEALS_configcredentials;

	@Value("${USP_CLAIMS.credentials}")
	private String USP_CLAIMS_configcredentials;

	@Value("${USP_PRA.credentials}")
	private String USP_PRA_configcredentials;

	@Value("${CSP_CLAIMS.credentials}")
	private String CSP_CLAIMS_configcredentials;

	@Value("${OCM.credentials}")
	private String OCM_configcredentials;

	@Value("${IHR.credentials}")
	private String IHR_configcredentials;

	@Value("${CC.credentials}")
	private String CC_configcredentials;

	@Value("${CAP.credentials}")
	private String CAP_configcredentials;
	
	@Value("${HouseCalls.credentials}")
	private String HouseCalls_configcredentials;

	@Value("${TEXAS_GOLD_CARD.credentials}")
	private String TEXAS_GOLD_CARD_configcredentials;

	@Value("${TRACKIT.credentials}")
	private String TRACKIT_configcredentials;

	@Value("${NGSClaims.credentials}")
	private String NGSClaims_configcredentials;
	
	@Value("${ATSANDALINK.credentials}")
	private String ATSAPPEALS_configcredentials;

	@Value("${MemberPayment.credentials}")
	private String MemberPayment_configcredentials;

	@Value("${OTHER.credentials}")
	private String OTHER_configcredentials;
	
	@Value("${MNR.credentials}")
	private String mnrConfigcredentials;
	
	@Value("${consumerEngineering.credentials}")
	private String consumerEngineeringConfigcredentials;

	@Value("${SSBCI.credentials}")
	private String ssbciConfigcredentials;

	@Autowired
	private ObjectMapper mapper;

	@SuppressWarnings({"unchecked"})
	public Map<String, Object> getClientMapFromPrintTrail(String printTrail) {
		mapper = new ObjectMapper();
		final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
		Map<String, Object> data = null;
		try {
			data = mapper.readValue(printTrailMap, type);
			return (Map<String, Object>) data.get(printTrail);
		} catch (Exception ex) {
			LOGGER.error("Error in ConfigData-->getClientFromPrintTrail, printTrail={}, e={}", printTrail,ex.getMessage());
			return null;
		}
	}

    public String getUploadProvider(Integer spaceId) {
        Map<String, Object> credentialsMap = getCredentials(spaceId);
        if (credentialsMap == null || credentialsMap.isEmpty()) {
            return DEFAULT_UPLOAD_PROVIDER;
        }

        Object provider = credentialsMap.get("uploadProvider");
        if (provider == null || provider.toString().trim().isEmpty()) {
            return DEFAULT_UPLOAD_PROVIDER;
        }

        return provider.toString().trim().toUpperCase();
    }

    public String getDoc360DocClass(Integer spaceId) {
        Map<String, Object> credentialsMap = getCredentials(spaceId);
        if (credentialsMap == null || credentialsMap.isEmpty()) {
            return "";
        }

        Object docClass = credentialsMap.get("doc360DocClass");
        return docClass == null ? "" : docClass.toString();
    }

	@SuppressWarnings({ "unchecked" })
	public Map<String, Object> getCredentials(Integer spaceId) {
		if (allClientCredentials.isEmpty()) setCredentials();

		Map<String, Object> credentials = null;
		int retryCount = 1;
		int maxRetries = 5;

		while (credentials == null && retryCount <= maxRetries) {
			credentials = (Map<String, Object>) Collections.unmodifiableMap(allClientCredentials).get(spaceId.toString());
			if (credentials == null) {
				LOGGER.warn("No credentials found for spaceId={}, retrying... (attempt {} of {})", spaceId, retryCount + 1, maxRetries);
				setCredentials();
				retryCount++;
			}
		}

		if (credentials == null) {
			LOGGER.error("No credentials found for spaceId={} after {} attempts", spaceId, maxRetries);
			return Collections.emptyMap();
		}

		return Collections.unmodifiableMap(credentials);
	}

	private void setCredentials() {
		mapper = new ObjectMapper();
		final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
		try {
			allClientCredentials.putAll(mapper.readValue(LETGEN_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(UNET_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(NEXTGEN_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(_1CLICK_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CCSManual_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(UNET_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(COSMOS_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(COSMOS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(UHC_WEST_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CSP_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ODAR_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(MR_APPEALS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ETS_APPEALS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(USP_CLAIMS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(USP_PRA_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CSP_CLAIMS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(OCM_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(IHR_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CC_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(CAP_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(HouseCalls_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(TEXAS_GOLD_CARD_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(TRACKIT_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(NGSClaims_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ATSAPPEALS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(MemberPayment_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(OTHER_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(mnrConfigcredentials, type));
			allClientCredentials.putAll(mapper.readValue(consumerEngineeringConfigcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ssbciConfigcredentials, type));
			LOGGER.info("All Credentials have been set.");
		} catch (JsonProcessingException ex) {
			LOGGER.error("Error in ConfigData-->setCredentials, {}", ex.getMessage());
		}
	}
}
