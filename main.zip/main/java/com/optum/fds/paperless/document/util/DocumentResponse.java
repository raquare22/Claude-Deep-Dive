/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who                              Revision
 * May 13 2015  Vinata Gangolli, Kwasi Boateng 	 Initial version
 ****************************************************************/
package com.optum.fds.paperless.document.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.optum.fds.paperless.domain.revision.DocumentRevision;
import org.bson.Document;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String fdsDocumentId;
    private String parentId;
    private String externalId;
    private Integer spaceId;
    private String cloudSpaceId;
    private String status;
    private String version;
    private String expires;
    private String dateCreated;
    private String dateModified;
    private Rules rules;
    private String storeInputFiles;
    private String errorMessage;
    private Attachment[] attachments;

    private Document metadata;
    private String doc360DocClass;

    private List<DocumentRevision> revisions;
    
    public String getFdsDocumentId() {
		return fdsDocumentId;
	}

	public void setFdsDocumentId(String fdsDocumentId) {
		this.fdsDocumentId = fdsDocumentId;
	}

	public String getCloudSpaceId() {
		return cloudSpaceId;
	}

	public void setCloudSpaceId(String cloudSpaceId) {
		this.cloudSpaceId = cloudSpaceId;
	}

	public Integer getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(Integer spaceId) {
        this.spaceId = spaceId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getExpires() {
        return expires;
    }

    public void setExpires(String expires) {
        this.expires = expires;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public Attachment[] getAttachments() {
        return attachments == null ? null : attachments.clone();
    }

    public void setAttachments(Attachment[] attachments) {
        this.attachments = attachments == null ? null : attachments.clone();
    }

    public Rules getRules() {
        return rules;
    }

    public void setRules(Rules rules) {
        this.rules = rules;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getStoreInputFiles() {
        return storeInputFiles;
    }

    public void setStoreInputFiles(String storeInputFiles) {
        this.storeInputFiles = storeInputFiles;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }


    public Document getMetadata() {
        return metadata;
    }

    public void setMetadata(Document metadata) {
        this.metadata = metadata;
    }

    public String getDoc360DocClass() {
        return doc360DocClass;
    }

    public void setDoc360DocClass(String doc360DocClass) {
        this.doc360DocClass = doc360DocClass;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * @return the dateModified
     */
    public String getDateModified() {
        return dateModified;
    }

    /**
     * @param dateModified the dateModified to set
     */
    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public List<DocumentRevision> getRevisions() {
        return revisions == null ? null : new ArrayList<>(revisions);
    }

    public void setRevisions(List<DocumentRevision> revisions) {
        this.revisions = revisions == null ? null : new ArrayList<>(revisions);
    }

    @Override
    public String toString() {
        return "DocumentResponse [id=" + id + ", parent_id=" + parentId + ", external_id=" + externalId + ", space_id="
                + spaceId + ", status=" + status + ", version=" + version + ", expires=" + expires + ", rules=" + rules
                + ", store_input_files=" + storeInputFiles + "]";
    }
}
