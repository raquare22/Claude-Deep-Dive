package com.optum.fds.paperless.document.response.util;

import com.optum.fds.paperless.document.util.Attachment;
import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Parser;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class DocumentResponseUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentResponseUtil.class);

    private DocumentResponseUtil() {
        throw new AssertionError("cannot instantiate");
    }

    static DocumentResponse prepareFullDocumentResponse(DocumentMetaData documentMetaData,
                                                        List<AttachmentMetaData> attmtsMetaDataList) {
        LOGGER.debug("Entering prepareFullDocumentResponse");

        var response = new DocumentResponse();

        String cloudSpaceId = "";
        if (CollectionUtils.isNotEmpty(attmtsMetaDataList)) {
            var attachmentResponseList = prepareAttachmentResponse(attmtsMetaDataList);
            response.setAttachments((attachmentResponseList.toArray(new Attachment[0])));
            cloudSpaceId = attmtsMetaDataList.get(0).getCloudSpaceId();
        }

        response.setSpaceId(documentMetaData.getSpaceId());
        response.setDoc360DocClass(documentMetaData.getDoc360DocClass());
        if (documentMetaData.getStatus() != null) {
            response.setStatus(documentMetaData.getStatus().toString());
        }
        response.setCloudSpaceId(cloudSpaceId);
        response.setFdsDocumentId(documentMetaData.getFdsDocumentId());
        response.setId(documentMetaData.getId());
        response.setExternalId(documentMetaData.getExternalId());
        response.setMetadata(documentMetaData.getMetadata());
        if (documentMetaData.getDateCreated() != null) {	
        	SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zZ yyyy");
        	sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        	response.setDateCreated(sdf.format(documentMetaData.getDateCreated()));
        }
        LOGGER.debug("Leaving prepareFullDocumentResponse");
        return response;
    }

    public static void logInfoWithTransactionId(Logger logger, String info, String transactionId) {
        var sb = new StringBuilder();
        sb.append(info).append(" for transaction_id:").append(transactionId);
        logger.debug("for transaction_id: {}", sb);
    }

    public static String buildDocumentResponseInJson(DocumentMetaData documentMetaData,
                                                     List<AttachmentMetaData> attmtsMetaDataList) throws IOException {

        String transactionId = documentMetaData.getTransactionId();
        logInfoWithTransactionId(LOGGER, "Entered DocumentUtilService.buildDocumentResponseInJson", transactionId);

        var response = prepareFullDocumentResponse(documentMetaData, attmtsMetaDataList);

        logInfoWithTransactionId(LOGGER, "Exited DocumentUtilService.buildDocumentResponseInJson", transactionId);

        return Parser.toJson(response, "yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    }

    static List<Attachment> prepareAttachmentResponse(List<AttachmentMetaData> amds) {
        LOGGER.debug("Entering prepareAttachmentResponse");
        List<Attachment> attachments = new ArrayList<>();
        var counter = 0;
        for (AttachmentMetaData amd : amds) {
            counter++;
            var atmt = createAttachment(amd);
            attachments.add(atmt);
        }
        LOGGER.debug("Attachments Size {}", attachments.size());
        LOGGER.debug("Leaving prepareAttachmentResponse");
        return attachments;
    }

    static Attachment createAttachment(AttachmentMetaData amd) {
        LOGGER.debug("Entering createAttachment");
        var atmt = new Attachment();
    	LOGGER.debug("Entering createAttachment");
		atmt = Attachment.createDocLibAttachment(amd);
		LOGGER.debug("Leaving createAttachment with Id: {}", atmt.getId());
		return atmt;
    }
}
