////package com.optum.fs.processors;
package com.optum.fds.paperless.processors;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;


@Component
public class CsvProcessorsMonitor {

	private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    private static final Logger log = LoggerFactory.getLogger(CsvProcessorsMonitor.class);
    private static final String JOB_TYPE = "cleanUpProcessor";
    private static final String WRK_FLOW = "csvCleanupFilesProcess";

    @Autowired ProcessorsService processorsService;
    @Autowired CsvProcessorsService csvProcessorsService;
    
    @Value("${poll.schedulers.enabled:true}")
    String pollSchedulersEnabled;
    
    ////@EnableBatchPodsOnly
    ////@Scheduled(fixedRateString = "${cleanupSchedule}")
	////@Trace(dispatcher = true, metricName = "pollCsvProcessorsCollectionForCleanup")
	public void pollCsvProcessorsCollectionForCleanup() {
        if(Boolean.parseBoolean(pollSchedulersEnabled)) {
            pollCsvProcessorsForCleanup();
        }
	}
    
    public void pollCsvProcessorsForCleanup() {
        Date now = new Date();
        String dateFormatString = dateFormat.format(now);
        log.info("Poll Processor Transactions for Cleanup");
        log.info("The time is now {}", dateFormatString);
        List<String> metaDataStatusList = new ArrayList<String>();
        metaDataStatusList.add(MetaDataStatus.IN_PROCESS.toString());
        metaDataStatusList.add(MetaDataStatus.FATAL_ERROR.toString());
        
        int csvProcessorTransactionSearchTimeWindow = 0; //TODO
        ////int csvProcessorTransactionSearchTimeWindow = Integer.parseInt(Optional.ofNullable(getProperty(Workflow.POLL_CSV_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP))
                ////.orElse(Workflow.POLL_CSV_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP_VALUE));

                // get all csvProcesssorTransaction that are IN_PROCESS
                List<CsvProcessorTransaction> csvProcessorTransactions = csvProcessorsService.getAllCsvProcessorsTransactions(Arrays.asList(MetaDataStatus.IN_PROCESS.toString()), csvProcessorTransactionSearchTimeWindow);

        for (CsvProcessorTransaction csvProcessorTransaction : csvProcessorTransactions) {
            try {
                createCsvCleanupJobIfRequired(csvProcessorTransaction.getAppIdentifier(), csvProcessorTransaction.getId(),csvProcessorTransaction);
            } catch (Exception e) {
                log.error("Error in createCleanupJobIfRequired for: {} and Error: {}", csvProcessorTransaction.getId(), e.getMessage());
                
            }
        }
    }

	private void createCsvCleanupJobIfRequired(String appIdentifier,  String processorTransactionId,CsvProcessorTransaction csvProcessorTransaction) {
		
		
		 boolean jobExists = processorsService.findProcessorJobByTransactionIdFromQueue(processorTransactionId);
		 
			if (!jobExists) {
				boolean jobAllComplete = csvProcessorsService.isAllCsvProcessorRowTasksProcessed(csvProcessorTransaction);
				if (jobAllComplete) {
					if (MetaDataStatus.IN_PROCESS.equals(csvProcessorTransaction.getStatus())) {
						csvProcessorTransaction.setReadyStatus();
						csvProcessorsService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
						ProcessorMetaData processor = processorsService.findProcessorMetaDataById(csvProcessorTransaction.getProcessorId(), csvProcessorTransaction.getAppIdentifier());
						csvProcessorsService.createCsvProcessorJobEntry(processor, csvProcessorTransaction, JOB_TYPE, WRK_FLOW);
						log.info("Created cleanup job for {}", csvProcessorTransaction.getId());
					}
				}
			}
		
	}
	
	public void createCsvCleanupJobIfRequired(CsvProcessorTransaction csvProcessorTransaction) {
		
		
		 ////boolean jobExists = processorsService.findProcessorJobByTransactionIdFromQueue(processorTransactionId);
		 
			////if (!jobExists) {
				boolean jobAllComplete = csvProcessorsService.isAllCsvProcessorRowTasksProcessed(csvProcessorTransaction);
				if (jobAllComplete) {
					if (MetaDataStatus.IN_PROCESS.equals(csvProcessorTransaction.getStatus())) {
						csvProcessorTransaction.setReadyStatus();
						csvProcessorsService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
						ProcessorMetaData processor = processorsService.findProcessorMetaDataById(csvProcessorTransaction.getProcessorId(), csvProcessorTransaction.getAppIdentifier());
						csvProcessorsService.createCsvProcessorJobEntry(processor, csvProcessorTransaction, JOB_TYPE, WRK_FLOW);
						log.info("Created cleanup job for {}", csvProcessorTransaction.getId());
					}
				} else {
					log.info("NOT Created cleanup job for {}", csvProcessorTransaction.getId());
				}
			////}
		
	}
}
