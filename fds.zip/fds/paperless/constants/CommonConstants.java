package com.optum.fds.paperless.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommonConstants {
	public static final String SPRING_PROFILES_ACTIVE = "spring.profiles.active";
	
	public static final List<String> DEFAULT_SUBCATEGORY_LIST = new ArrayList<String>(Arrays.asList("CC", "PR", "RR", "OP", "XX", "ZZ"));

	public static final String SOMETHING_WENT_WRONG = "SOMETHING WENT WRONG ERROR={}";

	public static final String FDS_RETRY_COUNT_MAX = "FDSRetryCountMax";
	public static final String FDS_RETRY_SLEEP_TIME_MS = "FDSRetrySleepTimeMS";
	public static final String FDS_DOCUMENTS_URL = "FDSDocumentsUrl";
	public static final String FDS_POST_PDO_DOCUMENTS_URL = "FDSPostPDODocumentsUrl";
	public static final String FDS_RETENTION_PERIOD = "FDSRetentionPeriod";

	public static final String FS2_DOCUMENTS_BODY_NAME = "documents";

	public static final String INGEST_ROOT = "INGEST_ROOT";
	public static final String CSV_JSON_FILENAME = "csv.json";

	public static final String QUEUED_ID = "id";
	public static final String QUEUED_PATH_VARIABLE = "pathVariable";
	public static final String QUEUED_API_URL = "apiUrl";
	public static final String QUEUED_DELEGATE = "delegate";
	public static final String QUEUED_DELEGATE_PARMS = "delegateParms";
	public static final String QUEUED_RETRY_CNT = "retryCount";
	public static final String QUEUED_REQUEST = "queuedRequest";
	public static final String QUEUED_HTTP_METHOD = "httpMethod";

	public static final String SEND_QUEUE_NEEDS_SPACE_ID = "SendQueueNeedsSpaceId";

	public static final String CSV_SEND_QUEUE_AUTO_ERROR = "CsvSendQueueAutoError";
	public static final String HOOK_SEND_QUEUE_AUTO_ERROR = "HookSendQueueAutoError";
	public static final String METADATA_SEND_QUEUE_AUTO_ERROR = "MetadataSendQueueAutoError";

	public static final String FTP_ROOT_DIR = "ftp_rootdir";

	public static final String EMAIL_ALERT_REQ = "emailAlertReq";

	// email properties
	public static final String ELR_SMTP_RELAY_HOST = "ELR_SMTP_RELAY_HOST";
	public static final String SERVER_TYPE = "serverType";

	public static final String ENGINE_PORT_DEFAULT = "8081";
	public static final String AZURE_WITH_IDENTIFIERS_URL = "AzureWithIdentifiersUrl";
	public static final String AZURE_URL = "AzureUrl";
	public static final String AZURE_SCHEDULE_URL = "AzureScheduleUrl";
	public static final String AZURE_DLQ_URL = "AzureDlqUrl";
	public static final String ENGINE_DELIGATE_URL = "EngineDelegateUrl";
	public static final String HIGH_QUEUE = "HighPriorityQueue";
	public static final String MEDIUM_QUEUE = "MediumPriorityQueue";
	public static final String LOW_QUEUE = "LowPriorityQueue";


	private CommonConstants(){throw new AssertionError();}

}
