package com.optum.fds.paperless.client;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoField;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Date;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;


/**
 * The CustomDateDeserializer class is used to convert the client metadata createdDate
 * from this format: MM/dd/yyyy hh:mm:ss
 * to this format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'
 * @author jwang39
 *
 */
public class CustomDateDeserializer extends StdDeserializer<Date> {

	private static final long serialVersionUID = -1026166191652831116L;

	private static final Logger LOGGER = LogManager.getLogger(CustomDateDeserializer.class);

	// 12/31/2021 5:45:22 PM

	private DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder()
            .appendPattern("[MM/dd/yyyy H:mm:ss]")
            .appendPattern("[MMddyyyy]")
            .appendPattern("[MM/dd/yyyy]")
            .appendPattern("[MM/dd/yy]")
            .appendPattern("[M/dd/yyyy]")
            .appendPattern("[MM-dd-yyyy]")
            .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
            .parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
            .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
            .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
            .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00)
            .parseDefaulting(ChronoField.MILLI_OF_SECOND, 000)
            .toFormatter()
            .withLocale(Locale.US)
            .withZone(ZoneId.of("UTC"));

	private DateTimeFormatter dateTimeFormatter1 = new DateTimeFormatterBuilder()
            .appendPattern("[MM/dd/yyy hh:mm:ss a]")
            .appendPattern("[MM/dd/yyyy h:mm:ss a]")
            .appendPattern("[MM/d/yyyy h:mm:ss a]")
            .appendPattern("[M/dd/yyyy h:mm:ss a]")
            .appendPattern("[M/d/yyyy h:mm:ss a]")
            .appendPattern("[d/MM/yyyy h:mm:ss a]")
            .appendPattern("[dd/M/yyyy h:mm:ss a]")
            .appendPattern("[dd/MM/yyyy h:mm:ss a]")
            .appendPattern("[d/M/yyyy h:mm:ss a]")
            .appendPattern("[dd/MM/yyyy HH:mm:ss]")
            .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
            .parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
            .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
            .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00)
            .parseDefaulting(ChronoField.MILLI_OF_SECOND, 000)
            .toFormatter()
            .withLocale(Locale.US)
            .withZone(ZoneId.of("UTC"));

	private DateTimeFormatter dateTimeFormatter2 = new DateTimeFormatterBuilder()
            .appendPattern("[yyyy-MM-dd HH:mm:ss.SSS]")
            .appendPattern("[MM-dd-yyyy HH:mm:ss]")
            .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
            .parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
            .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
            .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00)
            .toFormatter()
            .withLocale(Locale.US)
            .withZone(ZoneId.of("UTC"));

    private DateTimeFormatter dateFormatter3 = DateTimeFormatter.ofPattern("MMMM dd, yyyy", Locale.US);

    private DateTimeFormatter dateFormatter4 = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.US);

    private DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("[yyyy-MM-dd'T'HH:mm:ss.SSS'Z']");

    private static final ThreadLocal<SimpleDateFormat> formatter = ThreadLocal.withInitial(() -> new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

	public CustomDateDeserializer() {
        this(null);
    }

    public CustomDateDeserializer(Class<?> vc) {
        super(vc);
    }

	@Override
    public Date deserialize(JsonParser jsonparser, DeserializationContext context) throws IOException, JsonProcessingException {
        ZonedDateTime zdt;
        String convertedDate;
        String date = jsonparser.getText();
        try {
            if (date == null || date.isEmpty()) {
                return null;
            }
            zdt = ZonedDateTime.parse(date, dateTimeFormatter);
            convertedDate = zdt.format(outputFormat);
            LOGGER.debug("convertedDate={}", convertedDate);
            return formatter.get().parse(convertedDate);
        } catch (Exception e1) {
            LOGGER.debug("Failed dateTimeFormatter: date={}; e={}", date, e1.getMessage());
            try {
                zdt = ZonedDateTime.parse(date, dateTimeFormatter1);
                convertedDate = zdt.format(outputFormat);
                LOGGER.debug("convertedDate={}", convertedDate);
                return formatter.get().parse(convertedDate);
            } catch (Exception e2) {
                LOGGER.debug("Failed dateTimeFormatter1: date={}; e={}", date, e1.getMessage());
                try {
                    zdt = ZonedDateTime.parse(date, dateTimeFormatter2);
                    convertedDate = zdt.format(outputFormat);
                    LOGGER.debug("convertedDate={}", convertedDate);
                    return formatter.get().parse(convertedDate);
                } catch (Exception e3) {
                    LOGGER.debug("Failed dateTimeFormatter2: date={}; e={}", date, e3.getMessage());
                    try {
                        LocalDate ld = LocalDate.parse(date, dateFormatter3);
                        zdt = ld.atStartOfDay(ZoneId.of("UTC"));
                        convertedDate = zdt.format(outputFormat);
                        LOGGER.debug("convertedDate={}", convertedDate);
                        return formatter.get().parse(convertedDate);
                    } catch (Exception e4) {
                        LOGGER.debug("Failed dateFormatter: date={}; e={}", date, e4.getMessage());
                        try{
                            LocalDate ld = LocalDate.parse(date, dateFormatter4);
                            zdt = ld.atStartOfDay(ZoneId.of("UTC"));
                            convertedDate = zdt.format(outputFormat);
                            LOGGER.debug("convertedDate={}", convertedDate);
                            return formatter.get().parse(convertedDate);
                        } catch (Exception e5) {
                            LOGGER.error("Failed dateFormatter5: date={}; e={}", date, e4.getMessage());
                            return null;
                        }
                    }
                }
            }
        }
    }

}
