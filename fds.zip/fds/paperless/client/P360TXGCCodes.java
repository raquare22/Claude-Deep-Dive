package com.optum.fds.paperless.client;

import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class P360TXGCCodes {

    private String procCodes;

    private String procCodesDescription;

    private String approvalRate;

    private String nbrOfCodes;

    public String getProcCodes() {
        return procCodes;
    }
    public void setprocCodes(String procCodes) {
        this.procCodes = procCodes;
    }
    public String getProcCodesDescription() {
        return procCodesDescription;
    }
    public void setProcCodesDescription(String procCodesDescription) {
        this.procCodesDescription = procCodesDescription;
    }
    public String getApprovalRate() {
        return approvalRate;
    }
    public void setApprovalRate(String approvalRate) {
        this.approvalRate = approvalRate;
    }
    public String getNbrOfCodes() {
        return nbrOfCodes;
    }
    public void setNbrOfCodes(String nbrOfCodes) {
        this.nbrOfCodes = nbrOfCodes;
    }

}
