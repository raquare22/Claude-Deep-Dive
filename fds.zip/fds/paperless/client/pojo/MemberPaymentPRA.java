package com.optum.fds.paperless.client.pojo;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;


public class MemberPaymentPRA extends ClientMetadata {

    private static final long serialVersionUID = -1234567890123456789L;


    @JsonProperty("subCategory")
    @JsonAlias("SubCategory")
    private String subCategory;

    @JsonProperty("mpin")
    @JsonAlias("ProviderMPIN")
    private String mpin;

    @JsonProperty("emailAlertReq")
    @JsonAlias("isPrintSuppressed")
    private String emailAlertReq = "Y";

    @JsonProperty("PassThruData")
    private String PassThruData;

    @JsonProperty("originalPrintTrail")
    private String originalPrintTrail;

    @JsonProperty("CONFIGKEY")
    private String CONFIGKEY;

    @JsonProperty("MailToAddress1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    private String MailToAddress6;

    @JsonProperty("CheckAmt")
    private String CheckAmt;

    @JsonProperty("CheckTraceNumber")
    @JsonAlias("CHECKNUMBER")
    private String CheckTraceNumber;

    @JsonProperty("ClaimNumber")
    @JsonAlias("CLAIMNUMBER")
    private String ClaimNumber;

    @JsonProperty("memberID")
    @JsonAlias("MemberId")
    private String memberId;

    @JsonProperty("memberName")
    private String memberName;

    @JsonProperty("NPI")
    @JsonAlias("BillingNPI")
    private String npi;

    @JsonProperty("patientAccountNumber")
    private String patientAccountNumber;

    @JsonProperty("physicianName")
    @JsonAlias("PHYSICIANNAME")
    private String physicianName;

    @JsonProperty("tin")
    @JsonAlias("TIN")
    private String tin;

    public MemberPaymentPRA() {
        this.category = "Payment from Members";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Payment from Members";
        this.createApplication = "Payment Engine";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "MM";
    }

    public String getSubCategory() {
        return subCategory;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        this.emailAlertReq = emailAlertReq;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String PassThruData) {
        this.PassThruData = PassThruData;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String MailToAddress1) {
        this.MailToAddress1 = MailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String MailToAddress2) {
        this.MailToAddress2 = MailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String MailToAddress3) {
        this.MailToAddress3 = MailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String MailToAddress4) {
        this.MailToAddress4 = MailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String MailToAddress5) {
        this.MailToAddress5 = MailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String MailToAddress6) {
        this.MailToAddress6 = MailToAddress6;
    }

    public String getCheckAmt() {
        return CheckAmt;
    }

    public void setCheckAmt(String CheckAmt) {
        this.CheckAmt = CheckAmt;
    }

    public String getCheckTraceNumber() {
        return CheckTraceNumber;
    }

    public void setCheckTraceNumber(String CheckTraceNumber) {
        this.CheckTraceNumber = CheckTraceNumber;
    }

    public String getClaimNumber() {
        return ClaimNumber;
    }

    public void setClaimNumber(String ClaimNumber) {
        this.ClaimNumber = ClaimNumber;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getNPI() {
        return npi;
    }

    public void setNPI(String NPI) {
        this.npi = NPI;
    }

    public String getPatientAccountNumber() {
        return patientAccountNumber;
    }

    public void setPatientAccountNumber(String patientAccountNumber) {
        this.patientAccountNumber = patientAccountNumber;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "MM";
            this.setFilePath(MemberPaymentPRA.Subcategory.MM.getFilePath());
        } else {
            this.subCategory = subCategory;
            MemberPaymentPRA.Subcategory subCat = null;
            try {
                subCat = MemberPaymentPRA.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = MemberPaymentPRA.Subcategory.MM;
            }
            this.setFilePath(subCat.getFilePath());
        }

        if(this.getExpiryDate() != null && this.getExpiryDate().length() == 7){
            this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));}
    }

    public enum ErrorMsg implements ErrorMessage {
        SubCategory (12, "Missing or invalid data: LETTERTYPE"),
        ProviderMPIN(12, "Missing or invalid data: ProviderMPIN"),
        isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
        CheckAmt(12, "Missing or invalid data: Claim Amount"),
        CHECKNUMBER (12, "Missing or invalid data: Check Trace Number"),
        ClaimNumber (12, "Missing or invalid data: Claim Number"),
        CHECKDATE (12, "Missing or invalid data: PROCESSDATE"),
        TIN (12, "Missing or invalid data: Provider TIN"),

        PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"),
        originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"),
        CONFIGKEY (22, "Missing or invalid data: ConfigKey(SEVERE)"),
        MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"),
        MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"),
        MailToAddress3 (22, "Missing or invalid data: MailToAddress3(SEVERE)");

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {
        M1("M1", "Commercial/Direct Deposit Remittance Documents"),
        M2("M2", "Commercial/Virtual Card Payment Remittance Documents"),
        M3("M3", "Medicare/Direct Deposit Remittance Documents"),
        M4("M4", "Medicare/Virtual Card Payment Remittance Documents"),
        M5("M5", "UHC West/Direct Deposit Remittance Documents"),
        M6("M6", "Community Plan/Direct Deposit Remittance Documents"),
        M7("M7", "Community Plan/Virtual Card Payments Remittance Documents"),
        MM("MM", "Other Payments from Members/Other");

        private final String subCat;
        private final String filePath;

        Subcategory(String subCat, String filePath) {
            this.subCat = subCat;
            this.filePath = filePath;
        }

        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }

        public static Subcategory fromSubCat(String subCat) {
            for (Subcategory subcategory : values()) {
                if (subcategory.subCat.equalsIgnoreCase(subCat)) {
                    return subcategory;
                }
            }
            return MM;
        }
    }
}