package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.CustomizeDateDeserializer;
import com.optum.fds.paperless.client.ErrorMessage;
import org.apache.commons.lang.StringUtils;

import java.util.Date;

public class TXGC extends ClientMetadata {

    private static final long serialVersionUID = 1L;

    @JsonProperty("u_tmplt_nm")
    @JsonAlias("templateName")
    private String templateName;
    
    @JsonAlias("subCategory")
    private String subCategory;

    @JsonProperty("u_tin")
    @JsonAlias("tin")
    private String tin;
    
    @JsonProperty("u_author")
    @JsonAlias("author")
    private String author;
    
    @JsonProperty("u_provider_npi")
    @JsonAlias("providerNpi")
    private String providerNpi;

    @JsonProperty("u_prov_grp_nm")
    @JsonAlias("providerGroupName")
    private String providerGroupName;

    @JsonProperty("isPrintSuppressed")
    @JsonAlias("emailAlertReq")
    private String emailAlertReq="N";

    @JsonProperty("u_sub_nm")
    @JsonAlias("providerName")
    private String providerName;
    

    @JsonProperty("u_mpin")
    @JsonAlias("mpin")
    private String mpin="";


    @JsonProperty("u_tracking_nbr")
    @JsonAlias("txgcUniqueId")
    private String txgcUniqueId;

    @JsonProperty("object_name")
    private String PassThruData;
    
    @JsonProperty("u_st")
    @JsonAlias("providerSt")
    private String providerState;


    public TXGC(){

    	
        this.fileType = "Letter";
        this.tenant = "Link";
        this.createApplication = "TXGC";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Notification/Prior Authorization Status Inquiry/Update";
        this.category= "TX Gold Card";
        this.subCategory = "NN";
        TXGC.Subcategory subCat = TXGC.Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }
    
    public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
		
		String subCategory = "";
		if (templateName.equals("TXGC001")) {
    		subCategory = "N4";
    	} else if (templateName.equals("TXGC002")) {
    		subCategory = "N5";
    	}
		
		setSubCategory(subCategory);
	}

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
    	// TXGC001 and TXGC002 for N4 and N5

        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "NN";
            this.setFilePath(TXGC.Subcategory.NN.getFilePath());
        } else {
            this.subCategory = subCategory;
            TXGC.Subcategory subCat = null;
            try {
                subCat = TXGC.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = TXGC.Subcategory.NN;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getTin() {
        return tin;
    }


    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }


    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null && !mpin.isEmpty()) {
            String paddedMpin = StringUtils.leftPad(mpin, 9, '0');
            this.mpin = paddedMpin;
        }
    }
    
    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getProviderNpi() {
		return providerNpi;
	}

	public void setProviderNpi(String providerNpi) {
		this.providerNpi = providerNpi;
	}

	public String getProviderGroupName() {
		return providerGroupName;
	}

	public void setProviderGroupName(String providerGroupName) {
		this.providerGroupName = providerGroupName;
	}

	public String getTxgcUniqueId() {
		return txgcUniqueId;
	}

	public void setTxgcUniqueId(String txgcUniqueId) {
		this.txgcUniqueId = txgcUniqueId;
	}

	public String getProviderState() {
		return providerState;
	}

	public void setProviderState(String providerState) {
		this.providerState = providerState;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}



	public enum ErrorMsg implements ErrorMessage {
    	u_tin (12, "Missing or invalid data: u_tin"),
    	u_tmplt_nm (12, "Missing or invalid data: u_tmplt_nm"),
    	isPrintSuppressed (12, "Missing or invalid data: isPrintSuppressed");


        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {

        // TXGC (ELGS)
        N4 ("N4", "Texas Gold Card/Approved"),
        N5 ("N5", "Texas Gold Card/Denied"),
        NN ("NN", "Texas Gold Card/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;

        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }

    }
}
