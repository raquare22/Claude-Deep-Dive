package com.optum.fds.paperless.client.pojo;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class UHCWest extends ClientMetadata {
	
	private static final long serialVersionUID = 7172914485321420066L;
	
	@JsonProperty("tin")
	private String tin;
	
	@JsonProperty("mpin")
	private String mpin="";
	
	@JsonProperty("emailAlertReq")
	@JsonAlias("isPrintSuppressed")
	private String emailAlertReq="N";
	
	@JsonProperty("EFT_Ind")
	private String EFT_Ind;
	
	@JsonProperty("physicianName")
	@JsonAlias("ProviderName")
	private String physicianName;
	
	@JsonProperty("CheckTraceNumber")
	private String CheckTraceNumber;
	
	@JsonProperty("DefaultUsed")
	private String DefaultUsed;
	
	@JsonAlias("CheckAmt")
	@JsonProperty("CheckAmount")
	private String CheckAmt;
	
	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;

	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;
	
	@JsonProperty("PassThruData")
	private String PassThruData;
	
	@JsonProperty("MailToAddress1") 
	private String MailToAddress1;
	
	@JsonProperty("MailToAddress2") 
	private String MailToAddress2;
	
	@JsonProperty("MailToAddress3") 
	private String MailToAddress3;
	
	@JsonProperty("MailToAddress4") 
	private String MailToAddress4;
	
	@JsonProperty("MailToAddress5") 
	private String MailToAddress5;
	
	@JsonProperty("MailToAddress6") 
	private String MailToAddress6;
	
	@JsonProperty("subCategory")
	protected String subCategory;
	
	@JsonProperty("paymentNumber")
	@JsonAlias("vendor_pay_id")
	private String paymentNumber;
	
	public UHCWest() {
		this.category = "Payment Document";
		this.fileType = "Letter";
		this.tenant = "Link";
		this.fileDescription = "Payment Package";
		this.createApplication = "PmntEng";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = "Claim Status";
		this.subCategory = "P5";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null){
			this.mpin = mpin;
		}
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getEFT_Ind() {
		return EFT_Ind;
	}

	public void setEFT_Ind(String eFT_Ind) {
		EFT_Ind = eFT_Ind;
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getCheckTraceNumber() {
		return CheckTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		CheckTraceNumber = checkTraceNumber;
	}

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getCheckAmt() {
		return CheckAmt;
	}

	public void setCheckAmt(String checkAmt) {
		CheckAmt = checkAmt;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String cONFIGKEY) {
		CONFIGKEY = cONFIGKEY;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}
	
	public String getSubCategory() {
		return subCategory;
	}
	
	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "PR";
			this.setFilePath(Subcategory.PR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.PR;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}
	
	public String getPaymentNumber() {
		return paymentNumber;
	}
	
	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}
	
	public enum ErrorMsg implements ErrorMessage {
		tin (22, "Missing or invalid data: tin(SEVERE)"), //"EFT_Ind==\"Y\" && emailAlertReq!=\"N\"" - verify
		mpin (22, "Missing or invalid data: mpin(SEVERE)"), //"emailAlertReq!=\"N\"" - verify
		subCategory (12, "Missing or invalid data: subCategory"),
		isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),//verify
		createdDate (12, "Missing or invalid data: createdDate"),
		
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), //"emailAlertReq!=\"N\""
		originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), //"emailAlertReq!=\"N\"" //verify
		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), //"emailAlertReq!=\"N\""

		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), //"emailAlertReq!=\"N\""

		CheckTraceNumber (12, "Missing or invalid data: CheckTraceNumber"), //verify
		EFT_Ind (22, "Missing or invalid data: EFT_Ind(SEVERE)");
		
		
		private int errorCode;
	    private String errorMessage;

	    ErrorMsg(int code, String message) {
	        this.errorCode = code;
	        this.errorMessage = message;
	    }

	    public int getErrorCode() {
	        return errorCode;
	    }
	    public String getErrorMessage() {
	        return errorMessage;
	    }

	}
	
	public enum Subcategory {
		
		P5 ("P5", "UHC West Payment Packages/Detailed Pmt Docs"),
		PR ("PR", "Other PRAs/Other");
		
		private String subCat;
		private String filePath;
		
		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
	        return subCat;
	    }
		
		public String getFilePath() {
			return filePath;
		}
	}
	
	
}

