package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.CustomDateDeserializer;
import com.optum.fds.paperless.client.CustomDateSerializer;
import com.optum.fds.paperless.client.CustomizeDateDeserializer;
import com.optum.fds.paperless.client.ErrorMessage;

import java.util.Date;

public class PriorAuthNextGen extends ClientMetadata {

	private static final long serialVersionUID = -8112581189246463961L;

	@JsonProperty("NotificationNumber")
	@JsonAlias("notificationNumber")
	private String notificationNumber;

	@JsonProperty("LetterCategory")
	@JsonAlias("subCategory")
	private String subCategory;

	@JsonProperty("ProviderTaxID")
	@JsonAlias("tin")
	private String tin;

	@JsonProperty("ProviderMPIN")
	@JsonAlias("mpin")
	private String mpin="";

	@JsonProperty("ProviderName")
	@JsonAlias("providerName")
	private String providerName;

	@JsonProperty("MemberID")
	@JsonAlias("memberId")
	private String memberId;

	@JsonProperty("MemberName")
	@JsonAlias("memberName")
	private String memberName;

	@JsonProperty("GroupNumber")
	@JsonAlias("policyNumber")
	private String policyNumber;

	@JsonProperty("ServiceStartDate")
	@JsonAlias("dateOfService")
	@JsonDeserialize(using = CustomizeDateDeserializer.class)
	@CustomDateFormat(dateFormat = "MM/dd/yyyy")
	private Date dateOfService;

	@JsonProperty("IsPrintSuppressed")
	@JsonAlias("emailAlertReq")
	private String emailAlertReq="Y";

	@JsonProperty("LetterHistoryID")
	private String LetterHistoryID;

	@JsonProperty("PassThruData")
	private String PassThruData;

	@JsonProperty("OriginPrintTrail")
	@JsonAlias("originalPrintTrail")
	private String originalPrintTrail;

	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;

	@JsonProperty("DMSecurityClass")
	private String DMSecurityClass;

	@JsonProperty("RelatedID")
	private String RelatedID;

	@JsonProperty("MemberAltID")
	private String MemberAltID;

	@JsonProperty("ELGSLETTERGENID")
	private String ELGSLETTERGENID;

	@JsonProperty("ProviderDEC")
	private String ProviderDEC;

	@JsonProperty("NotificationLetterID")
	private String NotificationLetterID;

	@JsonProperty("ELGSREQUESTID")
	private String ELGSREQUESTID;

	@JsonProperty("GenerationType")
	private String GenerationType;

	@JsonProperty("WORKGROUP_NME")
	private String WORKGROUP_NME;

	@JsonProperty("LetterPriority")
	private String LetterPriority;

	@JsonProperty("LegacyEntity")
	private String LegacyEntity;

	@JsonProperty("BusinessSegment")
	private String BusinessSegment;

	@JsonProperty("DefaultUsed")
	private String DefaultUsed;

	@JsonProperty("HHKey")
	private String HHKey;

	@JsonProperty("DUPLEXSIMPLEX")
	private String DUPLEXSIMPLEX;

	@JsonProperty("RequesterID")
	private String RequesterID;

	@JsonProperty("MailToAddress1")
	private String MailToAddress1;

	@JsonProperty("MailToAddress2")
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
	private String MailToAddress3;

	@JsonProperty("MailToAddress4")
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
	private String MailToAddress6;

	public PriorAuthNextGen(){
		this.category = "Prior Auth Notification";
		this.fileType = "Letter";
		this.tenant = "Link";
		this.createApplication = "NextGen";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = "Notification/Prior Authorization Status Inquiry/Update";
		this.subCategory = "ZZ";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getNotificationNumber() {
		return notificationNumber;
	}

	public void setNotificationNumber(String notificationNumber) {
		this.notificationNumber = notificationNumber;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "ZZ";
			this.setFilePath(Subcategory.ZZ.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.ZZ;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null){
			this.mpin = mpin;
		}
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getLetterHistoryID() {
		return LetterHistoryID;
	}

	public void setLetterHistoryID(String letterHistoryID) {
		LetterHistoryID = letterHistoryID;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String CONFIGKEY) {
		this.CONFIGKEY = CONFIGKEY;
	}

	public String getDMSecurityClass() {
		return DMSecurityClass;
	}

	public void setDMSecurityClass(String DMSecurityClass) {
		this.DMSecurityClass = DMSecurityClass;
	}

	public String getRelatedID() {
		return RelatedID;
	}

	public void setRelatedID(String relatedID) {
		RelatedID = relatedID;
	}

	public String getMemberAltID() {
		return MemberAltID;
	}

	public void setMemberAltID(String memberAltID) {
		MemberAltID = memberAltID;
	}

	public String getELGSLETTERGENID() {
		return ELGSLETTERGENID;
	}

	public void setELGSLETTERGENID(String ELGSLETTERGENID) {
		this.ELGSLETTERGENID = ELGSLETTERGENID;
	}

	public String getProviderDEC() {
		return ProviderDEC;
	}

	public void setProviderDEC(String providerDEC) {
		ProviderDEC = providerDEC;
	}

	public String getNotificationLetterID() {
		return NotificationLetterID;
	}

	public void setNotificationLetterID(String notificationLetterID) {
		NotificationLetterID = notificationLetterID;
	}

	public String getELGSREQUESTID() {
		return ELGSREQUESTID;
	}

	public void setELGSREQUESTID(String ELGSREQUESTID) {
		this.ELGSREQUESTID = ELGSREQUESTID;
	}

	public String getGenerationType() {
		return GenerationType;
	}

	public void setGenerationType(String generationType) {
		GenerationType = generationType;
	}

	public String getWORKGROUP_NME() {
		return WORKGROUP_NME;
	}

	public void setWORKGROUP_NME(String WORKGROUP_NME) {
		this.WORKGROUP_NME = WORKGROUP_NME;
	}

	public String getLetterPriority() {
		return LetterPriority;
	}

	public void setLetterPriority(String letterPriority) {
		LetterPriority = letterPriority;
	}

	public String getLegacyEntity() {
		return LegacyEntity;
	}

	public void setLegacyEntity(String legacyEntity) {
		LegacyEntity = legacyEntity;
	}

	public String getBusinessSegment() {
		return BusinessSegment;
	}

	public void setBusinessSegment(String businessSegment) {
		BusinessSegment = businessSegment;
	}

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getHHKey() {
		return HHKey;
	}

	public void setHHKey(String HHKey) {
		this.HHKey = HHKey;
	}

	public String getDUPLEXSIMPLEX() {
		return DUPLEXSIMPLEX;
	}

	public void setDUPLEXSIMPLEX(String DUPLEXSIMPLEX) {
		this.DUPLEXSIMPLEX = DUPLEXSIMPLEX;
	}

	public String getRequesterID() {
		return RequesterID;
	}

	public void setRequesterID(String requesterID) {
		RequesterID = requesterID;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public enum ErrorMsg implements ErrorMessage {
		LetterGenerationDate (12, "Missing or invalid data: LetterGenerationDate"),
		NotificationNumber (12, "Missing or invalid data: NotificationNumber"),
		LetterCategory (12, "Missing or invalid data: LetterCategory"),
		ProviderTaxID (12,"Missing or invalid data: ProviderTaxID"),
		ProviderMPIN (12, "Missing or invalid data: ProviderMPIN"), //"emailAlertReq!=\"N\""
		IsPrintSuppressed (12, "Missing or invalid data: IsPrintSuppressed"),

		LetterHistoryID (22, "Missing or invalid data: LetterHistoryID(SEVERE)"), //"emailAlertReq!=\"N\""
		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), //"emailAlertReq!=\"N\""
		OriginPrintTrail (22, "Missing or invalid data: OriginPrintTrail(SEVERE)"), //"emailAlertReq!=\"N\""
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress5 (22, "Missing or invalid data: MailToAddress5(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress6 (22, "Missing or invalid data: MailToAddress6(SEVERE)"); //"emailAlertReq!=\"N\""

		private int errorCode;
		private String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		public int getErrorCode() {
			return errorCode;
		}
		public String getErrorMessage() {
			return errorMessage;
		}

	}

	public enum Subcategory {

		// PriorAuthNextGen
		A1 ("A1", "Commercial Prior Auth/Approved"),
		A2 ("A2", "Commercial Prior Auth/Denied"),
		A3 ("A3", "Commercial Prior Auth/Lack of Information"),
		A4 ("A4", "Medicare Prior Auth/Approved"),
		A5 ("A5", "Medicare Prior Auth/Denied"),
		A6 ("A6", "Medicare Prior Auth/Lack of Information"),
		A7 ("A7", "UHC West Prior Auth/Approved"),
		A8 ("A8", "UHC West Prior Auth/Denied"),
		A9 ("A9", "UHC West Prior Auth/Lack of Information"),
		N1 ("N1", "Community Plan Prior Auth/Approved"),
		N2 ("N2", "Community Plan Prior Auth/Denied"),
		N3 ("N3", "Community Plan Prior Auth/Lack of Information"),
		ZZ ("ZZ", "Misc. Prior Auth/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
	}
}