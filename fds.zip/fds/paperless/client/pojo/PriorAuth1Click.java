package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.CustomizeDateDeserializer;
import com.optum.fds.paperless.client.ErrorMessage;
import org.apache.commons.lang.StringUtils;

import java.util.Date;

public class PriorAuth1Click extends ClientMetadata {

	private static final long serialVersionUID = -5285158878445419619L;

	@JsonProperty("LetterCategory")
	@JsonAlias("subCategory")
	private String subCategory;

	@JsonProperty("ProviderTaxID")
	@JsonAlias("tin")
	private String tin;

	@JsonProperty("ProviderMPIN")
	@JsonAlias("mpin")
	private String mpin="";

	@JsonProperty("IsPrintSuppressed")
	@JsonAlias("emailAlertReq")
	private String emailAlertReq="Y";

	@JsonProperty("ServiceStartDate")
	@JsonAlias("dateOfService")
	@JsonDeserialize(using = CustomizeDateDeserializer.class)
	@CustomDateFormat(dateFormat = "MM/dd/yyyy") // 6/14/2018
	private Date dateOfService;

	@JsonProperty("RELATEDID")
	private String RELATEDID;

	@JsonProperty("NotificationNumber")
	@JsonAlias("notificationNumber")
	private String notificationNumber;

	@JsonProperty("MemberID")
	@JsonAlias("memberId")
	private String memberId;

	@JsonProperty("ProviderFirstName")
	private String providerFirstName;

	@JsonProperty("ProviderLastName")
	private String providerLastName;

	@JsonProperty("providerName")
	private String providerName;

	@JsonProperty("physicianName")
	private String physicianName;

	@JsonProperty("MemberFirstName")
	private String memberFirstName;

	@JsonProperty("MemberLastName")
	private String memberLastName;

	@JsonProperty("memberName")
	private String memberName;

	@JsonProperty("MemberPolicyNbr")
	@JsonAlias("policyNumber")
	private String policyNumber;

	@JsonProperty("HISTORYID")
	@JsonAlias("LetterHistoryID")
	private String LetterHistoryID;

	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;

	@JsonProperty("PassThruData")
	private String PassThruData;

	@JsonProperty("OriginPrintTrail")
	@JsonAlias("originalPrintTrail")
	private String originalPrintTrail;

	@JsonProperty("MailToAddress1")
	private String MailToAddress1;

	@JsonProperty("MailToAddress2")
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
	private String MailToAddress3;

	@JsonProperty("MailToAddress4")
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
	private String MailToAddress6;

	public PriorAuth1Click(){
		this.category = "Prior Auth Notification";
		this.fileType = "Letter";
		this.tenant = "Link";
		this.createApplication = "1Click";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = "Notification/Prior Authorization Status Inquiry/Update";
		this.subCategory = "ZZ";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "ZZ";
			this.setFilePath(Subcategory.ZZ.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.ZZ;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null && !mpin.isEmpty()) {
			String paddedMpin = StringUtils.leftPad(mpin, 9, '0');
			this.mpin = paddedMpin;
		}
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getRELATEDID() {
		return RELATEDID;
	}

	public void setRELATEDID(String RELATEDID) {
		this.RELATEDID = RELATEDID;
	}

	public String getNotificationNumber() {
		return notificationNumber;
	}

	public void setNotificationNumber(String notificationNumber) {
		this.notificationNumber = notificationNumber;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;

		if (this.providerFirstName == null || this.providerFirstName.isEmpty()) {
			this.providerName = this.providerLastName;
			this.physicianName = this.providerLastName;
		} else {
			this.providerName = this.providerLastName + " " + this.providerFirstName;
			this.physicianName = this.providerName;
		}
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;

		if (this.memberFirstName == null) {
			this.memberFirstName = "";
		}
		if (this.memberLastName == null) {
			this.memberLastName = "";
		}
		this.memberName = this.memberLastName + " " + this.memberFirstName;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getLetterHistoryID() {
		return LetterHistoryID;
	}

	public void setLetterHistoryID(String letterHistoryID) {
		LetterHistoryID = letterHistoryID;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String CONFIGKEY) {
		this.CONFIGKEY = CONFIGKEY;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public enum ErrorMsg implements ErrorMessage {
		CREATEDATE (12, "Missing or invalid data: CREATEDATE"),
		LetterCategory (12, "Missing or invalid data: LetterCategory"),
		ProviderTaxID (12, "Missing or invalid data: ProviderTaxID"),
		ProviderMPIN (12,"Missing or invalid data: ProviderMPIN"), //"emailAlertReq!=\"N\""
		IsPrintSuppressed (12, "Missing or invalid data: IsPrintSuppressed"),
		ServiceStartDate (12, "Missing or invalid data: ServiceStartDate"),
		RELATEDID (12, "Missing or invalid data: RELATEDID"),
		NotificationNumber (12, "Missing or invalid data: NotificationNumber"),

		HISTORYID (22, "Missing or invalid data: HISTORYID(SEVERE)"), //"emailAlertReq!=\"N\""
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), //"emailAlertReq!=\"N\""
		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), //"emailAlertReq!=\"N\""
		OriginPrintTrail (22, "Missing or invalid data: OriginPrintTrail(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress5 (22, "Missing or invalid data: MailToAddress5(SEVERE)"), //"emailAlertReq!=\"N\""
		MailToAddress6 (22, "Missing or invalid data: MailToAddress6(SEVERE)"); //"emailAlertReq!=\"N\""

		private int errorCode;
		private String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		public int getErrorCode() {
			return errorCode;
		}
		public String getErrorMessage() {
			return errorMessage;
		}

	}

	public enum Subcategory {

		// PriorAuth1Click
		A1 ("A1", "Commercial Prior Auth/Approved"),
		A2 ("A2", "Commercial Prior Auth/Denied"),
		A3 ("A3", "Commercial Prior Auth/Lack of Information"),
		A4 ("A4", "Medicare Prior Auth/Approved"),
		A5 ("A5", "Medicare Prior Auth/Denied"),
		A6 ("A6", "Medicare Prior Auth/Lack of Information"),
		A7 ("A7", "UHC West Prior Auth/Approved"),
		A8 ("A8", "UHC West Prior Auth/Denied"),
		A9 ("A9", "UHC West Prior Auth/Lack of Information"),
		N1 ("N1", "Community Plan Prior Auth/Approved"),
		N2 ("N2", "Community Plan Prior Auth/Denied"),
		N3 ("N3", "Community Plan Prior Auth/Lack of Information"),
		ZZ ("ZZ", "Misc. Prior Auth/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
	}
}