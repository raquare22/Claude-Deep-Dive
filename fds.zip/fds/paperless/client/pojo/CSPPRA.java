package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class CSPPRA extends ClientMetadata {

	private static final long serialVersionUID = -5929915112417318793L;
	
	@JsonProperty("tin")
	private String tin;
	
	@JsonProperty("mpin")
	private String mpin="";
	
	@JsonProperty("emailAlertReq")
	@JsonAlias("isPrintSuppressed")
	private String emailAlertReq="Y";
	
	@JsonProperty("EFT_Ind")
	private String EFT_Ind;
	
	@JsonProperty("physicianName")
	private String physicianName;
	
	@JsonProperty("CheckTraceNumber")
	private String CheckTraceNumber;
	
	@JsonProperty("multClaimNumber")
	@JsonAlias("claimNumber")
	private String multClaimNumber;
	
	@JsonProperty("multMemberId")
	@JsonAlias("memberId")
	private String multMemberId;
	
	@JsonProperty("multSubscriberId")
	@JsonAlias("subscriberId")
	private String multSubscriberId;
	
	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;
	
	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;
	
	@JsonProperty("PassThruData")
	private String PassThruData;
	
	@JsonProperty("checkAmt")
	private String checkAmt;
	
	@JsonProperty("MailToAddress1") 
	private String MailToAddress1;
	
	@JsonProperty("MailToAddress2") 
	private String MailToAddress2;
	
	@JsonAlias("MailToAddress3")
	@JsonProperty("MailToAddress4") 
	private String MailToAddress3;
	
	@JsonAlias("MailToAddress4")
	@JsonProperty("MailToAddress3") 
	private String MailToAddress4;
	
	@JsonProperty("MailToAddress5") 
	private String MailToAddress5;
	
	@JsonProperty("MailToAddress6") 
	private String MailToAddress6;
	
	@JsonProperty("subCategory")
	protected String subCategory;
	
	@JsonProperty("835_Ind")
	private String Ind_835;
	
	@JsonProperty("paymentNumber")
	@JsonAlias("vendor_pay_id")
	private String paymentNumber;

	public CSPPRA() {
		this.category = "Payment Document";
		this.fileType = "Advice";
		this.tenant = "Link";
		this.fileDescription = "Payment Document";
		this.createApplication = "CSP-PRA";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = "Claim Status";
		this.subCategory = "PR";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}
	
	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null) {
			this.mpin = mpin;
		}
	}

	public String getCheckAmt() {
		return checkAmt;
	}

	public void setCheckAmt(String checkAmt) {
		this.checkAmt = checkAmt;
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}
	
	public String getInd_835() {
		return Ind_835;
	}

	public void setInd_835(String ind_835) {
		this.Ind_835 = ind_835;
	}

	public String getEFT_Ind() {
		return EFT_Ind;
	}

	public void setEFT_Ind(String eFT_Ind) {
		EFT_Ind = eFT_Ind;
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getCheckTraceNumber() {
		return CheckTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		CheckTraceNumber = checkTraceNumber;
	}

	public String getMultClaimNumber() {
		return multClaimNumber;
	}

	public void setMultClaimNumber(String multClaimNumber) {
		this.multClaimNumber = multClaimNumber;
	}

	public String getMultMemberId() {
		return multMemberId;
	}

	public void setMultMemberId(String multMemberId) {
		this.multMemberId = multMemberId;
	}

	public String getMultSubscriberId() {
		return multSubscriberId;
	}

	public void setMultSubscriberId(String multSubscriberId) {
		this.multSubscriberId = multSubscriberId;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String cONFIGKEY) {
		CONFIGKEY = cONFIGKEY;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public String getPrivilege() {
		return privilege;
	}

	public void setPrivilege(String privilege) {
		this.privilege = privilege;
	}
	
	public String getSubCategory() {
		return subCategory;
	}
	
	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "PR";
			this.setFilePath(Subcategory.PR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.PR;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}
	
	public String getPaymentNumber() {
		return paymentNumber;
	}
	
	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}
	
	@Override
	public void setExpiryDate(String expiryDate) {
		if (expiryDate != null && expiryDate.length() == 7 && this.subCategory != null) {
			this.expiryDate = this.vcpExpiryDateFormat(expiryDate, this.subCategory);
		} else {
            this.expiryDate = expiryDate;
		}
	}
	
	public enum ErrorMsg implements ErrorMessage {
		tin (22, "Missing or invalid data: tin(SEVERE)"), //"EFT_Ind==\"Y\" && emailAlertReq!=\"N\""
		mpin (22, "Missing or invalid data: mpin(SEVERE)"), //"emailAlertReq==\"Y\""
		subCategory (12, "Missing or invalid data: subCategory"),
		isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
		createdDate (12, "Missing or invalid data: createdDate"),
		
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), //"emailAlertReq==\"Y\""
		originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), //"emailAlertReq==\"Y\""
		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), //"emailAlertReq==\"Y\""

		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), //"emailAlertReq==\"Y\""
		MailToAddress3 (22, "Missing or invalid data: MailToAddress3(SEVERE)"), //"emailAlertReq==\"Y\""
		
		claimNumber (12, "Missing or invalid data: claimNumber");
		
		
		private int errorCode;
	    private String errorMessage;

	    ErrorMsg(int code, String message) {
	        this.errorCode = code;
	        this.errorMessage = message;
	    }

	    public int getErrorCode() {
	        return errorCode;
	    }
	    public String getErrorMessage() {
	        return errorMessage;
	    }

	}
	
	public enum Subcategory {
		
		P1 ("P1", "Commercial/Detailed PRAs"),
		P2 ("P2", "Commercial/Virtual Card Payments and Info Only PRAs"),
		P6 ("P6", "Community Plan/PRA"),
		P7 ("P7", "Community Plan/Virtual Card Payments"),
		P8 ("P8", "Commercial/Zero-Dollar PRAs"),
		P9 ("P9", "Medicare/Zero-Dollar PRAs"),
		P0 ("P0", "Community Plan/Zero-Dollar PRAs"),
		E1 ("E1", "Other/Zero-Dollar PRAs"),
		PR ("PR", "Other PRAs/Other");
		
		private String subCat;
		private String filePath;
		
		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
	        return subCat;
	    }
		
		public String getFilePath() {
			return filePath;
		}
	}
	
}

