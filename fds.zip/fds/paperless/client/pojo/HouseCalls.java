package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.*;

import java.io.Serial;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class HouseCalls extends ClientMetadata {

    @Serial
    private static final long serialVersionUID = 3951827406159372841L;

    @JsonProperty("subCategory")
    @JsonAlias("sub_Category")
    private String subCategory;

    @JsonProperty("tin")
    @JsonAlias("tin")
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("mpin")
    private String mpin;

    @JsonProperty("emailAlertReq")
    @JsonAlias("isPrintSuppressed")
    private String emailAlertReq;

    @JsonProperty("physicianName")
    @JsonAlias("PCP_Name")
    private String physicianName;

    @JsonProperty("memberId")
    @JsonAlias("Subscriber_ID")
    private String memberId;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("originalPrintTrail")
    private String originalPrintTrail;


    public HouseCalls() {
        this.category = "House Call";
        this.createApplication = "Schedular";
        this.fileDescription = "Post Assessment Letter";
        this.fileType = "Letter";
        this.privilege = "Notification/Prior Authorization Status Inquiry/Update";
        this.providerEmailId = "";
        this.postCardInd = false;
        this.tenant = "Link";
        this.subCategory = "HH";
        Subcategory subCat = Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    @Override
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
        this.expiryDate = calculateExpiryDate(createdDate); // Update expiryDate whenever createdDate is set
    }

    private String calculateExpiryDate(Date createdDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(createdDate);
        calendar.add(Calendar.MONTH, 24); // Add 24 months
        Date expiryDate = calendar.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return formatter.format(expiryDate);
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null) {
            this.mpin = mpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if (subCategory == null || subCategory.isEmpty()) {
            this.subCategory = "";
            this.setFilePath(Subcategory.HH.getFilePath());
        } else {
            this.subCategory = subCategory;
            Subcategory subCat;
            try {
                subCat = Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = Subcategory.HH;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public enum Subcategory {
        H1("H1", "HouseCalls Documentation/Post Assessment Letter"), HH("HH", "HouseCalls Documentation/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath) {
            this.subCat = subCat;
            this.filePath = filePath;
        }

        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }

    public enum ErrorMsg implements ErrorMessage {
        Load_Date(12, "Missing or invalid data: PROCESSDATE"),
        sub_Category(12, "Missing or invalid data: LETTERTYPE"),
        tin(12, "Missing or invalid data: Provider TIN"),
        mpin(12, "Missing or invalid data: ProviderMPIN"),
        isPrintSuppressed(12, "Missing or invalid data: IsPrintSuppressed"),
        originalPrintTrail(22, "Missing or invalid data: OriginalPrintTrail (SEVERE)"); //"emailAlertReq==\"Y\""

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}
