package com.optum.fds.paperless.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Arrays;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class P360TXGCDocument implements Serializable {

    @JsonProperty(value = "npi")
    private String npi;
    @JsonProperty(value = "ExemptionApprovalStatus")
    private String ExemptionApprovalStatus;
    @JsonProperty(value = "ExemptionStartDt")
    private String ExemptionStartDt;
    @JsonProperty(value = "ExemptionEndDt")

    private String ExemptionEndDt;
    @JsonProperty(value = "ExemptionCycleStartDt")
    private String ExemptionCycleStartDt;
    @JsonProperty(value = "ExemptionCycleEndDt")
    private String ExemptionCycleEndDt;

//    @JsonProperty(value = "Codes")
//    private P360TXGCCodes[] Codes;

//    public P360TXGCCodes[] getCodes() {
//        return Codes;
//    }
//
//    public void setCodes(P360TXGCCodes[] codes) {
//        Codes = codes;
//    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getExemptionApprovalStatus() {
        return ExemptionApprovalStatus;
    }

    public void setExemptionApprovalStatus(String exemptionApprovalStatus) {
        ExemptionApprovalStatus = exemptionApprovalStatus;
    }

    public String getExemptionStartDt() {
        return ExemptionStartDt;
    }

    public void setExemptionStartDt(String exemptionStartDt) {
        ExemptionStartDt = exemptionStartDt;
    }

    public String getExemptionEndDt() {
        return ExemptionEndDt;
    }

    public void setExemptionEndDt(String exemptionEndDt) {
        ExemptionEndDt = exemptionEndDt;
    }

    public String getExemptionCycleStartDt() {
        return ExemptionCycleStartDt;
    }

    public void setExemptionCycleStartDt(String exemptionCycleStartDt) {
        ExemptionCycleStartDt = exemptionCycleStartDt;
    }

    public String getExemptionCycleEndDt() {
        return ExemptionCycleEndDt;
    }

    public void setExemptionCycleEndDt(String exemptionCycleEndDt) {
        ExemptionCycleEndDt = exemptionCycleEndDt;
    }

    @Override
    public String toString() {
        return "P360TXGCDocument{" +
                "npi=" + npi +
                ", ExemptionApprovalStatus='" + ExemptionApprovalStatus + '\'' +
                ", ExemptionStartDt='" + ExemptionStartDt + '\'' +
                ", ExemptionEndDt='" + ExemptionEndDt + '\'' +
                ", ExemptionCycleStartDt='" + ExemptionCycleStartDt + '\'' +
                ", ExemptionCycleEndDt='" + ExemptionCycleEndDt + '\'' +
//                ", Codes=" + Arrays.toString(Codes) +
                '}';
    }
}
