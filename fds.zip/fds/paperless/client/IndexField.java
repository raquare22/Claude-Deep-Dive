package com.optum.fds.paperless.client;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class IndexField {
	@JacksonXmlProperty(localName = "idxName") 
	public String idxName;
	@JacksonXmlProperty(localName = "idxValue")
	public String idxValue;

	public String getIdxName() {
		return idxName;
	}

	public void setIdxName(String idxName) {
		this.idxName = idxName;
	}

	public String getIdxValue() {
		return idxValue;
	}

	public void setIdxValue(String idxValue) {
		this.idxValue = idxValue;
	}
}
