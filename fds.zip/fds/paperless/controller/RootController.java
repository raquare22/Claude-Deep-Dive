package com.optum.fds.paperless.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {

    @GetMapping("/")
    public String healthCheck() {
        return String.format("PPL Paperless Activiti is up and running");
    }
}