package com.optum.fds.paperless.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Component
@RestController
@RequestMapping("/api")
public class CSVProcessorController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CSVProcessorController.class);

    private static final String INVALID_REQUEST = "Invalid request";
    private static final String EMPTY_REQUEST_BODY = "Null or empty request body";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
    private static final String NO_CSV_PROCESSOR_FOUND = "No CSV processor found for this ProcessorId";

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private CsvProcessorService csvProcessorService;

    @PostMapping(value = "/csvProcessor", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postCSVProcessor(@RequestBody String jsonStr) {

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", "Error during postCSVProcessor: " + INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        try {
            var processorMetaData = mapper.readValue(jsonStr, ProcessorMetaData.class);
            var insertedCSVProcessor = csvProcessorService.saveCSVProcessorMetaData(processorMetaData);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), insertedCSVProcessor));
        } catch (Exception ex) {
            LOGGER.error("Error to process workflow:CSV Processor, HTTPStatus={}, apiPath=/csvProcessor, method=POST, jsonstr={} error={}", 
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(getProcessorId(jsonStr)), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(GenericResponse.from("500", "Error during postCSVProcessor: " + INTERNAL_SERVER_ERROR, ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value = "/csvProcessor", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> updateCSVProcessor(@RequestBody String jsonStr) {

        LOGGER.info("Entering update CSV processor id={}",  Encode.forJava(getProcessorId(jsonStr)));

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", "Error during updateCSVProcessor: " + INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        try {
            var processorMetaData = mapper.readValue(jsonStr, ProcessorMetaData.class);
            Map<String, Object> requestMap = new ObjectMapper().readValue(jsonStr, HashMap.class);

            if (processorMetaData.getId() == null || processorMetaData.getId().isEmpty()) {
                return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST, "Null or empty CSV processor id"),
                        HttpStatus.BAD_REQUEST);
            }

            csvProcessorService.updateCSVProcessor(processorMetaData, requestMap);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), "Updated successfully"));
            
        } catch (Exception e) {
            LOGGER.error("Error to process workflow:CSV Processor, HTTPStatus={}, apiPath=/csvProcessor, method=PUT, id={} error={}",
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(getProcessorId(jsonStr)), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(GenericResponse.from("500", "Error during updateCSVProcessor: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/csvProcessor/{id}")
    public ResponseEntity<GenericResponse> getCSVProcessorById(@PathVariable String id) {

        if (StringUtils.isEmpty(id)) {
            return new ResponseEntity<>(GenericResponse.from("400", "Error during getCSVProcessorById: " + INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        ProcessorMetaData processorMetaData = null;

        try {
            processorMetaData = csvProcessorService.getCSVProcessorById(id);
            if (processorMetaData != null) {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), processorMetaData));
            } else {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), NO_CSV_PROCESSOR_FOUND));
            }
        } catch (Exception e) {
        	LOGGER.error("Error to process workflow:CSV Processor, HTTPStatus={}, apiPath=/csvProcessor/{}, method=GET, error={}",
        			HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(id), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(GenericResponse.from("500", "Error during getCSVProcessorById: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value = "/csvProcessor/delete/{id}")
    public ResponseEntity<GenericResponse> deleteCSVProcessor(@PathVariable String id) {

        if (StringUtils.isEmpty(id)) {
            return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        ProcessorMetaData processorMetaData = null;

        try {
            processorMetaData = csvProcessorService.deleteCSVProcessor(id);
            if (processorMetaData != null) {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), processorMetaData));
            } else {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), NO_CSV_PROCESSOR_FOUND));
            }
        } catch (Exception e) {
            LOGGER.error("Error to process workflow:CSV Processor, HTTPStatus={}, apiPath=/csvProcessor/delete/{}, method=DELETE, error={}",
        			HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(id), ExceptionUtils.getStackTrace(e));
        	return new ResponseEntity<>(GenericResponse.from("500", "Error during deleteCSVProcessor: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public String getProcessorId(String jsonStr) {
        JSONObject jsonObject = new JSONObject(jsonStr);
        return (String) jsonObject.get("id");
    }
}