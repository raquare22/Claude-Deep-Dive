package com.optum.fds.paperless.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.model.MultiPostResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookMetaData;
import com.optum.fds.paperless.util.DocumentUtil;

@Component
@RestController
@RequestMapping("/api")
public class HooksController {

    private static final Logger LOGGER = LoggerFactory.getLogger(HooksController.class);

    private static final String INVALID_REQUEST = "Invalid request";
    private static final String EMPTY_REQUEST_BODY = "Null or empty request body";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
    private static final String NO_HOOK_FOUND = "No hook found for this HookId";

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private HookService hookService;


    @PostMapping(value = "/hooks", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postHook(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            var hookMetaData = mapper.readValue(jsonStr, HookMetaData.class);
            var insertedHook = hookService.saveHook(hookMetaData);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), insertedHook));
        }
        catch (Exception ex) {
            LOGGER.error("Error posting hook for id {} and error {}", Encode.forJava(gethookId(jsonStr)), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value = "/hooks", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> updateHook(@RequestBody String jsonStr) {
    	LOGGER.info("Entering updateHook id={}", Encode.forJava(gethookId(jsonStr)));
    	if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
    	
    	try {
    		var hookMetaData = mapper.readValue(jsonStr, HookMetaData.class);
    		
    		Map<String, Object> requestMap = new ObjectMapper().readValue(jsonStr, HashMap.class);
    		if (hookMetaData.getId() == null || hookMetaData.getId().isEmpty()) {
    			return new ResponseEntity<>(
                        GenericResponse.from("400", INVALID_REQUEST, "Null or empty hook id"),
                        HttpStatus.BAD_REQUEST);
    		}
    		hookService.updateHook(hookMetaData, requestMap);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), "Updated successfully"));
    		
    	} catch (Exception e) {
    		LOGGER.error("Error updating hook for id {} and error {}", Encode.forJava(gethookId(jsonStr)), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    }
    
	@GetMapping(value = "/hooks")
	public ResponseEntity<GenericResponse> getHookByName(@RequestParam Map<String, String> queryParams) {
		try {
			if (MapUtils.isEmpty(queryParams)) {
	    		return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
	    	}
			String hookName = queryParams.get("name");
			String appId = queryParams.get("appIdentifier");
			int spaceId = Integer.parseInt(queryParams.get("spaceId"));
			if (StringUtils.isEmpty(hookName) || StringUtils.isEmpty(appId) || spaceId <= 0) {
				return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
						HttpStatus.BAD_REQUEST);
			}
			List<HookMetaData> hookMetaData = null;

			hookMetaData = hookService.getHooksByName(appId, spaceId, hookName);
			return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), hookMetaData));
		} catch (Exception e) {
			return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
    
	@GetMapping(value = "/hooks/{id}")
	public ResponseEntity<GenericResponse> getHookById(@PathVariable String id) {
		if (StringUtils.isEmpty(id)) {
			return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
					HttpStatus.BAD_REQUEST);
		}
		HookMetaData hookMetaData = null;
		try {
			hookMetaData = hookService.getHookById(id);
			if (hookMetaData != null) {
				return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), hookMetaData));
			} else {
				return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), NO_HOOK_FOUND));
			}
		} catch (Exception e) {
			return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@DeleteMapping(value = "/hooks/delete/{id}")
	public ResponseEntity<GenericResponse> deleteHookById(@PathVariable String id) {
		if (StringUtils.isEmpty(id)) {
			return new ResponseEntity<>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
					HttpStatus.BAD_REQUEST);
		}
		HookMetaData hookMetaData = null;
		try {
			hookMetaData = hookService.deleteHook(id);
			if (hookMetaData != null) {
				return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), hookMetaData));
			} else {
				return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), NO_HOOK_FOUND));
			}
		} catch (Exception e) {
			return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public String gethookId(String jsonStr) {
		JSONObject jsonObject = new JSONObject(jsonStr);
		return (String) jsonObject.get("id");
	}
}
