package com.optum.fds.paperless.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.model.MultiPostResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.DocumentUtil;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Component
@RestController
@RequestMapping("/api")
public class DocumentController {

    @Autowired
    private DocumentUtil documentUtil;

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentController.class);

    private static final String INVALID_REQUEST = "Invalid request";
    private static final String EMPTY_REQUEST_BODY = "Null or empty request body";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";

	private static final Object NO_DOCUMENT_FOUND = "No Document Found for Id ";
	private static final String ERROR_UPDATE_DOCUMENT = "Error during updateDocument: ";

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private DocumentMetaDataService documentMetaDataService;

    

    @PostMapping(value = "/document", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postDocument(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(GenericResponse.from("400", "Error during postDocument: " + INVALID_REQUEST, EMPTY_REQUEST_BODY),HttpStatus.BAD_REQUEST);
        }
        try {
            var documentMetaData = mapper.readValue(jsonStr, DocumentMetaData.class);
            documentUtil.appendDefaultValues(documentMetaData);
            var insertedDocument = documentMetaDataService.saveDocumentMetaData(documentMetaData);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), insertedDocument));
        } catch (Exception ex) {
            LOGGER.error("Error posting document for jsonStr {} and error {}", Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<>(GenericResponse.from("500", "Error during postDocument: " + INTERNAL_SERVER_ERROR, ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value = "/document", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> updateDocument(@RequestBody String jsonStr) {
        LOGGER.info("Entering putDocument jsonStr={}", Encode.forJava(jsonStr));
    	if (StringUtils.isEmpty(jsonStr)) {
    		return new ResponseEntity<>(GenericResponse.from("400", ERROR_UPDATE_DOCUMENT + INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
    	}
    	
    	try {
    		var documentMetaData = mapper.readValue(jsonStr, DocumentMetaData.class);
    		
    		if (documentMetaData.getId() == null || documentMetaData.getId().isEmpty()) {
    			return new ResponseEntity<>(GenericResponse.from("400", ERROR_UPDATE_DOCUMENT + INVALID_REQUEST, "Null or empty document id"),HttpStatus.BAD_REQUEST);
    		}
    		var updatedDocument = documentMetaDataService.updateDocMetaData(documentMetaData, documentMetaData.getId());
    		if (updatedDocument == null) {
    			throw new NullPointerException("No document found with id: " + documentMetaData.getId());
    		}
            LOGGER.info(" update document id={}", documentMetaData.getId());
    		return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), updatedDocument));
    	} catch (NullPointerException e) {
            JSONObject jsonObject = new JSONObject(jsonStr);
            String docId = (String) jsonObject.get("id");
    		LOGGER.error("Error updating document {} and error {} {}", Encode.forJava(docId), e.getClass().getSimpleName(), e.getMessage());
    		return new ResponseEntity<>(GenericResponse.from("500", ERROR_UPDATE_DOCUMENT + INTERNAL_SERVER_ERROR, "No document found for payload {}: " + jsonStr), HttpStatus.INTERNAL_SERVER_ERROR);
    	} catch (Exception e) {
            JSONObject jsonObject = new JSONObject(jsonStr);
            String docId = (String) jsonObject.get("id");
    		LOGGER.error("Error updating document {} and error {}", Encode.forJava(docId), ExceptionUtils.getStackTrace(e));
    		return new ResponseEntity<>( GenericResponse.from("500", ERROR_UPDATE_DOCUMENT + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    }
    
    @PostMapping(value = "/document/multi", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postMultiDocument(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<>(GenericResponse.from("400", "Error during postMultiDocument: " + INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
        }

        try {
            var documentMetaDataList = Arrays.asList(mapper.readValue(jsonStr, DocumentMetaData[].class));
            var insertedDocList = documentMetaDataService.insertMultiDocuments(documentMetaDataList);

            List<String> docIds = new ArrayList<>();
            insertedDocList.forEach(doc -> docIds.add(doc.getId()));

            MultiPostResponse response = new MultiPostResponse(docIds);

            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), response));
        } catch (Exception e) {
            LOGGER.error("Error posting multi documents for jsonStr {} and error {}", Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(GenericResponse.from("500", "Error during postMultiDocument: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping(value = "/document/multi", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> putMultiDocument(@RequestBody Map<String, Object> requestMap) {
        long startTime = System.nanoTime();
        if (MapUtils.isEmpty(requestMap)) {
            LOGGER.warn("Error updating multi documents, invalid request, HTTPStatus={}", HttpStatus.BAD_REQUEST);
            return new ResponseEntity<>(GenericResponse.from("400", "Error during putMultiDocument: " + INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
        }

        List<String> documentIds = null;
        DocumentMetaData documentMetaData = null;
        String docIdStr = "";
        String docMetaDataStr = "";
        try {
            documentIds = (List<String>) requestMap.get("documentIds");
            documentMetaData = mapper.convertValue(requestMap.get("document"), DocumentMetaData.class);
            docIdStr = (documentIds == null || documentIds.isEmpty())  ? "" : documentIds.toString();
            docMetaDataStr = (documentMetaData == null) ? "" : documentMetaData.toString();

            LOGGER.info("Updating multi documents with docIds={}, documentMetadata={}",
                    Encode.forJava(docIdStr), Encode.forJava(docMetaDataStr));

            var response = documentMetaDataService.updateMultiDocuments(documentIds, documentMetaData);

            long latency = (System.nanoTime() - startTime) / 1000000;
            LOGGER.info("Success updating multi documents HTTPStatus={}, docIds={}, latency={}, response={}", HttpStatus.OK, Encode.forJava(docIdStr), latency, response);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), response));
        } catch (Exception e) {
            docIdStr = (documentIds == null || documentIds.isEmpty())  ? "" : documentIds.toString();
            docMetaDataStr = (documentMetaData == null) ? "" : documentMetaData.toString();
            long latency = (System.nanoTime() - startTime) / 1000000;
            LOGGER.error("Error updating multi documents docIds={}, documentmetaData={}, latency={}, error={}",
                    Encode.forJava(docIdStr), Encode.forJava(docMetaDataStr), latency, ExceptionUtils.getStackTrace(e));
            return new ResponseEntity(GenericResponse.from("500", "Error during putMultiDocument: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/document/{id}")
    public ResponseEntity<GenericResponse> getDocumentById(@PathVariable String id) {
        DocumentMetaData document = null;
        try {
            document = documentMetaDataService.getDocumentMetaData(id);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), document));
        } catch (Exception e) {
            return new ResponseEntity<>(GenericResponse.from("500", "Error during getDocumentById: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/document")
    public ResponseEntity<GenericResponse> getDocuments(@RequestParam Map<String, String> queryParams) {
        if (MapUtils.isEmpty(queryParams)) {
            return new ResponseEntity<>(GenericResponse.from("400", "Error during getDocuments: " + INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
        }

        List<DocumentMetaData> documents = null;

        try {
            documents = documentMetaDataService.getDocuments(queryParams);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), documents));
        } catch (Exception e) {
            LOGGER.error("Error finding documents error={}", ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(GenericResponse.from("500", "Error during getDocuments: " + INTERNAL_SERVER_ERROR, documents), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
    
    @DeleteMapping(value = "/document/delete/{id}")
    public ResponseEntity<GenericResponse> deleteDocument(@PathVariable String id) {

        if (StringUtils.isEmpty(id)) {
            return new ResponseEntity<>(GenericResponse.from("400", "Error during deleteDocument: " + INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
        }

        DocumentMetaData documentMetaData = null;
        try {
            documentMetaData = documentMetaDataService.deleteDocument(id);
            if (documentMetaData != null) {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), documentMetaData));
            } else {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), NO_DOCUMENT_FOUND));
            }
        } catch (Exception e) {
            return new ResponseEntity<>(GenericResponse.from("500", "Error during deleteDocument: " + INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}