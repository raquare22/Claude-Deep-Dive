package com.optum.fds.paperless.email;

import java.util.Properties;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

public class EmailConfig {


	public JavaMailSender getMailSender(String hostName, int portNumber) {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

		mailSender.setHost(hostName);
		mailSender.setPort(portNumber);

		Properties javaMailProperties = new Properties();
		javaMailProperties.put("mail.smtp.starttls.enable", "false");
		javaMailProperties.put("mail.smtp.auth", "false");
		javaMailProperties.put("mail.transport.protocol", "smtp");
		javaMailProperties.put("mail.smtp.starttls.required", "false");
		javaMailProperties.put("mail.debug", "true");

		mailSender.setJavaMailProperties(javaMailProperties);
		return mailSender;
	}
}
