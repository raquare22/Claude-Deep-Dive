package com.optum.fds.paperless.processing.service;


import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.query.Criteria;

public interface ProcessorTransactionsService {

	public ProcessorTransactionMetadata createProcessorTransactionMetadata(Map<String, Object> client, 
			String processorId, Integer configSpaceId, String fileName);
	
	public Map<String, Object> createProcessorTransactionMetadataClientHashmap(boolean sendCompanionFileMissingEmail, 
			boolean sendCompanionFileUnreadableEmail, String sampleZipFileName, Date companionFileDateReceived );
	
	public ProcessorTransactionMetadata updateProcessorTransactionMetadata( ProcessorTransactionMetadata 
			processorTransactionMetadata);
	
	public ProcessorTransactionMetadata getProcessorTransactionMetadataWithFileName(String fileName);
	
    public List<ProcessorTransactionMetadata> getProcessorTransactionMetaData(String searchCriteriaJson,Criteria filter) throws InvalidExpressionException;

	public ProcessorTransaction findProcessorTransactionByFileName(String zipFileName, Integer configSpaceId);

	
	}
