/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/8/17.
 */


package com.optum.fds.paperless.processing.service.util;



import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;


import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRevision;




public class ProcessorUtil {
    private static final Logger logger = LoggerFactory.getLogger(ProcessorUtil.class);
    private static ProcessorUtil instance;

    private ProcessorUtil() {}

    public static synchronized ProcessorUtil getInstance() {
        if(instance == null){
            instance = new ProcessorUtil();
        }

        return instance;
    }

    public static final ProcessorRevision createRevision(ProcessorMetaData processorMetaData){
    	 var processorRevision = new ProcessorRevision();
    	 try {
    		 BeanUtils.copyProperties(processorMetaData, processorRevision);
    	 }catch(Exception e) {
    		 logger.error("createRevision {}={}, {}={} {}",
 					"processorMetaDataId", processorMetaData.getId(),
 					"processorMetaDataName", processorMetaData.getName(),
 					ExceptionUtils.getStackTrace(e));
    	 }
    	return processorRevision;
    }
}
