/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 */

package com.optum.fds.paperless.processing.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@XmlRootElement(name = "document")
public class Document extends Documents {
    private String id;
    @JsonProperty("parent_id")
    private String parentId;
    @JsonProperty("space_id")
    private Integer spaceId;
    @JsonProperty("external_id")
    private String externalId;
    private String status;
    private String version;
    private String expires;

    @JsonProperty("store_input_files")
    private String storeInputFiles;

    private Map<String, Object> metadata;



    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getExpires() {
        return expires;
    }

    public void setExpires(String expires) {
        this.expires = expires;
    }




    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }




    public String getStoreInputFiles() {
        return storeInputFiles;
    }

    public void setStoreInputFiles(String storeInputFiles) {
        this.storeInputFiles = storeInputFiles;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

}
