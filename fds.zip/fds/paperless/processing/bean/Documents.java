/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 */

package com.optum.fds.paperless.processing.bean;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "document")
public class Documents {
    private Document[] document;

    public Document[] getDocuments() {
        return document==null?null:document.clone();
    }

    public void setDocuments(Document[] document) {
        this.document = document==null?null:document.clone();
    }
}
