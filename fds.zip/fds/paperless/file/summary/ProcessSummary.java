/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/30/17.
 */

package com.optum.fds.paperless.file.summary;

import static com.optum.fds.paperless.util.FileUtil.totalBytesAtLocation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.util.ProcessorTaskUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorError;
import com.optum.fds.paperless.mongo.processors.ProcessorErrorCode;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.util.Parser;

@Component
public class ProcessSummary {
    private static final Logger log = LoggerFactory.getLogger(ProcessSummary.class);
    private static final String OUTCOME_KEY = "outcome";
    private static final String ERROR_KEY = "error";
    private static final String ERROR_READING_ZIP_CONTENT_LOCATION = "There was an error reading zip content location.";
    private static final String ERROR_VALIDATING_SUMMARY_AGAINST_ZIP_CONTENT = "Error validating summary XML against zip contents. \n{}";
    private static final String LOCK_FILE_EXTENTION = "txt";
    
    private static final String PROCESSOR_TRANSACTION_ID = "processorTransactionId";
    private static final String SUMMARY_FILE =  "summaryFile";
    private static final String SUMMARY_FILE_LOCATION =  "summaryFileLocation";
    private static final String SUMMARY_FILE_BATCH_ID =  "summaryFileBatchId";
    private static final String ACTIVITY_PROCESS_KEY = "activityProcessKey";
    private static final String PATH_LOCATION = "pathLocation";
    
    private ProcessorError processorError;

    @Autowired ProcessorService processorService;


    /**********    Constructors *************/
    public ProcessSummary(){
        // Required Constructor
    }
    // Test constructor
    public ProcessSummary(ProcessorService processorServiceSource){
        processorService = processorServiceSource;
    }

    public void processSummaryFile(ProcessorTransaction processorTransaction) {

        // Return if transaction has Fatal errors
        if(processorTransaction.getStatus() == MetaDataStatus.FATAL_ERROR){
            return;
        }
        
        ProcessorExecutionRecord executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Retrieving summary file", processorTransaction);
        HashMap<String,String> message = new HashMap<>();

        File summaryFile = null;
        try {
            List outcome = getSummaryFile(processorTransaction.getLocation());
            summaryFile = (File) outcome.get(0);

            message.put(OUTCOME_KEY, (String) outcome.get(1));
        } catch (FileNotFoundException e) {
            log.error("processSummaryFile Summary File not found {}={}, {}={} {}",
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					SUMMARY_FILE, processorTransaction != null ? processorTransaction.getLocation() : "NULL",
					ExceptionUtils.getStackTrace(e));
            message.put(OUTCOME_KEY, "Summary file was NOT found");
            message.put(ERROR_KEY, e.toString());

            processorError = new ProcessorError(ProcessorErrorCode.FILE_NOT_FOUND);
            processorTransaction.getSummary().addError(processorError);

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
        }
        catch (IOException e){
            log.error("processSummaryFile Could not read file location; {}={}, {}={} {}",
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					SUMMARY_FILE_LOCATION, processorTransaction != null ? processorTransaction.getLocation() : "NULL",
					ExceptionUtils.getStackTrace(e));
            message.put(OUTCOME_KEY, "Could not read file location");
            message.put(ERROR_KEY, e.toString());

            processorError = new ProcessorError(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE);
            processorTransaction.getSummary().addError(processorError);

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
        }
        finally {
            ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord, message);
        }

        // Continue?
        if(processorTransaction.getStatus() == MetaDataStatus.FATAL_ERROR){
            return;
        }

        executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Parsing summary file", processorTransaction);
        message = new HashMap<>();
        SummaryFile summaryXML = null;
        SummaryFileWithAttributes summaryFileWithAttributes = null;
        try {
        	summaryFileWithAttributes = Parser.parseXMLFile(summaryFile, SummaryFileWithAttributes.class);
        	summaryFileCountFieldValidation(summaryFileWithAttributes, processorTransaction, message);
        	summaryXML = new SummaryFile();
        	convertSummaryFileWithAttributesToSummaryFile(summaryXML, summaryFileWithAttributes);
            message.put(OUTCOME_KEY, "Summary file parsed");
        } catch (JsonParseException e) {
            log.error("processSummaryFile Could not parse summary file {}={}, {}={} {}",
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					SUMMARY_FILE, summaryFile != null ? summaryFile.getName() : "NULL",
					ExceptionUtils.getStackTrace(e));
            message.put(OUTCOME_KEY, "Could not parse summary file.");
            message.put(ERROR_KEY, e.toString());

            processorError = new ProcessorError(ProcessorErrorCode.FILE_COULD_NOT_BE_PARSED);
            processorTransaction.getSummary().addError(processorError);

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
        } catch (JsonMappingException e) {
            log.error("processSummaryFile XML in summary file could not be mapped correctly {}={}, {}={} {}",
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					SUMMARY_FILE, summaryFile != null ? summaryFile.getName() : "NULL",
					ExceptionUtils.getStackTrace(e));
            message.put(OUTCOME_KEY, "XML in summary file could not be mapped correctly.");
            message.put(ERROR_KEY, e.toString());

            processorError = new ProcessorError(ProcessorErrorCode.XML_COULD_NOT_BE_MAPPED_IN_SUMMARY);
            processorTransaction.getSummary().addError(processorError);

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
        } catch (IOException e) {
            log.error("processSummaryFile Could not read summary file {}={}, {}={} {}",
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					SUMMARY_FILE, summaryFile != null ? summaryFile.getName() : "NULL",
					ExceptionUtils.getStackTrace(e));

            message.put(OUTCOME_KEY, "Could not parse summary file");
            message.put(ERROR_KEY, e.toString());

            processorError = new ProcessorError(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE);
            processorTransaction.getSummary().addError(processorError);

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
        }
        finally {
            ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord, message);
        }

        // Continue?
        if(processorTransaction.getStatus() == MetaDataStatus.FATAL_ERROR){
            return;
        }


        executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Performing initial validation", processorTransaction);
        message = new HashMap<>();

        // Performing High level Validation
        List outcome = summaryXMLHighLevelValidation(summaryXML);

        if(!(Boolean) outcome.get(0)){
            processorTransaction.getSummary().addError((ProcessorError) outcome.get(2));

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);

            ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord, (HashMap) outcome.get(1));

            return;
        }

        //Save Summary XML
        processorTransaction.getSummary().setXmlObject(summaryXML);

        message.put(OUTCOME_KEY, "High level validation compelte.");
        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord, message);



        // Validate
        summaryFileValidation(summaryXML, processorTransaction);

        List filesToProcess = processorTransaction.getFileToProcessList();

        if( filesToProcess == null || filesToProcess.isEmpty()){
            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
            processorService.saveProcessorTransactionMetaData(processorTransaction);
        }
    }
	/**
	 * @param summaryXML
	 * @param summaryFileWithAttributes
	 * @return
	 */
	private void convertSummaryFileWithAttributesToSummaryFile(SummaryFile summaryXML,
			SummaryFileWithAttributes summaryFileWithAttributes) {
		if(summaryFileWithAttributes != null){
			summaryXML.setBatchId(summaryFileWithAttributes.getBatchId());
			summaryXML.setCount(summaryFileWithAttributes.getCount());
			summaryXML.setDataGroup(summaryFileWithAttributes.getDataGroup());
			summaryXML.setFileList(summaryFileWithAttributes.getFileListAsStringNames());
		}
	}

    public List<Object> getSummaryFile(String summaryFileLocation) throws IOException {
        List toReturn = new ArrayList<>();

        final Path location = Paths.get(summaryFileLocation);
        List<File> summaryFiles = new ArrayList<>();
        try(final DirectoryStream<Path> stream = Files.newDirectoryStream(location, "*.summary")){
            stream.forEach(file -> summaryFiles.add(file.toFile()));

        } catch (Exception e) {
        	log.error("getSummaryFile {}={} {}",
					SUMMARY_FILE_LOCATION, summaryFileLocation,
					ExceptionUtils.getStackTrace(e));
            throw e;
        }

        // Getting Summary File
        if(summaryFiles.isEmpty()) {
            log.error("getSummaryFile: No Summary File found; {}={}",
					SUMMARY_FILE_LOCATION, summaryFileLocation);
            throw new FileNotFoundException("No Summary File found; " + SUMMARY_FILE_LOCATION + "=" + summaryFileLocation);	
        }
        else{
            Collections.sort(summaryFiles);
            toReturn.add(summaryFiles.get(0));
            if(summaryFiles.size() > 1) {
                log.warn("Found more than one summary file. Using first summary file; {}={}", SUMMARY_FILE_LOCATION, summaryFileLocation);
                toReturn.add("Found more than one summary file. Using first summary file");
            }
            else{
                toReturn.add("Summary file was found");
            }
        }

        return toReturn;
    }

    public List summaryXMLHighLevelValidation(SummaryFile summaryXML) {
        List toReturn = new ArrayList<>();
        HashMap<String,String> message = new HashMap<>();

        toReturn.add(true);

        if(summaryXML.getFileList() == null || summaryXML.getFileList().isEmpty()){
            toReturn.set(0, false);

            message.put(OUTCOME_KEY, "XML missing Files Node");
            toReturn.add(message);

            toReturn.add(new ProcessorError(ProcessorErrorCode.XML_MISSING_FILES_TO_PROCESS));
        }

        return toReturn;
    }

    public void summaryFileValidation(SummaryFile summaryXML, ProcessorTransaction processorTransaction) {
        final String metadataExtension = "metadata";

        ProcessorExecutionRecord executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Performing validation of summary xml against zip contents", processorTransaction);

        validateCountAgainstFileList(summaryXML, processorTransaction, executionRecord);

        final Path location = Paths.get(processorTransaction.getLocation());

        // Collecting file names.
        final List<String> files = summaryXML.getFileList();

        // Collecting Metadata Files
        final List<String> metadataFiles = getMetadataFiles(metadataExtension, location, processorTransaction, executionRecord);
        if(processorTransaction.getStatus() == MetaDataStatus.FATAL_ERROR){
            ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord);
            return;
        }

        // Collecting All files
        final List<String> filesAtContentLocation = getFilesAtLocation(location, processorTransaction, executionRecord);
        if(processorTransaction.getStatus() == MetaDataStatus.FATAL_ERROR){
            ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord);
            return;
        }

        calculateTotalBytesForTransaction(processorTransaction, location);


        cycleThroughZipFiles(processorTransaction, metadataExtension, executionRecord, files, metadataFiles, filesAtContentLocation);

        // Were there any missing files?
        checkIfFilesWereMissing(processorTransaction, metadataExtension);

        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord);
    }
    
	public void summaryFileCountFieldValidation(SummaryFileWithAttributes summaryFileWithAttributes,
			ProcessorTransaction processorTransaction, HashMap<String, String> message) {
		try {
			Integer.parseInt(summaryFileWithAttributes.getCount());
		} catch (NumberFormatException e) {
			log.error("summaryFileCountFieldValidation Bad format in summary file Count {}={}, {}={} {}",
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					SUMMARY_FILE_BATCH_ID, summaryFileWithAttributes != null ? summaryFileWithAttributes.getBatchId() : "NULL",
					ExceptionUtils.getStackTrace(e));
			message.put(OUTCOME_KEY, "Bad format in summary file Count.");
			message.put(ERROR_KEY, e.toString());
			processorTransaction = Optional.ofNullable(processorTransaction).orElseThrow(NullPointerException::new);
			processorError = new ProcessorError(ProcessorErrorCode.NUMBER_FORMAT_EXCEPTION_SUMMARY_COUNT);
			processorTransaction.getSummary().addError(processorError);

			processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
		}
	}

    private static final void calculateTotalBytesForTransaction(ProcessorTransaction processorTransaction, Path location) {
        // Getting total bytes to be processed
        String[] excludeExtensions = {"zip", "metadata", "summary"};
        final Long totalBytesToBeProcessed = totalBytesAtLocation(location, Arrays.asList(excludeExtensions));
        processorTransaction.getSummary().getProcessingMetrics().setTotalBytes(totalBytesToBeProcessed);
    }

    private static final void checkIfFileIsMetadataAndHasCorrespondingFile(String fileName, String metadataExtension, List<String> files, ProcessorExecutionRecord executionRecord, ProcessorTransaction processorTransaction){
        if(
            fileName.endsWith(metadataExtension) &&
            files.stream().noneMatch(fileNameProvided ->
                !fileNameProvided.equals(fileName) &&
                fileNameProvided.startsWith(Utilities.stripFileExtension(fileName))
            )
        ) {
            HashMap<String, String> messageForFile = new HashMap<>();
            messageForFile.put(OUTCOME_KEY, "Metadata File did not have corresponding file.");
            messageForFile.put(ERROR_KEY, "No file found for metadata file " + fileName);
            ProcessorTaskUtil.addMessageToProcessorExecutionRecord(executionRecord, messageForFile);
            processorTransaction.addMissingFile(fileName);
            processorTransaction.addExtraFile(fileName);
        }
    }

    private static final void checkIfFilesWereMissing(ProcessorTransaction processorTransaction, String metadataExtension){
        List<String> missingFiles = processorTransaction.getMissingFileList();

        if(missingFiles != null && !missingFiles.isEmpty()){
            if(!missingFiles.stream().noneMatch( fileName -> fileName.endsWith(metadataExtension))){
                processorTransaction.getSummary().addError(new ProcessorError(ProcessorErrorCode.EXTRA_METADATA_FILE_FOUND));
            }
            
            for (String fileName : missingFiles) {
            	if (!fileName.endsWith(metadataExtension) && !fileName.endsWith(LOCK_FILE_EXTENTION) && !fileName.startsWith(".nfs")) {
            	  	processorTransaction.getSummary().addError(new ProcessorError(ProcessorErrorCode.EXTRA_FILE_FOUND_WITH_NO_METADATA, fileName));
            	}
            }
        }
    }

    private void cycleThroughZipFiles(ProcessorTransaction processorTransaction, String metadataExtension, ProcessorExecutionRecord executionRecord, List<String> files, List<String> metadataFiles, List<String> filesAtContentLocation) {
        // Cycling through files
        final boolean[] hasExtraFiles = {false};
        final boolean[] extraFileProcessed = {false};
        final ProcessorExecutionRecord finalExecutionRecord = executionRecord;
        filesAtContentLocation.stream().forEach(fileName -> {
            // Only check non-metadata/summary/zip files
            if (!fileName.endsWith(metadataExtension) && !fileName.endsWith("summary") && !fileName.endsWith("zip") && !fileName.endsWith(LOCK_FILE_EXTENTION) && !fileName.startsWith(".nfs")) {
                boolean isExtraFile = !fileInList(files, fileName, finalExecutionRecord, processorTransaction);

                if(isExtraFile) {
                    hasExtraFiles[0] = true;
                }

                if(hasMetadataFile(fileName, metadataExtension, metadataFiles, finalExecutionRecord, processorTransaction)) {
                    if(isExtraFile){
                        extraFileProcessed[0] = true;
                    }

                    processorTransaction.addFileToProcess(fileName);
                }
            } else {
                checkIfFileIsMetadataAndHasCorrespondingFile(fileName, metadataExtension, filesAtContentLocation, finalExecutionRecord, processorTransaction);
            }
        });

        if(hasExtraFiles[0] && extraFileProcessed[0]){
            processorTransaction.getSummary().addError(new ProcessorError(ProcessorErrorCode.PDF_FILE_NAME_MISMATCH));
        }
    }

    private static boolean fileInList(List<String> files, String fileName, ProcessorExecutionRecord executionRecord, ProcessorTransaction processorTransaction){
        boolean fileInList = true;
        // Is it in the list
        if (!files.contains(fileName)) {
            fileInList = false;
            HashMap<String, String> messageForFile = new HashMap<>();
            messageForFile.put(OUTCOME_KEY, "File was not specified in XML.");
            messageForFile.put(ERROR_KEY, "File: " + fileName);
            ProcessorTaskUtil.addMessageToProcessorExecutionRecord(executionRecord, messageForFile);
            processorTransaction.addExtraFile(fileName);
        }
		return fileInList;
    }

    private static List<String> getFilesAtLocation(Path location, ProcessorTransaction processorTransaction, ProcessorExecutionRecord executionRecord){
        List<String> files = new ArrayList<>();
        HashMap<String, String> message = new HashMap<>();

        try(final Stream<Path> stream = Files.list(location)){
            stream.filter(Files::isRegularFile).forEach(file -> files.add(file.getFileName().toString()));
            message.put(OUTCOME_KEY, "Retrieved all files in content location");
        } catch (Exception e) {
            log.error("getFilesAtLocation: {} {}={}, {}={}, {}={} {}",
            		ERROR_VALIDATING_SUMMARY_AGAINST_ZIP_CONTENT,
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					ACTIVITY_PROCESS_KEY, executionRecord != null ? executionRecord.getActivitiProcessKey() : "NULL",
					PATH_LOCATION, location != null ? location.toString() : "NULL",
					ExceptionUtils.getStackTrace(e));
            message.put(OUTCOME_KEY, ERROR_READING_ZIP_CONTENT_LOCATION);
            message.put(ERROR_KEY, e.toString());
            processorTransaction = Optional.ofNullable(processorTransaction).orElseThrow(NullPointerException::new);
            ProcessorError processorError = new ProcessorError(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE);
            processorTransaction.getSummary().addError(processorError);

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
        }
        finally {
            ProcessorTaskUtil.addMessageToProcessorExecutionRecord(executionRecord, message);
        }

        return files;
    }


    private static final List<String> getMetadataFiles(String metadataExtension, Path location, ProcessorTransaction processorTransaction, ProcessorExecutionRecord executionRecord){
        final List<String> metadataFiles = new ArrayList<>();
        HashMap<String, String> message = new HashMap<>();

        try{

            FileUtil.getFilesByExtension(metadataExtension, location)
                .stream()
                .forEach(file ->
                    metadataFiles.add(file.getName())
                );
            message.put(OUTCOME_KEY, "Retrieved all metadata files from location");
        } catch (Exception e) {
            log.error("getMetadataFiles {} {}={}, {}={}, {}={} {}",
            		ERROR_VALIDATING_SUMMARY_AGAINST_ZIP_CONTENT,
					PROCESSOR_TRANSACTION_ID, processorTransaction != null ? processorTransaction.getId() : "NULL",
					ACTIVITY_PROCESS_KEY, executionRecord != null ? executionRecord.getActivitiProcessKey() : "NULL",
					PATH_LOCATION, location != null ? location.toString() : "NULL",
					ExceptionUtils.getStackTrace(e));

            message.put(OUTCOME_KEY, ERROR_READING_ZIP_CONTENT_LOCATION);
            message.put(ERROR_KEY, e.toString());
            processorTransaction = Optional.ofNullable(processorTransaction).orElseThrow(NullPointerException::new);
            processorTransaction.getSummary().addError(new ProcessorError(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE));

            processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
        }
        finally {
            ProcessorTaskUtil.addMessageToProcessorExecutionRecord(executionRecord, message);
        }


        return metadataFiles;
    }

    private static final boolean hasMetadataFile(String fileName, String metadataExtension, List<String> metadataFiles, ProcessorExecutionRecord executionRecord, ProcessorTransaction processorTransaction){

        // Replacing extension
        String fileNameWithReplaceExtenstion = Utilities.replaceExtension(fileName, metadataExtension);
        boolean hasMetadataFile = !metadataFiles.stream().noneMatch(metadataFileName -> metadataFileName.equals(fileNameWithReplaceExtenstion));

        if(!hasMetadataFile) {
//            HashMap<String, String> messageForFile = new HashMap<>();
//            messageForFile.put(OUTCOME_KEY, "File did not have corresponding metadata file.");
//            messageForFile.put(ERROR_KEY, "No metadata file found for " + fileName);
//            processorTransaction.getSummary().addError(new ProcessorError(ProcessorErrorCode.NO_METADATA_FILE_FOUND, fileName));
//            ProcessorTaskUtil.addMessageToProcessorExecutionRecord(executionRecord, messageForFile);
            processorTransaction.addMissingFile(fileName);
        }

        return hasMetadataFile;
    }

    private void validateCountAgainstFileList(SummaryFile summaryXML, ProcessorTransaction processorTransaction, ProcessorExecutionRecord executionRecord){
        HashMap<String, String>  message = new HashMap<>();
        int summaryXMLCount=Integer.parseInt(summaryXML.getCount());
        if(summaryXMLCount != summaryXML.getFileList().size()){
            String errorMessage = "Count is at " + summaryXML.getCount() + " and there are " + summaryXML.getFileList().size() + " files listed.";
            message.put(OUTCOME_KEY, "There is mismatch between count and specified files.");
            message.put(ERROR_KEY, errorMessage);

            processorError = new ProcessorError(ProcessorErrorCode.FILE_COUNT_MISMATCH);
            processorError.setErrorMessage(processorError.getErrorMessage() + " " + errorMessage);
            processorTransaction.getSummary().addError(processorError);

        }
        else{
            message.put(OUTCOME_KEY, "Count and specified files totals matched.");
        }

        ProcessorTaskUtil.addMessageToProcessorExecutionRecord(executionRecord, message);
    }
}
