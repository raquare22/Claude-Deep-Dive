/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/31/17.
 */

package com.optum.fds.paperless.file.summary;


import java.io.Serializable;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SummaryFile implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("BatchID")
    String batchId;
    @JsonProperty("Datagroup")
    String dataGroup;
    @JsonProperty("Count")
    String count;
  //  @JsonProperty("Files")
  //  SummaryFiles files;
    
    @JsonProperty("FileName")
   transient List<String> fileList;

    public List<String> getFileList() {
        return fileList;
    }
    public void setFileList(List<String> fileList) {
        this.fileList = fileList;
    }

    public String getBatchId() {
        return batchId;
    }
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }
    public String getDataGroup() {
        return dataGroup;
    }
    public void setDataGroup(String dataGroup) {
        this.dataGroup = dataGroup;
    }
    public String getCount() {
        return count;
    }
    public void setCount(String count) {
        this.count = count;
    }
/*    public SummaryFiles getFiles() {
        return files;
    }
    public void setFiles(SummaryFiles files) {
        this.files = files;
    }*/
}
