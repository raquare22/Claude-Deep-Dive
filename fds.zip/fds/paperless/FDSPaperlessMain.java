package com.optum.fds.paperless;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class FDSPaperlessMain {
	
	  private static final Logger LOGGER = LogManager.getLogger(FDSPaperlessMain.class);

	  protected static boolean shutdown = false;

    public static void main(String[] args) {
    	
    	 SpringApplication application =new SpringApplication(FDSPaperlessMain.class);
    	 application.run(args); 
    	 
    	
    }
    
    
 

	@Bean
	public CommandLineRunner init(final RepositoryService repositoryService, final RuntimeService runtimeService,
								  final TaskService taskService) {
		return new CommandLineRunner() {
			public void run(String... strings) throws Exception {
				System.out.println("Number of process definitions : " + repositoryService.createProcessDefinitionQuery().count());
				System.out.println("Number of tasks : " + taskService.createTaskQuery().count());
				System.out.println("Number of tasks after process start : " + taskService.createTaskQuery().count());
			}
		};
	}

}