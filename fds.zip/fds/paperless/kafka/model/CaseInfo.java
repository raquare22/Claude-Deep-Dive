package com.optum.fds.paperless.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseInfo {
    @JsonProperty("CaseNumber")
    private String caseNumber;

    @JsonProperty("CaseStatus")
    private String caseStatus;

    @JsonProperty("LstClaimInfo")
    private List<ClaimInfo> lstClaimInfo;

    @JsonProperty("MemberInfo")
    private MemberInfo memberInfo;

    @JsonProperty("CreatedOn")
    private String createdOn;

    private String mpin;
    private String tin;

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getCaseStatus() {
        return caseStatus;
    }

    public void setCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
    }

    public List<ClaimInfo> getLstClaimInfo() {
        return lstClaimInfo;
    }

    public void setLstClaimInfo(List<ClaimInfo> lstClaimInfo) {
        this.lstClaimInfo = lstClaimInfo;
    }

    public MemberInfo getMemberInfo() {
        return memberInfo;
    }

    public void setMemberInfo(MemberInfo memberInfo) {
        this.memberInfo = memberInfo;
    }
}