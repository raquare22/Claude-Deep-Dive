package com.optum.fds.paperless.kafka.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProviderDetails {

    String providerTin;
    String admittingProviderName;
    String facilityProvider;
    String providerName;
    String providerNpi;
    
    List<BHProvider> bhProviderList; 

    public String getProviderTin() {
        return providerTin;
    }

    public void setProviderTin(String providerTin) {
        this.providerTin = providerTin;
    }

    public String getAdmittingProviderName() {
        return admittingProviderName;
    }

    public void setAdmittingProviderName(String admittingProviderName) {
    	this.admittingProviderName = admittingProviderName;
    }

    public String getFacilityProvider() {
        return facilityProvider;
    }

    public void setFacilityProvider(String facilityProvider) {
        this.facilityProvider = facilityProvider;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getProviderNpi() {
        return providerNpi;
    }

    public void setProviderNpi(String providerNpi) {
        this.providerNpi = providerNpi;
    }
    
    public List<BHProvider> getBhProviderList() {
		return bhProviderList;
	}

	public void setBhProviderList(List<BHProvider> bhProviderList) {
		this.bhProviderList = bhProviderList;
	}

	@Override
	public String toString() {
		return "ProviderDetails [providerTin=" + providerTin + ", admittingProviderName=" + admittingProviderName
				+ ", facilityProvider=" + facilityProvider + ", providerName=" + providerName + ", providerNpi="
				+ providerNpi + "]";
	}
}
