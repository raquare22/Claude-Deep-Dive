package com.optum.fds.paperless.kafka.model;

import java.util.Map;

public class KafkaMessage {
    private MemberDetails memberDetails;    
    private Map<String, Object> encounterDetails;
    private ProviderDetails providerDetails;
    private RecordInfo recordInfo;

    public MemberDetails getMemberDetails() {
        return memberDetails;
    }

    public void setMemberDetails(MemberDetails memberDetails) {
        this.memberDetails = memberDetails;
    }

    public Map<String, Object> getEncounterDetails() {
        return encounterDetails;
    }

    public void setEncounterDetails(Map<String, Object> encounterDetails) {
        this.encounterDetails = encounterDetails;
    }

    public ProviderDetails getProviderDetails() {
        return providerDetails;
    }

    public void setProviderDetails(ProviderDetails providerDetails) {
        this.providerDetails = providerDetails;
    }

    public RecordInfo getRecordInfo() {
        return recordInfo;
    }

    public void setRecordInfo(RecordInfo recordInfo) {
        this.recordInfo = recordInfo;
    }

    @Override
    public String toString() {
        return "{" +
                "memberDetails=" + memberDetails +
                ", encounterDetails=" + encounterDetails +
                ", providerDetails=" + providerDetails +
                ", recordInfo=" + recordInfo +
                '}';
    }

}
