package com.optum.fds.paperless.kafka.model;

public class Provider {
    private String providerTin;
    private String mpin;
    private Integer appealCount;
    private Integer paanCount;
    private Integer reconCount;

    public String getProviderTin() {
        return providerTin;
    }

    public void setProviderTin(String providerTin) {
        this.providerTin = providerTin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public Integer getAppealCount() {
        return appealCount;
    }

    public void setAppealCount(Integer appealCount) {
        this.appealCount = appealCount;
    }

    public Integer getPaanCount() {
        return paanCount;
    }

    public void setPaanCount(Integer paanCount) {
        this.paanCount = paanCount;
    }

    public Integer getReconCount() {
        return reconCount;
    }

    public void setReconCount(Integer reconCount) {
        this.reconCount = reconCount;
    }
}
