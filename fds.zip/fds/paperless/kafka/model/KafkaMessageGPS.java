package com.optum.fds.paperless.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaMessageGPS {
    private String id;
    private String householdId;
    private String insuredPlanId;
    private String applicationId;
    private String type;
    private String effectiveDate;
    private String endDate;
    private String status;
    private String eventType;
    private String sourceType;
    private List<String> programNames;
    private List<ProviderGPS> providers;
    private Boolean attestationCompleted;
    private String firstName;

    public String getMbi() {
        return mbi;
    }

    public void setMbi(String mbi) {
        this.mbi = mbi;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    private String lastName;
    private String dateOfBirth;
    private String mbi;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHouseholdId() {
        return householdId;
    }

    public void setHouseholdId(String householdId) {
        this.householdId = householdId;
    }

    public String getInsuredPlanId() {
        return insuredPlanId;
    }

    public void setInsuredPlanId(String insuredPlanId) {
        this.insuredPlanId = insuredPlanId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public List<String> getProgramNames() {
        return programNames;
    }

    public void setProgramNames(List<String> programNames) {
        this.programNames = programNames;
    }

    public List<ProviderGPS> getProviders() {
        return providers;
    }

    public void setProviders(List<ProviderGPS> providers) {
        this.providers = providers;
    }

    public Boolean getAttestationCompleted() {
        return attestationCompleted;
    }

    public void setAttestationCompleted(Boolean attestationCompleted) {
        this.attestationCompleted = attestationCompleted;
    }

    @Override
    public String toString() {
        return "KafkaMessageGPS{" +
                "id='" + id + '\'' +
                ", householdId='" + householdId + '\'' +
                ", insuredPlanId='" + insuredPlanId + '\'' +
                ", applicationId='" + applicationId + '\'' +
                ", type='" + type + '\'' +
                ", effectiveDate='" + effectiveDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", status='" + status + '\'' +
                ", eventType='" + eventType + '\'' +
                ", sourceType='" + sourceType + '\'' +
                ", programNames=" + programNames +
                ", providers=" + providers +
                ", attestationCompleted=" + attestationCompleted +
                '}';
    }
}
