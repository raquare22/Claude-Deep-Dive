package com.optum.fds.paperless.kafka.model;

import java.util.List;

public class TrackitKafka {
    private String emailAddress;
    private List<Provider> provider;

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public List<Provider> getProvider() {
        return provider;
    }

    public void setProvider(List<Provider> provider) {
        this.provider = provider;
    }

}
