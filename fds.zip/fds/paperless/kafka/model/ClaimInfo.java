package com.optum.fds.paperless.kafka.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimInfo {

    @JsonProperty("TRN_ClaimInfoID")
    private String trn_ClaimInfoID;

    @JsonProperty("ProviderStatus")
    private String providerStatus;

    @JsonProperty("ClaimNumber")
    private String claimNumber;

    @JsonProperty("BillingTaxID")
    private String billingTaxID;

    @JsonProperty("MPIN")
    private String mpin;

    @JsonProperty("ClaimSystem")
    private String claimSystem;

    @JsonProperty("PatientID")
    private String patientID;

    public String getTrn_ClaimInfoID() {
        return trn_ClaimInfoID;
    }

    public void setTrn_ClaimInfoID(String trn_ClaimInfoID) {
        this.trn_ClaimInfoID = trn_ClaimInfoID;
    }

    public String getProviderStatus() {
        return providerStatus;
    }

    public void setProviderStatus(String providerStatus) {
        this.providerStatus = providerStatus;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public String getBillingTaxID() {
        return billingTaxID;
    }

    public void setBillingTaxID(String billingTaxID) {
        this.billingTaxID = billingTaxID;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public String getClaimSystem() {
        return claimSystem;
    }

    public void setClaimSystem(String claimSystem) {
        this.claimSystem = claimSystem;
    }

    public String getPatientID() {
        return patientID;
    }

    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }
// Getters and Setters
}

