package com.optum.fds.paperless.kafka.model;

public class RecordInfo {
    String recordID;
    String recordType;
    String recordLastUpdateDate;
    String encounterID;

    public String getRecordID() {
        return recordID;
    }

    public void setRecordID(String recordID) {
        this.recordID = recordID;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getRecordLastUpdateDate() {
        return recordLastUpdateDate;
    }

    public void setRecordLastUpdateDate(String recordLastUpdateDate) {
        this.recordLastUpdateDate = recordLastUpdateDate;
    }

    public String getEncounterID() {
        return encounterID;
    }

    public void setEncounterID(String encounterID) {
        this.encounterID = encounterID;
    }

	@Override
	public String toString() {
		return "RecordInfo [recordID=" + recordID + ", recordType=" + recordType + ", recordLastUpdateDate="
				+ recordLastUpdateDate + ", encounterID=" + encounterID + "]";
	}
    
    
}
