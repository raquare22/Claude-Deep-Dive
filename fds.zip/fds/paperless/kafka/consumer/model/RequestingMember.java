package com.optum.fds.paperless.kafka.consumer.model;

public class RequestingMember {
	
    private String memberIdCardNbr;
    private String firstName;
    private String lastName;
    private String dob;
    private String groupNumber;
    private String dependentSeqNbr;
    
	public String getMemberIdCardNbr() {
		return memberIdCardNbr;
	}
	public void setMemberIdCardNbr(String memberIdCardNbr) {
		this.memberIdCardNbr = memberIdCardNbr;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGroupNumber() {
		return groupNumber;
	}
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}
	public String getDependentSeqNbr() {
		return dependentSeqNbr;
	}
	public void setDependentSeqNbr(String dependentSeqNbr) {
		this.dependentSeqNbr = dependentSeqNbr;
	}
    
    

}
