package com.optum.fds.paperless.kafka.consumer.model;

public class MemberInfo {
	
	private RequestingMember requestingMember;
    private RequestedMember requestedMember;
    
	public RequestingMember getRequestingMember() {
		return requestingMember;
	}
	public void setRequestingMember(RequestingMember requestingMember) {
		this.requestingMember = requestingMember;
	}
	public RequestedMember getRequestedMember() {
		return requestedMember;
	}
	public void setRequestedMember(RequestedMember requestedMember) {
		this.requestedMember = requestedMember;
	}
    
    

}
