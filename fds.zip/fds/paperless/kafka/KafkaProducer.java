package com.optum.fds.paperless.kafka;
	
	import org.slf4j.Logger;
    import org.slf4j.LoggerFactory;
    import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.beans.factory.annotation.Value;
	import org.springframework.kafka.core.KafkaTemplate;
	import org.springframework.stereotype.Service;

	@Service
	public class KafkaProducer {

        private static final Logger logger = LoggerFactory.getLogger(KafkaProducer.class);

        @Autowired
		private KafkaTemplate<String, String> kafkaTemplate;

		public void send(String message,String topicName) {
            if (message == null || message.isEmpty()) {
                logger.error("KafkaProducer --> Cannot send null or empty message");
                throw new IllegalArgumentException("KafkaProducer --> Message cannot be null or empty");
            }

            if (topicName == null || topicName.isEmpty()) {
                logger.error("KafkaProducer --> Cannot send to null or empty topic");
                throw new IllegalArgumentException("KafkaProducer --> Topic name cannot be null or empty");
            }

            try {
                kafkaTemplate.send(topicName, message);
                logger.info("KafkaProducer --> Message sent successfully to topic: {}", topicName);
            } catch (Exception e) {
                logger.error("KafkaProducer --> Failed to send message to topic: {}, error: {}", topicName, e.getMessage(), e);
                throw new RuntimeException("Failed to send message to Kafka topic", e);
            }
        }
	}
