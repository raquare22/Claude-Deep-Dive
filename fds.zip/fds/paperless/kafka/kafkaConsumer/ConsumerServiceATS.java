package com.optum.fds.paperless.kafka.kafkaConsumer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.kafka.model.ATSKafka;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.ATS", havingValue = "true")
public class ConsumerServiceATS {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerServiceATS.class);
    @Autowired
    ErrorMetaDataService errorMetaDataService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Value("${PRUN.ATS_SPACEID}")
    private int ATS_SPACEID;

    @Value("${ATS_QUERY_TIME_WINDOW}")
    private int queryTimeWindow;

    @KafkaListener(
    		topics = "${spring.kafka.topic.ATSTwoWayTopic}", 
    		groupId = "${kafkaGroupIdATS}",
    	    properties = {
    	         		   "bootstrap.servers=${ATSBootstrapServers}",
    	         		   "ssl.keystore.location=${ATSconsumerKeystorePath}", 
    	         		   "ssl.keystore.password=${ATSconsumerkeystorePassword}", 
    	         		   "ssl.truststore.location=${ATSconsumertruststorelocation}", 
    	         		   "ssl.truststore.password=${ATSconsumertruststorePassword}"
    	     			}
    		
    		)
    public void consumeSecondary(ConsumerRecord<String, String> message) {
        LOGGER.info("ATS Kafka ConsumerService-->consumeSecondary-->message received from second kafka topic: key={}, value={}", message.key(), Encode.forJava(message.value()));
        processTopic(message);
    }


    @KafkaListener(
    		topics = "${spring.kafka.topic.ATSTopic}", 
    		groupId = "${kafkaGroupIdATS}",
    	    properties = {
     	         		   "bootstrap.servers=${ATSBootstrapServers}",
     	         		   "ssl.keystore.location=${ATSconsumerKeystorePath}", 
     	         		   "ssl.keystore.password=${ATSconsumerkeystorePassword}", 
     	         		   "ssl.truststore.location=${ATSconsumertruststorelocation}", 
     	         		   "ssl.truststore.password=${ATSconsumertruststorePassword}"
     	     			}
    		)
    public void consumePrimary(ConsumerRecord<String, String> message) {
        LOGGER.info("ATS Kafka ConsumerService-->consumePrimary-->message received from first kafka topic: key={}, value={}", message.key(), Encode.forJava(message.value()));

        List<DocumentMetaData> insertedDocList = new ArrayList<>();
        String metadataStr = null;

        DocumentMetaData document = null;

        String caseNumber = null;

        ObjectMapper objectMapper = new ObjectMapper();
        try {

            String kafkaMsgStr = message.value();

            String cleanedKafkaMsgStr = kafkaMsgStr.replace("\\\"", "");
            cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\T\\\\", "");
            cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\E\\\\", "");
            cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\", "");

            ATSKafka atsMsg = objectMapper.readValue(cleanedKafkaMsgStr, ATSKafka.class);

            caseNumber = atsMsg.getCaseInfo().getCaseNumber();

            Map<String, Object> kafkaMap = new HashMap<>();
            kafkaMap.put("kafkaMessage", atsMsg);
            kafkaMap.put("key", message.key());

            DocumentMetaData docMetadata = documentMetaDataService.getATSDocumentMetaData(caseNumber, ATS_SPACEID, queryTimeWindow);

            if ( docMetadata == null) {
                LOGGER.info("ATS KafkaConsumerService Primary --> document not already in Mongo, inserting, CaseNumber={}", Encode.forJava(caseNumber));

                TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.ATS_KAFKA_DOCUMENT.getTemplate());
                metadataStr = templateHandler.convertWithTemplate(kafkaMap);

                org.bson.Document metadata =  objectMapper.readValue(metadataStr, new TypeReference<org.bson.Document>(){});
                document = new DocumentMetaData();
                document.setMetadata(metadata);
                document.setStatus(MetaDataStatus.AVAILABLE);

                insertedDocList.add(document);

                if (CollectionUtils.isEmpty(insertedDocList)) {
                    LOGGER.warn("ATS KafkaConsumerService Primary -->Kafka Consumer-->documentMetaDataList is null or empty");
                    return;
                }
                documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, ATS_SPACEID);
                LOGGER.info("Kafka Consumer-ATS Primary - document inserted to mongodb: transactionId={}, caseNumber={}", Encode.forJava(message.key()), Encode.forJava(caseNumber));

            } else{
                LOGGER.info("ATS KafkaConsumerService Primary--> document already in Mongo, updating status, transactionId={}, CaseNumber={}", Encode.forJava(message.key()), Encode.forJava(caseNumber));
                // if the caseId record already exists in the DB, then set metadata with new values

                TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.ATS_KAFKA_DOCUMENT.getTemplate());
                metadataStr = templateHandler.convertWithTemplate(kafkaMap);
                org.bson.Document metadata =  objectMapper.readValue(metadataStr, new TypeReference<org.bson.Document>(){});
                docMetadata.setMetadata(metadata);
                documentMetaDataService.updateDocMetaData(docMetadata, docMetadata.getId());
                LOGGER.info("Kafka Consumer-ATS Primary - document status updated in MongoDB: transactionId={}, CaseNumber={}", Encode.forJava(message.key()), Encode.forJava(caseNumber));
            }

        } catch (Exception e) {
            LOGGER.error("ATS KafkaConsumerService --> unable to convert json string to documentMetaData, transactionId={}, caseNumber={}, e={}",
                    Encode.forJava(message.key()), Encode.forJava(caseNumber), ExceptionUtils.getStackTrace(e));
        }
    }

    private void processTopic(ConsumerRecord<String, String> message) {
        Map<String, Object> kafkaResponseMap = new HashMap<>();
        String key;
        DocumentMetaData docMetadata = null;
        Map<String, Object> twoWayStatus = new HashMap<>();

        try {
            kafkaResponseMap = objectMapper.readValue(message.value(), new TypeReference<>() {});
            key = message.key();

            twoWayStatus = objectMapper.readValue(objectMapper.writeValueAsString(kafkaResponseMap.get("TwoWayStatus")) , new TypeReference<>() {});

            Integer attemptNumber = 1;
            if (kafkaResponseMap.containsKey("CaseNumber")) {
                attemptNumber = (Integer) kafkaResponseMap.get("AttemptNumber");
            }
            Integer taskFlowId = (Integer) kafkaResponseMap.get("TRN_TaskFlowId");
            String appealStatus = (String) twoWayStatus.get("Value");
            String caseNumber = (String) kafkaResponseMap.get("CaseNumber");
            String submitterEmailAddress = null;

            if (kafkaResponseMap.containsKey("SubmitterEmailAddress")) {
                submitterEmailAddress = (String) kafkaResponseMap.get("SubmitterEmailAddress");
            }

            // get first document with that caseNumber to copy the metadata
            // queryTimeWindow is # of days to search back for documents with that caseNumber (i.e. -15 or -30 days)
            docMetadata = documentMetaDataService.getATSDocumentMetaData(caseNumber, ATS_SPACEID, queryTimeWindow);
            
            if (docMetadata == null) {
                LOGGER.error("ATS Kafka ConsumerService-->consumeSecondary --> documentMetaData not found in mongo, transactionId={}, CaseNumber={}", Encode.forJava(message.key()), Encode.forJava(caseNumber));
                return;
            }

            // every time we get a new record in the two way topic, we should insert a new record into db instead of updating existing documents
            // since we could get multiple messages in two way topic that have duplicate attemptNumber or taskFlowIds, all with the same caseNumber
            // for each case, we should send a separate email
                // attemptNumber 1, taskFlowId = 123
                // attemptNumber 1, taskFlowId = 456
                // attemptNumber 2, taskFlowId = 123
                // attemptNumber 2, taskFlowId = 456
            var metadata = docMetadata.getMetadata();

            metadata.put("attemptNumber", attemptNumber);
            metadata.put("taskFlowId", taskFlowId);
            metadata.put("caseStatus", appealStatus);
            if(submitterEmailAddress != null && !submitterEmailAddress.isEmpty()) {
                metadata.put("providerEmailId", submitterEmailAddress);
            }

            // remove any metadata fields added by PRUN if it exists
            metadata.remove("eDeliveryError");
            metadata.remove("dateEmailSent");
            metadata.remove("messageId");
            metadata.remove("prepostEnded");
            metadata.remove("sendEmailNotifications");
            metadata.remove("sendPENAPIRequest");
            metadata.remove("addedToResponseFile");

            DocumentMetaData newDoc = new DocumentMetaData();
            newDoc.setMetadata(metadata);

            newDoc.setStatus(MetaDataStatus.AVAILABLE);
            List<DocumentMetaData> insertedDocList = new ArrayList<>();
            insertedDocList.add(newDoc);

            documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, ATS_SPACEID);
            
        } catch (Exception e) {
            LOGGER.error("ATS Kafka ConsumerService-->consumeSecondary --> unable to convert json string to documentMetaData in processTopic, transactionId={}, e={}",
                    Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e));
        }

    }
}