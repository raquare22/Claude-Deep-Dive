package com.optum.fds.paperless.kafka.kafkaConsumer;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.kafka.model.KafkaMessageGPS;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.gps", havingValue = "true")
public final class GPSConsumerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GPSConsumerService.class);

    private static final String STATUS = "status";

    @Autowired
    ErrorMetaDataService errorMetaDataService;

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Value("${SSBCI_SPACEID}")
    private String ssbci_spaceId;

    @Value("${SSBCI_QUERY_TIME_WINDOW}")
    private int queryTimeWindow;

    @KafkaListener(

            topics = "${spring.kafka.topic.gps}",
            groupId = "${kafkaGroupIdGPS}",
            properties= {
                    "bootstrap.servers=${GPSKafkaConsumerBootstrapServers}",
                    "ssl.keystore.location=${GPSConsumerKeystorePath}",
                    "ssl.keystore.password=${GPSConsumerKeystorePassword}",
                    "ssl.truststore.location=${GPSConsumerTruststoreLocation}",
                    "ssl.truststore.password=${GPSConsumerTruststorePassword}"
            }
    )
    public void consume(ConsumerRecord<String, String> message) {
        LOGGER.info("KafkaConsumerService --> Kafka GPS Consumer -->message received: key={}, value={}",
                message.key(), Encode.forJava(message.value()));


        ObjectMapper mapper = new ObjectMapper();
        List<DocumentMetaData> insertedDocList = new ArrayList<>();
        String metadataListStr = null;
        List<DocumentMetaData> existingDocMetadata = null;
        DocumentMetaData document = null;
        try {
            String cleanedMessageValue = org.apache.commons.text.StringEscapeUtils.unescapeJava(message.value());
            KafkaMessageGPS kafkaMessageGPS = mapper.readValue(cleanedMessageValue, KafkaMessageGPS.class);
            Map<String, Object> kafkaResponseMap = new HashMap<>();
            kafkaResponseMap.put("kafkaMessage", kafkaMessageGPS);
            kafkaResponseMap.put("key", message.key());

            TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.GPS_KAFKA_DOCUMENT.getTemplate());
            metadataListStr = templateHandler.convertWithTemplate(kafkaResponseMap);
            List<org.bson.Document> metadataList = mapper.readValue(metadataListStr, new TypeReference<List<org.bson.Document>>(){});

            for (org.bson.Document metadata : metadataList) {
                if(validateDocument(metadata, message.key()))
                {
                    document = new DocumentMetaData();
                    document.setMetadata(metadata);
                    document.setStatus(MetaDataStatus.AVAILABLE);
                    insertedDocList.add(document);
                }
                else {
                    LOGGER.warn("Kafka GPS Consumer --> Metadata validation failed for Transaction Key={}", Encode.forJava(message.key()));
                }
            }

            existingDocMetadata = documentMetaDataService.getGPSDocumentMetaData(message.key(), Integer.parseInt(ssbci_spaceId), queryTimeWindow);
            if (existingDocMetadata != null && !existingDocMetadata.isEmpty()) {
                updateGPSMetadataStatus(existingDocMetadata, metadataList.get(0), message.key());
                return;
            }
            LOGGER.info("Kafka GPS Consumer -->No document in mongo for Transaction Key={}", Encode.forJava(message.key()));

        } catch (Exception e) {
            LOGGER.error("KafkaConsumerService --> Kafka GPS Consumer --> unable to convert json string to documentMetaData, kafkaKey={}, e={}",
                    Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e));
        }
        if (CollectionUtils.isEmpty(insertedDocList)) {
            LOGGER.warn("KafkaConsumerService --> Kafka GPS Consumer-->documentMetaDataList is null or empty");
            return;
        }
        documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, Integer.parseInt(ssbci_spaceId));
        LOGGER.info("Kafka GPS Consumer --> document inserted to mongodb: transactionId={}", message.key());

    }

    private void updateGPSMetadataStatus(List<DocumentMetaData> existingDocMetadataList, Document metadata, String key) {
        try {
            if (existingDocMetadataList == null || existingDocMetadataList.isEmpty() || metadata == null) {
                LOGGER.info("Kafka GPS Consumer --> nothing to update for transactionKey={}", Encode.forJava(key));
                return;
            }

            String newStatus = metadata.getString(STATUS);
            Object newAttestation = metadata.get(Workflow.ATTESTATION_COMPLETED);

            for (DocumentMetaData existingDoc : existingDocMetadataList) {
                try {
                    Document existingMetadata = existingDoc.getMetadata();
                    boolean changed = false;

                    String existingStatus = existingMetadata.getString(STATUS);
                    if (newStatus != null && !newStatus.equals(existingStatus)) {
                        existingMetadata.put(STATUS, newStatus);
                        changed = true;
                    }

                    if (existingMetadata.get(Workflow.ATTESTATION_COMPLETED) == null && newAttestation != null) {
                        existingMetadata.put(Workflow.ATTESTATION_COMPLETED, newAttestation);
                        changed = true;
                    }

                    if (changed) {
                        existingDoc.setMetadata(existingMetadata);
                        documentMetaDataService.saveDocumentMetaData(existingDoc);
                        LOGGER.info("Kafka GPS Consumer --> updated metadata for documentId={}, transactionKey={}, newStatus={}", existingDoc.getId(), Encode.forJava(key), Encode.forJava(newStatus));
                    } else {
                        LOGGER.info("Kafka GPS Consumer --> no metadata change for documentId={}, transactionKey={}", existingDoc.getId(), Encode.forJava(key));
                    }

                } catch (Exception ex) {
                    LOGGER.error("Kafka GPS Consumer --> unable to update a metadata entry for transactionKey={}, documentId={}, e={}",
                            Encode.forJava(key),
                            existingDoc.getId(),
                            ExceptionUtils.getStackTrace(ex));
                }
            }
        } catch (Exception e) {
            LOGGER.error("Kafka GPS Consumer --> unable to update metadata status for transactionKey={}, e={}",
                    Encode.forJava(key), ExceptionUtils.getStackTrace(e));
        }
    }

    private boolean validateDocument(Document metadata, String key) {
        if (metadata == null || metadata.isEmpty()) {
            LOGGER.warn("Kafka GPS Consumer --> documentMetaData or metadata is null for Transaction Key={}", Encode.forJava(key));
            return false;
        }
        return validateStatus(metadata) && validateMetadataFields(metadata, key);
    }

    private boolean validateStatus(Document metadata) {
        String status = metadata.getString(STATUS);
        String eventType = metadata.getString("eventType");

        return (Workflow.ELECTRONIC_OUTREACH.equals(status) && Workflow.INITIATE_OUTREACH.equals(eventType)) ||
                (Workflow.MANUAL_OUTREACH.equals(status) && Workflow.INITIATE_OUTREACH.equals(eventType)) ||
                (Workflow.VERIFIED.equals(status) && Workflow.VERIFIED.equals(eventType)) ||
                (Workflow.TERMED.equals(status) && Workflow.TERMED.equals(eventType));
    }

    private boolean validateMetadataFields(Document metadata, String key) {
        String[] requiredFields = {"id", "effectiveDate", "endDate", "mbi", "firstName", "lastName", "dateOfBirth", "providers"};
        String[] requiredProviderFields = {"taxId", "providerId", "pcpName"};
        for (String field : requiredFields) {
            if (!metadata.containsKey(field) || metadata.get(field) == null) {
                LOGGER.warn("Kafka GPS Consumer --> Missing or empty required field: {}, Transaction Key: {}", field, Encode.forJava(key));
                return false;
            }
            if (metadata.get(field).toString().isEmpty()) {
                LOGGER.warn("Kafka GPS Consumer --> Missing or empty required field: {}, Transaction Key: {}", field, Encode.forJava(key));
                return false;
            }

        }
        Object providersObj = metadata.get("providers");
        if (providersObj == null ) {
            LOGGER.warn("Kafka GPS Consumer --> Missing providers obj, Transaction Key: {}", Encode.forJava(key));
            return false;
        }
        HashMap<String, String> provider;
        try {
            provider = (HashMap<String, String>) providersObj;
        } catch (ClassCastException e) {
            LOGGER.warn("Kafka GPS Consumer --> invalid providers obj, Transaction Key: {}", Encode.forJava(key));
            return false;
        }
        for (String field : requiredProviderFields) {
            if (!provider.containsKey(field) || provider.get(field) == null || provider.get(field).isEmpty()) {
                LOGGER.warn("Kafka GPS Consumer --> Missing or empty provider required field: {}, Transaction Key: {}", field, Encode.forJava(key));
                return false;
            }
        }

        // Validate endDate > current date
        String endDateStr = metadata.getString("endDate");
        try {
            java.time.LocalDate endDate = java.time.LocalDate.parse(endDateStr);
            if (!endDate.isAfter(java.time.LocalDate.now())) {
                return false;
            }
        } catch (Exception e) {
            LOGGER.warn("Kafka GPS Consumer --> Exception parsing date string, Transaction Key: {}", Encode.forJava(key));
            return false;
        }

        return true;
    }


}
