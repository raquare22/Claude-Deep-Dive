package com.optum.fds.paperless.kafka.kafkaConsumer;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;
import org.json.JSONException;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.adt_cns", havingValue = "true")
public final class ADTCNSConsumerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ADTCNSConsumerService.class);
    @Autowired
    ErrorMetaDataService errorMetaDataService;

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Value("${PRUN.ADT_CNS_SPACEID}")
    private int ADT_CNS_SPACEID;

    @KafkaListener(topics = "${spring.kafka.topic}", groupId = "${kafkaGroupId}")
    public void consume(ConsumerRecord<String, String> message) {

        List<DocumentMetaData> insertedDocList = new ArrayList<>();
        String metadataListStr = null;

        DocumentMetaData document = null;
        try {

            Map<String, Object> kafkaResponseMap = new HashMap<>();
            kafkaResponseMap.put("kafkaResponse", message.value());
            kafkaResponseMap.put("key", message.key());

            ObjectMapper mapper = new ObjectMapper();

            TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.CNS_KAFKA_MESSAGE.getTemplate());
            metadataListStr = templateHandler.convertWithTemplate(kafkaResponseMap);

            List<org.bson.Document> metadataList = mapper.readValue(metadataListStr, new TypeReference<List<org.bson.Document>>(){});

            for (org.bson.Document metadata : metadataList) {
                document = new DocumentMetaData();

                document.setMetadata(metadata);
                document.setStatus(MetaDataStatus.AVAILABLE);

                insertedDocList.add(document);

            }

        } catch (Exception e) {
            LOGGER.error("ADTCNSConsumerService --> unable to convert json string to documentMetaData, kafkaKey={}, e={}",
                    Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e));
        }
        if (CollectionUtils.isEmpty(insertedDocList)) {
            LOGGER.warn("ADTCNSConsumerService-->Kafka Consumer-->documentMetaDataList is null or empty");
            return;
        }
        documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, ADT_CNS_SPACEID);
        LOGGER.info("Kafka Consumer-ADT_CNS - document inserted to mongodb: transactionId={}", message.key());

    }
}
