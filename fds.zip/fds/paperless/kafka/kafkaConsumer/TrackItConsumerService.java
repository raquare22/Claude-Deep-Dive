package com.optum.fds.paperless.kafka.kafkaConsumer;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.kafka.model.TrackitKafka;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.TrackIt", havingValue = "true")
public final class TrackItConsumerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrackItConsumerService.class);

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Value("${PRUN.TRACKIT_SPACEID}")
    private int TrackIt_SPACEID;

    @KafkaListener(
            topics = "${spring.kafka.topic.trackit}",
            groupId = "${kafkaGroupIdTrackIt}",
            properties = {
                    "bootstrap.servers=${TrackItBootstrapServers}",
                    "ssl.keystore.location=${TrackItconsumerKeystorePath}",
                    "ssl.keystore.password=${TrackItconsumerkeystorePassword}",
                    "ssl.truststore.location=${TrackItconsumertruststorelocation}",
                    "ssl.truststore.password=${TrackItconsumertruststorePassword}"
            }
    )
    public void consume(ConsumerRecord<String, String> message) {
        List<DocumentMetaData> insertedDocList = new ArrayList<>();
        String metadataStr = null;

        DocumentMetaData document = null;
        try {
            ObjectMapper mapper = new ObjectMapper();
            TrackitKafka trackitKafka = mapper.readValue(message.value(), TrackitKafka.class);

            validateTrackItMessage(trackitKafka);

            Map<String, Object> kafkaResponseMap = new HashMap<>();
            kafkaResponseMap.put("kafkaResponse", message.value());

            TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.TRACKIT_KAFKA_TEMPLATE.getTemplate());
            metadataStr = templateHandler.convertWithTemplate(kafkaResponseMap);

            Document metadata = mapper.readValue(metadataStr, Document.class);
            document = new DocumentMetaData();
            document.setMetadata(metadata);
            document.setStatus(MetaDataStatus.AVAILABLE);

            insertedDocList.add(document);

            LOGGER.info("TrackItConsumerService --> Successfully processed message for email: {}", trackitKafka.getEmailAddress());

        } catch (JsonParseException e) {
            LOGGER.error("TrackItConsumerService --> Invalid JSON format in Kafka message: key={}, value={}, error={}",
                    Encode.forJava(message.key()), message.value(), ExceptionUtils.getStackTrace(e));
            return;
        } catch (IllegalArgumentException e) {
            LOGGER.error("TrackItConsumerService --> Validation failed for Kafka message: key={}, error={}, message={}",
                    Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e), e.getMessage());
            return;
        } catch (Exception e) {
            LOGGER.error("TrackItConsumerService --> Parsing/conversion failure for Kafka message: key={}, error={}, message={}",
                    Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e), e.getMessage());
        }

        if (CollectionUtils.isEmpty(insertedDocList)) {
            LOGGER.warn("TrackItConsumerService --> documentMetaDataList is null or empty");
            return;
        }

        try {
            documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, TrackIt_SPACEID);
            LOGGER.info("TrackItConsumerService --> Document inserted to MongoDB: transactionId={}", message.key());
        } catch (Exception e) {
            LOGGER.error("TrackItConsumerService --> Failed to insert documents to MongoDB: transactionId={}, error={}",
                    message.key(), ExceptionUtils.getStackTrace(e));
        }
    }

    private void validateTrackItMessage(TrackitKafka trackitKafka) {
        if (trackitKafka == null) {
            LOGGER.error("TrackItConsumerService --> Received TrackitKafka message cannot be null");
            throw new IllegalArgumentException("TrackitKafka message cannot be null");
        }

        if (trackitKafka.getEmailAddress() == null || trackitKafka.getEmailAddress().isEmpty()) {
            LOGGER.error("TrackItConsumerService --> Email address is required in message");
            throw new IllegalArgumentException("Email address is required");
        }

        if (trackitKafka.getProvider() == null || trackitKafka.getProvider().isEmpty()) {
            LOGGER.error("TrackItConsumerService --> At least one provider is required in message");
            throw new IllegalArgumentException("At least one provider is required");
        }

        trackitKafka.getProvider().forEach(provider -> {
            if (provider.getProviderTin() == null || provider.getProviderTin().isEmpty()) {
                LOGGER.error("TrackItConsumerService --> Provider TIN is required for each provider");
                throw new IllegalArgumentException("Provider TIN is required");
            }
            if (provider.getMpin() == null || provider.getMpin().isEmpty()) {
                LOGGER.error("TrackItConsumerService --> Provider MPIN is required for each provider");
                throw new IllegalArgumentException("Provider MPIN is required");
            }
        });
    }
}
