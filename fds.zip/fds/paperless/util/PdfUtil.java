package com.optum.fds.paperless.util;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.io.RandomAccessRead;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PdfUtil {

    private final float fontSize;
    private final double xCoordinate;
    private final double yCoordinate;
    private final String pdfFile;
    private final String outputPdf;
    private final String receiverAddressIdentifier;

    private PdfUtil(PdfUtilBuilder pdfUtilBuilder) {

        this.xCoordinate = pdfUtilBuilder.xCoordinate;
        this.yCoordinate = pdfUtilBuilder.yCoordinate;
        this.fontSize = pdfUtilBuilder.fontSize;
        this.receiverAddressIdentifier = pdfUtilBuilder.receiverAddressIdentifier;
        this.pdfFile = pdfUtilBuilder.pdfFile;
        this.outputPdf = pdfUtilBuilder.outputPdf;
    }

    public static class PdfUtilBuilder {
        private float fontSize;
        private double xCoordinate;
        private double yCoordinate;
        private String pdfFile;
        private String outputPdf;
        private String receiverAddressIdentifier;

        public PdfUtilBuilder setFontSize(float fontSize) {
            this.fontSize = fontSize;
            return this;
        }

        public PdfUtilBuilder setxCoordinate(double xCoordinate) {
            this.xCoordinate = xCoordinate;
            return this;
        }

        public PdfUtilBuilder setyCoordinate(double yCoordinate) {
            this.yCoordinate = yCoordinate;
            return this;
        }

        public PdfUtilBuilder setPdfFile(String pdfFile) {
            this.pdfFile = pdfFile;
            return this;
        }

        public PdfUtilBuilder setOutputPdf(String outputPdf) {
            this.outputPdf = outputPdf;
            return this;
        }

        public PdfUtilBuilder setReceiverAddressIdentifier(String receiverAddressIdentifier) {
            this.receiverAddressIdentifier = receiverAddressIdentifier;
            return this;
        }

        public PdfUtil build() {
            return new PdfUtil(this);
        }

        public String getReceiverAddressIdentifier() {
            return receiverAddressIdentifier;
        }
    }

    public void writeOnPdf() throws IOException  {
            try ( PDDocument document = Loader.loadPDF(new File(pdfFile))) {
                PDPageTree pages = document.getPages();
                PDPage firstPage = pages.get(0);
                PDRectangle rectangle = firstPage.getMediaBox();

                if (rectangle.getHeight() >= rectangle.getWidth()) {
                    portrait(document, pages);
                } else {
                    landscape(document, pages);
                }
                document.save(outputPdf);
            } catch (IOException e) {
                throw new IOException("IOException on input file " + pdfFile, e);
                      }
    }

    public void writeOnEncryptedPdf() throws IOException {
        var encryptedPdf = new File(pdfFile);
        PDDocument document = Loader.loadPDF(encryptedPdf);
        document.setAllSecurityToBeRemoved(true);
        document.save(encryptedPdf);
        document.close();
        writeOnPdf();
    }

    public void portrait(PDDocument document, PDPageTree pages) throws IOException {

    	PDFont font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        float fontSize = 8;

        double pdfPageHeight = pages.get(0).getMediaBox().getHeight();
        double pdfPageWidth = pages.get(0).getMediaBox().getWidth();

        int upperRightX = (int) Math.ceil(pdfPageWidth - 190);
        int upperRightY = (int) Math.ceil(pdfPageHeight - (pdfPageHeight - 6));

        int lowerLeftX = (int) Math.ceil(pdfPageWidth - 40);
        int lowerLeftY = (int) Math.ceil(pdfPageHeight - (pdfPageHeight - 26));

        for (var i = 0; i <= pages.getCount(); i++) {
            PDPage page = pages.get(0);
            try(PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true)) {

                contentStream.beginText();
                contentStream.setFont(font, fontSize);
                contentStream.newLineAtOffset((int) Math.ceil(xCoordinate * 79), (int) Math.ceil(yCoordinate * 414.10));
                contentStream.showText(receiverAddressIdentifier);
                contentStream.endText();

                    PDRectangle rect = new PDRectangle(lowerLeftX, lowerLeftY, upperRightX - lowerLeftX, upperRightY - lowerLeftY);
                    contentStream.setNonStrokingColor(1, 1, 1);
                    contentStream.addRect(rect.getLowerLeftX(), rect.getLowerLeftY(), rect.getWidth(), rect.getHeight());
                    contentStream.fillAndStroke();
                }
            }
    }

    public void landscape(PDDocument document, PDPageTree pages) throws IOException {

        PDFont font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        float fontSize = 8;

        double pdfPageHeight = pages.get(0).getMediaBox().getHeight();
        double pdfPageWidth = pages.get(0).getMediaBox().getWidth();

        int upperRightX = (int) Math.ceil(pdfPageWidth - 190);
        int upperRightY = (int) Math.ceil(pdfPageHeight - (pdfPageHeight - 6));

        int lowerLeftX = (int) Math.ceil(pdfPageWidth - 40);
        int lowerLeftY = (int) Math.ceil(pdfPageHeight - (pdfPageHeight - 26));

        for (var i = 0; i <= pages.getCount(); i++) {
            PDPage page = pages.get(0);
            try(PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true)) {

                contentStream.beginText();
                contentStream.setFont(font, fontSize);
                contentStream.newLineAtOffset((int) Math.ceil((xCoordinate - .1) * 80), (int) Math.ceil((yCoordinate - .1) * 414.10 - 139));
                contentStream.showText(receiverAddressIdentifier);
                contentStream.endText();

                PDRectangle rect = new PDRectangle(lowerLeftX, lowerLeftY, upperRightX - lowerLeftX, upperRightY - lowerLeftY);
                contentStream.setNonStrokingColor(1, 1, 1);
                contentStream.addRect(rect.getLowerLeftX(), rect.getLowerLeftY(), rect.getWidth(), rect.getHeight());
                contentStream.fillAndStroke();
            }
        }
    }
}
