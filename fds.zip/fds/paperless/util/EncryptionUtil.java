////package com.optum.fds.paperless.processorlistener.util;
package com.optum.fds.paperless.util;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.BlowfishEngine;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class EncryptionUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(EncryptionUtil.class);

    private static final String CLEF_VAL_PHRASE = "Tw0 r0aDs div3rg3d in a y3l10w wo0d";
    private static final String SLAT1 = "S0 thEy pArtEd; aNd the y0uNg mAn pUrSU3d hI3, ";

    /**
     * This is for use by external users only.
     * 
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) {
        try {
            if (args != null && args.length > 1) {
                printInput(args);
                if ("encrypt".equalsIgnoreCase(args[0])) {
                    if (args.length > 2) {
                       encrypt(args[1], args[2]);
                    } else {
                      encrypt(args[1]);
                    }
                }
                else if ("decrypt".equalsIgnoreCase(args[0])) {
                    if (args.length > 2) {
                      decrypt(args[2], args[1]);
                    } else {
                        decrypt(args[1]);
                    }
                }
                else {
                    LOGGER.debug("Usage: encrypt/decrypt stringToEncryptOrDecrypt optionlSalt");
                }
            }
            else {
                LOGGER.debug("Usage: encrypt/decrypt stringToEncryptOrDecrypt optionlSalt");
                LOGGER.debug("If you are using a salt and decrypting use the same salt you used to encrypt");
            }
        } catch (Exception e) {
            LOGGER.warn("Encrypt or Decrypt exception {}",
                    ExceptionUtils.getStackTrace(e));
        }
    }

    private static void printInput(String[] args) {
        if (args != null && args.length > 2) {
            LOGGER.debug("Here is the input: Operation {} StringToEncrypt:{} salt: {} ", args[0], args[1], args[2]);
        } else if (args != null && args.length > 1) {
            LOGGER.debug("Here is the input: Operation:{} StringToEncrypt:{} ", args[0], args[1]);
        }
    }

    /**
     * @param salt
     * @param input
     * @return
     * @throws Exception
     */
    public static String encrypt(String salt, String input) throws Exception {
        BlowfishEngine engine = new BlowfishEngine();
        PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(engine);
        KeyParameter key = new KeyParameter(CLEF_VAL_PHRASE.getBytes());
        cipher.init(true, key);
        byte[] in = (salt + input).getBytes();
        byte[] out = new byte[cipher.getOutputSize(in.length)];
        int len1 = cipher.processBytes(in, 0, in.length, out, 0);
        try {
            cipher.doFinal(out, len1);
        } catch (Exception e) {
            LOGGER.error("encrypt {}={}, {}={} {}",
            		"salt", salt,
            		"input", input,
                    ExceptionUtils.getStackTrace(e));
            throw new Exception(e.getMessage(), e);
        }
        return new String(Base64.encode(out));
    }

    /**
     * uses a default salt
     * 
     * @param input
     * @return
     * @throws Exception
     */
    public static String encrypt(String input) throws Exception {
        return EncryptionUtil.encrypt(SLAT1, input);
    }

    /**
     * @param salt
     * @param encryptedString
     * @return
     * @throws InvalidCipherTextException
     * @throws IllegalStateException
     * @throws DataLengthException
     */
    public static String decrypt(String salt, String encryptedString) throws DataLengthException, IllegalStateException, InvalidCipherTextException {
        BlowfishEngine engine = new BlowfishEngine();
        PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(engine);
        StringBuilder result = new StringBuilder();
        KeyParameter key = new KeyParameter(CLEF_VAL_PHRASE.getBytes());
        cipher.init(false, key);
        byte[] out = Base64.decode(encryptedString);
        byte[] out2 = new byte[cipher.getOutputSize(out.length)];
        int len2 = cipher.processBytes(out, 0, out.length, out2, 0);
        cipher.doFinal(out2, len2);
        String s2 = new String(out2);
        for (int i = 0; i < s2.length(); i++) {
            char c = s2.charAt(i);
            if (c != 0) {
                result.append(c);
            }
        }
        return result.toString().replace(salt, "");
    }

    /**
     * uses default salt
     * 
     * @param encryptedString
     * @return
     * @throws InvalidCipherTextException
     * @throws IllegalStateException
     * @throws DataLengthException
     */
    public static String decrypt(String encryptedString) throws DataLengthException, IllegalStateException, InvalidCipherTextException {
        return EncryptionUtil.decrypt(SLAT1, encryptedString);
    }
}