////package com.optum.fs.handlebar.helper;
package com.optum.fds.paperless.util.handlebar.helper;

import java.io.IOException;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.jknack.handlebars.Helper;
import com.github.jknack.handlebars.Options;
import com.google.common.base.Strings;

public class UHCWestFixedWidthHelper implements Helper<Object> {

	private static final Logger LOGGER = LoggerFactory.getLogger(UHCWestFixedWidthHelper.class);
	private static final String LEFT = "L";
	private static final String RIGHT = "R";
	String mpinResult = null;
	String mpinValue = null;

	@Override
	public CharSequence apply(Object context, Options options) throws IOException {

		try {
			mpinValue = (context == null) ? "" : context.toString();

			String lengthChar = Optional.ofNullable(options.param(0)).map(obj -> obj.toString())
					.orElse(StringUtils.EMPTY);

			String paddingString = Optional.ofNullable(options.param(1)).map(obj -> obj.toString())
					.orElse(StringUtils.EMPTY);

			String align = Optional.ofNullable(options.param(2)).map(obj -> obj.toString()).orElse(StringUtils.EMPTY);

			String truncDirection = Optional.ofNullable(options.param(3)).map(obj -> obj.toString())
					.orElse(StringUtils.EMPTY);

			if (StringUtils.isEmpty(mpinValue)) {
				return mpinResult;
			} else {

				int length = Integer.parseInt(lengthChar);

				if (mpinValue.length() > length) {

					mpinResult = truncDirection(length, truncDirection);

				} else if (mpinValue.length() == length) {

					mpinResult = mpinValue;

				} else {

					if (!StringUtils.isEmpty(paddingString)) {
						char paddingChar = (!StringUtils.isEmpty(paddingString)) ? paddingString.charAt(0): Character.MIN_VALUE;
						mpinResult = addPadding(length, paddingChar, align);
					} else {
						mpinResult = mpinValue;
					}

				}
				return mpinResult;

			}
		} catch (NumberFormatException e) {
			LOGGER.warn("apply Number Format Exception {}={}, {}={} {}", "mpinValue", mpinValue, "mpinResult",
					mpinResult, ExceptionUtils.getStackTrace(e));
			return mpinResult;
		} catch (Exception e) {
			LOGGER.warn("apply truncate {}={}, {}={} {}", "mpinValue", mpinValue, "mpinResult", mpinResult,
					ExceptionUtils.getStackTrace(e));
			return mpinResult;
		}
	}

	private String truncDirection(int length, String truncDirection) {
		if (truncDirection.equalsIgnoreCase(LEFT)) {
			mpinResult = StringUtils.right(mpinValue, length);
		} else if (truncDirection.equalsIgnoreCase(RIGHT)) {
			mpinResult = StringUtils.left(mpinValue, length);
		}
		return mpinResult;
	}

	private String addPadding(int length, char paddingChar, String align) {
		if (align.equalsIgnoreCase(LEFT)) {
			mpinResult = Strings.padStart(mpinValue, length, paddingChar);
		} else if (align.equalsIgnoreCase(RIGHT)) {
			mpinResult = Strings.padEnd(mpinValue, length, paddingChar);
		}
		return mpinResult;
	}
}
