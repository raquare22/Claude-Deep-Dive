package com.optum.fds.paperless.util;

public class StringUtils {
	public static String format(String[] strArr) {
		StringBuffer strBuff = new StringBuffer();
		for(int i=0; i<strArr.length; i++) {
			if(i>0) {
				strBuff.append(" ");
			}
			strBuff.append(strArr[i]);
		}
		return strBuff.toString();
	}
	public static  boolean isNullOrEmpty(String str) {
		if(str == null || str.trim().equals("") ) {
			return true;
		}
		return false;
	}

}
