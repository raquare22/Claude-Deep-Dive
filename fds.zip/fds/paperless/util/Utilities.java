/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 2/23/17.
 */

package com.optum.fds.paperless.util;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class Utilities {
    private static Utilities instance;

    private static final Logger LOGGER = LoggerFactory.getLogger(Utilities.class);
    private static final byte[] WRITE_BUFFER = new byte[1024];
    
    private static final String LOCK_FILE_NAME = "locked.txt";

    protected Utilities() {
    }

    /**
     * This method creates a temporary directory in the system's temp folder
     * using the provided preFix name as a prefix.
     * 
     * @param preFix
     * @return
     * @throws IOException
     */
    public static Path createWorkingDirectory(String preFix, String tempDirRoot) throws IOException {
        LOGGER.trace("Creating working directory for {}", preFix);

        return Files.createTempDirectory(Paths.get(tempDirRoot), preFix);
    }

    public static Path createWorkingDirectory(String tempDirRoot) throws IOException {
        LOGGER.debug("Creating working directory for {}", tempDirRoot);

        return Files.createDirectories(Paths.get(tempDirRoot));
    }

    public static Path createWorkingDirectoryWithParams(String delimiter, String...elements) throws IOException {
        return createWorkingDirectory(String.join(delimiter, elements));
    }

    public static boolean deleteWorkingDirectory(String workingDirecory) {
        var toReturn = true;
        try {
            final var workingDirectoryPath = Paths.get(workingDirecory);
            toReturn = deleteWorkingDirectory(workingDirectoryPath);
        } catch (Exception e) {
        	LOGGER.error("deleteWorkingDirectory {}={} {}",
        			"workingDirectory", workingDirecory,
        			ExceptionUtils.getStackTrace(e));
        }
        return toReturn;
    }

    public static boolean deleteWorkingDirectory(Path workingDirectory) throws IOException {
        final var toReturn = new boolean[]{true};
        LOGGER.info("Deleting working directory {}", workingDirectory);
		try (Stream<Path> paths = Files.walk(workingDirectory, FileVisitOption.FOLLOW_LINKS)) {
			paths.forEach(path -> {
				if (!path.toFile().isDirectory()) {
					try {
						Files.delete(path);
					} catch (Exception e) {
						LOGGER.error("deleteWorkingDirectory: {}={} {}",
			        			"path", path, ExceptionUtils.getStackTrace(e));
						toReturn[0] = false;
					}
				}

			});
		}catch (Exception e) {
			LOGGER.error("deleteWorkingDirectory: {}={} {}",
        			"workingDirectory", workingDirectory, ExceptionUtils.getStackTrace(e));
			toReturn[0] = false;
		}
		return toReturn[0];
    }

    public static void expandFile(File zipFile, File destination) throws IOException {
        expandFile(zipFile.toPath(), destination.toPath());
    }

    public static void expandFile(File zipFile, Path destination) throws IOException {
        expandFile(zipFile.toPath(), destination);
    }

    public static void expandFile(Path zipFile, File destination) throws IOException {
        expandFile(zipFile, destination.toPath());
    }
    
	public static boolean checkAndCreateLockFile(String filePath) throws IOException {
		LOGGER.debug("filePath={}", filePath);
		var lockFile = new File(filePath, LOCK_FILE_NAME);
		var lockFileAlreadyExists = lockFile.exists();
		if (lockFileAlreadyExists) {
			return true;
		} else {
            lockFileAlreadyExists = !createLockFile(filePath);
		}
		return lockFileAlreadyExists;
	}
    
    public static boolean createLockFile(String destination) throws IOException {
    	var lockFile = new File(destination, LOCK_FILE_NAME);
    	return touch(lockFile);
    }
    
    public static boolean touch(File file) throws IOException{
        if (!file.exists()) {
        	try(OutputStream is = new BufferedOutputStream(Files.newOutputStream(file.toPath()))){
        		return true;
        	}
        }
        LOGGER.warn("Attempting to create a file which already exists: {}", file.getAbsolutePath());
        return false;
    }

    public static synchronized boolean expandFile(Path zipFile, Path destination) throws IOException {
        
    	// generate lock file for downstream processes to know this has already been done
		if (checkAndCreateLockFile(destination.toString())) { return true; }
		
        LOGGER.debug("Unzipping {} to {}", zipFile, destination);
        
        // generate lock file for downstream processess to know this has already been done
      	try (InputStream is = new BufferedInputStream(Files.newInputStream(zipFile))) {
      	
          // Getting Zip File
          try (var zipInputStream = new ZipInputStream(is)) {


                // Getting first preFix in zip
                var zipEntry = zipInputStream.getNextEntry();

                // Extracting all files
                var i = 0;
                try {
                    while (zipEntry != null) {
                        var destinationFile = new File(destination.toString(), zipEntry.getName());
                        if (!destinationFile.toPath().normalize().startsWith(destination.toAbsolutePath()))
                            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
                        writeFile(zipInputStream, destinationFile);
                        zipEntry = zipInputStream.getNextEntry();
                        i++;
                    }
                }
                catch (IOException e) {
                    LOGGER.error("Zip extraction error; Entries processed={}; Last zipEntry processed: {}", i, getZipEntryInfo(zipEntry));
                    throw e;
                }

                LOGGER.info("Unzipping of {} to {} complete.", zipFile, destination);

            }
        }
        return false;
    }
    
    static void writeFile(ZipInputStream zipInputStream, File destinationFile) {
        if (isZipSlip(destinationFile)) {
            return;
        }
    	 try (OutputStream fileOutputStream = new BufferedOutputStream(Files.newOutputStream(destinationFile.toPath())) ){

            int length;
            while ((length = zipInputStream.read(WRITE_BUFFER)) > 0) {
                fileOutputStream.write(WRITE_BUFFER, 0, length);
            }
            fileOutputStream.flush();
        } catch (FileNotFoundException e) {
            LOGGER.warn("writeFile File not found {}={} {}",
            		"destinationFile", destinationFile.getName(),
            		ExceptionUtils.getStackTrace(e));
        } catch (Exception e) {
            LOGGER.error("writeFile {}={} {}",
            		"destinationFile", Optional.ofNullable(destinationFile).map(File::getName).orElse("NULL"),
                    ExceptionUtils.getStackTrace(e));
        }
    }

 // Check the destinationFile is not outside of the target e.g it must not begin with ../
 	public static boolean isZipSlip(File destinationFile) {
 		String canonicalPath;
 		File normalizedFile=destinationFile.toPath().normalize().toFile();
 		try {
 			canonicalPath = getCanonicalPaths(normalizedFile);
 		} catch (IOException e) {
 			LOGGER.error("destinationFile={}: {}; {}", destinationFile, e.getClass().getSimpleName(), e.getMessage());
 			return true;
 		}
 		String destinationPath = normalizedFile.getPath();
 		if (!canonicalPath.startsWith(destinationPath) ) {
 			// If the path is a link it will fail
 			LOGGER.error("ZIP SLIP: Entry is outside of the target dir: destinationFile={}, canonicalPath={}, destinationPath={}", destinationFile, canonicalPath, destinationPath);
 			return true;
 		}
 		return false;
 	}
 	
 	public static String getCanonicalPaths(File file) throws IOException
 	{
 		return file.getCanonicalPath(); 
 	}

    public static synchronized Utilities getInstance() {
        if (instance == null) {
            instance = new Utilities();
        }
        return instance;
    }

    public static String getFileExtension(String fileName) {
        final Integer startPos = fileName.lastIndexOf('.');
        if (startPos > 0) {
        	fileName = fileName.substring(startPos + 1, fileName.length()).toLowerCase();
        }

        return fileName;
    }

    public static Map<String, Object> getFileInformation(File file) {
        Map<String, Object> fileData = new HashMap<>();
        fileData.put("size", file.length());
        fileData.put("type", getFileExtension(file.getName()));
        return fileData;
    }

    public File getResourceFile(String fileName) throws URISyntaxException {
        final URL resource = Thread.currentThread().getContextClassLoader().getResource(fileName);
        return Paths.get(resource.toURI()).toFile();
    }

    public static String stripFileExtension(String fileName) {
        final Integer startPos = fileName.lastIndexOf('.');
        if (startPos > 0) {
            fileName = fileName.substring(0, startPos);
        }
        return fileName;
    }

    public static String replaceExtension(String fileName, String newExtension) {
        return new StringBuilder()
            .append(stripFileExtension(fileName)).append('.').append(newExtension).toString();
    }
    
    protected static String getZipEntryInfo(ZipEntry zipEntry) {
        return zipEntry != null ? "name=" + zipEntry.getName() + ", method=" + zipEntry.getMethod() : "NULL";
    }

    public static boolean validateProviderEmail(String providerEmail) {
        //ValidEmailRegexTest.java - use this class to validate emailId and regex pattern
        String regexPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9]+)*$";
        final Pattern VALID_EMAIL_ADDRESS_REGEX=Pattern.compile(regexPattern,Pattern.CASE_INSENSITIVE);
        Matcher matcher =VALID_EMAIL_ADDRESS_REGEX.matcher(providerEmail);
        return matcher.find();
    }
    
}
