package com.optum.fds.paperless.util;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.io.RandomAccessFile;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class FileSplitUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(FileSplitUtil.class);

	private static long bytesSplitMultiple = 1024L * 1024L;

	public static void setBytesSplitMultiple(long bytesSplitMultipleValue) {
		bytesSplitMultiple = bytesSplitMultipleValue;
		LOGGER.info("Setting bytesSplitMultiple={}", bytesSplitMultiple);
	}

	// maxBytesNewLineWithin: Max number of bytes on a split to parse backward to locate a new line
	public static List<StringBuilder> checkAndSplitFile(String filePath, int splitPerMbSize, int maxBytesNewLineWithin) throws IOException {
		boolean isFileToSplit = FileSplitUtil.isSplitFile(splitPerMbSize, filePath);
		if (! isFileToSplit) {
			return new ArrayList<>();
		}
		List<StringBuilder> splitList = splitFilePerMbPerNewLine(filePath, splitPerMbSize, maxBytesNewLineWithin);
		LOGGER.info("filePath={}, splitList.size={}, bytesSplitMultiple={}", filePath, splitList.size(), bytesSplitMultiple);
		return splitList;
	}

	public static boolean isSplitFile(int splitPerMbSize, String sourceFile) throws IOException {
		Path filePath = Paths.get(sourceFile);
		long fileSize = filePath.toFile().length();
		LOGGER.debug("fileSize={}", fileSize);
		final long bytesPerSplit = bytesSplitMultiple * splitPerMbSize;
		return fileSize >= bytesPerSplit;
	}

	// If the file was not fully split i.e had an IOException it returns empty List<StringBuilder>
	protected static List<StringBuilder> splitFilePerMbPerNewLine(final String fileName, final int splitPerMbSize, int maxBytesNewLineWithin) {
		List<StringBuilder> splitList = new ArrayList<>();
		if (splitPerMbSize <= 0) {
			return splitList;
		}

		long sourceSize;
		Path fileNamePath = Paths.get(fileName);
		try {
			sourceSize = Files.size(fileNamePath);
		} catch (IOException e) {
			LOGGER.error("Exception file.size: fileName={}; {}", fileName, ExceptionUtils.getStackTrace(e));
			return splitList;
		}

		final long bytesPerSplit = bytesSplitMultiple * splitPerMbSize;
		if (sourceSize < bytesPerSplit) {
			LOGGER.debug("Not splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);
			return splitList;
		}
		LOGGER.debug("Splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);

		int i = 0;
		long offset = 0;
		long numSplits = sourceSize / bytesPerSplit;
		long remainingBytes = sourceSize % bytesPerSplit;
		long writtenByteSize = 0;
		long sourceSizeOrig = sourceSize;
		long writtenByteSizeTotal = 0;
		LOGGER.debug("fileName={}, sourceSize={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, splitPerMbSize={}, maxBytesNewLineWithin={}",
			fileName, sourceSize, bytesPerSplit, numSplits, remainingBytes, splitPerMbSize, maxBytesNewLineWithin);
		try {
			try (RandomAccessFile sourceFile = new RandomAccessFile(fileName, "r");
				FileChannel sourceChannel = sourceFile.getChannel()) {
				while (numSplits > 0) {
					LOGGER.debug("PRE: fileName={}, i={}, sourceSize={}, offset={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, writtenByteSize={}, writtenByteSizeTotal={}",
						fileName, i, sourceSize, offset, bytesPerSplit, numSplits, remainingBytes, writtenByteSize, writtenByteSizeTotal);
					writtenByteSize = writePartToSplitList(fileName, ++i, offset, bytesPerSplit, maxBytesNewLineWithin, sourceChannel, splitList, false);
					writtenByteSizeTotal = writtenByteSizeTotal + writtenByteSize;
					sourceSize = sourceSize - writtenByteSize;
					offset = offset + writtenByteSize;
					numSplits = sourceSize / bytesPerSplit;
					remainingBytes = sourceSize % bytesPerSplit;
					LOGGER.debug("POST: fileName={}, i={}, sourceSize={}, offset={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, writtenByteSize={}, writtenByteSizeTotal={}",
						fileName, i, sourceSize, offset, bytesPerSplit, numSplits, remainingBytes, writtenByteSize, writtenByteSizeTotal);
				}
				if (remainingBytes > 0) {
					writtenByteSize = writePartToSplitList(fileName, ++i, offset, remainingBytes, maxBytesNewLineWithin, sourceChannel, splitList, true);
					writtenByteSizeTotal = writtenByteSizeTotal + writtenByteSize;
				}
			}
		} catch(IOException e) {
			LOGGER.error("Exception while splitting fileName={}: msg={}", fileName, e.getMessage());
			return splitList;
		}
		if (sourceSizeOrig != writtenByteSizeTotal) {
			LOGGER.error("Done: Backing out any splitFiles; Bytes written splitFiles mismatch; fileName={}, sourceSizeOrig={}, writtenByteSizeTotal={}",
				fileName, sourceSizeOrig, writtenByteSizeTotal);
			return splitList;
		} else {
			LOGGER.debug("Done: fileName={}, sourceSizeOrig={}, writtenByteSizeTotal={}, splitList.size={}", fileName, sourceSizeOrig, writtenByteSizeTotal, splitList.size());
		}
		return splitList;
	}

	protected static long writePartToSplitList(String origFile, int i, long offset, long bytesPerSplit, int maxBytesNewLineWithin, FileChannel sourceChannel,
			List<StringBuilder> splitList, boolean remaining) throws IOException {
		LOGGER.debug("origFile={}, i={}, offset={}, bytesPerSplit={}, remaining={}", origFile, i, offset, bytesPerSplit, remaining);
		if (! remaining) {
			ByteBuffer buf = ByteBuffer.allocate(maxBytesNewLineWithin);
			LOGGER.debug("origFile={}, i={}, offset={}, bytesPerSplit={}, newOffset={}",
				origFile, i, offset, bytesPerSplit, offset + bytesPerSplit - maxBytesNewLineWithin);
			int noOfBytesRead = sourceChannel.read(buf, offset + bytesPerSplit - maxBytesNewLineWithin);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("File break: origFile={}, i={}, remaining={}, noOfBytesRead={}, fileContent=<{}>",
					origFile, i, remaining, noOfBytesRead, new String(buf.array(), StandardCharsets.UTF_8));
			}
			boolean foundNewLine = false;
			for (int index = maxBytesNewLineWithin - 1; index >= 0; index--) {
				byte currentByte = buf.get(index);
				if (currentByte == '\n') {
					LOGGER.debug("NEWLINE found: origFile={}, i={}, offset={}, bytesPerSplit={}, index={}", origFile, i, offset, bytesPerSplit, index);
					foundNewLine = true;
					break;
				}
				bytesPerSplit--;
			}
			LOGGER.debug("origFile={}, i={}, offset={}, bytesPerSplit={}, foundNewLine={},", origFile, i, offset, bytesPerSplit, foundNewLine);
		}
	
		MappedByteBuffer buff = sourceChannel.map(FileChannel.MapMode.READ_ONLY, offset, bytesPerSplit);
		splitList.add(new StringBuilder(StandardCharsets.UTF_8.decode(buff)));
		return bytesPerSplit;
	}
}