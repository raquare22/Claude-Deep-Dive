package com.optum.fds.paperless.util.csv;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.executions.UnprocessedRecord;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class CsvToJsonUtil {
	private static final Logger LOG = LoggerFactory.getLogger(CsvToJsonUtil.class);
	private static final String OUTPUT_JSON_FILE_NAME_SUFFIX = ".json";
	private static final String OUTPUT_TEXT_FILE_NAME_SUFFIX = ".txt";
	private static final String START_OF_FILE = "start";
	private static final String END_OF_FILE = "end";
	private static final int STRICT_JSON_YES = 1;
	private static final int STRICT_JSON_NO = 0;
	
	private String templateName = "";
	
	public void setTemplateName(String template) {
		templateName = template;
	}

	public void writetoFileUsingTemplate(String outputFileName, String jsonFile, String startOrEnd, int strictJsonFlag) throws FSDataException, IOException {
		LOG.info("outputFileName={}, jsonFile={}, startOrEnd={}, strictJsonFlag={}", outputFileName, jsonFile, startOrEnd, strictJsonFlag);
		try (FileWriter fw = new FileWriter(outputFileName, true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			if (START_OF_FILE.equals(startOrEnd) && strictJsonFlag == STRICT_JSON_YES) {
				out.write("[");
			}
			if (jsonFile != null) {
				LOG.info("csv jsonFile={}", jsonFile);
				if(StringUtils.isEmpty(templateName)) {
					LOG.info("csv templateName is empty: Defaulting to CosmosPRACompanion"); //This should probably throw an exception
					templateName="CosmosPRACompanion";
				} else {
					LOG.info("csv templateName is not empty; templateName={}", templateName);
				}
				
				String json = TemplateFactory.getInstance(templateName).convertWithTemplate(jsonFile);
				LOG.debug("json={}", json);
				String processedJson = json.replaceAll("(,)?\"([^\"]*)\":\"\"", "");
				LOG.debug("processedJson={}", processedJson);
				out.write(processedJson);
				out.flush();
			}
			if (strictJsonFlag == STRICT_JSON_NO) {
				out.write("\n");
			} else if (strictJsonFlag == STRICT_JSON_YES) {
				if (END_OF_FILE.equals(startOrEnd)) {
					out.write("]");
				} else {
					out.write(",");
				}
			}
			out.flush();
		} catch (IOException e) {
			LOG.error("writetoFileUsingTemplate Output File Not found {}", e.getMessage());
			throw e;
		}
	}

	public String convertCsvToJson(String locationDirectory, String csvFileName, char delimit, int strictJsonFlag, List<UnprocessedRecord> unprocessedRecords) throws IOException, FSDataException { 
		LOG.info("locationDirectory={}, csvFileName={}, strictJsonFlag={}", locationDirectory, csvFileName, strictJsonFlag);

		String jsonFileName = createJsonFileName(locationDirectory,csvFileName, strictJsonFlag);
		LOG.info("JSON jsonFileName={}", jsonFileName);
		writetoFileUsingTemplate(jsonFileName, locationDirectory + "/" + csvFileName, "NA", strictJsonFlag);
		int index = jsonFileName.lastIndexOf("/");
		LOG.info("Returning jsonFileName={}", jsonFileName);
		return jsonFileName.substring(index + 1);

		/*

		try (InputStream file = new BufferedInputStream(Files.newInputStream(Paths.get(locationDirectory+"/"+ csvFileName)));
				InputStreamReader reader = new InputStreamReader(file);
				BufferedReader bufferedReader = new BufferedReader( reader );
				CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withDelimiter(delimit));) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			mapper.setSerializationInclusion(Include.NON_NULL);
			Iterable<CSVRecord> csvRecords = csvParser.getRecords();

			Iterator<CSVRecord> csvRecordItr = csvRecords.iterator();
			List<String> fieldNames = new ArrayList<>();
			if (csvRecordItr.hasNext()) {
				CSVRecord rec = csvRecordItr.next();
				Iterator<String> columnItr = rec.iterator();
				for (int i = 0; columnItr.hasNext(); i++) {
					columnItr.next();
					String column = rec.get(i);
					if (StringUtils.isBlank(column)) {
						break;
					}
					fieldNames.add(column);
				}
			}

			// Iterate rows from 2nd row and build object with header column
			// names of first row
			boolean start = true;
			jsonFileName = createJsonFileName(locationDirectory,csvFileName, strictJsonFlag);
			LOG.info("JSON file - {}", jsonFileName);
			int rowCounter = 1;
			while (csvRecordItr.hasNext()) {
				CSVRecord csvRecord = csvRecordItr.next();
				try{
					Map<String, String> modelMap = new LinkedHashMap<>();
					// Accessing Values by Column Index
					for (int i = 0; i < fieldNames.size(); i++) {
						String rec = csvRecord.get(i);
						if(StringUtils.isNotBlank(rec)){
							String repl = rec.replaceAll("(\\r|\\n|\\r\\n)+", "");
							String repl2 = repl.replaceAll("\"", "\\'");
							modelMap.put(fieldNames.get(i), repl2);
						}
					}
					String jsonRecordStr = mapper.writeValueAsString(modelMap);
					LOG.info("Record JSON - {}", jsonRecordStr);
					if (csvRecordItr.hasNext()) {
						writetoFileUsingTemplate(jsonFileName, jsonRecordStr, start ? START_OF_FILE : "NA", strictJsonFlag);
					} else {
						writetoFileUsingTemplate(jsonFileName, jsonRecordStr, END_OF_FILE, strictJsonFlag);
					}
					start = false;
				} catch(ArrayIndexOutOfBoundsException | FSDataException | IOException e) {
					UnprocessedRecord unprocessedRecord=new UnprocessedRecord(csvRecord.toString(),rowCounter);
					HashMap<String, String> message = new HashMap<>();
					message.put("error", ExceptionUtils.getStackTrace(e));
					unprocessedRecord.addMessage(message);	
					unprocessedRecords.add(unprocessedRecord);   
				}
				rowCounter++;
			}
		}
		int index = jsonFileName.lastIndexOf("/");
		return jsonFileName.substring(index + 1);
		*/
	}

	String createJsonFileName(String locationDirectory, String csvFileName, int strictJsonFlag) {
		String[] parts = csvFileName.split("\\.");
		String fileName = parts[0];
		String jsonFileName;
		if (strictJsonFlag == STRICT_JSON_YES) {
			jsonFileName = fileName + OUTPUT_JSON_FILE_NAME_SUFFIX;
		}
		else {
			jsonFileName = fileName + "_json" + OUTPUT_TEXT_FILE_NAME_SUFFIX;
		}
		return locationDirectory+ File.separator + jsonFileName;
	}
}
