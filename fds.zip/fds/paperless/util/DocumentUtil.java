package com.optum.fds.paperless.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.domain.revision.DocumentRevision;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class DocumentUtil {
	
	@Autowired
	private ConfigData config;
	
	public static void updateDateModified(DocumentMetaData doc) {
		doc.setDateModified(new Date());
	}
	
	public static void updateDocumentMetaDataRevisions(DocumentMetaData doc) {
		DocumentRevision revision = createRevision(doc, String.valueOf(doc.getSpaceId()));
		List<DocumentRevision> revisionList = doc.getRevisions();
		if (revisionList != null) {
			revisionList.add(revision);
		} else {
			revisionList = new ArrayList<>();
			revisionList.add(revision);
			doc.setRevisions(revisionList);
		}
	}
	
	public static DocumentRevision createRevision(DocumentMetaData doc, String spaceId) {

		// routine to take DocumentMetaData and create a document revision Entry
		// for it
		DocumentRevision revisionEntry = new DocumentRevision();
		if (doc.getExternalId() != null) {
			revisionEntry.setExternalId(doc.getExternalId());
		}
		revisionEntry.setAppIdentifier(doc.getAppIdentifier());
		revisionEntry.setClientId(doc.getClientId());
		revisionEntry.setDateCreated(doc.getDateCreated());
		revisionEntry.setDateModified(doc.getDateModified());
		revisionEntry.setStatus(doc.getStatus());
		revisionEntry.setSpaceId(spaceId);
		revisionEntry.setTransactionId(doc.getTransactionId());
		
		if (doc.getMetadata() != null) {
			Document metadata = new org.bson.Document();
			doc.getMetadata().forEach((key, value) -> {
				metadata.append(key, value);
			});
			revisionEntry.setMetadata(metadata);
		}
		if (doc.getDocumentAttachments() != null && !doc.getDocumentAttachments().isEmpty()) {
			revisionEntry.setDocumentAttachments(doc.getDocumentAttachments());
		}
		if (doc.getErrorMessage() != null && !doc.getErrorMessage().isEmpty()) {
			revisionEntry.setErrorMessage(doc.getErrorMessage());
		}
		return revisionEntry;

	}
	
	public void appendDefaultValuesWithSpaceId(DocumentMetaData documentMetaData, int spaceId) {
		documentMetaData.setTransactionId(UUID.randomUUID().toString());
        documentMetaData.setStatus(MetaDataStatus.AVAILABLE);
        var clientId = config.getCredentials(spaceId).get("clientId").toString();
		var appIdentifier = config.getCredentials(spaceId).get("appIdentifier").toString();
		
		documentMetaData.setSpaceId(spaceId);
		documentMetaData.setClientId(Integer.parseInt(clientId));
		documentMetaData.setAppIdentifier(appIdentifier);
	}
	
    public void appendDefaultValues(DocumentMetaData documentMetaData) {
        documentMetaData.setTransactionId(UUID.randomUUID().toString());
        documentMetaData.setStatus(MetaDataStatus.AVAILABLE);
        if (documentMetaData.getSpaceId() == 0) {
            throw new NullPointerException("spaceId cannot be null");
        }

        var clientId = config.getCredentials(documentMetaData.getSpaceId()).get("clientId").toString();
		var appIdentifier = config.getCredentials(documentMetaData.getSpaceId()).get("appIdentifier").toString();
		
		
		documentMetaData.setClientId(Integer.parseInt(clientId));
		documentMetaData.setAppIdentifier(appIdentifier);
    }

}
