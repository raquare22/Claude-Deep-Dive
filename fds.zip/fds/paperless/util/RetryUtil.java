package com.optum.fds.paperless.util;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.FDSCloudDocument;
import com.optum.fds.paperless.workflow.beans.FDSCloudGetDocumentsResponse;

import jakarta.ws.rs.core.UriBuilderException;

@Component
public class RetryUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RetryUtil.class);

	
//	public ResponseEntity<byte[]> retryGetAttachment(URI awsUri, String urlToken, RestTemplate restTemplate) throws InterruptedException, URISyntaxException {
//		
//		int count = 0;
//		int retryInterval = 1000;
//		int retryCount = 3;
//		
//		// get new token for retry
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("Authorization", urlToken);
//		HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);
//
//		
//		LOGGER.info("retryGetAttachment request searchUrl:{}, interval:{}, retryCount:{} ", Encode.forJava(awsUri.toString())
//				,retryInterval, retryCount );
//
//		while (count < retryCount) {
//			try {
//				synchronized (this) {
//					this.wait(retryInterval);
//				}
//				String sanitizedURL = "";
//				try{
//					sanitizedURL = SanitizeUtil.sanitizeURL(awsUri.toString());
//				}catch (UriBuilderException e){
//					LOGGER.error("getAttachment Invoking Retry Mechanism, err={}", ExceptionUtils.getStackTrace(e));
//					String errorMessage = "Error Building URL";
//					byte[] errorBytes = errorMessage.getBytes();
//					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorBytes);
//				}
//
//				return restTemplate.exchange(sanitizedURL, HttpMethod.GET, attachmentEntity, byte[].class);
//			} catch (HttpServerErrorException e) {
//				if (HttpUtils.validateStatusCode(e.getStatusCode())) {
//					LOGGER.error("retryGetAttachment Provider Search - Invoking Retry Mechanism Again: {} ", count);
//					if (count == (retryCount - 1)) {
//						LOGGER.error("retryGetAttachment HTTP 5xx Error after {} retries, err = {}", count, ExceptionUtils.getStackTrace(e));
//						throw e;
//					}
//				} else {
//					throw e;
//				}
//			} catch (InterruptedException e) {
//				Thread.currentThread().interrupt();
//				throw e;
//			} catch (Exception e) {
//				LOGGER.error("retryGetAttachment Error while Provider Search{}", ExceptionUtils.getStackTrace(e));
//				throw e;
//			} finally {
//				count++;
//			}
//		}
//		return null;
//	}

	public ResponseEntity<byte[]> retryGetAttachment(String awsUri, String urlToken, RestTemplate restTemplate) throws InterruptedException, URISyntaxException {

		var retryInterval = 500L;
		var retryCount = 3;
		
		var retryHandler = new RetryOnExceptionHandler(retryCount, retryInterval);

		// get new token for retry
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", urlToken);
		HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

		
		ResponseEntity<byte[]> response = null;
		
		long startTime = System.nanoTime();
		
		while (retryHandler.shouldRetry()) {
			try {
				try {
					response = restTemplate.exchange(awsUri, HttpMethod.GET, attachmentEntity, byte[].class);
					
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					LOGGER.info("retryGetAttachment Consumer=fds.paperless, ServiceName=fds.cloud, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
							 HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
					break;
				} catch (HttpStatusCodeException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
				
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						
						LOGGER.error("retryGetAttachment HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("retryGetAttachment HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						ResponseEntity<byte[]> errorResponse = new ResponseEntity<byte[]>(null, headers, e.getStatusCode().value());
						return errorResponse;
					}
				}
			} catch (OutOfRetriesException e) {

				LOGGER.error("retryGetAttachment HttpStatusCodeException 3 retries exhausted Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, err={}", 
						Encode.forJava(awsUri.toString()), HttpMethod.GET.toString(), ExceptionUtils.getStackTrace(e));
				ResponseEntity<byte[]> errorResponse = new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
				return errorResponse;
			}
		}
		
		return response;
	}
	
	public ResponseEntity<DocumentAttachmentMetaData> retryFDSCloudCall(URI awsUri, String newAccessToken, RestTemplate restTemplate) throws InterruptedException {
		
		var retryInterval = 500L;
		var retryCount = 3;
		
		var retryHandler = new RetryOnExceptionHandler(retryCount, retryInterval);
		
		// get new token for retry
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", newAccessToken);
		HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

		ResponseEntity<DocumentAttachmentMetaData> response = null;
		
		long startTime = System.nanoTime();
		
		while (retryHandler.shouldRetry()) {
			try {
				try {
					response = restTemplate.exchange(awsUri, HttpMethod.GET, attachmentEntity, DocumentAttachmentMetaData.class);
					
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					LOGGER.info("retryFDSCloudCall Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
							 Encode.forJava(awsUri.toString()), HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
					break;
				} catch (HttpStatusCodeException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
				
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						
						LOGGER.error("retryFDSCloudCall HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(awsUri.toString()), HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("retryFDSCloudCall HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(awsUri.toString()), HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						ResponseEntity<DocumentAttachmentMetaData> errorResponse = new ResponseEntity<DocumentAttachmentMetaData>(null, headers, e.getStatusCode().value());
						return errorResponse;
					}
				}
			} catch (OutOfRetriesException e) {

				LOGGER.error("retryFDSCloudCall HttpStatusCodeException 3 retries exhausted Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, err={}", 
						Encode.forJava(awsUri.toString()), HttpMethod.GET.toString(), ExceptionUtils.getStackTrace(e));
				ResponseEntity<DocumentAttachmentMetaData> errorResponse = new ResponseEntity<DocumentAttachmentMetaData>(HttpStatus.INTERNAL_SERVER_ERROR);
				return errorResponse;
			}
		}
		
		return response;
	}
	
public ResponseEntity<FDSCloudDocument> retryFDSCloudGetCall(URI awsUri, String newAccessToken, RestTemplate restTemplate) throws InterruptedException {
		
		int count = 0;
		int retryInterval = 1000;
		int retryCount = 3;
		
		// get new token for retry
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", newAccessToken);
		HttpEntity<?> attachmentEntity = new HttpEntity<>(headers);

		
		LOGGER.info("retryFDSCloudCall request headers, interval:{}, retryCount:{} ", retryInterval, retryCount );

		while (count < retryCount) {
			try {
				synchronized (this) {
					this.wait(retryInterval);
				}
				return restTemplate.exchange(awsUri, HttpMethod.GET, attachmentEntity, FDSCloudDocument.class);
			} catch (HttpServerErrorException e) {
				if (HttpUtils.validateStatusCode(e.getStatusCode())) {
					LOGGER.error("retryFDSCloudCall Provider Search - Invoking Retry Mechanism Again: {} ", count);
					if (count == (retryCount - 1)) {
						LOGGER.error("retryFDSCloudCall HTTP 5xx Error after {} retries, err = {}", count, ExceptionUtils.getStackTrace(e));
						throw e;
					}
				} else {
					throw e;
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw e;
			} catch (Exception e) {
				LOGGER.error("retryGetAttachment Error while Provider Search{}", ExceptionUtils.getStackTrace(e));
				throw e;
			} finally {
				count++;
			}
		}
		return null;
	}
	

}
