package com.optum.fds.paperless.util;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Component
public class HookTransaction {
	
	@Autowired
    private HookService hookService;

		private static final Logger LOGGER = LoggerFactory.getLogger(HookTransaction.class);
		private static final String COMPLETE = "COMPLETE";
		public void updateHookTransaction(DelegateExecution execution, HookTransactionMetaData hookTransactionMetaData, Map<String, String> msg) {
		{	
		
		if (hookTransactionMetaData != null) {
	    	var fileName="";
	    	var fileList = (List<String>) execution.getVariable(Workflow.SFTP_FILE_LIST);

	    	if (fileList != null) {
	    		for (var file : fileList) {
	    			File objfileName = new File(file);
	    			fileName = fileName.join(" ", fileName, objfileName.getName());
	    		}
	    	} else {
	    		LOGGER.warn("Sftp file list is empty hookTransactionMetaData.id={}, filename={}", hookTransactionMetaData.getId(), fileName);
	    	}

			if (!fileName.isEmpty()) {
				msg.put(Workflow.FILE_NAME, fileName);
				LOGGER.info("Hook transaction update fileName: {}", fileName);
			}

	    	var hookExecutionList = hookTransactionMetaData.getHookExecutionList();

	    	
	    	Map<String, String> hookExecutionMessage = null;
	    	if (hookExecutionList != null && !hookExecutionList.isEmpty() && hookExecutionList.get(0) != null
	    			&& hookExecutionList.get(0).getMessageList() != null && !hookExecutionList.get(0).getMessageList().isEmpty() 
	    			&& hookExecutionList.get(0).getMessageList().get(0) != null) {
	    		hookExecutionMessage = hookTransactionMetaData.getHookExecutionList().get(0).getMessageList().get(0);
	    		hookExecutionMessage.putAll(msg);
	    	} else {
	    		hookExecutionMessage = new HashMap<>();
	    		hookExecutionMessage.putAll(msg);
	    	}

	    	hookTransactionMetaData.getHookExecutionList().get(0).updateMessage(hookExecutionMessage);
	    	hookTransactionMetaData.setStatus(COMPLETE);
	    	hookService.updateHookTransaction(hookTransactionMetaData);
	    }
		
		}
		
	}
	
	
}
