package com.optum.fds.paperless.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import jakarta.ws.rs.core.UriBuilderException;
import java.net.URI;
import java.net.URISyntaxException;

public final class SanitizeUtil {
	private static final String AUTHORIZATION = "Authorization";

	private SanitizeUtil() {}

	public static String sanitizeString(String input){
		if (input == null) {
			return null;
		}
		try {
			return JsonParser.parseString(input).toString();
		} catch (JsonSyntaxException e) {
			//return input.replaceAll("[^a-zA-Z0-9_-]", "");
			return "Sanitize Failure";
		}
	}

	public static String sanitizeToString(String str) {
        return str == null ? null : str.replaceAll("\\v", "");
    }


	public static HttpEntity<?> sanitizeHttpEntityHeaderRmAuth(HttpEntity<?> requestEntity) {
		requestEntity = new HttpEntity<>(requestEntity.getHeaders());
		HttpHeaders httpHeaders = requestEntity.getHeaders();
		httpHeaders.remove(AUTHORIZATION);
		if (requestEntity.getHeaders().getContentType() != null) {
			httpHeaders.setContentType(new MediaType(sanitizeString(requestEntity.getHeaders().getContentType().toString())));
		}
		return requestEntity;
	}

	public static String sanitizeResponseEntityBody(ResponseEntity<?> response) {
		return response != null && response.getBody() != null ? sanitizeString(response.getBody().toString()) : null;
	}

	public static String sanitizeURL(String url) throws UriBuilderException, URISyntaxException {
		String sanitizedURL = "";
		var awsUri = new URI(url);
		//rebuilding the uri
		sanitizedURL = awsUri.getScheme() + "://" + awsUri.getHost() + awsUri.getPath();
		if (awsUri.getQuery() != null) {
			sanitizedURL += "?" + awsUri.getQuery();
		}
		if (awsUri.getFragment() != null) {
			sanitizedURL += "#" + awsUri.getFragment();
		}
		return sanitizedURL;
	}
	


	public static String sanitizeAttachmentURL(URI uri) throws UriBuilderException, URISyntaxException {
		String sanitizedURL = "";
		//rebuilding the uri
		sanitizedURL = uri.getScheme() + "://" + uri.getHost() + uri.getRawPath();
		if (uri.getQuery() != null) {
			sanitizedURL += "?" + uri.getRawQuery();
		}
		if (uri.getFragment() != null) {
			sanitizedURL += "#" + uri.getRawFragment();
		}
		return sanitizedURL;
	}

}