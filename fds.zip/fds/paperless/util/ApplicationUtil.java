////package com.optum.fs.util.helper;
package com.optum.fds.paperless.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApplicationUtil {

	private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

	public ApplicationUtil() {}

	public static Boolean isNotNull(Object o) {
		return (o != null) ? true : false;

	}
    public static String getServerDate() {
        TimeZone tz = TimeZone.getTimeZone("UTC");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); // Quoted "Z" to indicate UTC, no timezone offset
        df.setTimeZone(tz);
        return df.format(new Date());
    }

    public String rerSuccess(String message) {
        message += ", RERstatus=SUCCESS";
        return message;
    }

    public  String rerFailure(String message) {
        message += ", RERstatus=FAILURE";
        return message;
    }

	public static boolean validateExpiryDate(String expiryDate, int numOfDays, int offset) throws ParseException {
		Calendar now = new GregorianCalendar();
        Calendar lowerRangeExpectedExpiryDate = (GregorianCalendar) now.clone();
        lowerRangeExpectedExpiryDate.add(Calendar.DAY_OF_YEAR, numOfDays - offset);
        Calendar upperRangeExpectedExpiryDate = (GregorianCalendar) now.clone();
        upperRangeExpectedExpiryDate.add(Calendar.DAY_OF_YEAR, numOfDays + offset);
        Calendar resultExpiryDate = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_DATE_FORMAT, Locale.ENGLISH);
        resultExpiryDate.setTime(sdf.parse(expiryDate));
        return ((resultExpiryDate.after(lowerRangeExpectedExpiryDate) && resultExpiryDate.before(upperRangeExpectedExpiryDate)));
    }
}
