/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/22/17.
 */

package com.optum.fds.paperless.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 */
public class Converters {
    private static final Logger logger = LoggerFactory.getLogger(Converters.class);

    private Converters(){}

    public static Date convertISOStringToDate(String isoDate){
        Date date = null;
        List<SimpleDateFormat> simpleDateFormatList = new ArrayList<>();
        simpleDateFormatList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        simpleDateFormatList.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'"));
        simpleDateFormatList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX"));
        simpleDateFormatList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX"));
        simpleDateFormatList.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS"));
        simpleDateFormatList.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"));
        simpleDateFormatList.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSXXX"));

        if (isoDate != null && !isoDate.isEmpty()) {
            for (SimpleDateFormat isoDateFormat : simpleDateFormatList) {
                try {
                    date = isoDateFormat.parse(isoDate);
                    break;
                } catch (ParseException ex) {
                    // Try next format
                }
            }
        }
        if(date == null){
            logger.debug("ParseException found while trying to covert date");
        }

        return date;
    }
}
