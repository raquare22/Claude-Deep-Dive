package com.optum.fds.paperless.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

import com.optum.fds.paperless.constants.CommonConstants;

import java.util.function.Function;

public final class Utility {

	@Value("${spring.profiles.active}")
	private static String activeProfile;
	
	private static final Logger LOGGER = LogManager.getLogger(Utility.class);

	public static final Function<String, String> envFunction = System::getenv;

	public static String getEnvironment() {
		String env = envFunction.apply(activeProfile);
		String local = "local";
		if(env == null) {
		    return local;
		}
		for(Environments envs : Environments.values()) {
			if(envs.getEnv().equals(env)) {
				return env;
			}
		}
		return local;
	}
}
