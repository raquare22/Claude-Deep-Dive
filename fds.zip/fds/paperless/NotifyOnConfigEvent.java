package com.optum.fds.paperless;

public interface NotifyOnConfigEvent {
	boolean configChange();
}