package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.java.delegate.SendACKFileToSftpServer;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorTask;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProcessorTransactionCore extends ProcessorTask {

    private static final Logger LOGGER = LoggerFactory.getLogger(SendACKFileToSftpServer.class);
    public void setReadyStatus() {
        setEndTime();
        setStatus(MetaDataStatus.READY);
    }

    public MetaDataStatus setCompleteStatus() {
        MetaDataStatus status = MetaDataStatus.COMPLETE;
        if (CollectionUtils.isNotEmpty(super.getSummary().getErrorList())) {
            status = MetaDataStatus.COMPLETE_WITH_ERRORS;
        }
        setStatus(status);
        LOGGER.info("Updated ProcessorTransaction status to {}", getStatus());
        return status;
    }
}
