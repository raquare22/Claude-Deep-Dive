/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who                 Revision
 * 12.Dec.2016  Terry J. Violette   Initial version
 ****************************************************************/
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.optum.fds.paperless.domain.revision.HookRevision;
//import com.optum.fds.paperless.processorlistener.mongo.processors.MetaData;
import com.optum.fds.paperless.mongo.processors.MetaData;

////import com.optum.fs.domain.revision.HookRevision;

@Document(collection = "hook")
public class HookMetaData extends MetaData implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private String   errorMessage;
    private Date     expires;
    private transient org.bson.Document hook;
    private String   hookRecordType;
    private String   method;
    private String   parentId;
    private int      spaceId;
    private String   target;
    private int  	executionOrder;
    private Boolean locked = false;


    public String getParentId() {
        return parentId;
    }
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }
    public String getMethod() {
        return method;
    }
    public void setMethod(String method) {
        this.method = method;
    }
    public String getTarget() {
        return target;
    }
    public void setTarget(String target) {
        this.target = target;
    }
    public Date getExpires() {
        return expires==null?null:(Date)expires.clone();
    }
    public void setExpires(Date expires) {
        this.expires = expires==null?null:(Date)expires.clone();
    }
    public String getErrorMessage() {
        return errorMessage;
    }
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public org.bson.Document getHook() {
		return hook;
	}
	public void setHook(org.bson.Document hook) {
		this.hook = hook;
	}
	@Override
	public List<HookRevision> getRevisions() {
		return revisions;
	}

    public void setHookRecordType(String hookRecordType) {
        this.hookRecordType = hookRecordType;
    }
    public String getHookRecordType() {
        return hookRecordType;
    }
    public int getSpaceId() {
        return spaceId;
    }
    public void setSpaceId(Integer spaceId) {
        if(spaceId != null) {
            this.spaceId = spaceId;
        }
    }
	public int getExecutionOrder() {
		return executionOrder;
	}
	public void setExecutionOrder(int executionOrder) {
		this.executionOrder = executionOrder;
	}
    
    public boolean isLocked() {
        return locked == null ? false : locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }


}
