package com.optum.fds.paperless.mongo;


import com.fasterxml.jackson.annotation.JsonProperty;


public class BatchInfo extends MetaData{


    @JsonProperty("zipFileName")
    String zipFileName;
    
    @JsonProperty("zipFileCreationDate")
    String zipFileCreationDate;
    
    @JsonProperty("itemsCount")
    Integer itemsCount;
    
	public String getZipFileName() {
		return zipFileName;
	}
	public void setZipFileName(String zipFileName) {
		this.zipFileName = zipFileName;
	}
	public String getZipFileCreationDate() {
		return zipFileCreationDate;
	}
	public void setZipFileCreationDate(String zipFileCreationDate) {
		this.zipFileCreationDate = zipFileCreationDate;
	}
	public Integer getItemsCount() {
		return itemsCount;
	}
	public void setItemsCount(Integer itemsCount) {
		this.itemsCount = itemsCount;
	}



   

   
}