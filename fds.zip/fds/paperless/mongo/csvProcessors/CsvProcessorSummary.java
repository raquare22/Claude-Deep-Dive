////package com.optum.fs.mongo.csvProcessors;
package com.optum.fds.paperless.mongo.csvProcessors;

//org.bson.Document
import org.bson.Document;
//import com.optum.fs.mongo.processors.ProcessorSummaryCore;

import com.optum.fds.paperless.mongo.processors.ProcessorSummaryCore;

import java.util.HashMap;

import org.bson.Document;

public class CsvProcessorSummary extends ProcessorSummaryCore {

    //transient org.bson.Document csvRowResult;
	transient Document csvRowResult;
    private CsvProcessingMetrics csvProcessingMetrics;

    public Document getCsvRowResult() {
        return csvRowResult;
    }
    public void setCsvRowResult(Document csvRowResultObj) {
        this.csvRowResult = csvRowResultObj;
    }

    public CsvProcessingMetrics getCsvProcessingMetrics() {
        if (csvProcessingMetrics == null) {
            csvProcessingMetrics = new CsvProcessingMetrics();
            csvProcessingMetrics.setBytesProcessed(0L);
            csvProcessingMetrics.setRowCount(0);
            csvProcessingMetrics.setTotalBytes(0L);
            csvProcessingMetrics.setTotalRunTime(0L);
            csvProcessingMetrics.setErrorCount(new HashMap());
        } else {
            if (csvProcessingMetrics.getBytesProcessed() == null) {
                csvProcessingMetrics.setBytesProcessed(0L);
            }
            if (csvProcessingMetrics.getRowCount() == null) {
                csvProcessingMetrics.setRowCount(0);
            }
            if (csvProcessingMetrics.getTotalBytes() == null) {
                csvProcessingMetrics.setTotalBytes(0L);
            }
            if (csvProcessingMetrics.getTotalRunTime() == null) {
                csvProcessingMetrics.setTotalRunTime(0L);
            }
            if (csvProcessingMetrics.getErrorCount() == null) {
                csvProcessingMetrics.setErrorCount(new HashMap());
            }
        }
        return csvProcessingMetrics;
    }

    public void setCsvProcessingMetrics(CsvProcessingMetrics csvProcessingMetrics) {
        this.csvProcessingMetrics = csvProcessingMetrics;
    }

}
