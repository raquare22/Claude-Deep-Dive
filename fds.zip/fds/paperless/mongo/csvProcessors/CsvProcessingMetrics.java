/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2018.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 */

////package com.optum.fs.mongo.csvProcessors;
package com.optum.fds.paperless.mongo.csvProcessors;

import com.optum.fds.paperless.mongo.processors.ProcessingMetricsCore;

////import com.optum.fs.mongo.processors.ProcessingMetricsCore;

public class CsvProcessingMetrics extends ProcessingMetricsCore{

    private Integer               rowCount;

    public Integer getRowCount() {
        return rowCount;
    }
    public void setRowCount(Integer rowCount) {
        this.rowCount = rowCount;
    }
}
