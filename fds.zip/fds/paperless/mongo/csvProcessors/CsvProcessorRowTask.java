/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2018.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 */

package com.optum.fds.paperless.mongo.csvProcessors;


import java.util.Date;

import com.optum.fds.paperless.mongo.MetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;

public class CsvProcessorRowTask extends MetaData {
	private Integer configSpaceId;
	private ProcessorRecordTypes processorRecordType;

	private String csvProcessorTransactionId;
	private String processorId;
	private String jsonFileName;
	private String csvFileName;
	private Integer fileRowNumber;
	private String location;
	private String processedByHost;
	private String serverType;
	private Date dateProcessed;
	private String targetId;
	private String targetType;
	private String request;
	private String response;
	private String restTargetId;
	private Boolean isRestApiSuccessful;

	public Integer getConfigSpaceId() {
		return configSpaceId;
	}

	public void setConfigSpaceId(Integer configSpaceId) {
		if (configSpaceId != null) {
			this.configSpaceId = configSpaceId;
		}
	}

	public ProcessorRecordTypes getProcessorRecordType() {
		return processorRecordType;
	}

	public void setProcessorRecordType(ProcessorRecordTypes processorRecordType) {
		this.processorRecordType = processorRecordType;
	}

	public String getCsvProcessorTransactionId() {
		return csvProcessorTransactionId;
	}

	public void setCsvProcessorTransactionId(String processorTransactionId) {
		this.csvProcessorTransactionId = processorTransactionId;
	}

	public String getProcessorId() {
		return processorId;
	}

	public void setProcessorId(String processorId) {
		this.processorId = processorId;
	}

	public String getCsvFileName() {
		return csvFileName;
	}

	public void setCsvFileName(String csvFileName) {
		this.csvFileName = csvFileName;
	}

	public String getJsonFileName() {
		return jsonFileName;
	}

	public void setJsonFileName(String jsonFileName) {
		this.jsonFileName = jsonFileName;
	}

	public Integer getFileRowNumber() {
		return fileRowNumber;
	}

	public void setFileRowNumber(Integer fileRowNumber) {
		this.fileRowNumber = fileRowNumber;
	}

	public String getProcessedByHost() {
		return processedByHost;
	}

	public void setProcessedByHost(String processedByHost) {
		this.processedByHost = processedByHost;
	}

	public String getServerType() {
		return serverType;
	}

	public void setServerType(String serverType) {
		this.serverType = serverType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getDateProcessed() {
		return (Date) dateProcessed.clone();
	}

	public void setDateProcessed(Date dateProcessed) {
		this.dateProcessed = (Date) dateProcessed.clone();
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

	public String getTargetType() {
		return targetType;
	}

	public void setTargetType(String targetType) {
		this.targetType = targetType;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getRestTargetId() {
		return restTargetId;
	}

	public void setRestTargetId(String restTargetId) {
		this.restTargetId = restTargetId;
	}

	public Boolean getIsRestApiSuccessful() {
		return isRestApiSuccessful;
	}

	public void setIsRestApiSuccessful(Boolean isRestApiSuccessful) {
		this.isRestApiSuccessful = isRestApiSuccessful;
	}

	@Override
	public String toString() {
		return "CsvProcessorRowTask [csvProcessorTransactionId=" + csvProcessorTransactionId + ", csvFileName=" + csvFileName
			+ ", fileRowNumber=" + fileRowNumber + ", targetId=" + targetId  + "]";
	}
}
