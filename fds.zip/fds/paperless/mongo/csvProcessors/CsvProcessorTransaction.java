/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2018.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 */

////package com.optum.fs.mongo.csvProcessors;
package com.optum.fds.paperless.mongo.csvProcessors;

////import com.optum.fs.mongo.ProcessorTransactionCore;
import com.optum.fds.paperless.mongo.ProcessorTransactionCore;

import java.io.Serializable;

public class CsvProcessorTransaction extends ProcessorTransactionCore implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer rowCount;
    private String jsonFileName;

    public Integer getRowCount() {
        return rowCount;
    }

    public void setRowCount(Integer rowCount) {
        this.rowCount = rowCount;
    }

    public String getJsonFileName() {
        return jsonFileName;
    }

    public void setJsonFileName(String jsonFileName) {
        this.jsonFileName = jsonFileName;
    }
}
