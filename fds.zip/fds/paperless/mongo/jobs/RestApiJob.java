////package com.optum.fs.mongo.jobs;
package com.optum.fds.paperless.mongo.jobs;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;

import java.net.URI;


public class RestApiJob extends Job {
	private static final long serialVersionUID = 1L;
	private String appIdentifier;
	private int clientId;
	private String dbStatusObjectId;  // csvProcessorRowTask id
	private HttpMethod method;
	private transient HttpEntity<Object> request;
	private String sourceId; // hook id or processor id
    private String sourceType; // hook or processor
    private String sourceJobType; // processorRestApiJob
    private int spaceId;
    private URI uri;
    private String workFlow;
    private String csvFileName;
    private String jsonFileName;


	public String getCsvFileName() {
		return csvFileName;
	}

	public void setCsvFileName(String csvFileName) {
		this.csvFileName = csvFileName;
	}

	public String getJsonFileName() {
		return jsonFileName;
	}

	public void setJsonFileName(String jsonFileName) {
		this.jsonFileName = jsonFileName;
	}

	public RestApiJob() {
    	// default constructor
	}

	/**
	 * @return the appIdentifier
	 */
	public String getAppIdentifier() {
		return appIdentifier;
	}

	/**
	 * @param appIdentifier the appIdentifier to set
	 */
	public void setAppIdentifier(String appIdentifier) {
		this.appIdentifier = appIdentifier;
	}

	/**
	 * @return the clientId
	 */
	public int getClientId() {
		return clientId;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the dbStatusObjectId
	 */
	public String getDbStatusObjectId() {
		return dbStatusObjectId;
	}

	/**
	 * @param dbStatusObjectId the dbStatusObjectId to set
	 */
	public void setDbStatusObjectId(String dbStatusObjectId) {
		this.dbStatusObjectId = dbStatusObjectId;
	}

	/**
	 * @return the method
	 */
	public HttpMethod getMethod() {
		return method;
	}

	/**
	 * @param method the method to set
	 */
	public void setMethod(HttpMethod method) {
		this.method = method;
	}

	/**
	 * @return the request
	 */
	public HttpEntity<Object> getRequest() {
		return request;
	}

	/**
	 * @param request the request to set
	 */
	public void setRequest(HttpEntity<Object> request) {
		this.request = request;
	}

	/**
	 * @return the sourceId
	 */
	public String getSourceId() {
		return sourceId;
	}

	/**
	 * @param sourceId the sourceId to set
	 */
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	/**
	 * @return the sourceJobType
	 */
	public String getSourceJobType() {
		return sourceJobType;
	}

	/**
	 * @param sourceJobType the sourceJobType to set
	 */
	public void setSourceJobType(String sourceJobType) {
		this.sourceJobType = sourceJobType;
	}

	/**
	 * @return the sourceType
	 */
	public String getSourceType() {
		return sourceType;
	}

	/**
	 * @param sourceType the source to set
	 */
	public void setSourceType(String source) {
		this.sourceType = source;
	}

	/**
	 * @return the spaceId
	 */
	public int getSpaceId() {
		return spaceId;
	}

	/**
	 * @param spaceId the spaceId to set
	 */
	public void setSpaceId(int spaceId) {
		this.spaceId = spaceId;
	}

	/**
	 * @return the uri
	 */
	public URI getUri() {
		return uri;
	}

	/**
	 * @param uri the uri to set
	 */
	public void setUri(URI uri) {
		this.uri = uri;
	}

	/**
	 * @return the workFlow
	 */
	public String getWorkFlow() {
		return workFlow;
	}

	/**
	 * @param workFlow the workFlow to set
	 */
	public void setWorkFlow(String workFlow) {
		this.workFlow = workFlow;
	}

}