/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who                 Revision
 * 12.Dec.2016  Terry J. Violette   Initial version
 ****************************************************************/
//package com.optum.fs.mongo.jobs;
package com.optum.fds.paperless.mongo.jobs;

import org.springframework.data.annotation.Id;

import java.io.Serializable;
import java.util.Date;


public class Job implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    private String jobId;
    private String jobType ;
    private Date executionDateTime;
    private int executionOrder;
    private String transactionId;

    private String targetType ; /// e.g. document
    private String targetId ;   /// e.g docId or fsId in case of attachment
    private String serverName;
    private String serverType;


    public String getJobId() {
        return jobId;
    }
    public void setJobId(String jobId) {
        this.jobId = jobId;
    }
    public String getJobType() {
        return jobType;
    }
    public void setJobType(String jobType) {
        this.jobType = jobType;
    }
    
    public Date getExecutionDateTime() {
    	return executionDateTime==null?null:(Date)executionDateTime.clone();
        }
    public void setExecutionDateTime(Date executionDateTime) {
    	 this.executionDateTime = executionDateTime==null?null:(Date)executionDateTime.clone();
    }
    public int getExecutionOrder() {
        return executionOrder;
    }
    public void setExecutionOrder(int executionOrder) {
        this.executionOrder = executionOrder;
    }
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public String getTargetType() {
        return targetType;
    }
    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }
    public String getTargetId() {
        return targetId;
    }
    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }
    public void setServerName(String serverName) {
        this.serverName = serverName;
    }
    public String getServerName() {
        return serverName;
    }

    public void setServerType(String serverType) {
        this.serverType = serverType;
    }

    public String getServerType() {
        return serverType;
    }


    @Override
    public String toString() {
        return "Job [jobId=" + jobId + ", jobType=" + jobType + ", executionDateTime=" + executionDateTime + ", executionOrder=" + executionOrder + ", transactionId=" + transactionId
                + ", targetType=" + targetType + ", targetId=" + targetId + ", serverName=" + serverName
                + ", serverType=" + serverType +"]";
    }

    
}

