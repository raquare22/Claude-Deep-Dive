package com.optum.fds.paperless.mongo;

import java.util.HashMap;
import java.util.Map;
import com.optum.fds.paperless.exception.ErrorCode;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;


public class ErrorCodeToStatus {
	private ErrorCodeToStatus () {}
	
	private static Map<ErrorCode, MetaDataStatus> errorCodeStatusMap = new HashMap<>();
		
	static {
		errorCodeStatusMap.put(ErrorCode.PROCESS, MetaDataStatus.COMPLETE_WITH_ERRORS);
		errorCodeStatusMap.put(ErrorCode.VALIDATION, MetaDataStatus.COMPLETE_WITH_ERRORS);
		errorCodeStatusMap.put(ErrorCode.PROCESS_SEND, MetaDataStatus.COMPLETE_WITH_ERRORS);
		errorCodeStatusMap.put(ErrorCode.OUT_OF_RETRIES, MetaDataStatus.COMPLETE_WITH_ERRORS);
		errorCodeStatusMap.put(ErrorCode.AUTHORIZATION_INITIALIZE, MetaDataStatus.COMPLETE_WITH_ERRORS);
		errorCodeStatusMap.put(ErrorCode.RESPONSE_FILE_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.PREPOST_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.BOUNCE_EMAIL_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.MATCH_AND_MERGE_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.SHUTTERFLY_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.REQUIRE_FIELD_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.COMPANION_FILE_EMAIL_ALERT_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.PEN_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.CLEANUP_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.CSV_CLEANUP_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.SFTP_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.FILE_UNZIP_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.PROCESS_METADATA_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.STORAGE_ERROR_SHUTTERFLY_ERROR, MetaDataStatus.AUTOMATIC);
		errorCodeStatusMap.put(ErrorCode.PROCESS_TEXT_FILE_ERROR, MetaDataStatus.AUTOMATIC);
		
	}


	public static MetaDataStatus getErrorCodeStatusDefault(ErrorCode errorCode) {
		return errorCodeStatusMap.get(errorCode);
	}
	
}
