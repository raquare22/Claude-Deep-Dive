package com.optum.fds.paperless.mongo;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class FDSCloudDocument {
	
private String documentId;
	
	private String spaceId;
	
	private String metadata;
	
	private List<String> searchTerms;
	
	private Date createdOn;
	
	private Date modifiedOn;
	
	private String createdBy;
	
	private String modifiedBy;
	
	private List<DocumentAttachmentMetaData> attachments;

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public List<String> getSearchTerms() {
		return searchTerms;
	}

	public void setSearchTerms(List<String> searchTerms) {
		this.searchTerms = searchTerms;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public List<DocumentAttachmentMetaData> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentAttachmentMetaData> attachments) {
		this.attachments = attachments;
	}

	@Override
	public String toString() {
		return "FDSCloudDocument [documentId=" + documentId + ", spaceId=" + spaceId + ", metadata=" + metadata
				+ ", searchTerms=" + searchTerms + ", createdOn=" + createdOn + ", modifiedOn=" + modifiedOn
				+ ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy + ", attachments=" + attachments + "]";
	}

}
