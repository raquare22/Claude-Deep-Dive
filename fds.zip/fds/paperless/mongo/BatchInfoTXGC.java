package com.optum.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BatchInfoTXGC extends MetaData {

	@JsonProperty("npi")
    String npi;

    @JsonProperty("exemptionEffectiveStartDate")
    String exemptionEffectiveStartDate;
    @JsonProperty("exemptionEffectiveEndDate")
    String exemptionEffectiveEndDate;

    @JsonProperty("TemplateName")
    String TemplateName;

    @JsonProperty("cycleStartDate")
    String cycleStartDate;

    @JsonProperty("cycleEndDate")
    String cycleEndDate;

    public String getCycleStartDate() {
        return cycleStartDate;
    }

    public void setCycleStartDate(String cycleStartDate) {
        this.cycleStartDate = cycleStartDate;
    }

    public String getCycleEndDate() {
        return cycleEndDate;
    }

    public void setCycleEndDate(String cycleEndDate) {
        this.cycleEndDate = cycleEndDate;
    }

    public String getTemplateName() {
        return TemplateName;
    }

    public void setTemplateName(String templateName) {
        TemplateName = templateName;
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }
    public String getExemptionEffectiveStartDate() {
        return exemptionEffectiveStartDate;
    }

    public void setExemptionEffectiveStartDate(String exemptionEffectiveStartDate) {
        this.exemptionEffectiveStartDate = exemptionEffectiveStartDate;
    }

    public String getExemptionEffectiveEndDate() {
        return exemptionEffectiveEndDate;
    }

    public void setExemptionEffectiveEndDate(String exemptionEffectiveEndDate) {
        this.exemptionEffectiveEndDate = exemptionEffectiveEndDate;
    }
}

