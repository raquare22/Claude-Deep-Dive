/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2014-2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When         Who                                 Why
 * May 15 2015  Vinata Gangolli, Kwasi Boateng 		Initial version
 * 06.Oct.2016  Terry J. Violett                    Adding metadata
 * 16.Nov.2016  Will Herrera                        Adding DocumentRevisions
 ****************************************************************/

////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.domain.revision.DocumentRevision;
//import com.optum.fds.paperless.processorlistener.mongo.processors.MetaData;
import com.optum.fds.paperless.mongo.processors.MetaData;


/**
 * The Mongo file metadata.
 * 
 */
@Document(collection = "document")
public class DocumentMetaData extends MetaData implements Serializable{
	private static final long serialVersionUID = 1L;

    private List<DocumentAttachmentMetaData> documentAttachments;
	
	private String   externalId;
	private Date     expires;
	private String   errorMessage;

    private transient org.bson.Document metadata ;
    private String   parentId;
    
    @JsonProperty("spaceId")
    @JsonAlias("space_id")
    private int spaceId;
    
    private String fsId;
    
    private String fdsAttachmentId;
    
    private String fdsDocumentId;
    
    private String fileName;
    
    private String s3FilePath;
    
    private String fileType;

    private String doc360DocumentId;

    private String doc360DocClass;

    public String getDoc360DocumentId() {
        return doc360DocumentId;
    }

    public void setDoc360DocumentId(String doc360DocumentId) {
        this.doc360DocumentId = doc360DocumentId;
    }

    public String getDoc360DocClass() {
        return doc360DocClass;
    }

    public void setDoc360DocClass(String doc360DocClass) {
        this.doc360DocClass = doc360DocClass;
    }

    public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getS3FilePath() {
		return s3FilePath;
	}
	public void setS3FilePath(String s3FilePath) {
		this.s3FilePath = s3FilePath;
	}
	public String getFdsAttachmentId() {
		return fdsAttachmentId;
	}
	public void setFdsAttachmentId(String fdsAttachmentId) {
		this.fdsAttachmentId = fdsAttachmentId;
	}
	public String getFsId() {
		return fsId;
	}
	public void setFsId(String fsId) {
		this.fsId = fsId;
	}
	public String getFdsDocumentId() {
		return fdsDocumentId;
	}
	public void setFdsDocumentId(String fdsDocumentId) {
		this.fdsDocumentId = fdsDocumentId;
	}
	public void setSpaceId(int spaceId) {
		this.spaceId = spaceId;
	}
	public String getExternalId() {
		return externalId;
	}
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}
	public List<DocumentAttachmentMetaData> getDocumentAttachments() {
		return documentAttachments==null?null:new ArrayList<>(documentAttachments);
   
	}
	public void setDocumentAttachments(List<DocumentAttachmentMetaData> documentAttachments) {
		 this.documentAttachments = documentAttachments==null?null:new ArrayList<>(documentAttachments);
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public Date getExpires() {
		return expires==null?null:(Date)expires.clone();
	}
	public void setExpires(Date expires) {
		this.expires = expires==null?null:(Date)expires.clone();
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
    public org.bson.Document getMetadata() {
		return metadata;
	}
	public void setMetadata(org.bson.Document metadata) {
		this.metadata = metadata;
	}
	public int getSpaceId() {
        return spaceId;
    }
    public void setSpaceId(Integer spaceId) {
        if(spaceId != null) {
            this.spaceId = spaceId;
        }
    }

    @Override
	public String toString() {
		return "DocumentMetaData [documentAttachments=" + documentAttachments + ", externalId=" + externalId
				+ ", expires=" + expires + ", errorMessage=" + errorMessage + ", parentId=" + parentId + ", spaceId="
				+ spaceId + ", fsId=" + fsId + ", fdsAttachmentId=" + fdsAttachmentId + ", fdsDocumentId="
				+ fdsDocumentId + ", fileName=" + fileName + ", s3FilePath=" + s3FilePath +  ", metadata=" + metadata + "]";
	}

    @Override
	public List<DocumentRevision> getRevisions() {
		return revisions;
	}


}