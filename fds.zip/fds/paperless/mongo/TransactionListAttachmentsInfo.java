////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransactionListAttachmentsInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<TransactionAttachmentInfo> attachments;
	private long totalRecords;
	private int start;
	private int count;
	public List<TransactionAttachmentInfo> getAttachments() {
		return attachments==null?null:new ArrayList<>(attachments);
	}
	public void setAttachments(List<TransactionAttachmentInfo> attachments) {
		 this.attachments = attachments==null?null:new ArrayList<>(attachments);
	}
	public long getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

}
