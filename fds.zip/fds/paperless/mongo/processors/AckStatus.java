////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

/**
 * Created by sroy59 on 6/12/18.
 */



import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum AckStatus {
    IN_PROCESS,
    COMPLETE
}
