package com.optum.fds.paperless.mongo.processors;

public enum ProcessorRecordTypes {
	processorTextFile,
    processor,
    processorTransaction,
    processorFileTask,
    processorMapping,
    csvProcessorTransaction,
    csvProcessorRowTask,
    processorTransactionMetadata,
    processorSftpSendEmail,
    sftpConvertFileToDocument,
    processorRealTimeAPI
}

