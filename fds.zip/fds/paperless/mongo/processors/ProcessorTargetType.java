/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 4/17/17.
 */

//package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

/**
 *
 */
public enum ProcessorTargetType {
    attachments,
    documents,
    hooks
}
