/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/13/17.
 */

/////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

////import com.optum.fs.mongo.MetaData;

/*
 * Processor Mapping: Used to convert File Metadata fields to Client Specific fields
 */
public class ProcessorMapping extends MetaData implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L; 
	private transient List<ProcessorMap> mapping;
    private ProcessorRecordTypes processorRecordType;
    
	private Integer spaceId;
   
	public List<ProcessorMap> getMapping() {
        return mapping==null?null:new ArrayList<>(mapping);
    }
    public void setMapping(List<ProcessorMap> mapping) {
    	this.mapping = mapping==null?null:new ArrayList<>(mapping);
        
    }

    public Integer getSpaceId() {
		return spaceId;
	}
    
    public ProcessorRecordTypes getProcessorRecordType() {
		return processorRecordType;
	}
    
	public void setProcessorRecordType(ProcessorRecordTypes processorRecordType) {
		this.processorRecordType = processorRecordType;
	}
	
	public void setSpaceId(Integer spaceId) {
		this.spaceId = spaceId;
	}
	
    public void addMap(ProcessorMap mapToAdd){
        if(mapping == null){
            mapping = new ArrayList<>();
        }

        mapping.add(mapToAdd);
    }
}
