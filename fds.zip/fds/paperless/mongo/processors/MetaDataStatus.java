package com.optum.fds.paperless.mongo.processors;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum MetaDataStatus{
    ACTIVE,
    AVAILABLE,
    CLEANING,
    COMPLETE,
    COMPLETE_WITH_ERRORS,
    CONVERSION_ERROR,
    DELETED,
    DONE,
    EXPIRED,
    FATAL_ERROR,
    IN_PROCESS,
    NEW,
    OK,
    READY,
    SHUTDOWN,
    ERROR,
    PURGING,
    STORAGE_ERROR,
    READY_HEALTH_CHECK,
	SEVERE_ERROR,
	AUTOMATIC,
	MANUAL;
}