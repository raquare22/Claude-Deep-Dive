////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * The Mongo file metadata.
 * 
 */

public class ActionMetaData implements Serializable {
    private static final long serialVersionUID = 1L;

    private String action;
    private transient List<VirusscanResult> virusScanResults;
    private Date dateCreated;
    private Date dateModified;

    public ActionMetaData() {
        super();
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Date getDateCreated() {
        return dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public Date getDateModified() {
        return dateModified == null ? null : (Date) dateModified.clone();
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified == null ? null : (Date) dateModified.clone();
    }

    public List<VirusscanResult> getVirusScanResults() {
        return virusScanResults == null ? null : new ArrayList<>(virusScanResults);
    }

    public void setVirusScanResults(List<VirusscanResult> virusScanResults) {
        this.virusScanResults = virusScanResults == null ? null : new ArrayList<>(virusScanResults);

    }

}
