////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.io.Serializable;
import java.util.Date;

/**
 * The Mongo file metadata.
 * 
 */

public class FileMetaData implements Serializable {
	private static final long serialVersionUID = 1L;
 
	private String filename;
	private long fileSize;

	private Date dateCreated;
	private Date dateModified;
	
	private String externalId;
	private String attachmentId;
	private String sourceSystemName;
	private Date sourceSystemDateCreated;

	
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public Date getDateCreated() {
		return dateCreated==null?null:(Date)dateCreated.clone();
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated==null?null:(Date)dateCreated.clone();
	}

	public Date getDateModified() {
		return dateModified==null?null:(Date)dateModified.clone();
	}

	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified==null?null:(Date)dateModified.clone();
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(String attachmentId) {
		this.attachmentId = attachmentId;
	}

	public String getSourceSystemName() {
		return sourceSystemName;
	}

	public void setSourceSystemName(String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}

	public Date getSourceSystemDateCreated() {
		return sourceSystemDateCreated==null?null:(Date)sourceSystemDateCreated.clone();
	}

	public void setSourceSystemDateCreated(Date sourceSystemDateCreated) {
		this.sourceSystemDateCreated = sourceSystemDateCreated==null?null:(Date)sourceSystemDateCreated.clone();
	}

}