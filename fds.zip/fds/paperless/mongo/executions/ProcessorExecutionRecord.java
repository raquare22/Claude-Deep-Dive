/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 */

////package com.optum.fs.mongo.executions;
package com.optum.fds.paperless.mongo.executions;

import java.io.Serializable;

public class ProcessorExecutionRecord extends ExecutionRecord implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String description;

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}
