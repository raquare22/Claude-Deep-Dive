/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/30/17.
 */

package com.optum.fds.paperless.mongo.executions;

import java.util.*;

/**
 *
 */
public class ExecutionRecord {

    private String appIdentifier;
    private int clientId;
    private Date dateCreated;
    private Date dateModified;
    private List<Map<String, String>> messageList;
    private String serverName;
    private String serverIp;
    private int spaceId;
    private String status;
    private String version;

    /************* Activiti Workflow stuff *****************/
    private String activitiJobId;
    private String activitiJobStatus;
    private String activitiProcessKey;
    private Date dateActivitiJobCompleted;
    private Date dateActivitiJobCreated;
    private Date dateActivitiJobModified;

    /************************* Getters and Setters **********************/
    public String getAppIdentifier() {
        return appIdentifier;
    }

    public void setAppIdentifier(String appIdentifier) {
        this.appIdentifier = appIdentifier;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public Date getDateCreated() {
        return dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public Date getDateModified() {
        return dateModified == null ? null : (Date) dateModified.clone();
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified == null ? null : (Date) dateModified.clone();
    }

    public List<Map<String, String>> getMessageList() {
        return messageList == null ? null : new ArrayList<>(messageList);
    }

    public void setMessageList(List<Map<String, String>> messageList) {
        this.messageList = messageList == null ? Collections.emptyList() : new ArrayList<>(messageList);
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getServerName() {
        return serverName;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getActivitiJobId() {
        return activitiJobId;
    }

    public void setActivitiJobId(String activitiJobId) {
        this.activitiJobId = activitiJobId;
    }

    public String getActivitiJobStatus() {
        return activitiJobStatus;
    }

    public void setActivitiJobStatus(String activitiJobStatus) {
        this.activitiJobStatus = activitiJobStatus;
    }

    public String getActivitiProcessKey() {
        return activitiProcessKey;
    }

    public void setActivitiProcessKey(String activitiProcessKey) {
        this.activitiProcessKey = activitiProcessKey;
    }

    public Date getDateActivitiJobCompleted() {
        return dateActivitiJobCompleted == null ? null : (Date) dateActivitiJobCompleted.clone();
    }

    public void setDateActivitiJobCompleted(Date dateActivitiJobCompleted) {
        this.dateActivitiJobCompleted = dateActivitiJobCompleted == null ? null : (Date) dateActivitiJobCompleted.clone();
    }

    public Date getDateActivitiJobCreated() {
        return dateActivitiJobCreated == null ? null : (Date) dateActivitiJobCreated.clone();
    }

    public void setDateActivitiJobCreated(Date dateActivitiJobCreated) {
        this.dateActivitiJobCreated = dateActivitiJobCreated == null ? null : (Date) dateActivitiJobCreated.clone();
    }

    public Date getDateActivitiJobModified() {
        return dateActivitiJobModified == null ? null : (Date) dateActivitiJobModified.clone();
    }

    public void setDateActivitiJobModified(Date dateActivitiJobModified) {
        this.dateActivitiJobModified = dateActivitiJobModified == null ? null : (Date) dateActivitiJobModified.clone();
    }

    /********** Methods *********/
    public void addMessage(Map<String, String> message) {
        if (messageList == null) {
            messageList = new ArrayList<>();
        }
        messageList.add(message);
    }
    
    public void updateMessage(Map<String, String> message) {
    	if (messageList == null) {
    		messageList = new ArrayList<>();
    		messageList.add(message);
    	} else {
    		messageList.set(0, message);
    	}
    }
}
