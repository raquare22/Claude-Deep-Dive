package com.optum.fds.paperless.mongo;

import java.util.Date;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "docvaultTransaction")
public class DocvaultTransaction  {
    
    @Id
    private String id;
    
    private int spaceId;
    private String fsId;
    private String documentId;
    private String fileName;
    private String podName;
    private Date dateSent;
    private int responseCode;
    private String responseMsg;
    private Map<String, Object> errorMap;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public int getSpaceId() {
        return spaceId;
    }
    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }
    public String getFsId() {
        return fsId;
    }
    public void setFsId(String fsId) {
        this.fsId = fsId;
    }
    public String getDocumentId() {
        return documentId;
    }
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getPodName() {
        return podName;
    }
    public void setPodName(String podName) {
        this.podName = podName;
    }
    public Date getDateSent() {
        return dateSent;
    }
    public void setDateSent(Date dateSent) {
        this.dateSent = dateSent;
    }
    public int getResponseCode() {
        return responseCode;
    }
    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }
    public String getResponseMsg() {
        return responseMsg;
    }
    public void setResponseMsg(String responseMsg) {
        this.responseMsg = responseMsg;
    }
    public Map<String, Object> getErrorMap() {
        return errorMap;
    }
    public void setErrorMap(Map<String, Object> errorMap) {
        this.errorMap = errorMap;
    }

}
