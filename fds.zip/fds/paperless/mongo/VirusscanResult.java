/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who              Revision
 * Oct 30 2014  Kwasi Boateng 	 Initial version
 ****************************************************************/
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

/**
 * Virus scan results object to store in mongo
 * 
 * @author KBoateng
 *
 */
public class VirusscanResult {
	private String filename;
	private String status;
	private String statusCode;
	private String description;
	private int fileSize;
	
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public int getFileSize() {
		return fileSize;
	}
	
	public void setfileSize(int fileSize) {
		this.fileSize = fileSize;
	} 
}
