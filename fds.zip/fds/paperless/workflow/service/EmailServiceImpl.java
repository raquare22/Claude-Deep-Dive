package com.optum.fds.paperless.workflow.service;

import com.optum.fds.paperless.email.EmailSender;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;

import java.net.Inet4Address;
import java.util.Arrays;
import java.util.Map;

@Service("emailService")
public class EmailServiceImpl implements EmailService {
	
	@Value("${ELR_SMTP_RELAY_HOST}")
	private String elrSMTPRelayOSEHost;
	

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	JavaMailSender javaMailSender;


	public EmailServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	/**
	 * Below Method will be used for sending mails with error/exception details.
	 * 
	 * @param errorMap
	 * @return void
	 */
	public boolean sendEmail(DelegateExecution execution, Map<String, Object> errorMap, String message) {

		boolean mailSent = false;
		LOGGER.debug("EmailServiceImpl-->sendEmail-->ENTER");
		if(errorMap != null && !errorMap.isEmpty()) {
		for (Map.Entry<String, Object> errMsg : errorMap.entrySet()) {
			LOGGER.debug("EmailServiceImpl-->sendEmail-->{}", errMsg.getKey().concat(": ").concat(errMsg.getValue().toString()));
		}
		}
		try {
			boolean isErrorExists = false;
			if ((errorMap != null &&  errorMap.get(Workflow.NEW_ERRORS) != null && errorMap.size() > 1)
					|| (errorMap != null && errorMap.get(Workflow.NEW_ERRORS) == null && errorMap.size() >= 1)) {
				isErrorExists = true;
			}
			if (errorMap != null && !errorMap.isEmpty() ) {
				for (Map.Entry<String, Object> errMsg : errorMap.entrySet()) {
					LOGGER.debug("{}: {}", errMsg.getKey(), errMsg.getValue());
				}
			}
			if (isErrorExists) {
				
				String emailSender = "noreply@optum.com";
				String emailReceiver = execution.getVariable(Workflow.EMAIL_RECEIVER, String.class);
				String emailMessage = getEmailMessage(errorMap, message);
				String environment = execution.getVariable(Workflow.ENVIRONMENT, String.class);
				String hostName = Inet4Address.getLocalHost().getHostAddress();
				String emailSubject = "FDS: Exception in " + execution.getEventName() + " - " + environment + " - "
						+ hostName;
				

				if (javaMailSender instanceof JavaMailSenderImpl) {
					JavaMailSenderImpl javaMailSenderImpl = (JavaMailSenderImpl) javaMailSender;
					javaMailSenderImpl.setHost(elrSMTPRelayOSEHost);
				}
				if (emailReceiver.contains("{")) {
					// if multiple receiver emails, parse the string into an array
					String[] emailReceiverArr = parseEmailReceiver(emailReceiver);
					LOGGER.debug("parseEmailReceiver arr={}", Arrays.toString(emailReceiverArr));
					EmailSender.sendMail(emailSender, emailReceiverArr, emailSubject, emailMessage, javaMailSender);
				} else {
					EmailSender.sendMail(emailSender, emailReceiver, emailSubject, emailMessage, javaMailSender);
				}
				mailSent = true;
			}

		} catch (Exception e) {
			LOGGER.error("sendEmail Error while sending out Email {}={}, {}={} {}",
					"delegateExecutionId", execution != null ? execution.getId() : "NULL",
					"message", message,
					ExceptionUtils.getStackTrace(e));
			mailSent = false;
		}
		LOGGER.debug("EmailServiceImpl-->sendEmail-->EXIT");
		return mailSent;
	}

	/**
	 * Generate Email message based on error details.
	 * 
	 * @param errorMap
	 * @return String
	 */
	private String getEmailMessage(Map<String, Object> errorMap, String message) {
		StringBuilder sb = new StringBuilder();
		if (StringUtils.isNotEmpty(message)) {
			sb.append(message);
			sb.append("\n");
		}
		for (Map.Entry<String, Object> errMsg : errorMap.entrySet()) {
			if (!(Workflow.NEW_ERRORS).equals(errMsg.getKey())) {
				sb.append(errMsg.getKey()).append(": ").append(errMsg.getValue());
			}
		}

		return sb.toString();
	}

	@Override
	public boolean sendEmail(DelegateExecution execution, String message) {
		boolean mailSent = false;
		LOGGER.debug("EmailServiceImpl-->sendEmail-->ENTER");
		
		try {
				String emailSender = execution.getVariable(Workflow.EMAIL_SENDER, String.class);
				String emailReceiver = execution.getVariable(Workflow.EMAIL_RECEIVER, String.class);
				String emailMessage = getEmailMessage(message);
				String emailSubject = execution.getVariable(Workflow.EMAIL_SUBJECT, String.class);

				if (javaMailSender instanceof JavaMailSenderImpl) {
					JavaMailSenderImpl javaMailSenderImpl = (JavaMailSenderImpl) javaMailSender;
					javaMailSenderImpl.setHost(elrSMTPRelayOSEHost);
				}
				
				if (emailReceiver.contains("{")) {
					// if multiple receiver emails, parse the string into an array
					String[] emailReceiverArr = parseEmailReceiver(emailReceiver);
					LOGGER.debug("parseEmailReceiver arr={}", Arrays.toString(emailReceiverArr));
					EmailSender.sendMail(emailSender, emailReceiverArr, emailSubject, emailMessage, javaMailSender);
				} else {
					EmailSender.sendMail(emailSender, emailReceiver, emailSubject, emailMessage, javaMailSender);
				}
				
				
				mailSent = true;
			

		} catch (Exception e) {
			LOGGER.error("sendEmail Error while sending out Email {}={}, {}={} {}",
					"delegateExecutionId", execution != null ? execution.getId() : "NULL",
					"message", message,
					ExceptionUtils.getStackTrace(e));
			mailSent = false;
		}
		LOGGER.debug("EmailServiceImpl-->sendEmail-->EXIT");
		return mailSent;
	}
	
	private String getEmailMessage(String message) {
		StringBuilder sb = new StringBuilder();
		if (StringUtils.isNotEmpty(message)) {
			sb.append(message);
			sb.append("\n");
		}
		return sb.toString();
	}
	
	protected String[] parseEmailReceiver(String emailReceiver) {
		return emailReceiver.substring(emailReceiver.indexOf("{")+1, emailReceiver.indexOf("}")).split("\\s*;\\s*");
	}

}
