package com.optum.fds.paperless.workflow.constants;


import org.apache.commons.text.CaseUtils;

public enum OptumProcessEnum {

    START("start"),
    END("end"),
    STD_PROCESS_CATEGORY("stdProcessCategory"),
    TRANSFORM_MERGE_PROCESS("transformMergeProcess"),
    TRANSFORM_PROCESS("transformProcess"),
    DATABASE_INSERT_PROCESS("databaseInsertProcess"),
    CSV_CLEANUP_FILES_PROCESS("csvCleanupFilesProcess"),
    SECURE_MESSAGE_PROCESS("secureMessageProcess"),
    SECURE_MESSAGE_WITH_TEMPLATE_PROCESS("secureMessageWithTemplateProcess"),
    RABBIT_MQ_PROCESS("rabbitMQProcess"),
    RABBIT_MQ_FOR_ELGS_PROCESS("rabbitMQForELGSProcess"),
    RABBIT_MQ_READER_PROCESS("rabbitMQReaderProcess"),

    PREPROCESS_VALIDATION_PROCESS("preprocessValidationProcess"),

    TRANSFORM_MERGE_PROCESS_ASYNC("transformMergeProcessAsync"),
    SFTP_PROCESS("sftpProcess"),

    METADATA_FILE_PROCESS("metadataFileProcess"),
    FILE_UNZIP_PROCESS("fileUnzipProcess"),
    CLEANUP_FILES_CREATE_ACK_PROCESS("cleanupFilesCreateACKProcess"),

    BOUNCED_PROVIDER_EMAIL_ADDRESS_PROCESS("bouncedProviderEmailAddressProcess"),

    RETRIEVE_PROVIDER_EMAIL_ADDRESS_PROCESS("retrieveProviderEmailAddressProcess"),
    RETRIEVE_CORPORATE_MPIN_PROCESS("retrieveCorporateMPINProcess"),

    PROCESSOR_RESTART_PROCESS("processorRestartProcess"),
	DELETE_RECORDS_ON_EXPIRY_DATE_PROCESS("deleteRecordsOnExpiryDateProcess"),

    EMAIL_DOCUMENT_PROCESS("emailDocumentProcess"),
    ORS_INTEGRATION_PROCESS("orsIntegrationProcess"),

    PURGE_DOCUMENT_PROCESS("purgeDocumentProcess"),
    CSV_TO_FDS_DOCUMENT_PROCESS("csvToFdsDocumentProcess"),

    CSV_SFTP_PROCESS("csvSftpProcess"),
    CALL_REST_API_PROCESS("callRestApiProcess"),

    NO_CORPORATE_MPIN_OR_NO_EMAIL_ADDRESS_PROCESS("noCorporateMPINOrNoEmailAddressRerouteProcess"),

    SEND_TO_SHUTTERFLY_PROCESS("sendToShutterflyProcess"),
    SEND_DOCUMENTS_TO_SHUTTERFLY_PROCESS("sendDocumentsToShutterflyProcess"),

    RETRIEVE_CORPORATE_MPIN_V2_PROCESS("retrieveCorporateMPINv2Process"),

    IRIS_COPAY_HOLD_PROCESS("irisCopayHoldProcess"),

    MAP_DOCUMENTS_FROM_DB_TO_SFTP_DIRECTORY_PROCESS("mapDocumentsFromDbToSftpDirectoryProcess"),

    TRANSFORM_MERGE_ATTACHMENTS_UPDATE_DOCUMENT_PROCESS ("transformMergeAttachmentsUpdateDocumentProcess"),

    CLEANUP_FILES_CREATE_ACK_TEMPLATE_PROCESS("cleanupFilesCreateACKProcessWithTemplateProcess"),

    SFTP_OUTBOUND_PROCESS("sftpOutboundProcess"),

    WORKFLOW1("workflow1"),

    CHECK_SPACE_PROPERTIES_PROCESS("checkSpacePropertiesForFormSettings"),

    REQUIRED_FIELD_RULE_PROCESS("requiredFieldRuleProcess"),

    FORM_SUBMITTED_TRANSACTION_SEND_EMAIL_PROCESS("formSubmittedTransactionSendEmailProcess"),

    DOCUMENT_EXPIRATION_EMAILS_PROCESS("documentExpirationEmailsProcess"),
    MATCH_AND_MERGE_DOCUMENTS_FROM_DB_PROCESS("matchAndMergeDocumentsFromDbProcess"),
    SECURE_MESSAGE_WITH_UPDATE_DOCUMENT_PROCESS("secureMessageWithUpdateDocumentProcess"),
    EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS("emailProcessorTransactionMetadataProcess"),
    SIMPLE_EMAIL_PROCESS("simpleEmailProcess"),

    POST_DOCUMENT_DOCVAULT_PROCESS,
    POST_DOCUMENT_DOCVAULT_FOR_ELGS_PROCESS,
    PROVIDER_EMAIL_NOTIFICATION_POST_PROCESS("providerEmailNotificationPostProcess"),
    PROVIDER_EMAIL_NOTIFICATION_PROCESS("providerEmailNotificationProcess"),
	APPEALS_RESPONSE_FILE_PROCESS("AppealsResponseFileProcess");


    private final String name;

    /*
     * Add an enum as all caps with underscore word separator
     * Do not use parens with String and this constructor
     * will create a String in camel case with the first letter in lowercase
     * We are keeping previous entered Strings for backward compatibility*
     * Comma separated enum list, last entry closes with semicolon
     * Keep the name below 46 characters
     */
    private OptumProcessEnum() {
        name = CaseUtils.toCamelCase(this.name(), false, '_');
    }

    /*
     * Enter a String when adding an enum
     * The toString() method will return the String you enter
     * By convention we are starting the names for processes with a lowercase letter
     * Keep the name below 46 characters (example: with concat of Process:1:22916 want to keep below 64 for id_ column)
     */
    private OptumProcessEnum(String value) {
        this.name = value;
    }

    @Override
    public String toString() {
        return this.name;
    }

}
