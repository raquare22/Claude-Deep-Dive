package com.optum.fds.paperless.workflow.constants;

import org.apache.commons.text.CaseUtils;

public enum OptumTaskEnum {
	
    STD_TASK_CATEGORY("stdTaskCategory"),
    
    CLEAN_INGEST_TASK("CleanIngestFiles"),
    MERGE_TASK("MergeFiles"),
    TRANSFORM_TASK("TransformToPdf"),
    WAIT_TASK("RelayMetaData"),
    CREATE_DOCUMENT_TASK("CreateDocument"),
    UPDATE_DOCUMENT_TASK("UpdateDocument"),
    CREATE_ATTACHMENT_TASK("CreateAttachment"),
    DELETE_INGEST_FILES_TASK("DeleteIngestFiles"),
    SWITCH_TO_ASYNC_TASK("SwitchToAsync"),
    DATABASE_INSERT_TASK("DatabaseInsert"),
    
    SECURE_MESSAGE_TASK("SecureMessage"),
    SECURE_MESSAGE_WITH_TEMPLATE_TASK("SecureMessageWithTemplate"),
    REQUIRED_VARS_FOR_SECURE_MESSAGE_WITH_TEMPLATE_TASK("RequiredVarsForSecureMessageWithTemplate"),
    OAUTH_FOR_SMAPI_TASK("OauthForSmapi"),
    RABBIT_MQ_TASK("RabbitMQ"),
    RABBIT_MQ_READER_TASK("RabbitMQReader"),
    RABBIT_MQ_POST_TASK("RabbitMQPost"),
    
    PREPROCESS_VALIDATION_TASK("PreprocessValidation"),
    CLEANUP_RABBIT_MQ_READER_TASK("CleanupRabbitMQReader"),
   
    ERROR_HANDLER_TASK("ErrorHandler"),

    SFTP_TASK("Sftp"),
    SFTP_CLEANUP_TASK("SftpCleanup"),
    
    CSV_SFTP_TASK("CsvSftp"),
    CALL_REST_API_TASK("CallRestApi"),
      
    METADATA_FILE_TASK("MetadataFile"),
    FILE_UNZIP_TASK("FileUnzip"),
    CLEANUP_FILES_CREATE_ACK_TASK("CleanupFilesCreateACK"),
    CREATE_ACK_FILE_TASK("CreateACKFile"),
    SEND_ACK_FILE_TO_SFTP_SERVER_TASK("SendACKFileToSftpServer"),
    MOVE_ORIGINAL_ZIP_TO_ARCHIVE_FOLDER_TASK("MoveOriginalZipToArchiveFolder"),
    DELETE_WORKING_DIRECTORY_TASK("DeleteWorkingDirectory"),
    CSV_DELETE_WORKING_DIRECTORY_TASK("CSVDeleteWorkingDirectory"),
	
	CSV_UPDATE_PROCESSOR_TRANSACTION_STATUS_TASK("CsvUpdateProcessorTransactionStatus"),
	
	CSV_MOVE_ORIGINAL_TO_ARCHIVE_FOLDER_TASK("CsvMoveOriginalToArchiveFolder"),
    
	IDENTIFY_DOCUMENTS_TASK("IdentifyDocuments"),
	MANIPULATE_PDF_FILE_TASK("ManipulatePdfFile"),
	IDENTIFY_SHUTTERFLY_DOCUMENTS_TASK("IdentifyShutterflyDocuments"),
    
	OAUTH_TASK("Oauth"),
    RETRIEVE_PROVIDER_EMAIL_ADDRESS_TASK("RetrieveProviderEmailAddress"),
	CREATE_SHUTTERFLY_DOCUMENTS("CreateShutterflyDocuments"),
    RETRIEVE_CORPORATE_MPIN_TASK("RetrieveCorporateMPIN"),
    RETRIEVE_CORPORATE_MPIN_V2_TASK("RetrieveCorporateMPINv2"),
    SAVE_CORPORATE_MPIN_TASK("SaveCorporateMPIN"),
    EMAIL_FDS_SSMO("EmailFdsSsmo"),

    PROCESSOR_RESTART_TASK("ProcessorRestart"),
    CREATE_ONE_ZIPFILE_PRINTSERVICES_TASK("CreateOneZipfilePrintServices"),
    DELETE_RECORDS_ON_EXPIRY_DATE_TASK("DeleteRecordsOnExpiryDate"),

    OAUTH_MANAGER_TASK("OauthManager"),
    BUILD_EMAIL_TASK("BuildEmail"),
    SEND_EMAIL_TASK("SendEmail"),
    CONNECT_AND_RETRIEVE_DOC_RECORD_TASK("ConnectAndRetrieveDocRecord"),
    UPDATE_DOCUMENT_SENT_TO_PRINT_SERVICES_IF_NEEDED("UpdateDocumentSentToPrintServicesIfNeeded"),
    
    NO_CORPORATE_MPIN_OR_NO_EMAIL_ADDRESS_DOCUMENTS_TASK("IdentifyNoMPINOrNoEmailAddressDocuments"),
    CONNECT_AND_RETRIEVE_DOCUMENTS_TASK("ConnectAndRetrieveDocuments"),

	RABBIT_MQ_RECORD_INGEST_TASK("RabbitMqRecordIngestTask"),

	MAP_FIELDS_TO_ORS_API("MapFieldsToOrsApi"),

	SEND_DOCUMENT_TO_ORS_API("SendDocumentToOrsApi"),

	PURGE_DOCUMENT_TASK("PurgeDocument"),

	JSON_FILE_TO_REST_API("JsonFileToRestApi"),

	CSV_TO_JSON_FILE_TASK("CsvToJsonFile"),

	ORS_SOAP_LOGGER("ORSSoapLogger"),

	HTTP_POST("HttpPost"),

	HTTP_URL_ENCODED_FORM_POST("HttpUrlEncodedFormPost"),

	HTTP_GET("HttpGet"),

    JSON_PARSER("JsonParser"),

    IRIS_COPAY_HOLD_WRAPPER("IrisCopayHoldWrapper"),
    
    REQUIRED_VARS_FOR_MAP_DOCUMENTS_TO_SFTP_DIRECTORY_TASK("RequiredVarsForMapDocumentsToSftpDirectoryTask"),
    
    IDENTIFY_DOCUMENTS_FROM_DB("IdentifyDocumentsFromDb"),
    TRANSFORM_JSON_FILE_WITH_TEMPLATE("TransformJsonFileWithTemplate"),
    
	RETRIEVE_ATTACHMENTS_AND_FORMPDF("RetrieveAttachmentsAndFormPdf"),

	TRANSFORM_MERGE_TASK("TransformAndMerge"),

	UPDATE_DOCUMENT_API_TASK("UpdateDocumentApi"),

	VERIFY_REQ_VARS_FOR_TRANSFORM_PROCESS("VerifyRequiredVarsForTransformProcess"),
	
	REQUIRED_VARS_FOR_CLEANUP_FILES_CREATE_ACK_TEMPLATE_TASK("RequiredVarsCleanUpAndACkTemplate"),
	
	RETRIEVE_PROCESSOR_TRANSACTIONS_TASK("RetrieveProcessorTransaction"),
	
	CREATE_ACK_TEMPLATE_TASK("CreateAckTemplate"),
	
	SEND_FILE_TO_SFTP_TASK("SendFileToSFTP"),

	VERIFY_REQ_VARS_FOR_SFTP_PROCESS("VerifyRequiredVarsForSftpProcess"),

	PERFORM_OUTBOUND_SFTP("PerformOutboundSftp"),
	
	SFTP_OUTBOUND_SEND_EMAIL_NOTIFICATION_TASK("SftpOutboundSendEmailNotification"),

	RETRIEVE_MERGED_ATTACHMENT("RetrieveAttachment"),

    UPDATE_PROCESSOR_TRANSACTION_LIST_TASK_1("UpdateProcessorTransactionList_1"),

    UPDATE_PROCESSOR_TRANSACTION_LIST_TASK_2("UpdateProcessorTransactionList_2"),	

	SEND_RESPONSE_TO_SFTP_TASK("SendResponseFileToSftp"),
	
	IDENTIFY_DOCUMEMTS_FROM_DB_TASK("IdentifyDocumentsFromDb"),

	CHECK_SPACE_PROPERTIES_FOR_FORM_SETTING("CheckSpacePropertiesForFormSetting"),
	
    GET_SPACE_PROPERTIES_TASK("GetSpacePropertiesTask"),
	
	VERIFY_REQ_VARS_FOR_SPACE_PROPERTIES("VerifyRequiredVarsForSpaceProperties"),
	
	CALL_NEXT_PROCESS_BASED_ON_CRITERIA("CallNextProcessBasedOnCriteria"),
	
	OAUTH_MANAGER_LIST_TASK("OauthManagerList"),
	
	
    SEND_DOCUMENT_TRANSACTION_EMAIL_TASK("SendDocumentTransactionEmail"),
    EMAIL_SIMPLE(),
	PROCESS_REQUIRED_FIELD_RULE_TASK("ProcessRequiredFieldRule"),
	
	DOCUMENT_EXPIRATION_EMAILS_TASK("DocumentExpirationEmails"),
	
	SECURE_MESSAGE_LIST_WITH_TEMPLATE_TASK("SecureMessageListWithTemplate"),
	REQUIRED_VARS_FOR_MATCH_AND_MERGE_DOCUMENTS_FROM_DB("RequiredVarsForMatchAndMergeDocumentsFromDb"),
	
	UPDATE_DOCUMENT_WITH_HOOK_ELEMENTS("UpdateDocumentWithHookElements"),
	
	MATCH_AND_MERGE_DOCUMENTS_FROM_DB("MatchAndMergeDocumentsFromDB"),
	
     REQUIRED_VARS_FOR_EMAIL_PROCESSOR_TRANSACTION_METADATA("RequiredVarsForEmailProcessorTransactionMetadata"),
     
     IDENTIFY_PROCESSOR_TRANSACTION_METADATA_FROM_DB("IdentifyProcessorTransactionMetadataFromDb"),
     
     SET_PROCESSOR_TRANSACTION_METADATA_FOR_COSMOS_PRA("SetProcessorTransactionMetadataForCosmosPRA"),
     
     SEND_EMAIL_LIST("SendEmailList"),
     
     UPDATE_PROCESSOR_TRANSACTION_METADATA("UpdateProcessorTransactionMetadata"),
     
     CLEAN_INGEST_FILES("CleanIngestFiles"),
     
     ACCESS_TOKEN_DOCVAULT_TASK("AccessTokenDocvault"),
     POST_DOCUMENT_DATA_DOCVAULT_TASK("PostDocumentDataDocvault"),
     UPDATE_DOCUMENT_LIST_DOCVAULT_TASK("UpdateDocumentListDocvault"),
     CHECK_FOR_DUPLICATE_TASK("CheckForDuplicate"),
     SEND_EMAIL_REQUEST_TO_PEN ("SendEmailRequestToPEN"),
     REQUIRED_VARS_FOR_PROVIDER_EMAIL_NOTIFICATION("RequiredVarsForProviderEmailNotification"),
	
	REQUIRED_VARS_APPEALS_RESPONSE_FILE_PROCESS("RequiredVarsAppealsResponseFileProcess"),

    RETRIEVE_EMAIL_FROM_DIGITAL_SECURITY("RetrieveEmailFromDigiSec"),
	TRANSFORM_JSON_AND_GENERATE_FILE("TransformJsonAndGenerateFile");
	
	private final String name;
	
	/*
	 * Add an enum as all caps with underscore word separator
	 * Do not use parens with String and this constructor
	 * will create a String in camel case with the first letter as a cap
	 * to use for the toString() method when creating task services
	 * We are keeping previous entered Strings for backward compatability
	 * Comma separated enum list, last entry closes with semicolon
	 * Keep the name below 46 characters
	 */
	private OptumTaskEnum() {
		name = CaseUtils.toCamelCase(this.name(), true, '_');
	}
	
	/*
	 * Enter a String when adding an enum
	 * The toString() method will return the String you enter
	 * By convention we are starting the Service names for tasks with a cap
	 * Keep the name below 46 characters (example: with concat of TaskWrap:1.22676 want to keep below 64 for id_ column)
	 */
	private OptumTaskEnum(String value) {
		this.name = value;		
	}
	
	@Override
	public String toString() {
		return this.name;
	}

}