package com.optum.fds.paperless.workflow.beans;

public class ZipUtilBean {
	String fileName;
	String zipEntryFileName;
	String pathOrigin;
	
	public ZipUtilBean(String fileName, String zipEntryFileName, String pathOrigin) {
		super();
		this.fileName = fileName;
		this.zipEntryFileName = zipEntryFileName;
		this.pathOrigin = pathOrigin;
	}
	public String getFileName() {
		return fileName;
	}
	public String getZipEntryFileName() {
		return zipEntryFileName;
	}
	public String getPathOrigin() {
		return pathOrigin;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setZipEntryFileName(String zipEntryFileName) {
		this.zipEntryFileName = zipEntryFileName;
	}
	public void setPathOrigin(String pathOrigin) {
		this.pathOrigin = pathOrigin;
	}
	
	@Override
	public String toString() {
		return "ZipUtilBean [fileName=" +
				fileName +
				", zipEntryFileName=" +
				zipEntryFileName +
				", pathOrigin=" +
				pathOrigin +
				"]";
	}

	public static ZipUtilBean from(String fileName, String zipEntryFileName, String pathOrigin) {
		return new ZipUtilBean(fileName, zipEntryFileName, pathOrigin);
	}
	
}
