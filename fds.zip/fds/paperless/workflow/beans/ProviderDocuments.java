package com.optum.fds.paperless.workflow.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Not used in RetrieveProviderEmailWorkflow as PDO document will be directly fetched from Prun Mongo
 * Instead use a List<ProviderDocument> instead.
 */
@Deprecated
public class ProviderDocuments {

    private List<ProviderDocument> documents;

    private String totalRecords;

    private String startRecord;

    private int count;

    public List<ProviderDocument> getDocuments() {
        return (documents == null) ? Collections.emptyList() : new ArrayList<>(documents);
    }

    public ProviderDocuments setDocuments(List<ProviderDocument> documents) {
        this.documents = documents == null ? Collections.emptyList() : new ArrayList<>(documents);
        return this;
    }

    public String getTotalRecords() {
        return totalRecords;
    }

    public ProviderDocuments setTotalRecords(String totalRecords) {
        this.totalRecords = totalRecords;
        return this;
    }

    public String getStartRecord() {
        return startRecord;
    }

    public ProviderDocuments setStartRecord(String startRecord) {
        this.startRecord = startRecord;
        return this;
    }

    public int getCount() {
        return count;
    }

    public ProviderDocuments setCount(int count) {
        this.count = count;
        return this;
    }
}
