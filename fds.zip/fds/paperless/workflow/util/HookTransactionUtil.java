package com.optum.fds.paperless.workflow.util;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class HookTransactionUtil {

	private HookTransactionUtil() {
		throw new AssertionError("no instance should be created");
	}

	public static HookTransactionMetaData createHookTransaction(DocumentMetaData documentMetaDataObject,
			Map<String, String> hookExecutionMessage, String processName) {

		var hookTransactionMetaData = new HookTransactionMetaData().setSpaceId(documentMetaDataObject.getSpaceId())
				.setClientId(documentMetaDataObject.getClientId())
				.setAppIdentifier(documentMetaDataObject.getAppIdentifier()).setStatus(Workflow.HOOK_STATUS_ACTIVE)
				.setDateCreated(new Date()).setDateModified(new Date())
				.setHookRecordType(Workflow.HOOK_RECORD_TYPE_TRANSACTION).setTargetId(documentMetaDataObject.getId())
				.setTargetType(Workflow.DOCUMENTS_COLLECTION);

		HookExecutionRecordMetaData hookExecutionRecordMetaData = new HookExecutionRecordMetaData();
		hookExecutionRecordMetaData.setAppIdentifier(documentMetaDataObject.getAppIdentifier());
		hookExecutionRecordMetaData.setDateCreated(new Date());
		hookExecutionRecordMetaData.setClientId(documentMetaDataObject.getClientId());
		hookExecutionRecordMetaData.setSpaceId(documentMetaDataObject.getSpaceId());
		hookExecutionRecordMetaData.setActivitiProcessKey(processName);
		hookExecutionRecordMetaData.addMessage(hookExecutionMessage);
		hookTransactionMetaData.setHookExecutionList(List.of(hookExecutionRecordMetaData));

		return hookTransactionMetaData;
	}

	public static HookTransactionMetaData createCronHookTransaction(
			HookExecutionRecordMetaData hookExecutionRecordMetaData) {

		var hookTransactionMetaData = new HookTransactionMetaData().setSpaceId(hookExecutionRecordMetaData.getSpaceId())
				.setStatus(Workflow.HOOK_STATUS_ACTIVE).setDateCreated(new Date()).setDateModified(new Date())
				.setHookRecordType(Workflow.HOOK_RECORD_TYPE_TRANSACTION)
				.setClientId(hookExecutionRecordMetaData.getClientId())
				.setTargetId(hookExecutionRecordMetaData.getHookId()).setTargetType(Workflow.HOOK);
		hookTransactionMetaData.setHookExecutionList(List.of(hookExecutionRecordMetaData));

		return hookTransactionMetaData;
	}

	public static HookExecutionRecordMetaData getHookExecutionRecord(Map<String, String> hookExecutionRecord,
			Map<String, String> hookExecutionMessage, String processName) {
		HookExecutionRecordMetaData hookExecutionRecordMetaData = new HookExecutionRecordMetaData();
		hookExecutionRecordMetaData.setAppIdentifier(hookExecutionRecord.get(Workflow.APP_IDENTIFIER));
		hookExecutionRecordMetaData.setHookId(hookExecutionRecord.get(Workflow.HOOK_ID));
		hookExecutionRecordMetaData.setDateCreated(new Date());
		hookExecutionRecordMetaData.setSpaceId(Integer.parseInt(hookExecutionRecord.get(Workflow.SPACE_ID)));
		hookExecutionRecordMetaData.setActivitiProcessKey(processName);
		hookExecutionRecordMetaData.addMessage(hookExecutionMessage);

		return hookExecutionRecordMetaData;
	}
	
	public static HookTransactionMetaData createHookTransactionWithHookId(DocumentMetaData documentMetaDataObject,
			Map<String, String> hookExecutionMessage, String processName, String hookId) {

		var hookTransactionMetaData = new HookTransactionMetaData().setSpaceId(documentMetaDataObject.getSpaceId())
				.setClientId(documentMetaDataObject.getClientId())
				.setAppIdentifier(documentMetaDataObject.getAppIdentifier()).setStatus(Workflow.HOOK_STATUS_ACTIVE)
				.setDateCreated(new Date()).setDateModified(new Date())
				.setHookRecordType(Workflow.HOOK_RECORD_TYPE_TRANSACTION).setTargetId(documentMetaDataObject.getId())
				.setTargetType(Workflow.DOCUMENTS_COLLECTION);

		HookExecutionRecordMetaData hookExecutionRecordMetaData = new HookExecutionRecordMetaData();
		hookExecutionRecordMetaData.setAppIdentifier(documentMetaDataObject.getAppIdentifier());
		hookExecutionRecordMetaData.setDateCreated(new Date());
		hookExecutionRecordMetaData.setClientId(documentMetaDataObject.getClientId());
		hookExecutionRecordMetaData.setSpaceId(documentMetaDataObject.getSpaceId());
		hookExecutionRecordMetaData.setActivitiProcessKey(processName);
		hookExecutionRecordMetaData.addMessage(hookExecutionMessage);
		hookExecutionRecordMetaData.setHookId(hookId);
		hookTransactionMetaData.setHookExecutionList(List.of(hookExecutionRecordMetaData));

		return hookTransactionMetaData;
	}
}
