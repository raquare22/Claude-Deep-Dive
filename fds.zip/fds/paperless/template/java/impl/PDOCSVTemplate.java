package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import java.io.IOException;
import java.util.*;

public class PDOCSVTemplate extends TemplateHandler{

    @Override
    public String convertWithTemplate(String jsonString) {

        var st = this.templateLoader.getTemplate(Templates.PDO_CSV);

        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentMetadataFromJsonString(jsonString);
        } catch (IOException e) {
        	throw new RuntimeException(e);
        }

        Map<String, String> metadataMap = new HashMap<>();

        return st.add("document", document)
                .add("map", metadataMap)
                .render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.PDO_CSV);

        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonFilePath(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Map<String, String> metadataMap = new HashMap<>();

        return st.add("document", document)
                .add("map", metadataMap)
                .render();
    }

    @Override
	public String convertWithTemplate(Object pojo) {
		return null;
	}
}