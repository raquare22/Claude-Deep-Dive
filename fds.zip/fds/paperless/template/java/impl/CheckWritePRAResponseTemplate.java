package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.apache.commons.lang.StringUtils;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.factory.Lists;
import org.eclipse.collections.impl.list.mutable.FastList;

import java.io.IOException;
import java.util.Date;
import java.util.List;

public class CheckWritePRAResponseTemplate extends TemplateHandler {

	@Override
	public String convertWithTemplate(String jsonString) {
		var st = this.templateLoader.getTemplate(Templates.CHECK_WRITE_PRA_RESPONSE);
		List<DocumentMetaData> documentMetaDataList;
		try {
			documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		var paramsList = FastList.<Params>newList();
		var counter = new Counter();
		for (var documentMetaData : documentMetaDataList) {
			var metaData = documentMetaData.getMetadata();
			var originalCompanionRecords = Lists.mutable
					.withAll(metaData.getList(Workflow.ORIGNIAL_COMPANION_FILE_RECORDS, String.class));
			var fileName = metaData.getString(Workflow.FILE_NAME);
			var dateCreated = documentMetaData.getDateCreated();
			var dateModified = documentMetaData.getDateModified();
			var originalPrintTrail = metaData.getString(Workflow.ORIGINAL_PRINT_TRAIL);
			var id = documentMetaData.getId();

			originalCompanionRecords.forEach(x -> paramsList.add(
					new Params(x, fileName, dateCreated, dateModified, originalPrintTrail, id, StringUtils.EMPTY)));
			counter.add(originalCompanionRecords.size());
		}

		return st.add("list", paramsList).add("counter", counter.toString()).render();
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		var st = this.templateLoader.getTemplate(Templates.CHECK_WRITE_PRA_RESPONSE);
		List<DocumentMetaData> documentMetaDataList;
		try {
			documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		var paramsList = FastList.<Params>newList();
		var counter = new Counter();
		for (var documentMetaData : documentMetaDataList) {
			var metaData = documentMetaData.getMetadata();
			var originalCompanionRecords = Lists.mutable
					.withAll(metaData.getList(Workflow.ORIGNIAL_COMPANION_FILE_RECORDS, String.class));
			var fileName = metaData.getString(Workflow.FILE_NAME);
			var dateCreated = documentMetaData.getDateCreated();
			var dateModified = documentMetaData.getDateModified();
			var originalPrintTrail = metaData.getString(Workflow.ORIGINAL_PRINT_TRAIL);
			var id = documentMetaData.getId();

			originalCompanionRecords.forEach(x -> paramsList.add(
					new Params(x, fileName, dateCreated, dateModified, originalPrintTrail, id, StringUtils.EMPTY)));
			counter.add(originalCompanionRecords.size());
		}

		return st.add("list", paramsList).add("counter", counter.toString()).render();
	}

	@Override
	public String convertWithTemplate(Object pojo) {
		return null;
	}

	static class Params {
		private final String originalCompanionFileRecords;
		private final String fileName;
		private final Date dateCreated;
		private final Date dateModified;
		private final String originalPrintTrail;
		private final String id;
		private final String fixedWidth;

		public Params(String originalCompanionFileRecords, String fileName, Date dateCreated, Date dateModified,
				String originalPrintTrail, String id, String fixedWidth) {
			this.originalCompanionFileRecords = originalCompanionFileRecords;
			this.fileName = fileName;
			this.dateCreated = dateCreated;
			this.dateModified = dateModified;
			this.originalPrintTrail = originalPrintTrail;
			this.id = id;
			this.fixedWidth = fixedWidth;
		}

		public String getOriginalCompanionFileRecords() {
			return originalCompanionFileRecords;
		}

		public String getFileName() {
			return fileName;
		}

		public Date getDateCreated() {
			return dateCreated;
		}

		public Date getDateModified() {
			return dateModified;
		}

		public String getOriginalPrintTrail() {
			return originalPrintTrail;
		}

		public String getId() {
			return id;
		}

		public String getFixedWidth() {
			return fixedWidth;
		}
	}
}
