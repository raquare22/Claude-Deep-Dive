package com.optum.fds.paperless.template.java.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.kafka.consumer.model.KafkaMessage;
import com.optum.fds.paperless.kafka.consumer.model.PlanDetails;
import com.optum.fds.paperless.kafka.consumer.model.ReferralDetails;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.Document;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.stringtemplate.v4.ST;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;


public class PCPEmailRequestToPENTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(PCPEmailRequestToPENTemplate.class);

    static ObjectMapper mapper = new ObjectMapper();

    @Override
    public String convertWithTemplate(String jsonString) {
        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonFile(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    private <T> T convertValueIfNeeded(Object obj, Class<T> clazz) {
        if (clazz.isInstance(obj)) {
            return clazz.cast(obj);
        } else if (obj instanceof Map) {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(obj, clazz);
        }
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        ST st = this.templateLoader.getTemplate(Templates.PCP_EMAIL_REQUEST_TO_PEN);
        DocumentMetaData document = (DocumentMetaData) pojo;
        PlanDetails planDetails = convertValueIfNeeded(document.getMetadata().get("planDetails"), PlanDetails.class);
        ReferralDetails referralDetails = convertValueIfNeeded(document.getMetadata().get("referralDetails"), ReferralDetails.class);
        String templateName = null;
        String category =null;

        HashMap<String, String> values = new HashMap<>();

        if (document.getMetadata().containsKey(Workflow.SEND_EMAIL_NOTIFICATIONS) &&
                Boolean.TRUE.equals(document.getMetadata().get(Workflow.SEND_EMAIL_NOTIFICATIONS))) {
            templateName = "PCP_Reminder";
            category = "PCP_Reminder";
        } else {
            templateName = "PCP";
            category = "PCP";
        }
        String formattedPlanEndDate = formatPlanEndDate(planDetails.getPlanEndDate());

        values.put("planEndDate", formattedPlanEndDate);
        values.put("requestId", referralDetails.getRequestId());
        values.put("templateName", templateName);
        values.put("category", category);

        return st.add("document", document)
                .add("values", values).render();
    }

    private String formatPlanEndDate(String planEndDateStr) {
        // 2024-07-12
        if (planEndDateStr == null || planEndDateStr.isEmpty()) {
            return "";
        }
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        DateFormat format2 = new SimpleDateFormat("MM/dd/yyyy");
        format2.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            Date date = format.parse(planEndDateStr);
            return format2.format(date);
        } catch (ParseException e) {
            LOGGER.error("convertDateToCSTFormat -- Unable to parse planEndDate string {}", planEndDateStr);
            return "";
        }

    }
}
