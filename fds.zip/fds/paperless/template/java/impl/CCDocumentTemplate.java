package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class CCDocumentTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(CCDocumentTemplate.class);

    @Override
    public String convertWithTemplate(String content) {

        if (StringUtils.isNullOrEmpty(content)) {
            LOGGER.error("CCDocumentTemplate --> file is empty");
            return null;
        }

        var st = this.templateLoader.getTemplate(Templates.CC_DOCUMENT_TEMPLATE);
        String[] contentArr = content.split("\\n");
        List<String> stringList = Arrays.asList(contentArr);
        ArrayList<String> list = new ArrayList<String>();
        list.addAll(stringList);

        if (list.isEmpty()) {
            LOGGER.error("CCDocumentTemplate --> file is empty");
            return null;
        }

        // ignore header line of file
        list.remove(0);

        List<Map<String, String>> metadataList = new ArrayList<>();

        for (String row : list) {

            Map<String, String> metadataMap = new HashMap<>();
            String[] rowContent = row.split(",");
            
            String indicator = rowContent[2] != null ? rowContent[2].toUpperCase() : rowContent[2];          

            metadataMap.put("corporateMpin", rowContent[0]);
            metadataMap.put("tin", rowContent[1]);
            metadataMap.put("templateEmailIndicator", indicator);
            metadataMap.put("category", indicator);

            metadataList.add(metadataMap);
        }


        return st.add("list", metadataList)
                .render();
    }


    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        String content = null;
        try {
            Path path = Path.of(filePath);
            content = Files.readString(path);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return convertWithTemplate(content);
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }

}
