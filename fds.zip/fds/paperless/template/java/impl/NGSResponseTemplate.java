package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class NGSResponseTemplate extends TemplateHandler {
	
	  private static final String GMT = "GMT-00:00";
	   

	@Override
	public String convertWithTemplate(String jsonString) {

		var st = this.templateLoader.getTemplate(Templates.NGS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<NGSResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            var caseId = metaData.getString(Workflow.CASE_ID);
            var historyId = metaData.getString(Workflow.HISTORYID);
            var originalZipFileName = metaData.getString(Workflow.ORIGINAL_ZIP_FILE_NAME);
            var docLibUploadDate = metaData.getString(Workflow.METADATA_DOCLIB_UPLOAD_DATE);
            

            paramsList.add(new NGSResponseTemplate.Params(caseId, historyId, originalZipFileName, docLibUploadDate));
        }

        return st.add("list", paramsList).add("counter", counter.toString()).render();
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {

		 var st = this.templateLoader.getTemplate(Templates.NGS_RESPONSE);
	        List<DocumentMetaData> documentMetaDataList;
	        try {
	            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
	        } catch (IOException e) {
	            throw new RuntimeException(e);
	        }

	        var paramsList = FastList.<NGSResponseTemplate.Params>newList();
	        var counter = new Counter();
	        for (var documentMetaData : documentMetaDataList) {
	            var metaData = documentMetaData.getMetadata();
	            var caseId = metaData.getString(Workflow.CASE_ID);
	            var historyId = metaData.getString(Workflow.HISTORYID);
	            var originalZipFileName = metaData.getString(Workflow.ORIGINAL_ZIP_FILE_NAME);
	            var docLibUploadDate = metaData.getString(Workflow.METADATA_DOCLIB_UPLOAD_DATE);
	           
	            paramsList.add(new NGSResponseTemplate.Params(caseId, historyId, originalZipFileName, docLibUploadDate));
	        }

	        return st.add("list", paramsList).add("counter", counter.toString()).render();
	}
	
	static class Params {
    	DateTimeFormatter outFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    	String format = "MM-dd-yyyy HH:mm:ss";
        private final String caseId;
        private final String historyId;
        private final String originalZipFileName;
        private String docLibUploadDate;

        public Params(String caseId, String historyId, String originalZipFileName, String docLibUploadDate) {
            this.caseId = caseId;
            this.historyId = historyId;
            this.originalZipFileName = originalZipFileName.trim();
            if (docLibUploadDate != null && !docLibUploadDate.isEmpty()) {
            	this.docLibUploadDate = getDate(format, outFormat, docLibUploadDate);
            } else {
            	this.docLibUploadDate = docLibUploadDate;
            }
           
            
        }

        public String getCaseId() {
            return caseId;
        }

        public String getHistoryId() {
            return historyId;
        }

        public String getOriginalZipFileName() {
            return originalZipFileName;
        }

        public String getDocLibUploadDate() {
			return docLibUploadDate;
		}
    }
	  public static String getDate(String outputFormat, DateTimeFormatter formatter, String date) {
	    	DateTimeFormatter outFormat = DateTimeFormatter.ofPattern(outputFormat);
	        LocalDateTime localtime = LocalDateTime.parse(date, formatter);
	        ZonedDateTime zonedDateTime = localtime.atZone(ZoneId.of(GMT));
	        ZonedDateTime zonedDateTimeCST = zonedDateTime.withZoneSameInstant(ZoneId.of("America/Chicago"));
			
	        return zonedDateTimeCST.format(outFormat);

	    }

	@Override
	public String convertWithTemplate(Object pojo) {
		// TODO Auto-generated method stub
		return null;
	}

}
