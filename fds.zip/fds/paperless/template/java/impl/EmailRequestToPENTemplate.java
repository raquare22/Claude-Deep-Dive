package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.java.delegate.SendEmailRequestToPEN;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class EmailRequestToPENTemplate extends TemplateHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(SendEmailRequestToPEN.class);

    @Override
    public String convertWithTemplate(String jsonString) {

        var st = this.templateLoader.getTemplate(Templates.EMAIL_REQUEST_TO_PEN);

        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonFile(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Map<String, String> metadataMap = new HashMap<>();

        return st.add("document", document)
                .add("map", metadataMap)
                .render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.EMAIL_REQUEST_TO_PEN);

        DocumentMetaData document = (DocumentMetaData) pojo;

        Map<String, String> metadataMap = new HashMap<>();

        return st.add("document", document)
                .add("map", metadataMap)
                .render();
	}
}