package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class AppealsNotificationsResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.APPEALS_NOTIFICATIONS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<AppealsNotificationsResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            paramsList.add(new AppealsNotificationsResponseTemplate.Params(documentMetaData));
        }
        return st.add("list", paramsList).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.APPEALS_NOTIFICATIONS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<AppealsNotificationsResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
            paramsList.add(new AppealsNotificationsResponseTemplate.Params(documentMetaData));
        }
        return st.add("list", paramsList).render();
    }

    public static String formatDateEmailSent(String string) {
        if (string == null || string.isEmpty()) {
            return "";
        }
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date date = null;
        try {
            date = originalFormat.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return targetFormat.format(date);
    }

    public static String formatDateCreated(Date date) {
        if (date == null) {
            return "";
        }
        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return targetFormat.format(date);
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }

    protected static class Params {

        private final String tin;
        private final String corporateMpin;
        private final String providerEmailId;
        private final String dateEmailSent;
        private final String eDeliveryError;
        private final String appealsReferenceNumber;
        private final String status;
        private final Integer attemptNumber;
        private final String receivedDate;

        public Params(DocumentMetaData documentMetaData) {
            var metadata = documentMetaData.getMetadata();
            this.tin = metadata.getString("tin");
            this.corporateMpin = metadata.getString("corporateMpin");
            this.providerEmailId = metadata.getString("providerEmailId");
            this.dateEmailSent = formatDateEmailSent(metadata.getString("dateEmailSent"));
            this.eDeliveryError = sanitizeEDeliveryError(metadata.getString("eDeliveryError"));
            this.appealsReferenceNumber = metadata.getString("caseNumber");
            this.status = metadata.getString("caseStatus");
            this.attemptNumber = metadata.getInteger("attemptNumber");
            this.receivedDate = formatDateCreated(documentMetaData.getDateCreated());
        }

        public String getTin() {
            return tin;
        }

        public String getCorporateMpin() {
            return corporateMpin;
        }

        public String getProviderEmailId() {
            return providerEmailId;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }

        public String getEDeliveryError() {
            return eDeliveryError;
        }

        public String getAppealsReferenceNumber() {
            return appealsReferenceNumber;
        }

        public String getStatus() {
            return status;
        }

        public Integer getAttemptNumber() {
            return attemptNumber;
        }

        public String getReceivedDate() {
            return receivedDate;
        }
        
		private static String sanitizeEDeliveryError(String value) {
			if (value == null || value.isBlank()) {
				return "";
			}
			String sanitized = value.replace('|', ',');
			return sanitized;
		}

    }
}