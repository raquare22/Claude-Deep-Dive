package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import java.io.IOException;
import java.util.Date;
import java.util.List;

public class ODARResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.ODAR_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<ODARResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            var letterGroupId = metaData.getString(Workflow.LETTER_GROUP_ID);
            var letterType = metaData.getString(Workflow.LETTER_TYPE);
            var dateCreated = documentMetaData.getDateCreated();

            paramsList.add(new ODARResponseTemplate.Params(letterGroupId, letterType, dateCreated));
        }

        return st.add("list", paramsList).add("counter", counter.toString()).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.ODAR_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<ODARResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            var letterGroupId = metaData.getString(Workflow.LETTER_GROUP_ID);
            var letterType = metaData.getString(Workflow.LETTER_TYPE);
            var dateCreated = documentMetaData.getDateCreated();

            paramsList.add(new ODARResponseTemplate.Params(letterGroupId, letterType, dateCreated));
        }

        return st.add("list", paramsList).add("counter", counter.toString()).render();
    }

    static class Params {
        private final String letterGroupId;
        private final String letterType;
        private final Date dateCreated;

        public Params(String letterGroupId, String letterType, Date dateCreated) {
            this.letterGroupId = letterGroupId;
            this.letterType = letterType;
            this.dateCreated = dateCreated;
        }

        public String getLetterGroupId() {
            return letterGroupId;
        }

        public String getLetterType() {
            return letterType;
        }

        public Date getDateCreated() {
            return dateCreated;
        }

    }

    @Override
    public String convertWithTemplate(Object pojo) {
        // TODO Auto-generated method stub
        return null;
    }
}