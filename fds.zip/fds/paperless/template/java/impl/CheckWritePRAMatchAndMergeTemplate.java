package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.util.List;

import org.eclipse.collections.impl.list.mutable.FastList;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class CheckWritePRAMatchAndMergeTemplate extends TemplateHandler {

	@Override
	public String convertWithTemplate(String jsonString) {
		List<DocumentMetaData> documentMetaDataList;
		try {
			documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return convertWithTemplate(documentMetaDataList);
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		List<DocumentMetaData> documentMetaDataList;
		try {
			documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return convertWithTemplate(documentMetaDataList);
	}


	public String convertWithTemplate(List<DocumentMetaData> documentMetaDataList) {
		var paramsList = FastList.<Params>newList();
		for (var documentMetaData : documentMetaDataList) {
			var metaData = documentMetaData.getMetadata();
			var barcode = metaData.getString(Workflow.BARCODE);
			var div = metaData.getString(Workflow.DIV);
			var memberNumber = metaData.getString(Workflow.MEMBER_NUMBER_CAMEL);
			var memberName = metaData.getString(Workflow.MEMBER_NAME_CAMEL);
			var claimNumber = metaData.getString(Workflow.CLAIM_NUMBER_CAMEL);
			var mediaType = metaData.getString(Workflow.MEDIA_TYPE_CAMEL);
			var claimSystem = metaData.getString(Workflow.CLAIM_SYSTEM_CAMEL);
			paramsList.add(new Params(barcode, div, memberNumber, memberName, claimNumber, mediaType, claimSystem));
		}

		var st = this.templateLoader.getTemplate(Templates.MATCH_AND_MERGE);
		return st.add("list", paramsList).add("counter", documentMetaDataList.size()).render();
	}
	
	@Override
	public String convertWithTemplate(Object pojo) {
		List<DocumentMetaData> documentList = (List<DocumentMetaData>) pojo;
		return convertWithTemplate(documentList);
	}

	static class Params {
		private final String barcode;
		private final String div;
		private final String memberNumber;
		private final String memberName;
		private final String claimNumber;
		private final String mediaType;
		private final String claimSystem;

		public Params(String barcode, String div, String memberNumber, String memberName, String claimNumber,
				String mediaType, String claimSystem) {
			super();
			this.barcode = barcode;
			this.div = div;
			this.memberNumber = memberNumber;
			this.memberName = memberName;
			this.claimNumber = claimNumber;
			this.mediaType = mediaType;
			this.claimSystem = claimSystem;
		}

		public String getBarcode() {
			return barcode;
		}

		public String getDiv() {
			return div;
		}

		public String getMemberNumber() {
			return memberNumber;
		}

		public String getMemberName() {
			return memberName;
		}

		public String getClaimNumber() {
			return claimNumber;
		}

		public String getMediaType() {
			return mediaType;
		}

		public String getClaimSystem() {
			return claimSystem;
		}

	}
}
