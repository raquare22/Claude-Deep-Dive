package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.factory.Lists;
import org.eclipse.collections.impl.list.mutable.FastList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.fds.paperless.java.delegate.CreateShutterflyDocuments;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class CheckWritePRACompanionTemplate extends TemplateHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(CheckWritePRACompanionTemplate.class);
	
	@Override
	public String convertWithTemplate(String jsonString) {
		LOGGER.debug("convertWithTemplate string={}", jsonString);
		List<DocumentMetaData> documentMetaDataList;
		
		try {
			documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
			throw new RuntimeException(e);
        }
		
		return convertWithTemplate(documentMetaDataList);
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		List<DocumentMetaData> documentMetaDataList;

		try {
			documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return convertWithTemplate(documentMetaDataList);
	}

	public String convertWithTemplate(List<DocumentMetaData> documentMetaDataList) {
		var paramsList = FastList.<Params>newList();
		var counter = new Counter();
		for (var documentMetaData : documentMetaDataList) {
			var metaData = documentMetaData.getMetadata();
			var originalCompanionRecords = Lists.mutable
					.withAll(metaData.getList(Workflow.ORIGNIAL_COMPANION_FILE_RECORDS, String.class, new ArrayList<>()));

			originalCompanionRecords.forEach(x -> paramsList.add(new Params(x)));
			counter.add(originalCompanionRecords.size());
		}
		var st = this.templateLoader.getTemplate(Templates.CHECK_WRITE_PRA_COMPANION);
		return st.add("list", paramsList).add("counter", counter.toString()).render();
	}
	
	@Override
	public String convertWithTemplate(Object pojo) {
		LOGGER.info("convertWithTemplate object={}", pojo);
		
		// TODO Auto-generated method stub
		return null;
	}

	static class Params {
		private final String originalCompanionFileRecords;

		public Params(String originalCompanionFileRecords) {
			this.originalCompanionFileRecords = originalCompanionFileRecords;
		}

		public String getOriginalCompanionFileRecords() {
			return originalCompanionFileRecords;
		}
	}

}
