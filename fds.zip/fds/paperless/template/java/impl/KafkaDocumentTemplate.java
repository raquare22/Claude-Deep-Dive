package com.optum.fds.paperless.template.java.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.kafka.model.*;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KafkaDocumentTemplate extends TemplateHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaDocumentTemplate.class);
    private static final String PADDING_0 = "0";

    @Override
    public String convertWithTemplate(String jsonString) {
        return null;
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.CNS_KAFKA_MESSAGE);
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> kafkaResponse = (Map<String, Object>) pojo;
        String key = (String) kafkaResponse.get("key");
        
        String kafkaMsgStr = (String) kafkaResponse.get("kafkaResponse");
        
        String cleanedKafkaMsgStr = kafkaMsgStr.replace("\\\"", "");
        cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\T\\\\", "");
        cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\E\\\\", "");
        cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\", "");
        
        KafkaMessage msg = new KafkaMessage();
        try{
            msg = objectMapper.readValue(cleanedKafkaMsgStr, KafkaMessage.class);
        } catch (JsonProcessingException e){ 
            LOGGER.error("KafkaDocumentTemplate --> unable to convert json string to KafkaResponse, e={}", e.getMessage());
        }
        
        RecordInfo recordInfo = msg.getRecordInfo();
        MemberDetails memberDetails = msg.getMemberDetails();
        
        ProviderDetails providerDetails = msg.getProviderDetails();
        
        List<Map<String, Object>> providerInfoList = new ArrayList<>();
        
        Map<String, Object> providerInfo = new HashMap<>();
        
        providerInfo.put("providerTin", formatTin(providerDetails.getProviderTin()));
        providerInfo.put("providerNpi", providerDetails.getProviderNpi());
        providerInfo.put("admittingProviderName", providerDetails.getAdmittingProviderName());
        providerInfo.put("facilityProvider", providerDetails.getFacilityProvider());
        providerInfo.put("providerName", providerDetails.getProviderName());
        providerInfo.put("isBHProvider", false);
        
        providerInfoList.add(providerInfo);
        
        List<BHProvider> bhProviderList = providerDetails.getBhProviderList();
        
        
        if (bhProviderList != null && !bhProviderList.isEmpty() ) {
        	for (BHProvider bhProvider : bhProviderList) {
        		providerInfo = new HashMap<>();
        		providerInfo.put("providerTin", formatTin(bhProvider.getProviderTin()));
                providerInfo.put("providerNpi", bhProvider.getProviderNpi());
                providerInfo.put("providerName", bhProvider.getProviderName());
                providerInfo.put("isBHProvider", true);
                providerInfoList.add(providerInfo);
        	}
        }
        

        return st.add("recordInfo", recordInfo)
                .add("memberInfo", memberDetails)
                .add("providerInfoList", providerInfoList)
                .add("transactionId", key)
                .render();
    }
    
    private String formatTin(String tin) {
    	if (tin != null && !tin.isEmpty()) {
    		return StringUtils.leftPad(tin, 9, PADDING_0);
    	} else {
    		return tin;
    	}    	
    }

}
