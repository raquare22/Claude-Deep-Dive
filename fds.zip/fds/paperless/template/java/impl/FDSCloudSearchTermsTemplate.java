package com.optum.fds.paperless.template.java.impl;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class FDSCloudSearchTermsTemplate extends TemplateHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FDSCloudSearchTermsTemplate.class);
	private static final String PATIENT_ACCOUNT_NUMBER = "patientAccountNumber";
	private static final String CHECK_ID = "checkId";
	private static final String CHECK_AMOUNT = "checkAmount";
	private static final String CHECK_NUMBER = "checkNumber";
	private static final String CHECK_TRACE_NUMBER = "CheckTraceNumber";
	private static final String PIPE_DELIMITER = "|";
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.FDS_CLOUD_SEARCH_TERMS);
		
		LOGGER.info("string template loaded, st={}", st);
		
		org.bson.Document metadata = (org.bson.Document) pojo;
		
		Map<String, String> searchTermsMap = createSearchTermsMap(metadata);
		
		return st.add("map", searchTermsMap).render();
	}
	
	@Override
    public String convertWithTemplate(String jsonString) {
		org.bson.Document metadata;
        try {
        	metadata = WorkFlowUtil.readMetadataFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        return convertWithTemplate(metadata);
		
	}
	
	@Override
    public String convertWithTemplateFromFilePath(String filePath) {
		return null;
	}
	
	
	public String getSearchTermsString(org.bson.Document metadata) {
		Map<String, String> searchTermsMap = createSearchTermsMap(metadata);
		String str = "";		
		try {
			str = mapper.writeValueAsString(searchTermsMap);
		} catch (JsonProcessingException e) {
			LOGGER.error("FDSCloudSearchTermsTemplate error converting map to json string, e={}", ExceptionUtils.getStackTrace(e));;
		}
		return str;
	}
	
	public String filterDuplicates(String inputString) {
        String joinedInputString = "";

        try {
            if (!StringUtils.isEmpty(inputString)) {
                joinedInputString = (Arrays.asList(Arrays.stream(inputString.split("\\|"))
                        .filter(x -> !StringUtils.isBlank(x)).toArray(String[]::new)).stream()
                        .collect(Collectors.toSet())).stream()
                        .collect(Collectors.joining(PIPE_DELIMITER, PIPE_DELIMITER, PIPE_DELIMITER));
            }
        } catch (Exception e) {
            LOGGER.error("getting exception to filter duplicates {} {} ", inputString, ExceptionUtils.getStackTrace(e));
            joinedInputString = "";
        }

        return joinedInputString;
    }
	
	public Map<String, String> createSearchTermsMap(org.bson.Document metadata) {
		String createApplication = metadata.getString("createApplication");
		
		Map<String, String> searchTermsMap = new HashMap<>();
		
		String createdDate = metadata.getString("createdDate");
		searchTermsMap.put("createdDate", createdDate);
		searchTermsMap.put("expiryDate", metadata.getString("expiryDate"));
		searchTermsMap.put("category", metadata.getString("category"));
		searchTermsMap.put("subCategory", metadata.getString("subCategory"));
		searchTermsMap.put("filePath", metadata.getString("filePath"));
		searchTermsMap.put("emailAlertReq", metadata.getString("emailAlertReq"));
		searchTermsMap.put("tin", metadata.getString("tin"));
		searchTermsMap.put("mpin", metadata.getString("mpin"));
		
		switch (createApplication) {
			case "ELGS":
				searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("physicianName", metadata.getString("providerName"));
	            searchTermsMap.put("patientName", metadata.getString("PatientName"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            searchTermsMap.put("claimNumber", metadata.getString("claimNumber"));
	            
	            if (metadata.getString("MemberAltID") != null) {
	                searchTermsMap.put("memberId", metadata.getString("MemberAltID"));
	            } else {
	                searchTermsMap.put("memberId", metadata.getString("memberId"));
	            }
	            break;
	            
			case "LETGEN":
	            searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            searchTermsMap.put("claimNumber", metadata.getString("claimNumber"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            if (metadata.getString("MemberAltID") != null) {
	                searchTermsMap.put("memberId", metadata.getString("MemberAltID"));
	            } else {
	                searchTermsMap.put("memberId", metadata.getString("memberId"));
	            }
	            break;    
			case "NextGen":
	            searchTermsMap.put("physicianName", metadata.getString("providerName"));
	            searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            searchTermsMap.put("notificationId", metadata.getString("notificationNumber"));
	            searchTermsMap.put("letterHistoryId", metadata.getString("LetterHistoryID"));
	            if (metadata.getString("MemberAltID") != null) {
	                searchTermsMap.put("memberId", metadata.getString("MemberAltID"));
	            } else {
	                searchTermsMap.put("memberId", metadata.getString("memberId"));
	            }
	            break;
	        
			case "CCSManual", "1Click":
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            searchTermsMap.put("notificationId", metadata.getString("notificationNumber"));
	            searchTermsMap.put("letterHistoryId", metadata.getString("LetterHistoryID"));
	            if (metadata.getString("MemberAltID") != null) {
	                searchTermsMap.put("memberId", metadata.getString("MemberAltID"));
	            } else {
	                searchTermsMap.put("memberId", metadata.getString("memberId"));
	            }
	            
	            break;

			case "PmntEng", "Payment Engine":
				searchTermsMap.put("EFT_Ind", metadata.getString("EFT_Ind"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
	            searchTermsMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
	            searchTermsMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
	            break;
	        
			case "CheckWrite", "CDC":
	        	searchTermsMap.put("EFT_Ind", metadata.getString("EFT_Ind"));
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            searchTermsMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
	            searchTermsMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
	            searchTermsMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
	            break;  
	        
	        case "DOC1":
	            searchTermsMap.put("claimNumber", metadata.getString("claimNumber"));
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            
	            if (metadata.getString("MemberAltID") != null) {
	                searchTermsMap.put("memberId", metadata.getString("MemberAltID"));
	            } else {
	                searchTermsMap.put("memberId", metadata.getString("memberId"));
	            }
	            break;
	        
	        case "NICE":
	        	searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	        	searchTermsMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
	        	searchTermsMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
	        	break;
	        
	        case "CSP-PRA":
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            
	            String ind_835 = metadata.get("Ind_835") != null ? metadata.get("Ind_835").toString() : "";
	            searchTermsMap.put("Ind_835", ind_835);
	            searchTermsMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
	            searchTermsMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
	            searchTermsMap.put(CHECK_AMOUNT, metadata.getString("checkAmt"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            break;
	            
	        case "ODAR":
	            searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            searchTermsMap.put(CHECK_NUMBER, metadata.getString("multCheckNumber"));
	            searchTermsMap.put("memberName", filterDuplicates(metadata.getString("multMemberName")) );
	            searchTermsMap.put("claimNumber", filterDuplicates(metadata.getString("multClaimNumber")) );
	            searchTermsMap.put("memberId", filterDuplicates(metadata.getString("multMemberId")) );
	        break;
	        
	        case "NGS":
            case "MnR":
            case "ENI":
            case "CnS":
            case "NGSCNS":
            case "ATS":
	            searchTermsMap.put("memberId", metadata.getString("memberId"));
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            searchTermsMap.put("caseId", metadata.getString("caseId"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            break;
	        
	        case "ETS":
	        	searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	        	searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	        	searchTermsMap.put("caseId", metadata.getString("caseId"));
	        	searchTermsMap.put("memberName", metadata.getString("memberName"));
	        	searchTermsMap.put("memberId", metadata.getString("memberId"));
	        	searchTermsMap.put("memberName", metadata.getString("memberName"));
	        	break;
			
			case "USP-COM-PRS":
				searchTermsMap.put("EFT_Ind", metadata.getString("EFT_Ind"));
	        	searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            searchTermsMap.put("physicianName", metadata.getString("physicianName"));
	            searchTermsMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
	            searchTermsMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
	            break;
   	            
			case "CIRRUS":
	        	searchTermsMap.put("policyNumber", metadata.getString("policyNumber"));
	            searchTermsMap.put("physicianName", metadata.getString("providerName"));
	            searchTermsMap.put("memberName", metadata.getString("memberName"));
	            searchTermsMap.put("memberId", metadata.getString("memberId"));
	            searchTermsMap.put("claimNumber", metadata.getString("claimNumber"));
	            searchTermsMap.put("patientName", metadata.getString("PatientName"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            if (metadata.getString("MemberAltID") != null) {
	                searchTermsMap.put("memberId", metadata.getString("MemberAltID"));
	            } else {
	                searchTermsMap.put("memberId", metadata.getString("memberId"));
	            }
	            break;

	        case "MACESS":
	            searchTermsMap.put("physicianName", metadata.getString("providerName"));
	            searchTermsMap.put("claimNumber", metadata.getString("claimNumber"));
	            searchTermsMap.put("memberId", metadata.getString("memberId"));
	            searchTermsMap.put("Macess_SF_ID", metadata.getString("Macess_SF_ID"));
	            searchTermsMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            break;
	        case "TXGC":
	        	String providerName = metadata.getString("providerName");
            	if (providerName == null || providerName.isEmpty()) {
            		providerName = metadata.getString("providerGroupName");
            	}
            	searchTermsMap.put("physicianName", providerName);
            	break;
			default:
	        	break;
	    }
		
		return searchTermsMap;
	}

}
