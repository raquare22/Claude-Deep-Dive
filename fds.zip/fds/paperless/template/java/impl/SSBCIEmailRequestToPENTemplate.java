package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class SSBCIEmailRequestToPENTemplate extends TemplateHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(SSBCIEmailRequestToPENTemplate.class);

    @Override
    public String convertWithTemplate(String jsonString) {

        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonFile(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.SSBCI_EMAIL_REQUEST_TO_PEN);

        DocumentMetaData document = (DocumentMetaData) pojo;
        Document metadata = document.getMetadata();
        String templateName = null;
        String category = null;
        String type = metadata.getString("type");

        if (metadata.containsKey(Workflow.SEND_EMAIL_NOTIFICATIONS) &&
                Boolean.TRUE.equals(document.getMetadata().get(Workflow.SEND_EMAIL_NOTIFICATIONS))) {
            if( type.equalsIgnoreCase("SSBCI"))
            {
                templateName = "SSBCI_REMINDER";
                category = "SSBCI_REMINDER";
            }
            else{
                templateName = "CSNP_REMINDER";
                category = "CSNP_REMINDER";
            }
        } else {
            if( type.equalsIgnoreCase("SSBCI"))
            {
                templateName = "SSBCI";
                category = "SSBCI";
            }
            else{
                templateName = "CSNP";
                category = "CSNP";
            }
        }
        return st.add("document", document)
               .add("templateName", templateName)
                .add("category",category)
                .render();

    }
}
