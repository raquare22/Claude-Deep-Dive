package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IHRResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.IHR_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<IHRResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
            paramsList.add(new IHRResponseTemplate.Params(documentMetaData.getMetadata()));
        }
        return st.add("list", paramsList).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.IHR_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<IHRResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
        	paramsList.add(new IHRResponseTemplate.Params(documentMetaData.getMetadata()));
        }
        return st.add("list", paramsList).render();
    }

    private static String formatDateEmailSent(String string) {
    	if (string == null || string.length() == 0) {
    		return "";
    	}
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss.SSS'Z'");
        Date date = null;
        try {
            date = originalFormat.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        String formattedDate = targetFormat.format(date);
        return formattedDate;
    }
    
    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }
    
    static class Params {

        private final String providerName;
        private final String providerId;
        private final String npi;
        private final String taxId;
        private final String groupProviderId;
        private final String groupProviderMpin;
        private final String groupNpi;
        private final String groupTaxId;
        private final String email;
        private final String provAddressLine1;
        private final String provAddressLine2;
        private final String pcpFlag;
        private final String providerSpecialty;
        private final String providerType;
        private final String dateEmailSent;
        private final String eDeliveryError;
        
		public Params(String providerName, String providerId, String npi, String taxId, String groupProviderId,
				String groupProviderMpin, String groupNpi, String groupTaxId, String email, String provAddressLine1,
				String provAddressLine2, String pcpFlag, String providerSpecialty, String providerType,
				String dateEmailSent, String eDeliveryError) {
			this.providerName = providerName;
			this.providerId = providerId;
			this.npi = npi;
			this.taxId = taxId;
			this.groupProviderId = groupProviderId;
			this.groupProviderMpin = groupProviderMpin;
			this.groupNpi = groupNpi;
			this.groupTaxId = groupTaxId;
			this.email = email;
			this.provAddressLine1 = provAddressLine1;
			this.provAddressLine2 = provAddressLine2;
			this.pcpFlag = pcpFlag;
			this.providerSpecialty = providerSpecialty;
			this.providerType = providerType;
			this.dateEmailSent = dateEmailSent;
			this.eDeliveryError = eDeliveryError;
		}
		
		public Params(org.bson.Document metadata) {
			this.providerName = metadata.getString("providerName");
			this.providerId = metadata.getString("providerId");
			this.npi = metadata.getString("npi");
			this.taxId = metadata.getString("tin");
			this.groupProviderId = metadata.getString("groupProviderId");
			this.groupProviderMpin = metadata.getString("corporateMpin");
			this.groupNpi = metadata.getString("groupNpi");
			this.groupTaxId = metadata.getString("groupTaxId");
			this.email = metadata.getString("providerEmailId");
			this.provAddressLine1 = metadata.getString("provAddressLine1");
			this.provAddressLine2 = metadata.getString("provAddressLine2");
			this.pcpFlag = metadata.getString("pcpFlag");
			this.providerSpecialty = metadata.getString("providerSpecialty");
			this.providerType = metadata.getString("providerType");
			this.dateEmailSent = formatDateEmailSent(metadata.getString("dateEmailSent"));
			this.eDeliveryError = metadata.getString("eDeliveryError");			
		}

		public String getProviderName() {
			return providerName;
		}

		public String getProviderId() {
			return providerId;
		}

		public String getNpi() {
			return npi;
		}

		public String getTaxId() {
			return taxId;
		}

		public String getGroupProviderId() {
			return groupProviderId;
		}

		public String getGroupProviderMpin() {
			return groupProviderMpin;
		}

		public String getGroupNpi() {
			return groupNpi;
		}

		public String getGroupTaxId() {
			return groupTaxId;
		}

		public String getEmail() {
			return email;
		}

		public String getProvAddressLine1() {
			return provAddressLine1;
		}

		public String getProvAddressLine2() {
			return provAddressLine2;
		}

		public String getPcpFlag() {
			return pcpFlag;
		}

		public String getProviderSpecialty() {
			return providerSpecialty;
		}

		public String getProviderType() {
			return providerType;
		}

		public String getDateEmailSent() {
			return dateEmailSent;
		}

		public String getEDeliveryError() {
			return eDeliveryError;
		}
		
		

    }
}