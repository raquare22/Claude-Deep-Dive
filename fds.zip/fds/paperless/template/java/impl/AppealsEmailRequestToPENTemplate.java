package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class AppealsEmailRequestToPENTemplate extends TemplateHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(AppealsEmailRequestToPENTemplate.class);

    private  DocumentMetaDataService documentMetaDataService;
    @Autowired
    public AppealsEmailRequestToPENTemplate(DocumentMetaDataService documentMetaDataService) {
        this.documentMetaDataService=documentMetaDataService;
    }

    public AppealsEmailRequestToPENTemplate() {

    }
    @Override
    public String convertWithTemplate(String jsonString) {
        return null;
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }


    @Override
    public String convertWithTemplate(Object pojo) {

        List<DocumentMetaData> document = (List<DocumentMetaData>) pojo;
        return convertWithDocumentMetaData(document);
    }
    private String convertWithDocumentMetaData(List<DocumentMetaData> documentList) {

        var st = this.templateLoader.getTemplate(Templates.APPEALS_NOTIFICATION);
        ArrayList<Map<String, String>>  documentMetaDataList = new ArrayList<>();
        String templateName = null;
        String category =null;
        DocumentMetaData document = documentList.get(0);
        String status = document.getMetadata().getString("caseStatus");
        Integer attemptNumber = document.getMetadata().getInteger("attemptNumber", 1);

        String appealsDate = formatDate(document.getMetadata().getString("createdOn"));

        if (status.equalsIgnoreCase("Action Required") && attemptNumber.equals(1)){
            templateName = "AppealsActionRequired";
            category = "Appeals Action Required";
        }
        else if (status.equalsIgnoreCase("Action Required") && attemptNumber > 1) {
            templateName = "AppealsActionRequiredReminder";
            category = "Appeals Action Required Reminder";
        }
        else {
            templateName = "AppealsResubmitAttachment";
            category = "Appeals Resubmit Attachment";
        }
        String docStatus = "";
        for (DocumentMetaData doc : documentList) {

            Map<String, String> dataMap = new HashMap<>();
            String tin = doc.getMetadata().getString("tin");
            String corporateMpin = doc.getMetadata().getString("corporateMpin");
            String documentStatus = doc.getMetadata().getString("caseStatus");

            if (tin.length() < 9) {
                tin = StringUtils.leftPad(tin, 9, "0");
            }
            if (corporateMpin.length() < 9) {
                corporateMpin = StringUtils.leftPad(corporateMpin, 9, "0");
            }

            if (documentStatus.equalsIgnoreCase("Action Required") && attemptNumber >= 1){
                docStatus = "Action Required";
            }
            else {
                docStatus = "Resubmit Attachment";
            }

            String formattedTin = "XXXXX" + tin.substring(tin.length() - 4);
            String formattedCorporateMpin = "XXXXX" + corporateMpin.substring(corporateMpin.length() - 4);

            dataMap.put("Category", "Appeals");
            dataMap.put("CorporateTaxIDOwner", formattedCorporateMpin);
            dataMap.put("AppealReferenceNumber", doc.getMetadata().getString("caseNumber"));
            dataMap.put("TaxIDNumber", formattedTin);
            dataMap.put("CurrentStatus", docStatus);
            dataMap.put("ProviderOrganizationName", doc.getMetadata().getString("providerName"));
            documentMetaDataList.add(dataMap);

        }
        return st.add("document",document)
                .add("appealsDate", appealsDate)
                .add("list", documentMetaDataList)
                .add("templateName", templateName)
                .add("category",category).render();
    }

    private String formatDate(String dateStr) {
        // 2024-07-12T21:58:06.853
        if (dateStr == null || dateStr.isEmpty()) {
            return "";
        }
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        DateFormat format2 = new SimpleDateFormat("MM-dd-yyyy");
        format2.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            Date date = format.parse(dateStr);
            return format2.format(date);
        } catch (ParseException e) {
            LOGGER.error("convertDateToCSTFormat -- Unable to parse dateCreated string {}", dateStr);
            return "";
        }

    }
}
