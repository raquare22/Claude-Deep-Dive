package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.eclipse.collections.impl.list.mutable.FastList;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class TrackItResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        DocumentMetaData document;

        try {
            document = WorkFlowUtil.readDocumentFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.TRACK_IT_RESPONSE);
        DocumentMetaData document = (DocumentMetaData) pojo;

        Params params = new Params(document);

        return st.add("params", params).render();
    }

    static class Params {
        private final String recordId;
        private final String dateEmailSent;
        private final String eDeliveryError;
        private final String providerEmailId;
        private final String deliveryStatus;

        public Params(DocumentMetaData documentMetaData) {
            var metadata = documentMetaData.getMetadata();
            this.dateEmailSent = convertDate(sanitize(metadata.getString(Workflow.DATE_EMAIL_SENT)));
            this.recordId = sanitize(metadata.getString("recordID"));
            this.eDeliveryError = sanitize(metadata.getString(Workflow.EDELIVERY_ERROR));
            this.providerEmailId = sanitize(metadata.getString(Workflow.PROVIDER_EMAIL_ID));
            if (metadata.containsKey(Workflow.EDELIVERY_ERROR) && !metadata.getString(Workflow.EDELIVERY_ERROR).isEmpty()) {
                this.deliveryStatus = "Failure";
            } else {
                this.deliveryStatus = "Success";
            }
        }

        private String convertDate(String dateEmailSent) {
            // TODO: Convert UTC dateEmailSent string 2026-03-11T12:30:00.000Z to format yyyy-MM-dd HH:mm:ss in CST timezone
            if (dateEmailSent != null && !dateEmailSent.trim().isEmpty()) {
                try {
                    java.time.ZonedDateTime utcDateTime = java.time.ZonedDateTime.parse(dateEmailSent);
                    java.time.ZonedDateTime cstDateTime = utcDateTime.withZoneSameInstant(java.time.ZoneId.of("America/Chicago"));
                    return cstDateTime.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                } catch (java.time.format.DateTimeParseException e) {
                    // If parsing fails, return the original string
                    return "";
                }
            }
            return "";
        }

        private String sanitize(String value) {
            return (value != null && !value.trim().isEmpty()) ? value : "";
        }

        public String getEDeliveryError() {
            return eDeliveryError;
        }
        public String getDeliveryStatus() {
            return deliveryStatus;
        }
        public String getRecordId() {
            return recordId;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }

        public String getProviderEmailId() {
            return providerEmailId;
        }
    }

}
