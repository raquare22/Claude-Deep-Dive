package com.optum.fds.paperless.template.java.renderer;

import com.google.common.base.Strings;
import org.apache.commons.lang3.StringUtils;
import org.stringtemplate.v4.StringRenderer;

import java.util.Locale;
import java.util.Optional;

public class CustomStringRenderer extends StringRenderer {
    @Override
    public String toString(Object o, String formatString, Locale locale) {
        if (formatString == null || formatString.isBlank()) {
            return (String) o;
        }
        var value = (String) o;
        var character = formatString.charAt(0);
        if (character == 's') {
        	return subStringHandler(formatString, value);
        } else if (character >= '0' && character <= '9') {
            return myStringHandler(formatString, value);
        }
        return super.toString(o, formatString, locale);
    }
    
    private String subStringHandler(String formatString, String value) {
    	// example format string: format="substring-2-10"
    	try {
        	String[] formatVals = formatString.split("-");
        	Integer index1 = Integer.parseInt(formatVals[1]);
        	Integer index2 = Integer.parseInt(formatVals[2]);
        	return value.substring(index1, index2).trim();
    	} catch (StringIndexOutOfBoundsException e) {
    		return "";
    	}
    }

    private String myStringHandler(String formatString, String value) {
        String[] values = formatString.split("-");
        var lengthChar = String.valueOf(values[0]);

        var paddingString = Optional.of(values[1]).map(Object::toString)
                .orElse(StringUtils.EMPTY);

        var align = Optional.of(values[2]).map(Object::toString).orElse(StringUtils.EMPTY);

        String paddingStringResult = null;

        // If  paddingString is empty return null
        // else  length parameter value is less than the value length substring the
        // value.If align is L or R than do left or right padding of the value else
        //return null.
        if (StringUtils.isEmpty(paddingString)) {
            return null;
        } else {
            try {
                var length = Integer.parseInt(lengthChar);
                if (length < value.length()) {
                    value = value.substring(0, length);
                }
                var paddingChar = paddingString.charAt(0);
                if ("L".equalsIgnoreCase(align)) {
                    paddingStringResult = Strings.padStart(value, length, paddingChar);
                } else if ("R".equalsIgnoreCase(align)) {
                    paddingStringResult = Strings.padEnd(value, length, paddingChar);
                }
                return paddingStringResult;

            } catch (NumberFormatException ne) {
                return null;
            }
        }
    }
}
