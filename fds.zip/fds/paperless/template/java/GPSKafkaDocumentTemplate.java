package com.optum.fds.paperless.template.java;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.kafka.model.*;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.util.Utilities;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GPSKafkaDocumentTemplate extends TemplateHandler {
    @Override
    public String convertWithTemplate(String jsonString) {
        return "";
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return "";
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.GPS_KAFKA_DOCUMENT);

        Map<String, Object> kafkaMessage = (Map<String, Object>) pojo;
        String key = (String) kafkaMessage.get("key");
        KafkaMessageGPS gpsMsg = (KafkaMessageGPS) kafkaMessage.get("kafkaMessage");
        List<ProviderGPS> providers = (gpsMsg != null) ? gpsMsg.getProviders() : null;

        if (providers != null) {
            for (ProviderGPS provider : providers) {
                List<String> validEmails = provider.getEmailAddress().stream()
                        .filter(Utilities::validateProviderEmail)
                        .toList();
                provider.setEmailAddress(validEmails);
            }
        }

        return st.add("message", gpsMsg)
                .add("providers", providers)
                .add("transactionId", key)
                .render();
    }
}
