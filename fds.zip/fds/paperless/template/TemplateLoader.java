package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.java.renderer.CustomStringRenderer;
import com.optum.fds.paperless.template.listener.ErrorListener;
import org.stringtemplate.v4.DateRenderer;
import org.stringtemplate.v4.NumberRenderer;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.util.Date;
import java.util.Objects;

public class TemplateLoader {
	private static TemplateLoader templateLoader;
	private final STGroup stGroup;

	private TemplateLoader() {
		stGroup = new STGroupFile("allTemplates.stg");
		stGroup.registerRenderer(Date.class, new DateRenderer());
		stGroup.registerRenderer(String.class, new CustomStringRenderer());
		stGroup.registerRenderer(Number.class, new NumberRenderer());
		stGroup.setListener(new ErrorListener());
	}

	public static TemplateLoader getInstance() {
		if (templateLoader == null) {
			templateLoader = new TemplateLoader();
		}
		return templateLoader;
	}

	public ST getTemplate(Templates template) {
		return stGroup.getInstanceOf(template.getTemplate());
	}
}
