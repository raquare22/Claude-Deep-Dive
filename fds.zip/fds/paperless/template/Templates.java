package com.optum.fds.paperless.template;

public enum Templates {
	/**
	 * template method name should be same. For eg: checkWritePRAResponse,
	 * mergedMetaDataTemplate are present as method in allTemplates.stg
	 */
	MATCH_AND_MERGE("checkWritePRAMatchAndMerge"), CHECK_WRITE_PRA_RESPONSE("checkWritePRAResponse"),
	COSMOS_DOC1_STATUS("cosmosDoc1StatusTemplate"), COSMOS_ACK("cosmosAckTemplate"),
	MR_APPEALS_RESPONSE("MRAppealsResponse"), ODAR_RESPONSE("ODARResponse"),
	PRIOR_AUTH_RESPONSE("PriorAuthResponse"), ETS_APPEALS_RESPONSE("ETSAppealsResponse"),OCM_RESPONSE("OCMResponse"),
	COSMOS_PRA_COMPANION("CosmosPRACompanion"),
	CSP_CLAIMS_RESPONSE("CSPClaimsResponse"),
	FDS_CLOUD_SEARCH_TERMS("filterFDSCloudSearchTerms"),
	USP_CLAIMS_RESPONSE("USPClaimsResponse"),
	USP_CLAIMS_RESPONSE_API_NOTIFY("USPClaimsResponseApiNotify"),
	NGS_RESPONSE("NGSResponse"),
	CHECK_WRITE_PRA_COMPANION("checkWritePRACompanion"),CHECK_WRITE_PRA_EMAIL_ALERT("checkWritePRAEmailAlert"),
  	FILTER_REQ_FIELD_FOR_DOCVAULT("filterReqFieldForDocvault"),
	PDO_CSV("PDOCSVTemplate"), OPTUM_PAY_NUMBER_DOCUMENT("optumPayNumberDocument"), DOCLIB_PUT_REQUEST("docLibPutRequest"),
	EMAIL_REQUEST_TO_PEN("emailRequestToPEN"), IHR_DOCUMENT_TEMPLATE("IHRDocumentTemplate"),
	TXGC_ELGS_FILE("TexasGoldCardELGSFile"),
	TXGC_CSV_DOCUMENT("TXGCCSVDocument"),
	TXGC_JSON_DOCUMENT("TXGCJSONDocument"),
	IHR_RESPONSE("IHRResponse"), CC_RESPONSE("CCResponse"), CC_DOCUMENT_TEMPLATE("CCDocumentTemplate"),
	CAP_RESPONSE("CAPResponse"),
    ADT_CNS_EMAIL_REQUEST_TO_PEN("ADTCNSEmailRequestToPEN"),
	TRACKIT_EMAIL_REQUEST_TO_PEN("TrackItEmailRequestToPEN"),
	CNS_RESPONSE("CNSJSONResponse"),
	KAFKA_RESPONSE_DOCUMENT("KafkaResponseDocument"),
	KAFKA_MNR_DOCUMENT("KafkaMnRDocument"),
	ALINK_KAFKA_TEMPLATE("AlinkKafkaTemplate"),
	MNR_RESPONSE("MNRJSONResponse"),
	CNS_KAFKA_MESSAGE("CNSKafkaMessage"),
	ATS_KAFKA_DOCUMENT("ATSKafkaDocument"),
	HOUSE_CALLS_RESPONSE("HouseCallsResponse"),
	APPEALS_NOTIFICATION("appealsNotificationEmailRequestToPEN"),
	NGS_CLAIMS_RESPONSE("NGSClaimsResponse"),
	APPEALS_NOTIFICATIONS_RESPONSE("AppealsNotificationsResponse"),
	PCP_EMAIL_REQUEST_TO_PEN("PCPEmailRequestToPEN"),
	GPS_KAFKA_DOCUMENT("KafkaGPSDocument"),
	KAFKA_CONSUMER_ENGINEERING_DOCUMENT("KafkaConsumerEngineering"),
  TRACK_IT_RESPONSE("TrackItResponse"),
	SSBCI_EMAIL_REQUEST_TO_PEN("SSBCIEmailRequestToPEN"),
  TRACKIT_KAFKA_TEMPLATE("TrackItKafkaTemplate"),
	SSBCI_RESPONSE("SSBCIResponseTemplate");


	private final String template;

	Templates(String template) {
		this.template = template;
	}

	public String getTemplate() {
		return this.template;
	}
}
