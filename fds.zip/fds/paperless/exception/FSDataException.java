////package com.optum.fs.exception;
package com.optum.fds.paperless.exception;

/**
 * Base RunTime Exception fur Fusion Services
 * 
 * @author Vinata Gangolli
 */
public class FSDataException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	
	public FSDataException(String string) {
		super(string);
	}

	public FSDataException(String string, Throwable throwable) {
		super(string, throwable);
	}

	public FSDataException(Throwable throwable) {
		super(throwable);
	}
}
