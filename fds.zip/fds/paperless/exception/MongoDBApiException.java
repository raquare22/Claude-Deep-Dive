package com.optum.fds.paperless.exception;


public class MongoDBApiException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	
	public MongoDBApiException(String string) {
		super(string);
	}

	public MongoDBApiException(String string, Throwable throwable) {
		super(string, throwable);
	}

	public MongoDBApiException(Throwable throwable) {
		super(throwable);
	}
}
