package com.optum.fds.paperless.exception;

public class AuthorizationInitializeException extends PrunException {

	private static final long serialVersionUID = 9062649785092831382L;

	public AuthorizationInitializeException() {
		super(ErrorCode.AUTHORIZATION_INITIALIZE);
	}

	public AuthorizationInitializeException(String message, Throwable cause) {
		super(message, cause, ErrorCode.AUTHORIZATION_INITIALIZE);
	}

	public AuthorizationInitializeException(String message) {
		super(message, ErrorCode.AUTHORIZATION_INITIALIZE);
	}

	public AuthorizationInitializeException(Throwable cause) {
		super(cause, ErrorCode.AUTHORIZATION_INITIALIZE);
	}
}
