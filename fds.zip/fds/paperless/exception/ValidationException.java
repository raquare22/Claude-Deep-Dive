package com.optum.fds.paperless.exception;

public class ValidationException extends PrunException {

	private static final long serialVersionUID = -61896743006808776L;

	public ValidationException() {
		super(ErrorCode.VALIDATION);
	}

	public ValidationException(String message, Throwable cause) {
		super(message, cause, ErrorCode.VALIDATION);
	}

	public ValidationException(String message) {
		super(message, ErrorCode.VALIDATION);
	}

	public ValidationException(Throwable cause) {
		super(cause, ErrorCode.VALIDATION);
	}
}
