package com.optum.fds.paperless.exception;

public class HttpServerException extends PrunException {

	private static final long serialVersionUID = -3130853967314096765L;

	public HttpServerException() {
		super(ErrorCode.REST_API_ERROR);
	}

	public HttpServerException(String message, Throwable cause) {
		super(message, cause, ErrorCode.REST_API_ERROR);
	}

	public HttpServerException(String message) {
		super(message, ErrorCode.REST_API_ERROR);
	}

	public HttpServerException(Throwable cause) {
		super(cause, ErrorCode.REST_API_ERROR);
	}
}
