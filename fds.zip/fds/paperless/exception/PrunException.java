package com.optum.fds.paperless.exception;

public class PrunException extends Exception {

	private static final long serialVersionUID = -5645260182141742398L;

	private final ErrorCode code;

	public PrunException(ErrorCode code) {
		super();
		this.code = code;
	}

	public PrunException(String message, Throwable cause, ErrorCode code) {
		super(message, cause);
		this.code = code;
	}

	public PrunException(String message, ErrorCode code) {
		super(message);
		this.code = code;
	}

	public PrunException(Throwable cause, ErrorCode code) {
		super(cause);
		this.code = code;
	}

	public ErrorCode getCode() {
		return code;
	}
	
	@Override
	public String toString() {
		return code + ": " +  getMessage();
	}
}
