/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/30/17.
 */

////package com.optum.fs.fs_batch_processing.domain.util;
package com.optum.fds.paperless.domain.util;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.ProcessorTransactionCore;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.executions.UnprocessedRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.util.Utilities;

import org.mvel2.MVEL;
import org.mvel2.PropertyAccessException;

////import com.optum.fs.domain.service.CsvProcessorService;
////import com.optum.fs.domain.service.ProcessorService;
////import com.optum.fs.fs_batch_processing.file.Utilities;
////import com.optum.fs.fs_batch_processing.service.ProcessorsService;
////import com.optum.fs.mongo.ProcessorTransactionCore;
////import com.optum.fs.mongo.csvProcessors.CsvProcessorTransaction;
////import com.optum.fs.mongo.executions.ProcessorExecutionRecord;
////import com.optum.fs.mongo.executions.UnprocessedRecord;
////import com.optum.fs.mongo.processors.ProcessorFileTask;
////import com.optum.fs.mongo.processors.ProcessorTransaction;
////import com.optum.fs.mongo.processortransaction.ProcessorTransactionMetadata;
////import com.optum.fs.util.FileUtil;

public class ProcessorTaskUtil {
	private ProcessorTaskUtil() {
	}

	public static final void addMessageToProcessorExecutionRecordToProcessorTransaction(
			ProcessorTransactionCore processorTransaction, ProcessorExecutionRecord executionRecord,
			Map<String, String> message) {
		executionRecord.setDateModified(new Date());
		executionRecord.addMessage(message);
		processorTransaction.addProcessorExecutionRecord(executionRecord);
	}
	
	public static final String getFileName(String documentId, String appIdentifier, ProcessorFileTaskService processorFileTaskService, ProcessorsService processorsService) {
		String zipFileName = "";
		ProcessorFileTask processorFileTask = processorFileTaskService.getProcessorFileTaskForTargetId(documentId, "documents" ,appIdentifier);
		if (processorFileTask != null) {
			ProcessorTransaction processorTransaction = processorsService.getTransactionProcessorById(processorFileTask.getProcessorTransactionId());
			zipFileName = processorTransaction.getFileName();
		}
		return zipFileName;
	}

	public static final void addMessageToProcessorExecutionRecordToProcessorTransactionMetadata(
			ProcessorTransactionMetadata processorTransactionMetadata, ProcessorExecutionRecord executionRecord,
			Map<String, String> message) {
		executionRecord.setDateModified(new Date());
		executionRecord.addMessage(message);
		processorTransactionMetadata.addProcessorExecutionRecord(executionRecord);
	}

	public static final ProcessorExecutionRecord addMessageToProcessorExecutionRecord(
			ProcessorExecutionRecord executionRecord, Map<String, String> message) {
		executionRecord.setDateModified(new Date());
		executionRecord.addMessage(message);
		return executionRecord;
	}

	public static final ProcessorExecutionRecord addMiscellaneousToProcessorExecutionRecord(
			ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord) {

		executionRecord.setClientId(processorFileTask.getClientId());
		executionRecord.setSpaceId(processorFileTask.getConfigSpaceId());
		return executionRecord;
	}

	public static final ProcessorExecutionRecord createProcessorExecutionRecord(String description) {
		ProcessorExecutionRecord processorExecutionRecord = createBlankAudit();
		processorExecutionRecord.setDescription(description);

		return processorExecutionRecord;
	}

	//TODO:
	public static final boolean validateCriteriaMatch(String expression, Map<String, Object> rootNodeMap) {
		Boolean result = false;
		try {
			result = (Boolean) MVEL.eval(expression, rootNodeMap);

		} catch (PropertyAccessException ex) {
			result = false;
		}
		return result;
	}

	public static final boolean findDuplicateError(String errormsg, Set<String> errorList) {
		boolean match = errorList.stream().anyMatch(o -> o.contains(errormsg));
		return match;
	}

	public static final ProcessorExecutionRecord createProcessorExecutionRecord(String description,
			ProcessorTransactionCore processorTransaction) {
		ProcessorExecutionRecord processorExecutionRecord = createBlankAudit();
		processorExecutionRecord.setDescription(description);
		processorExecutionRecord.setClientId(processorTransaction.getClientId());
		processorExecutionRecord.setSpaceId(processorTransaction.getConfigSpaceId());

		return processorExecutionRecord;
	}

	public static final ProcessorExecutionRecord createProcessorExecutionRecord(String description, Map message) {
		ProcessorExecutionRecord processorExecutionRecord = createProcessorExecutionRecord(description);

		processorExecutionRecord.addMessage((HashMap<String, String>) message);

		return processorExecutionRecord;
	}

	public static final void updateFileMetrics(ProcessorFileTask processorFileTask, File fileToProcess,
			ProcessorFileTaskService processorFileTaskService) {
		// Updating metric information
		Map fileInfo = Utilities.getFileInformation(fileToProcess);
		processorFileTask.setFileSize((Long) fileInfo.get("size"));
		processorFileTask.setFileType((String) fileInfo.get("type"));

		processorFileTaskService.updateProcessorFileTask(processorFileTask);
	}

	public static final void updateFileMetrics(CsvProcessorTransaction csvProcessorTransaction, File fileToProcess,
			CsvProcessorService csvProcessorService) {
		csvProcessorTransaction.setJsonFileName(fileToProcess.getName());
		csvProcessorService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
	}

	public static final void updateServerMetrics(ProcessorFileTask processorFileTask,
			ProcessorFileTaskService processorFileTaskService) {
		processorFileTask.setProcessedByHost(FileUtil.getInstance().getLocalHostName());

		processorFileTaskService.updateProcessorFileTask(processorFileTask);
	}

	public static final void updateServerMetrics(CsvProcessorTransaction csvProcessorTransaction,
			CsvProcessorService csvProcessorService) {
		csvProcessorService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
	}

	public static final void updateProcessFileTaskWithExecutionRecord(ProcessorFileTaskService processorFileTaskService,
			ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord) {
		processorFileTask.addProcessorExecutionRecord(executionRecord);
		processorFileTaskService.updateProcessorFileTask(processorFileTask);
	}

	public static final void updateProcessFileTaskWithExecutionRecord(ProcessorFileTaskService processorFileTaskService,
			ProcessorFileTask processorFileTask, ProcessorExecutionRecord executionRecord,
			Map<String, String> message) {
		addMessageToProcessorExecutionRecord(executionRecord, message);
		addMiscellaneousToProcessorExecutionRecord(processorFileTask, executionRecord);
		updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask, executionRecord);
	}

	public static final void updateProcessTransactionWithExecutionRecord(ProcessorService processorService,
			ProcessorTransaction processorTransaction, ProcessorExecutionRecord executionRecord) {
		processorTransaction.addProcessorExecutionRecord(executionRecord);
		processorService.updateProcessorTransactionMetaData(processorTransaction);
	}

	public static final void updateProcessTransactionWithExecutionRecord(ProcessorService processorService,
			ProcessorTransaction processorTransaction, ProcessorExecutionRecord executionRecord,
			Map<String, String> message) {
		addMessageToProcessorExecutionRecord(executionRecord, message);
		updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord);
	}

	public static final void updateProcessTransactionWithExecutionRecord(CsvProcessorService csvProcessorService,
			ProcessorTransactionCore processorTransaction, ProcessorExecutionRecord executionRecord) {
		processorTransaction.addProcessorExecutionRecord(executionRecord);
		if (processorTransaction instanceof CsvProcessorTransaction) {
			csvProcessorService.updateCsvProcessorTransactionMetaData((CsvProcessorTransaction) processorTransaction);
		}
	}

	public static final void updateProcessTransactionWithUnprocessedRecord(CsvProcessorService csvProcessorService,
			ProcessorTransactionCore processorTransaction, List<UnprocessedRecord> unprocessedRecord) {
		processorTransaction.setUnprocessedRecordList(unprocessedRecord);
		if (processorTransaction instanceof CsvProcessorTransaction) {
			csvProcessorService.updateCsvProcessorTransactionMetaData((CsvProcessorTransaction) processorTransaction);
		}
	}

	public static final void updateProcessTransactionWithExecutionRecord(CsvProcessorService csvProcessorService,
			ProcessorTransactionCore processorTransaction, ProcessorExecutionRecord executionRecord,
			Map<String, String> message) {
		addMessageToProcessorExecutionRecord(executionRecord, message);
		updateProcessTransactionWithExecutionRecord(csvProcessorService, processorTransaction, executionRecord);
	}

	private static final ProcessorExecutionRecord createBlankAudit() {
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();

		processorExecutionRecord.setServerName(FileUtil.getInstance().getLocalHostName());
		processorExecutionRecord.setServerIp(FileUtil.getInstance().getLocalHostIP());
		processorExecutionRecord.setDateCreated(new Date());
		processorExecutionRecord.setDateModified(processorExecutionRecord.getDateCreated());

		return processorExecutionRecord;
	}

}
