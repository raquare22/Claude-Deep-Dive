////package com.optum.fs.domain.util;
package com.optum.fds.paperless.domain.util;


/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who              Revision
 * Nov 05 2013  Sai Nagesh 		Initial version
 ****************************************************************/

public interface FSConstants {

	public static final String GRANT_TYPE_REFRESH_TOKEN ="refresh_token";
	public static final int ACCESS_TOKEN_EXPIRATION_DURATION = 1800;
	public static final int REFRESH_TOKEN_EXPIRATION_DURATION = 1209600;
	public static final String BEARER ="bearer";
	public static final String APK = "apk";
	public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
	public static final String AUTHENTICATE_HEADER_NAME = "WWW-Authenticate";
	public static final String AUTHENTICATE_HEADER_VALUE = "Bearer realm=\"Federated Storage API\"";	
	public static final String GRANT_TYPE_AUTHORIZATION_CODE ="authorization_code";
	public static final String SKIP_OAUTH_FILTER_URL = "/oauth2/token";
	public static final String SKIP_OAUTH_FILTER_SVC_URL = "/svc";
	public static final String GRANT_TYPE_APP = "app";
	public static final String GRANT_TYPE_CLIENT = "client";
	public static final String UTC = "UTC";
	public static final String URL_ENCODED = "application/x-www-form-urlencoded; charset=UTF-8";
	public static final String CONTENT_TYPE_JSON = "application/json";
	public static final String API_VERSION = "X-API-Version";
	public static final String API_VERSION_DEPRECATED = "X-API-Version-Deprecating";
	public static final String BUILD = "build.";
	// Common constants
	public static final String EMPTY_STRING = "";
	public static final String COMMA_STRING = ",";
	public static final String A = "A";
	public static final boolean TRUE = true;
	public static final boolean FALSE = false;
	public static final String COUNT = "count"; 
	public static final String STRING_A = "A";
	public static final String STRING_I = "I";
	public static final String STRING_D = "D";
	public static final int INTEGER_1=1;
	public static final int MAX_COUNT = 250;
	public static final int MILLISECONDS_IN_A_DAY = 86400000;  //24 * 60 * 60 * 1000
	
	
	public static final String AUTHORIZATION = "Authorization";
	// Permissions constants
	public static final String PERMISSION_NOT_REQUIRED = "notrequired";
	
	//
	public static final String CXF_DEFAULT_ACCEPT_TYPE = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
	

	
	public static final String WILD_CARD = "*/*";
	public static final String DEPRECATING = "-Deprecating";
	String ASCENDING = "ascending";
	String DESCENDING = "descending";
	String ASC = "ASC";
	String DESC = "DESC";

	
	public static final String DELIVERY_DATE_FORMAT = "yyyy-MM-dd hh:mm:ss";
	public static final String DELIVERY_DATE_NOW = "Now";
	public static final String DELIVERY_DATE_TOMORROW = "Tomorrow";
	
    // Retention Period constant for unit testing
    public static final int DEFAULT_EXPIRY_DATE = 730;
	

	
}
