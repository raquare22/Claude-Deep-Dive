/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who              Revision
 * Dec 16 2016  Will Herrera     Initial version
 ****************************************************************/
////package com.optum.fs.domain.revision;
package com.optum.fds.paperless.domain.revision;

import java.io.Serializable;

import org.bson.Document;

/**
 * 
 * @author shalder3
 *
 */
public class HookRevision extends Revision implements Serializable{
    private static final long serialVersionUID = 1L;

    private String errorMessage;
    private transient Document hook;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Document getHook() {
        return hook;
    }

    public void setHook(Document hook) {
        this.hook = hook;
    }
}
