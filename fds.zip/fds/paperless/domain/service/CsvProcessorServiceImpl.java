/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2018.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 */

////package com.optum.fs.domain.service;
package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.jobs.ProcessorJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.util.ProcessorUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service("CsvProcessorService")
public class CsvProcessorServiceImpl implements CsvProcessorService {
    private static final Logger LOGGER = LoggerFactory.getLogger(CsvProcessorServiceImpl.class);
    private static final String CSV_PROCESSOR_COLLECTION_NAME = "csvProcessor";
    private static final String CSV_PROCESSOR_TRANSACTION_COLLECTION_NAME= "csvProcessorTransaction";
    private static final String QUERY_STRING = "{} query={}";
    private static final String QUERY_STRING_TO_FETCH_CMP_TRANS = "query string to fetch companion file transaction {}";
    private static final String STATUS_KEY = "status";
    private static final String APP_IDENTIFIER = "appIdentifier";
    private static final String PROCESSOR_ID = "processorId";
    private static final String SERVER_TYPE = "serverType";
    private static final String FILE_NAME = "fileName";
    private static final String CSV_PROCESSOR_TRANSACTION_ID = "csvProcessorTransactionId";
    private static final String FILE_ROW_NUMBER = "fileRowNumber";
    private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";
    private static final String CSV_ROW_TASK_COLLECTION_NAME = "csvProcessorRowTask";
    private static final String PROCESSOR_RECORD_TYPE = "processorRecordType";
	private static final String STATUS = "status";
	private static final String ID = "id";

    @Autowired
    MongoTemplate mongoTemplate;

    public CsvProcessorServiceImpl(MongoTemplate mongoTemplate) {
    	this.mongoTemplate = mongoTemplate;
    }

    @Override
    public ProcessorMetaData findProcessorMetaDataById(String processorId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(processorId));
        LOGGER.debug(QUERY_STRING, "findProcessorMetaDataById", query);
        try {
        	return op.findOne(query, ProcessorMetaData.class, CSV_PROCESSOR_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorMetaDataById", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData findProcessorMetaDataByFileName(String csvFilename, String appId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(FILE_NAME).is(csvFilename))
                .addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        LOGGER.debug(QUERY_STRING, "findProcessorMetaDataByFileName", query);
        try {
            return op.findOne(query, ProcessorMetaData.class, CSV_PROCESSOR_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorMetaDataByFileName", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    private List<CsvProcessorRowTask> getCsvProcessorRowTaskList(Query query) {
        LOGGER.debug(QUERY_STRING, "getCsvProcessorRowTaskList", query);
        try {
            var hmds = mongoTemplate.find(query, CsvProcessorRowTask.class, CSV_ROW_TASK_COLLECTION_NAME);
            LOGGER.debug("csvProcessorService-->getCsvProcessorRowTaskList-->EXIT");
            return hmds;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getCsvProcessorRowTaskList", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    private CsvProcessorRowTask getCsvProcessorRowTask(Query query) {
        LOGGER.debug(QUERY_STRING, "getCsvProcessorRowTask", query);
        try {
            var opt = getCsvProcessorRowTaskList(query).stream().findFirst().orElse(null);
            LOGGER.debug("csvProcessorService-->getCsvProcessorRowTask-->EXIT");
            return opt;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING,"getCsvProcessorRowTask", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public CsvProcessorRowTask getCsvProcessorRowTaskByProcessorTransactionIdRowNumber(String id, Integer rowNumber) {
    	Query query = new Query();
    	query.addCriteria(
    			Criteria.where(CSV_PROCESSOR_TRANSACTION_ID).is(id)
    			.and(FILE_ROW_NUMBER).is(rowNumber)
    			);
    	return getCsvProcessorRowTask(query);
    }

    @Override
    public CsvProcessorRowTask getCsvProcessorRowTask(String id, String appIdentifier, String serverType){
        LOGGER.debug("csvProcessorService-->getCsvProcessorRowTask-->ENTER");
        Query query = ProcessorUtil.getProcessorByServerTypeQuery(id, appIdentifier, serverType);
        return getCsvProcessorRowTask(query);
    }
    
    @Override
    public CsvProcessorRowTask getCsvProcessorRowTaskById(String id){
        LOGGER.debug("csvProcessorService-->getCsvProcessorRowTaskById-->ENTER");
        Query query = ProcessorUtil.getProcessorByRowTaskId(id);
        return getCsvProcessorRowTask(query);
    }

    private List<CsvProcessorTransaction> getCsvProcessorTransactionList(Query query) {
        LOGGER.debug(QUERY_STRING, "getCsvProcessorTransactionList", query);
        try {
            var hmds = mongoTemplate.find (query, CsvProcessorTransaction.class, CSV_PROCESSOR_TRANSACTION_COLLECTION_NAME);
            LOGGER.debug("csvProcessorService-->getCsvProcessorTransactionList-->EXIT");
            return hmds;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getCsvProcessorTransactionList", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    private CsvProcessorTransaction getCsvProcessorTransaction(Query query) {
        LOGGER.debug(QUERY_STRING, "getCsvProcessorTransaction", query);
        try {
            var csvProcessorTransactions = getCsvProcessorTransactionList(query)
                    .stream().findFirst().orElse(null);
            LOGGER.debug("csvProcessorService-->getCsvProcessorTransaction-->EXIT");
            return csvProcessorTransactions;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getCsvProcessorTransaction", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public CsvProcessorTransaction getCsvProcessorTransaction(String processorId, String appIdentifier, String serverType) {
        LOGGER.debug("csvProcessorService-->getCsvProcessorTransaction-->ENTER");
        Query query = getCsvProcessorTransactionByProcessorId(processorId, appIdentifier, serverType);
        return getCsvProcessorTransaction(query);
    }

    @Override
    public CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String processorId, String appIdentifier, String fileName, String serverType) {
        LOGGER.debug("csvProcessorService-->getCsvProcessorTransactionWithFileName-->ENTER");
        Query query = getCsvProcessorTransactionByProcessorIdAndFileName(processorId, appIdentifier, fileName, serverType);
        return getCsvProcessorTransaction(query);
    }
    
    public static Query getCsvProcessorTransactionByTransId(String id) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(id)
        );
        LOGGER.debug(QUERY_STRING, "getCsvProcessorTransactionByTransId", query);
        return query;
    }
    
    public static Query getCsvProcessorTransactionByProcessorId(String processorId, String appIdentifier, String serverType) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_ID).is(processorId)
                        .and(APP_IDENTIFIER).is(appIdentifier)
        );
//        ProcessorUtil.addServerTypeCriteria(serverType, query);
        LOGGER.debug(QUERY_STRING, "getCsvProcessorTransactionByTransId", query);
        return query;
    }

    public static Query getCsvProcessorTransactionByProcessorIdAndFileName(String processorId, String appIdentifier, String fileName, String serverType) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_ID).is(processorId)
                        .and(APP_IDENTIFIER).is(appIdentifier)
                        .and(FILE_NAME).is(fileName)
        );
//        ProcessorUtil.addServerTypeCriteria(serverType, query);
        LOGGER.debug(QUERY_STRING, "getCsvProcessorTransactionByProcessorIdAndFileName", query);
        return query;
    }

    @Override
    public CsvProcessorTransaction saveCsvProcessorTransactionMetaData(CsvProcessorTransaction csvProcessorTransaction) {
        LOGGER.debug("csvProcessorService-->saveCsvProcessorTransactionMetaData-->ENTER; csvProcessorTransaction={}", csvProcessorTransaction.getId());
        mongoTemplate.save(csvProcessorTransaction, CSV_PROCESSOR_TRANSACTION_COLLECTION_NAME);
        LOGGER.debug("csvProcessorService-->saveCsvProcessorTransactionMetaData-->EXIT");
        return csvProcessorTransaction;
    }

    @Override
    public CsvProcessorTransaction updateProcessorExecutionRecordOfCsvProcessorTransactionRecord(CsvProcessorTransaction csvProcessorTransaction, Map<String, Object> resultMap, ProcessorJob job) {
        LOGGER.debug("csvProcessorService-->updateProcessorExecutionRecordOfCsvProcessorTransactionRecord-->ENTER");
        ProcessorUtil.setExecutionRecordForActiviti(csvProcessorTransaction, resultMap, job);
        if(!csvProcessorTransaction.getStatus().equals(MetaDataStatus.FATAL_ERROR)){
            csvProcessorTransaction.setStatus(MetaDataStatus.IN_PROCESS);
        }
        LOGGER.debug("csvProcessorService-->updateProcessorExecutionRecordOfCsvProcessorTransactionRecord-->EXIT");
        return updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
    }

    @Override
    public CsvProcessorTransaction updateCsvProcessorTransactionMetaData(CsvProcessorTransaction csvProcessorTransaction){
        LOGGER.debug("csvProcessorService-->updateCsvProcessorTransactionMetaData-->ENTER; csvProcessorTransaction={}", csvProcessorTransaction.getId());
        csvProcessorTransaction.setDateModified(new Date());
        LOGGER.debug("csvProcessorService-->updateCsvProcessorTransactionMetaData-->EXIT");
        return saveCsvProcessorTransactionMetaData(csvProcessorTransaction);
    }

    @Override
    public List<CsvProcessorTransaction> getAllCsvProcessorTransactionInStatus(String status, String serverType) {
        LOGGER.debug("csvProcessorService-->getAllCsvProcessorTransactionInStatus-->ENTER");
        Query query = processorTransactionStatusAndServerTypeQuery(status, serverType);
        LOGGER.debug("csvProcessorService-->getAllCsvProcessorTransactionInStatus-->EXIT");
        return getCsvProcessorTransactionList(query);
    }
    
    @Override
    public List<CsvProcessorTransaction> getAllCsvProcessorTransactionInStatus(List<String> statusList, String serverType, int processorTransactionSearchTimeWindow) {
        LOGGER.debug("csvProcessorService-->getAllCsvProcessorTransactionInStatus-->ENTER");
        Query query = processorTransactionStatusAndServerTypeQuery(statusList, serverType, processorTransactionSearchTimeWindow);
        LOGGER.debug("csvProcessorService-->getAllCsvProcessorTransactionInStatus-->EXIT");
        return getCsvProcessorTransactionList(query);
    }

    @Override
    public List<CsvProcessorTransaction> getAllPendingCsvProcessorTransactions(int csvProcessorTransactionPendingTime , List<String> statuses, String serverType) {
        LOGGER.debug("csvProcessorService-->getAllPendingCsvProcessorTransactions-->ENTER");
        Query query = pendingCsvProcessorTransactionsQuery(csvProcessorTransactionPendingTime, statuses, serverType);
        LOGGER.debug("csvProcessorService-->getAllPendingCsvProcessorTransactions-->EXIT");
        return getCsvProcessorTransactionList(query);
    }

    @Override
    public CsvProcessorRowTask saveCsvProcessorRowTask(CsvProcessorRowTask csvProcessorRowTask, boolean updateFlag) {
        LOGGER.debug("CsvProcessorService-->saveCsvProcessorRowTask-->ENTER; {}", csvProcessorRowTask);
        if(updateFlag){
        	csvProcessorRowTask.setDateModified(new Date());
        }
        mongoTemplate.save(csvProcessorRowTask, CSV_ROW_TASK_COLLECTION_NAME);
        LOGGER.debug("CsvProcessorService-->saveCsvProcessorRowTask-->EXIT");

        return csvProcessorRowTask;
    }

    public Query processorTransactionStatusAndServerTypeQuery(String status, String serverType) {
        LOGGER.debug("CsvProcessorService-->processorTransactionStatusAndServerTypeQuery-->ENTER");
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE).is(ProcessorRecordTypes.csvProcessorTransaction)
                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).is(status)
        );

        LOGGER.debug(QUERY_STRING, "processorTransactionStatusAndServerTypeQuery", query);
        return query;
    }
    
    public Query processorTransactionStatusAndServerTypeQuery(List<String> statusList, String serverType, int processorTransactionSearchTimeWindow) {
        LOGGER.debug("CsvProcessorService-->processorTransactionStatusAndServerTypeQuery-->ENTER");
        Query query = new Query();
        
        Date currentDate =  new Date(System.currentTimeMillis() - ((long) processorTransactionSearchTimeWindow * 24 * 60 * 60 * 1000));
        LOGGER.debug("CsvProcessorService-->Date = {}" , currentDate);
        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE).is(ProcessorRecordTypes.csvProcessorTransaction)
                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).in(statusList)
                        .and("dateModified").gte(currentDate)
        );

        LOGGER.debug(QUERY_STRING, "processorTransactionStatusAndServerTypeQuery", query);
        return query;
    }

    public Query pendingCsvProcessorTransactionsQuery(int processorTransactionPendingTime, List<String> statusList, String serverType) {
        Query query = new Query();
        Date currentDate =  new Date(System.currentTimeMillis() - processorTransactionPendingTime * 1000L);

        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE).is(ProcessorRecordTypes.csvProcessorTransaction)
                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).in(statusList)
                        .and("dateModified").lte(currentDate)
        );
        LOGGER.debug(QUERY_STRING, "pendingCsvProcessorTransactionsQuery", query);
        return query;
    }
    
    @Override
    public DocumentMetaData saveCsvRecord(DocumentMetaData documentMetaData) {
    	LOGGER.trace("Entering saveCsvRecord: documentMetaData={}", documentMetaData);

        MongoOperations op = mongoTemplate;
        op.insert(documentMetaData, "document");
        return documentMetaData;
    }
    
    @Override
    public JobMetaData saveRestApiJobRecord(JobMetaData restApiJob) {
        LOGGER.trace("Entering saveRestApiJobRecord");
        LOGGER.trace("restApiJobData = {}", restApiJob);

        MongoOperations op = mongoTemplate;
        op.insert(restApiJob, "job");
        return restApiJob;
    }
    
    @Override
    public JobMetaData saveCsvProcessorJobRecord(JobMetaData csvProcessorJob) {
        LOGGER.trace("Entering saveCsvProcessorJobRecord");
        LOGGER.trace("csvProcessorJob = {}", csvProcessorJob);

        MongoOperations op = mongoTemplate;
        op.insert(csvProcessorJob, "job");
        return csvProcessorJob;
    }

	
	@Override
	public List<CsvProcessorRowTask> getAllCsvProcessorRowTaskInStatus(List<String> statusList, String serverType,
			String csvProcessorTransactionId) {
		LOGGER.debug("csvProcessorService-->getAllCsvProcessorRowTaskInStatus-->ENTER");

		Query query = getCsvProcessorRowTaskInStatus(statusList, serverType, csvProcessorTransactionId);
		return getCsvProcessorRowTaskList(query);
	}

	public Query getCsvProcessorRowTaskInStatus(List<String> statusList, String serverType, String csvProcessorTransactionId) {
		LOGGER.debug("CsvProcessorService-->getCsvProcessorRowTaskInStatus-->ENTER");
		Query query = new Query();
		query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE).is(ProcessorRecordTypes.csvProcessorRowTask)
				.and(STATUS_KEY).in(statusList).and(SERVER_TYPE).is(serverType).and(CSV_PROCESSOR_TRANSACTION_ID).is(csvProcessorTransactionId));
		LOGGER.debug(QUERY_STRING, "getCsvProcessorRowTaskInStatus", query);
		LOGGER.debug("CsvProcessorService-->getCsvProcessorRowTaskInStatus-->EXIT");
		return query;
	}
	
	@Override
	public CsvProcessorTransaction getCsvProcessorTransactionById(String id) {
		LOGGER.debug("csvProcessorService-->getCsvProcessorTransactionWithId-->ENTER");
        Query query = getCsvProcessorTransactionByTransId(id);
        return getCsvProcessorTransaction(query);
    }

	@Override
	public CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String fileName) {
		LOGGER.debug("csvProcessorService-->getCsvProcessorTransactionWithFileName-->ENTER");
		Query query = getCsvProcessorTransWithFileName(fileName);
		LOGGER.debug(QUERY_STRING, "getCsvProcessorTransactionWithFileName", query);
		return getCsvProcessorTransaction(query);

//		try {
//			List<CsvProcessorTransaction> hmds = mongoTemplate.find(query, CsvProcessorTransaction.class,
//					CSV_PROCESSOR_TRANSACTION_COLLECTION_NAME);
//			if (hmds != null && !hmds.isEmpty()) {
//				retVal = hmds.get(0);
//			} else {
//				LOGGER.info("companion file transaction getting null for file {}", fileName);
//			}
//			LOGGER.info("csvProcessorService-->getCsvProcessorTransactionWithFileName-->EXIT");
//			return retVal;
//		} catch (Exception e) {
//			LOGGER.error(QUERY_EXCEPTION_STRING, "getCsvProcessorTransactionWithFileName", query, ExceptionUtils.getStackTrace(e));
//			throw e;
//		}
	}


    @Override
    public ProcessorMetaData saveCSVProcessor(ProcessorMetaData processorMetaData) {
        LOGGER.debug("Entering saveCSVProcessor");
        MongoOperations op = mongoTemplate;
        op.insert(processorMetaData);
        LOGGER.debug("Leaving saveCSVProcessor");
        return processorMetaData;
    }

    @Override
    public void updateCSVProcessor(ProcessorMetaData processorMetaData, Map<String, Object> map) {
        Map processor = (Map) map.get("csvProcessor");
        Map action = (Map) processor.get("action");
        Map objConfig = (Map) action.get("config");
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(processorMetaData.getId()));
        Update update = new Update().set("csvProcessor.action.config", objConfig);
        LOGGER.debug(QUERY_STRING, "updateCSVProcessor", query);
        try {
            mongoTemplate.updateFirst(query, update, ProcessorMetaData.class, String.valueOf(processorMetaData));
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "updateCSVProcessor", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData getCSVProcessorById(String id) {
        LOGGER.debug("Entering getCSVProcessorById");
        ProcessorMetaData retVal = null;
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));

        LOGGER.debug(QUERY_STRING, "getCSVProcessorById", query);
        try {
            List<ProcessorMetaData> hmds = op.find(query, ProcessorMetaData.class,CSV_PROCESSOR_COLLECTION_NAME);
            if (org.apache.commons.collections.CollectionUtils.isNotEmpty(hmds)) {
                retVal = hmds.get(0);
            }
            LOGGER.debug("Leaving getCSVProcessorById");
            return retVal;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getCSVProcessorById", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData deleteCSVProcessor(String id) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        var update = new Update();
        update.set(STATUS, MetaDataStatus.DELETED);
        LOGGER.debug(QUERY_STRING, "delete csvProcessor", update);

        return op.findAndModify(query(where(ID).is(id)), update,
				new FindAndModifyOptions().returnNew(true), ProcessorMetaData.class,CSV_PROCESSOR_COLLECTION_NAME);
    }

	public Query getCsvProcessorTransWithFileName(String fileName) {

		LOGGER.debug("CsvProcessorService-->getCsvProcessorTransWithFileName-->ENTER");
		Query query = new Query();

		query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE).is(ProcessorRecordTypes.csvProcessorTransaction)
				.and(FILE_NAME).is(fileName));
		LOGGER.debug(QUERY_STRING_TO_FETCH_CMP_TRANS, query);
		LOGGER.debug("CsvProcessorService-->getCsvProcessorTransWithFileName-->EXIT");
		return query;
	}
	
	
	 
	@Override
	    public ProcessorMetaData saveCSVProcessorMetaData(ProcessorMetaData processorMetaData) {
	        LOGGER.debug("Entering Processor Save");

	        mongoTemplate.save(processorMetaData, CSV_PROCESSOR_COLLECTION_NAME);

	        LOGGER.trace("Exiting Processor Save");
	        return processorMetaData;
	    }
}