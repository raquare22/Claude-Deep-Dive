package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.FDSHelper;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.exception.ProcessException;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.util.Parser;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.io.IOException;
import java.util.Map;

@Service("sendQueueService")
@Configuration
public class SendQueueServiceImpl implements SendQueueService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SendQueueServiceImpl.class);
	private static final String CALLBACK_MAP = "callbackMap";

	@Autowired
	ServiceBase serviceBase;

	@Value("${AZURE_WITH_IDENTIFIERS_URL}")
	private String messageServiceUrl;

	@Value("${ENGINE_DELIGATE_URL}")
	private String engineDelegateUrl;

	@Value("#{${SpaceIdToPriorityQueueMap}}")
	private Map<Integer, String> spaceIdToPriorityQueueMap;

	@Value("${FDSDocumentsUrl}")
	private String fDSDocumentsUrl;

	@Value("${CallRestApiWithMsgServiceOnErrorCallbackMaxRetryCnt}")
	private Integer maxRetryCnt;

	public String getPriorityQueue(Integer spaceId) {
		String queue = spaceIdToPriorityQueueMap.get(spaceId);
		if (queue == null) {
			LOGGER.warn("QUEUE: No spaceIdToPriorityQueueMap entry for spaceId={}; Default to LowPriorityQueue", spaceId);
			queue = "LowPriorityQueue";
		}
		return queue;
	}

	public void sendRequestToQueue(Integer spaceId, String identifier, String targetId, String delegate, Map<String, Object> callbackMap)
			throws ProcessException, HttpServerException {
		String callbackMapJson = getMultiValueMapToJson(delegate, callbackMap);
		LOGGER.info("QUEUE: PRE POST; callbackMapJson={}", callbackMapJson);
		
		ResponseEntity<GenericResponse> responseEntity = null;
		try {
			responseEntity = sendRequestToQueue(spaceId, identifier, targetId, delegate, callbackMapJson);
			if (responseEntity == null) {
				responseEntity = new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": QUEUE responseEntity == null"), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			LOGGER.error("FAILURE: executing QUEUE request; spaceId={}, identifier={}, targetId={} error={}",
				spaceId, identifier, targetId, ExceptionUtils.getStackTrace(e));
			responseEntity = new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": QUEUE  Failure; " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		int status = responseEntity.getStatusCode().value();
		if (status == HttpStatus.OK.value()) {
			LOGGER.info("QUEUE: OK; spaceId={}, identifier={}, targetId={}", spaceId, identifier, targetId);
			return;
		}

		LOGGER.error("QUEUE: spaceId={}, identifier={}, targetId={}", spaceId, identifier, targetId);
		String msg = responseEntity.hasBody() ? responseEntity.getBody().getStatusCode() + ":" + responseEntity.getBody().getStatusMessage() + ": " + (String) responseEntity.getBody().getResponse() : "No body returned";
		if (status >= HttpStatus.INTERNAL_SERVER_ERROR.value()) {
			// Retry the request; appError with AUTOMATIC
			LOGGER.error("QUEUE: Retry the request; spaceId={}, identifier={}, targetId={}", spaceId, identifier, targetId);
			throw new HttpServerException(status + ":" + msg);
		}
		// appError with MANUAL
		throw new ProcessException(status + ":" + msg);
	}

	public boolean addSendDocumentRequestToFds(Integer spaceId, String identifier, String targetId, String delegate,
			MultiValueMap<String, Object> requestMap, Map<String, Object> callbackMap, Map<String, Object> restApiMsgServiceCallbackMap)
			throws HttpServerException {
		return addSendDocumentRequestToFds(spaceId, identifier, targetId, delegate, requestMap, callbackMap, restApiMsgServiceCallbackMap, 0);
	}

	public boolean addSendDocumentRequestToFds(Integer spaceId, String identifier, String targetId, String delegate,
			MultiValueMap<String, Object> requestMap, Map<String, Object> callbackMap, Map<String, Object> restApiMsgServiceCallbackMap, int retryCnt)
			throws HttpServerException {
		// CALLBACK = processMetadataFilesCallback
		LOGGER.info("spaceId={}, identifier={}, targetId={}, delegate={}", spaceId, identifier, targetId, delegate);

		ResponseEntity<GenericResponse> responseEntity = null;
		try {
			responseEntity = serviceBase.postRequestToSvcMultipartForm(fDSDocumentsUrl, requestMap, Integer.toString(spaceId));
			if (responseEntity == null) {
				LOGGER.error("FAILURE: executing POST request; responseEntity == null; spaceId={}, identifier={}, targetId={}, retryCnt={}",
					spaceId, identifier, targetId, retryCnt);
				responseEntity = new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": " + fDSDocumentsUrl + "; responseEntity == null"), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			LOGGER.error("FAILURE: executing POST request; spaceId={}, identifier={}, targetId={}, retryCnt={}, error={}",
				spaceId, identifier, targetId, retryCnt, ExceptionUtils.getStackTrace(e));
			responseEntity = new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": " + fDSDocumentsUrl + "; " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if (responseEntity.getStatusCode().value() == HttpStatus.OK.value() || responseEntity.getStatusCode().value() == HttpStatus.CREATED.value()) {
			LOGGER.info("CALLBACK: OK Invoking delegate={}, spaceId={}, identifier={}, targetId={}, retryCnt={}, callbackMap={}",
				delegate, spaceId, identifier, targetId, retryCnt, callbackMap);
			FDSHelper.runProcess(delegate, callbackMap, responseEntity.getBody());
			return true;
		}

		LOGGER.warn("FAILURE: executing POST request; spaceId={}, identifier={}, targetId={}, statusCode={}, requestMap={}",
			spaceId, identifier, targetId, responseEntity.getStatusCode(), requestMap);

		if (! isRetry(responseEntity)) {
			LOGGER.error("CALLBACK: FAILURE; status={} not 400 ConnectException or SocketException and not 500 series; Invoking delegate={}, spaceId={}, identifier={}, targetId={}, retryCnt={}, callbackMap={}",
					responseEntity.getStatusCode().value(), delegate, spaceId, identifier, targetId, retryCnt, callbackMap);
			FDSHelper.runProcess(delegate, callbackMap, responseEntity.getBody());
			return false;
		}

		if (retryCnt >= maxRetryCnt) {
			LOGGER.error("CALLBACK: FAILURE; MaxRetryCnt Exceeded; retryCnt={}, maxRetryCnt={}; Invoking delegate={}, spaceId={}, identifier={}, targetId={}, callbackMap={}",
				retryCnt, maxRetryCnt, delegate, spaceId, identifier, targetId, callbackMap);
			responseEntity = new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": " + "RetryCnt Exceeded=" + retryCnt), HttpStatus.INTERNAL_SERVER_ERROR);
			FDSHelper.runProcess(delegate, callbackMap, responseEntity.getBody());
			return false;
		}

		try {
			// Send message to messageService to queue CallRestApiWithMsgServiceOnErrorCallback which will retry addSendDocumentRequestToFds
			String callbackMapJson = getMultiValueMapToJson("callRestApiWithMsgServiceOnErrorCallback", restApiMsgServiceCallbackMap);
			LOGGER.warn("FAILURE: executing POST request initiate CALLBACK; Sending request to msgService callRestApiWithMsgServiceOnErrorCallback; spaceId={}, identifier={}, targetId={}, retryCnt={}, maxRetryCnt={}, callbackMapJson={}",
				spaceId, identifier, targetId, retryCnt, maxRetryCnt, callbackMapJson);
			responseEntity = sendRequestToQueue(spaceId, identifier + ":callRestApiWithMsgServiceOnErrorCallback", targetId, "callRestApiWithMsgServiceOnErrorCallback", callbackMapJson);
			if (responseEntity == null) {
				responseEntity = new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": QUEUE responseEntity == null"), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			LOGGER.error("FAILURE: executing QUEUE request initiate msgSvc CALLBACK; spaceId={}, identifier={}, targetId={}, retryCnt={}, error={}",
				spaceId, identifier, targetId, retryCnt, ExceptionUtils.getStackTrace(e));
			responseEntity = new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": QUEUE  Failure; " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		int status = responseEntity.getStatusCode().value();
		if (status == HttpStatus.OK.value()) {
			LOGGER.info("QUEUE: OK; spaceId={}, identifier={}, targetId={}, retryCnt={}", spaceId, identifier, targetId, retryCnt);
			return false;
		}

		LOGGER.info("QUEUE: spaceId={}, identifier={}, targetId={}, retryCnt={}", spaceId, identifier, targetId, retryCnt);
		String msg = "No body returned";
		if (responseEntity != null && responseEntity.getBody() != null) {
			msg = responseEntity.getBody().getStatusCode() + ":" + responseEntity.getBody().getStatusMessage() + ": " + (String) responseEntity.getBody().getResponse();
		}
		if (status >= HttpStatus.INTERNAL_SERVER_ERROR.value()) {
			// Retry the request: Calling method will write to appError and messageService will processes
			LOGGER.warn("QUEUE: Retry the request; spaceId={}, identifier={}, targetId={}, retryCnt={}", spaceId, identifier, targetId, retryCnt);
			throw new HttpServerException(status + ":" + msg);
		}

		LOGGER.error("CALLBACK: QUEUE FAILURE; Invoking delegate={}, spaceId={}, identifier={}, targetId={}, retryCnt={}, callbackMap={}",
			delegate, spaceId, identifier, targetId, retryCnt, callbackMap);
		FDSHelper.runProcess(delegate, callbackMap, responseEntity.getBody());
		return false;
	}

	protected boolean isRetry(ResponseEntity<GenericResponse> responseEntity) {
		// ServiceBase changes failures e.g 403 FORBIDDEN to 400 i.e HttpStatus.BAD_REQUEST. The responseEntity.getBody().getResponse().toString()
		// retains the 403 FORBIDDEN in message. The 403 becomes a STORAGE_ERROR in processMetadataFilesCallback if it is not resolved by retries
		String responseStr = responseEntity.getBody() != null && responseEntity.getBody().getResponse() != null ? responseEntity.getBody().getResponse().toString() : "NULL";
		return (responseEntity.getStatusCode().value() == HttpStatus.BAD_REQUEST.value() || responseStr.contains("ConnectException") || responseStr.contains("SocketException") || responseStr.contains("Service Unavailable"));
	}

	protected ResponseEntity<GenericResponse> sendRequestToQueue(Integer spaceId, String identifier, String targetId, String delegate, String callbackMapJson) {
		String queue = getPriorityQueue(spaceId);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.info("QUEUE POST: spaceId={}, queue={}, identifier={}, targetId={}, delegate={}, callbackMapJson={}", spaceId, queue, identifier, targetId, delegate, callbackMapJson);
		}
		else
		if (LOGGER.isInfoEnabled()){
			LOGGER.info("QUEUE POST: spaceId={}, queue={}, identifier={}, targetId={}, delegate={}", spaceId, queue, identifier, targetId, delegate);
		}
		return serviceBase.postRequestToSvc(messageServiceUrl, callbackMapJson, queue + "/" + engineDelegateUrl + "/" + identifier + "/" + targetId + "/" + spaceId);
	}

	protected String getMultiValueMapToJson(String delegate, Map<String, Object> callbackMap) throws ProcessException {
		MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
		requestMap.add("delegate", delegate);
		requestMap.add(CALLBACK_MAP, callbackMap);
		try {
			return Parser.toJson(requestMap);
		} catch (IOException e) {
			throw new ProcessException("delegate=" + delegate + ": " + e.getMessage());
		}
	}
}