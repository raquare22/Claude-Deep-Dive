package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTargetType;
import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;
import org.eclipse.collections.api.factory.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

import jakarta.ws.rs.NotFoundException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.function.UnaryOperator;

@Service("csvProcessorsService")
public class CsvProcessorsServiceImpl  implements CsvProcessorsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CsvProcessorsServiceImpl.class);

	private static final String VERSION = "1";
	private static final String ACTIVE = "ACTIVE";
	private static final String PROCESSOR_NOT_FOUND_TEMPLATE = "Processor with id of %s not found";
	private static final String DELIMITER = ", ";
	private static final String PREFIX = "[";
	private static final String SUFFIX = "]";
	
	@Autowired
	CsvProcessorService csvProcessorService;
	
	@Autowired
	TransactionService transactionService;

	// Constructor
	public CsvProcessorsServiceImpl() {
		// Required constructor
	}

	@Autowired
	MongoTemplate mongoTemplate;

	public CsvProcessorsServiceImpl(CsvProcessorService csvProcessorService, TransactionService transactionService) {
		this.csvProcessorService = csvProcessorService;
		this.transactionService = transactionService;
	}

	public CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorTransaction processorTransaction,
			String csvFileName, String csvJsonFileName, Transaction transactionMetaData) {
		LOGGER.debug("csvProcessorsService-->createCsvProcessorRowTask-->ENTER; csvFileName={}, csvJsonFileName={}", csvFileName, csvJsonFileName);
		CsvProcessorRowTask csvRowFileTask = new CsvProcessorRowTask();
		csvRowFileTask.setAppIdentifier(processorTransaction.getAppIdentifier());
		csvRowFileTask.setClientId(processorTransaction.getClientId());
		csvRowFileTask.setCsvFileName(csvFileName);
		csvRowFileTask.setJsonFileName(csvJsonFileName);
		csvRowFileTask.setLocation(processorTransaction.getLocation());
		csvRowFileTask.setConfigSpaceId(processorTransaction.getConfigSpaceId());
		csvRowFileTask.setTransactionId(transactionMetaData.getTransactionId());
		csvRowFileTask.setVersion(VERSION);
		csvRowFileTask.setProcessorId(processorTransaction.getProcessorId());
		csvRowFileTask.setStatus(MetaDataStatus.NEW);
		csvRowFileTask.setCsvProcessorTransactionId(processorTransaction.getId());
		csvRowFileTask.setProcessorRecordType(ProcessorRecordTypes.csvProcessorRowTask);
		////csvRowFileTask.setServerType(applicationPropertyUtil.get(SERVER_TYPE));
		processorTransaction.setServerType("ose-batch");
		LOGGER.debug("csvProcessorsService-->createCsvProcessorRowTask-->EXIT");
		return csvRowFileTask;
	}

	@Override
	public CsvProcessorTransaction createCsvProcessorTransaction(ProcessorMetaData processor, String fileName,
			String fileLocation, String transactionID) {
		LOGGER.debug("csvProcessorsService-->createCsvProcessorTransaction-->ENTER");

		CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
		processorTransaction.setAppIdentifier(processor.getAppIdentifier());
		processorTransaction.setClientId(processor.getClientId());
		processorTransaction.setFileName(fileName);
		processorTransaction.setLocation(fileLocation);
		processorTransaction.setConfigSpaceId(processor.getConfigSpaceId());
		processorTransaction.setTransactionId(transactionID);
		processorTransaction.setVersion(VERSION);
		processorTransaction.setProcessorId(processor.getId());
		processorTransaction.setStatus(MetaDataStatus.NEW);
		processorTransaction.setProcessorRecordType(ProcessorRecordTypes.csvProcessorTransaction);
		//processorTransaction.setServerType(ApplicationProperty.get(SERVER_TYPE));
		processorTransaction.setServerType("ose-batch");
		csvProcessorService.saveCsvProcessorTransactionMetaData(processorTransaction);

		LOGGER.debug("csvProcessorsService-->createCsvProcessorTransaction-->EXIT");
		return processorTransaction;
	}

	@Override
	public CsvProcessorTransaction getCsvTransactionProcessor(String appIdentifier, String processorId) {
		LOGGER.debug("csvProcessorsService-->getCsvTransactionProcessor-->ENTER");
		CsvProcessorTransaction processorTransaction = csvProcessorService.getCsvProcessorTransaction(processorId,
				appIdentifier, "ose-batch"); //ApplicationProperty.get(SERVER_TYPE)); //TODO

		if (processorTransaction == null) {
			throw new NotFoundException(String.format(PROCESSOR_NOT_FOUND_TEMPLATE, processorId));
		}
		LOGGER.debug("csvProcessorsService-->getCsvTransactionProcessor-->EXIT");
		return processorTransaction;
	}
	
	@Override
	public CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String appIdentifier, String processorId, String fileName) {
		LOGGER.debug("csvProcessorsService-->getCsvProcessorTransactionWithFileName-->ENTER");
		CsvProcessorTransaction processorTransaction = csvProcessorService.getCsvProcessorTransactionWithFileName(processorId,
				appIdentifier, fileName, "ose-batch"); //ApplicationProperty.get(SERVER_TYPE)); TODO

		if (processorTransaction == null) {
			throw new NotFoundException(String.format(PROCESSOR_NOT_FOUND_TEMPLATE, processorId));
		}
		LOGGER.debug("csvProcessorsService-->getCsvProcessorTransactionWithFileName-->EXIT");
		return processorTransaction;
	}
	
	@Override
	public ProcessorMetaData findProcessorMetaDataByFileName(String csvFilename, String appId) {
		return csvProcessorService.findProcessorMetaDataByFileName(csvFilename, appId);
	}
	
	@Override
	public ProcessorMetaData findProcessorMetaDataById(String id) {
		return csvProcessorService.findProcessorMetaDataById(id);
	}

	@Override
	public CsvProcessorTransaction updateCsvProcessorTransactionMetaData(
			CsvProcessorTransaction csvProcessorTransaction) {
		LOGGER.debug("csvProcessorsService-->updateCsvProcessorTransactionMetaData-->ENTER");
		return csvProcessorService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
	}
	
	@Override
	public List<CsvProcessorTransaction> getAllTransactionProcessorsShutdown() {
		LOGGER.debug("csvProcessorsService-->getAllTransactionProcessorsShutdown-->ENTER");
		return csvProcessorService.getAllCsvProcessorTransactionInStatus(MetaDataStatus.SHUTDOWN.toString(),"ose-batch");
				////ApplicationProperty.get(SERVER_TYPE)); TODO
	}

	@Override
	public List<CsvProcessorTransaction> getAllPendingCsvProcessorsTransactions(int processorTransactionPendingTime) {
		LOGGER.debug("csvProcessorsService-->getAllPendingCsvProcessorsTransactions-->ENTER");
		List<String> statusList = new ArrayList<>();
		statusList.add(MetaDataStatus.NEW.toString());
		statusList.add(MetaDataStatus.IN_PROCESS.toString());
		LOGGER.debug("csvProcessorsService-->getAllPendingCsvProcessorsTransactions-->EXIT");

		return csvProcessorService.getAllPendingCsvProcessorTransactions(processorTransactionPendingTime, statusList,"ose-batch");
				////ApplicationProperty.get(SERVER_TYPE)); //TODO
	}
	
	@Override
	public DocumentMetaData createCsvRecord(int spaceId, String appIdentifier, MetaDataStatus status, Map<String, Object> requestMap) {

		Document metadata = new Document();
		DocumentMetaData documentMetaData = new DocumentMetaData();
		for (Map.Entry<String, Object> entry : requestMap.entrySet()) {
			metadata.put(entry.getKey(), entry.getValue());
		}
		documentMetaData.setSpaceId(spaceId);
		documentMetaData.setAppIdentifier(appIdentifier);
		documentMetaData.setMetadata(metadata);
		documentMetaData.setStatus(status);
		documentMetaData.setClientId(685);
		documentMetaData.setTransactionId("43a009b9-a647-4279-b7e9-24a1f05bb54d");
		return csvProcessorService.saveCsvRecord(documentMetaData);
	}

	@Override
	public DocumentMetaData createCsvRecord(int spaceId, String appIdentifier, String tin, String mpin, String fileName, String fileType, String providerEmailId,
			String frequency, String deliveryMethod, String okToChangePdoInd, String autoEdelUpdateInd, MetaDataStatus status) {
		Document metadata = new Document();
		metadata.put(Workflow.TIN, tin);
		metadata.put(Workflow.MPIN, mpin);
		metadata.put(Workflow.FILE_NAME, fileName);
		metadata.put(Workflow.FILE_TYPE, fileType);
		metadata.put(Workflow.PROVIDER_EMAIL_ID, providerEmailId);
		metadata.put(Workflow.FREQUENCY, frequency);
		metadata.put(Workflow.DELIVERY_METHOD, deliveryMethod);
		metadata.put(Workflow.OK_TO_CHANGE_PDO_IND, okToChangePdoInd);
		metadata.put(Workflow.AUTO_EDEL_UPDATE_IND, autoEdelUpdateInd);
		
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setSpaceId(spaceId);
		documentMetaData.setAppIdentifier(appIdentifier);
		documentMetaData.setMetadata(metadata);
		documentMetaData.setStatus(status);
		documentMetaData.setClientId(685);
		documentMetaData.setTransactionId("43a009b9-a647-4279-b7e9-24a1f05bb54d");
		return csvProcessorService.saveCsvRecord(documentMetaData);

	}
	
	@Override
	public JobMetaData createRestApiJobEntry(ProcessorMetaData processor,
			CsvProcessorTransaction csvProcessorTransaction, String csvProcessorRowTaskId, String jobType, String wrkFlow,
			org.springframework.http.HttpMethod method, HttpEntity<Object> request, ProcessorRecordTypes sourceType,
			URI uri) {
	    Integer priority = processor.getPriority();
		JobMetaData jobEntry = new JobMetaData();
		jobEntry.setDateCreated(new Date());
		jobEntry.setDateModified(new Date());
		jobEntry.setStatus(ACTIVE);
		jobEntry.setJobType(jobType);
		jobEntry.setSpaceId(processor.getConfigSpaceId());
		jobEntry.setClientId(processor.getClientId());
		jobEntry.setAppIdentifier(processor.getAppIdentifier());
		jobEntry.setFileName(csvProcessorTransaction.getFileName());
		jobEntry.setFilePath(csvProcessorTransaction.getLocation());
		jobEntry.setWorkFlow(wrkFlow);
		jobEntry.setProcessorId(processor.getId());
		jobEntry.setProcessorJobType("processorRestApiJob");
		jobEntry.setProcessorTransactionId(csvProcessorTransaction.getId());
		jobEntry.setCsvProcessorRowTaskId(csvProcessorRowTaskId);
		jobEntry.setServerName(FileUtil.getInstance().getLocalHostName());
		////jobEntry.setServerType(applicationPropertyUtil.get(SERVER_TYPE));
		jobEntry.setMethod(method);
		////jobEntry.setRequest(new OptumHttpEntity((MultiValueMap<String, String>) request.getBody(), request.getHeaders()));
		jobEntry.setSourceType("processor");
		jobEntry.setUri(uri);
		jobEntry.setExecutionDateTime(new Date());
		if (priority != null) {
		    jobEntry.setPriority(priority);
		}

		csvProcessorService.saveRestApiJobRecord(jobEntry);

		return jobEntry;
	}
	
	

	@Override
	public JobMetaData createCsvProcessorJobEntry(ProcessorMetaData processor,
			CsvProcessorTransaction csvProcessorTransaction, String jobType, String wrkFlow) {
	    Integer priority = processor.getPriority();
		JobMetaData jobEntry = new JobMetaData();
		jobEntry.setDateCreated(new Date());
		jobEntry.setDateModified(new Date());
		jobEntry.setStatus(ACTIVE);
		jobEntry.setJobType(jobType);
		jobEntry.setSpaceId(processor.getConfigSpaceId());
		jobEntry.setClientId(processor.getClientId());
		jobEntry.setAppIdentifier(processor.getAppIdentifier());
		jobEntry.setFileName(csvProcessorTransaction.getFileName());
		jobEntry.setFilePath(csvProcessorTransaction.getLocation());
		jobEntry.setTemplateDefinition((String) processor.getProcessConfig().get("template_definition"));
		jobEntry.setTemplateId((String) processor.getProcessConfig().get("templateId"));
		jobEntry.setDelimit((String) processor.getProcessConfig().get("delimit"));
		jobEntry.setCompanionTRL((Boolean) processor.getProcessConfig().get("companionTRL"));
		jobEntry.setWorkFlow(wrkFlow);
		jobEntry.setProcessorId(processor.getId());
		jobEntry.setProcessorJobType("csvProcessorJob");
		jobEntry.setCsvProcessorTransactionId(csvProcessorTransaction.getId());
		jobEntry.setServerName(FileUtil.getInstance().getLocalHostName());
		////jobEntry.setServerType(applicationPropertyUtil.get(SERVER_TYPE));
		jobEntry.setExecutionDateTime(new Date());
	      if (priority != null) {
	            jobEntry.setPriority(priority);
	        }

		csvProcessorService.saveCsvProcessorJobRecord(jobEntry);

		return jobEntry;
	}


	@Override
	public CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorTransaction processorTransaction,
			String csvFileName, String csvJsonFileName, Integer rowNumber, String request, String targetType) {
		CsvProcessorRowTask cprt = new CsvProcessorRowTask();
		cprt.setCsvFileName(csvFileName);
		cprt.setTargetType(targetType);
		cprt.setFileRowNumber(rowNumber);
		cprt.setCsvFileName(csvFileName);
		cprt.setJsonFileName(csvJsonFileName);
		cprt.setRequest(request);
		cprt.setCsvProcessorTransactionId(processorTransaction.getId());
		cprt.setAppIdentifier(processorTransaction.getAppIdentifier());
		cprt.setClientId(processorTransaction.getClientId());
		////cprt.setServerType(applicationPropertyUtil.get(SERVER_TYPE));
		cprt.setServerType("ose-batch");
		return csvProcessorService.saveCsvProcessorRowTask(cprt, false);
	}

	@Override
	public CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorTransaction processorTransaction,
			Integer configSpaceId, String csvFileName, String csvJsonFileName, Integer rowNumber, String request, MetaDataStatus status) {
		CsvProcessorRowTask cprt = new CsvProcessorRowTask();
		cprt.setProcessorRecordType(ProcessorRecordTypes.csvProcessorRowTask);
		cprt.setConfigSpaceId(configSpaceId);
		cprt.setCsvFileName(csvFileName);
		cprt.setFileRowNumber(rowNumber);
		cprt.setCsvFileName(csvFileName);
		cprt.setJsonFileName(csvJsonFileName);
		cprt.setRequest(request);
		cprt.setStatus(status.toString());
		cprt.setCsvProcessorTransactionId(processorTransaction.getId());
		cprt.setAppIdentifier(processorTransaction.getAppIdentifier());
		cprt.setClientId(processorTransaction.getClientId());
		////cprt.setServerType(applicationPropertyUtil.get(SERVER_TYPE));
		cprt.setServerType("ose-batch");
		return csvProcessorService.saveCsvProcessorRowTask(cprt, false);
	}
	
	@Override
	public CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorTransaction processorTransaction,
			Integer configSpaceId, String csvFileName, String csvJsonFileName, Integer rowNumber, String request, String targetId, MetaDataStatus status) {
		CsvProcessorRowTask cprt = new CsvProcessorRowTask();
		cprt.setProcessorRecordType(ProcessorRecordTypes.csvProcessorRowTask);
		cprt.setConfigSpaceId(configSpaceId);
		cprt.setCsvFileName(csvFileName);
		cprt.setFileRowNumber(rowNumber);
		cprt.setCsvFileName(csvFileName);
		cprt.setJsonFileName(csvJsonFileName);
		cprt.setRequest(request);
		cprt.setStatus(status.toString());
		cprt.setCsvProcessorTransactionId(processorTransaction.getId());
		cprt.setAppIdentifier(processorTransaction.getAppIdentifier());
		cprt.setClientId(processorTransaction.getClientId());
		cprt.setTargetId(targetId);
		cprt.setTargetType(ProcessorTargetType.documents.toString());
		////cprt.setServerType(applicationPropertyUtil.get(SERVER_TYPE));
		cprt.setServerType("ose-batch");
		return csvProcessorService.saveCsvProcessorRowTask(cprt, false);
	}
	
	@Override
	public CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorRowTask csvProcessorRowTask) {
		return csvProcessorService.saveCsvProcessorRowTask(csvProcessorRowTask, false);
	}

	@Override
	public CsvProcessorRowTask updateCsvProcessorRowTask(CsvProcessorRowTask csvProcessorRowTask) {
		return csvProcessorService.saveCsvProcessorRowTask(csvProcessorRowTask, true);
	}

	@Override
	public List<CsvProcessorTransaction> getAllCsvProcessorsTransactions(List<String> statusList, int processorTransactionSearchTimeWindow) {
		////return csvProcessorService.getAllCsvProcessorTransactionInStatus(statusList, ApplicationProperty.get(SERVER_TYPE), processorTransactionSearchTimeWindow);
		return csvProcessorService.getAllCsvProcessorTransactionInStatus(statusList, "ose-batch", processorTransactionSearchTimeWindow);
	}

	@Override
	public CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String fileName) {
		return csvProcessorService.getCsvProcessorTransactionWithFileName(fileName);
	}

	@Override
	public List<CsvProcessorRowTask> getAllCompleteWithErrorsCsvProcessorsRowTasks(String csvProcessorTransactionId) {
		List<String> statusList= new ArrayList<>(); 
		statusList.add(MetaDataStatus.COMPLETE_WITH_ERRORS.toString());
		//return csvProcessorService.getAllCsvProcessorRowTaskInStatus(statusList, ApplicationProperty.get(SERVER_TYPE), csvProcessorTransactionId);
		return csvProcessorService.getAllCsvProcessorRowTaskInStatus(statusList, "ose-batch", csvProcessorTransactionId);
	}
	
	@Override
	public Boolean isAllCsvProcessorRowTasksWithCsvProcessorTransactionIdComplete(String csvProcessorTransactionId) {
		List<String> statusList = Lists.fixedSize.of(MetaDataStatus.COMPLETE.toString(),
				MetaDataStatus.COMPLETE_WITH_ERRORS.toString());
		List<CsvProcessorRowTask> csvProcessorRowTasks = csvProcessorService.getAllCsvProcessorRowTaskInStatus(
				//statusList, ApplicationProperty.get(SERVER_TYPE), csvProcessorTransactionId);
				statusList, "ose-batch", csvProcessorTransactionId);
		var joiner = new StringJoiner(DELIMITER, PREFIX, SUFFIX);
		UnaryOperator<String> func = x -> {
			joiner.add(x);
			return x;
		};

		var errorCounter = csvProcessorRowTasks
				.stream()
				.filter(x -> x.getStatus() == MetaDataStatus.COMPLETE_WITH_ERRORS)
				.map(CsvProcessorRowTask::getId)
				.map(func)
				.count();

		LOGGER.debug("csvProcessorRowTasks ids with {} : {}", MetaDataStatus.COMPLETE_WITH_ERRORS, joiner);
		return errorCounter == 0;
	}

    @Override
    public Boolean isAllCsvProcessorRowTasksProcessed(CsvProcessorTransaction csvProcessorTransaction) {
		List<String> statusList = Lists.fixedSize.of(MetaDataStatus.COMPLETE.toString(),
				MetaDataStatus.COMPLETE_WITH_ERRORS.toString());
          List<CsvProcessorRowTask> csvProcessorRowTasks = csvProcessorService.getAllCsvProcessorRowTaskInStatus(
                    ////statusList, ApplicationProperty.get(SERVER_TYPE), csvProcessorTransaction.getId());
                    statusList, "ose-batch", csvProcessorTransaction.getId());
          return csvProcessorTransaction.getRowCount().equals(csvProcessorRowTasks.size());
         
    }
    
    @Override
	public CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String appIdentifier, String processorId,
			String fileName, String serverType) {
		LOGGER.debug("csvProcessorsService-->getCsvProcessorTransactionWithFileName-->ENTER");
		CsvProcessorTransaction processorTransaction = csvProcessorService.getCsvProcessorTransactionWithFileName(processorId,
				appIdentifier, fileName, serverType);

		if (processorTransaction == null) {
			throw new NotFoundException(String.format(PROCESSOR_NOT_FOUND_TEMPLATE, processorId));
		}
		LOGGER.debug("csvProcessorsService-->getCsvProcessorTransactionWithFileName-->EXIT");
		return processorTransaction;
	}
}
