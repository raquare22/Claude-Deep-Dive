package com.optum.fds.paperless.domain.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.mongo.DocvaultTransaction;


@Service("docvaultTransactionService")
public class DocvaultTransactionServiceImpl implements DocvaultTransactionService {
    
    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public String insert(DocvaultTransaction transaction) {
        MongoOperations op = mongoTemplate;
        op.insert(transaction);
        return transaction.getId();
    }

}
