package com.optum.fds.paperless.domain.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

public interface JobsService {
	
	public List<String> getJobs(String token, String limit);
	
	public List<String> getJobsRESTApi(String token, String limit);
	
	public String runJob(String token, String jobId);
	
	public String createCleanupJob(String token);
	
	public String resolveInProcessJobs(String token);
}
