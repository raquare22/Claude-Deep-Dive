package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocvaultTransaction;

public interface DocvaultTransactionService {

    String insert(DocvaultTransaction transaction);

}
