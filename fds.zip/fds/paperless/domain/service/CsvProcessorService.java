/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2018.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 */

package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.jobs.ProcessorJob;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;

import java.util.List;
import java.util.Map;

public interface CsvProcessorService {

    ProcessorMetaData saveCSVProcessor(ProcessorMetaData processorMetaData);
    
    ProcessorMetaData saveCSVProcessorMetaData(ProcessorMetaData processorMetaData);

    void updateCSVProcessor(ProcessorMetaData processorMetaData, Map<String, Object> map);

    ProcessorMetaData getCSVProcessorById(String id);

    ProcessorMetaData deleteCSVProcessor(String id);

	ProcessorMetaData findProcessorMetaDataById(String id);

    ProcessorMetaData findProcessorMetaDataByFileName(String csvFilename, String appId);

    CsvProcessorRowTask getCsvProcessorRowTaskByProcessorTransactionIdRowNumber(String id, Integer rowNumber);

    CsvProcessorRowTask getCsvProcessorRowTask(String id, String appIdentifier, String serverType);

    CsvProcessorRowTask getCsvProcessorRowTaskById(String id);

    CsvProcessorTransaction getCsvProcessorTransactionById(String id);

    CsvProcessorTransaction getCsvProcessorTransaction(String id, String appIdentifier, String serverType);

    CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String id, String appIdentifier, String fileName, String serverType);

    CsvProcessorTransaction saveCsvProcessorTransactionMetaData(CsvProcessorTransaction processorTransaction);

    CsvProcessorTransaction updateProcessorExecutionRecordOfCsvProcessorTransactionRecord(CsvProcessorTransaction processorTransaction, Map<String, Object> resultMap, ProcessorJob job);

    CsvProcessorTransaction updateCsvProcessorTransactionMetaData(CsvProcessorTransaction processorTransaction);

    List<CsvProcessorTransaction> getAllCsvProcessorTransactionInStatus(String status, String serverType);

    List<CsvProcessorTransaction> getAllCsvProcessorTransactionInStatus(List<String> statusList, String serverType, int processorTransactionSearchTimeWindow);

    List<CsvProcessorTransaction> getAllPendingCsvProcessorTransactions(int csvProcessorTransactionPendingTime, List<String> statusList, String serverType);

    CsvProcessorRowTask saveCsvProcessorRowTask(CsvProcessorRowTask csvProcessorRowTask, boolean updateFlag);

    DocumentMetaData saveCsvRecord(DocumentMetaData documentMetaData);

    JobMetaData saveRestApiJobRecord(JobMetaData restApiJob);

    JobMetaData saveCsvProcessorJobRecord(JobMetaData csvProcessorJob);

    List<CsvProcessorRowTask> getAllCsvProcessorRowTaskInStatus(List<String> statusList, String serverType, String csvProcessorTransactionId);

    CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String fileName);

}