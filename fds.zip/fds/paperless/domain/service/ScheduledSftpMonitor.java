package com.optum.fds.paperless.domain.service;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import com.optum.fds.paperless.util.Utilities;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.re2j.Pattern;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import java.io.BufferedOutputStream;
import java.io.File;
import java.util.*;

/**
 * Poll Remote SFTP directory
 **/

@Component
public class ScheduledSftpMonitor {
    @Autowired
    ProcessorService processorService;
    @Autowired
    ProcessorsService processorsService;
    @Autowired
    SftpMonitorUtil sftpMonitorUtil;

    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledSftpMonitor.class);

    private static final String FILE_EXTENSION = ".zip";
    private static final String ACK_FILE_EXTENSION = "_ack.zip";
    private static final String HOST_NAME_SOURCE = "host_name_source";
    private static final String USER_NAME_SOURCE = "username_source";
    private static final String USER_CREDENTIALS_SOURCE = "pw_source";
    private static final String FTP_ROOT_DIR = "ftp_rootdir";
    private static final String FTP_ARCHIVE_DIR = "ftp_archivedir";
    public static final String INGEST_PATH_PROPERTY_NAME = "INGEST_ROOT";
    private static final String WRK_FLOW = "fileUnzipProcess";
    private static final String JOB_TYPE = "zipFileProcessor";
    private static final String DIRECTORY_LISTING = "directoryListing";
    private static final String CHANNEL_SFTP = "channelSftp";
    private static final String SFTP_SESSION = "sftpSession";
    private static final String CHANNEL = "channel";
    private static final String LOCK_FILE_NAME = "sftp_locked.txt";
    private static final String PROCESSOR_TRANSACTION_CREATED_FOR_FILENAME_AND_TRANSACTION_ID = "ScheduledSftpMonitor --> processorTransaction created, entryFilename={}, processorTransactionId={}";
    Map<String, String> correlationIds = new HashMap<>();



    public ScheduledSftpMonitor() {
        //Required constructor
    }
    public ScheduledSftpMonitor(ProcessorService processorService, ProcessorsService processorsService, SftpMonitorUtil sftpMonitorUtil) {
        this.processorService = processorService;
        this.processorsService = processorsService;
        this.sftpMonitorUtil = sftpMonitorUtil;
    }


    @SuppressWarnings({ "unchecked", "rawtypes" })
    public List<String> runSFTPMonitor(ProcessorMetaData inProcessor) throws IOException {
        LOGGER.debug("ScheduledSftpMonitor-->runSFTPMonitor-->ENTER");

       // Map processConfig = (Map) inProcessor.getProcess().get("config");
        Map<String, Object> processConfig = (Map) inProcessor.getProcess().get("process");
        Map<String, Object> config = null;
        if(processConfig!=null) {
        	 config = (Map) processConfig.get("config");
        }
        String sftpHost = (String) config.get(HOST_NAME_SOURCE);
        String sftpUSER = (String) config.get(USER_NAME_SOURCE);
        String sftpPASS = (String) config.get(USER_CREDENTIALS_SOURCE);
        String sftpWorkingDir = (String) config.get(FTP_ROOT_DIR);
        String sftpArchiveDir = (String) config.get(FTP_ARCHIVE_DIR);
        ProcessorMetaData processor = null;
        String fileName = "";
        String processorId = "";
        String processorTransactionId = "";
        List<String> arrProcessorTransactionId = new ArrayList<String>();

        sftpMonitorUtil.exceptionForMissingLoginCredential(sftpHost, sftpUSER, sftpPASS, sftpWorkingDir);

        processor = processorsService.getProcessor(inProcessor.getProcess().get("appIdentifier").toString(), inProcessor.getProcess().get("id").toString());

        processorId = processor.getId();
        correlationIds.put(processor.getId(), processor.getId() + "_" + processor.getConfigSpaceId());
        correlationIds.put(processor.getId() + "_serverName", processor.getId() + "_" + FileUtil.getInstance().getLocalHostName());

        String zipFileRegex = (String) config.get("zipFilePattern");
        
        if (sftpMonitorUtil.hasValidStatus(processor)) {
            Map<String, Object> processSftpResults = null;

            try {
                LOGGER.debug("runSFTPMonitor sftpWorkingDir: {}", sftpWorkingDir);
                processSftpResults = sftpMonitorUtil.proccessSFTPDirectory(sftpUSER, sftpPASS, sftpHost, sftpWorkingDir);

                // for each zip file in remote drop directory
                for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) processSftpResults.get(DIRECTORY_LISTING)) {

                    fileName = entry.getFilename();
                    correlationIds.put(processor.getId() + "_" + fileName, processor.getId() + "_" + fileName);

                    if (entry.getFilename().endsWith(FILE_EXTENSION) && !entry.getFilename().endsWith(ACK_FILE_EXTENSION) &&
                            processorsService.findProcessorMetaDataByFileName(entry.getFilename(), processor.getAppIdentifier()) == null) {
                    	
                    	if (validateZipFileName(fileName, zipFileRegex)) {
                    		processorTransactionId = processFromCurrentDir(processor, processConfig,  processSftpResults, entry.getFilename(), entry.getAttrs().getSize());
                        	
                        	if(!processorTransactionId.isEmpty()) {
                        		arrProcessorTransactionId.add(processorTransactionId);
                        	}
                    	} 
                    }
                }
            } catch (Exception ex) {
                logWithCorrelationId(ex, fileName, processorId, processorTransactionId);


            } finally {
                if (processSftpResults != null) {
                    sftpMonitorUtil.closeSFTPChannel((ChannelSftp) processSftpResults.get(CHANNEL_SFTP),
                            (Session) processSftpResults.get(SFTP_SESSION),
                            (Channel) processSftpResults.get(CHANNEL));
                }

                // update processor lastRun.
                processorsService.setLastRunAndStatus(processor.getId(), MetaDataStatus.IN_PROCESS);
            }

        } else {
            if (processor != null) {
                LOGGER.warn("runSFTPMonitor Processor: {}, ID: {}, is in status of {}.  SFTP process will not move files from the SFTP folder to the working folder.", processor.getName(), processor.getId(), processor.getStatus() );
            }
        }
        
        LOGGER.debug("ScheduledSftpMonitor-->runSFTPMonitor-->EXIT");
        return arrProcessorTransactionId;
    }
    
    public boolean validateZipFileName(String zipFileName, String regex) {
    	return Pattern.matches(regex, zipFileName);
    }

    String processFromCurrentDir(ProcessorMetaData processor, Map processConfig,  Map<String, Object> processSftpResults, String entryFileName, long entryFileSize) throws FSDataException, IOException, SftpException {
        LOGGER.info("ScheduledSftpMonitor-->runSFTPMonitor-->filename=[{}]", entryFileName);
        // Search processorTransaction for existing zip file entry
        Transaction transactionMetaData = processorsService.createTransactionRecord(processor);
        String processorTransactionId = "";
        // Set Create File OutPut Directory
        String dir = sftpMonitorUtil.createFileOutputDirectoryPath(processConfig, processor, entryFileName);
        if (!Paths.get(dir).toFile().exists()) {
        	Path filePath = Utilities.createWorkingDirectory(dir);

            // Downloading the specified file from the remote directory to the specified folder path
            ((ChannelSftp) processSftpResults.get(CHANNEL_SFTP)).get(entryFileName, filePath.toString());
            
            LOGGER.info("ScheduledSftpMonitor downloaded zip file to ingest directory filePath={}, filesInDirectory={}", filePath, Files.list(filePath));

            // Create processorTransaction entry
            processorTransactionId = createProcessorTransaction(processor, entryFileName, filePath.toString(), transactionMetaData.getTransactionId());
            correlationIds.put(processor.getId() + "_" + processorTransactionId, processor.getId() + "_" + processorTransactionId);
            
            LOGGER.info(PROCESSOR_TRANSACTION_CREATED_FOR_FILENAME_AND_TRANSACTION_ID, entryFileName, processorTransactionId);
            return processorTransactionId;

        } else {
            LOGGER.warn("runSFTPMonitor Directory already exists, continuing process {}", dir);
            
            Path ingestPath = Paths.get(dir);
            
            File ingestZipFile = Paths.get(dir + "/" + entryFileName).toFile();
            
            if (ingestZipFile.exists() && ingestZipFile.length() == entryFileSize) {
            	// ingest file exists and file size matches ECG file size, continue processing and create processorTransaction
            	processorTransactionId = createProcessorTransaction(processor, entryFileName, ingestPath.toString(), transactionMetaData.getTransactionId());
                correlationIds.put(processor.getId() + "_" + processorTransactionId, processor.getId() + "_" + processorTransactionId);
                LOGGER.info(PROCESSOR_TRANSACTION_CREATED_FOR_FILENAME_AND_TRANSACTION_ID, entryFileName, processorTransactionId);
                return processorTransactionId;            	
            } else {
            	// ingest file doesn't exist or file size doesn't match, create ingestLock.txt and redownload file from ECG and create processorTransaction
            	
            	// create ingest lock
            	if (checkAndCreateSftpLockFile(ingestPath.toString())) { 
            		// lock file already exists, don't do anything
            		LOGGER.warn("runSftpMonitor lock file already exists, do not continue processing, dir={}", dir);
            		return processorTransactionId;
            	} else {
            		// lock file was created, download zip file from ECG and create processorTransaction
            		
            		if (ingestZipFile.exists()) {
            			// if ingest zip file exists, delete partially downloaded zip file
            			try {
    						ingestZipFile.delete();
    					} catch (Exception e) {
    						LOGGER.error("deleteFile: {}={} {}", "file", ingestZipFile, ExceptionUtils.getStackTrace(e));
    					}
            		}

                    // Downloading the specified file from the remote directory to the specified folder path
                    ((ChannelSftp) processSftpResults.get(CHANNEL_SFTP)).get(entryFileName, ingestPath.toString());
                    LOGGER.info("ScheduledSftpMonitor --> Recreated ingest directory and downloaded zip file | ingest directory filePath={}, filesInDirectory={}", ingestPath, Files.list(ingestPath));

                    // Create processorTransaction entry
                    processorTransactionId = createProcessorTransaction(processor, entryFileName, ingestPath.toString(), transactionMetaData.getTransactionId());
                    correlationIds.put(processor.getId() + "_" + processorTransactionId, processor.getId() + "_" + processorTransactionId);
                    LOGGER.info(PROCESSOR_TRANSACTION_CREATED_FOR_FILENAME_AND_TRANSACTION_ID, entryFileName, processorTransactionId);
                    return processorTransactionId;
            	}
            }
        }
        
        
        // Scenarios
        
        // 1. Happy path: directory does not exist, file is downloaded from ingest and processorTransaction is created
        
        // 2. Processor transaction not created, filepath exists but file is not in ingest
        // 		2. a filepath exists but file is not in ingest
        // 				Remove filePath, download file again and create processorTransaction
        // 				Could cause concurrency issues if processor is triggered a second time while file is downloading
        // 		2. b filepath exists and file is in ingest
        //				Check file size matches and create processorTransaction
    }
    
    boolean checkAndCreateSftpLockFile(String filePath) throws IOException {
    	// return  true if lock file already exists
    	// return false if lock file was created
    	var lockFile = new File(filePath, LOCK_FILE_NAME);
		var lockFileAlreadyExists = lockFile.exists();
		
		if (!lockFileAlreadyExists) {
			lockFileAlreadyExists = !createLockFile(filePath);
		}
		
		return lockFileAlreadyExists;
    }
    
    boolean createLockFile(String destination) throws IOException {
    	var lockFile = new File(destination, LOCK_FILE_NAME);
    	return touch(lockFile);
    }
    
    boolean touch(File file) throws IOException{
        if (!file.exists()) {
        	try(OutputStream is = new BufferedOutputStream(Files.newOutputStream(file.toPath()))){
        		return true;
        	}
        }
        LOGGER.warn("Attempting to create a file which already exists: {}", file.getAbsolutePath());
        return false;
    }
    
    String createProcessorTransaction(ProcessorMetaData processor, String entryFileName, String filePath, String transactionId){
        ProcessorTransaction processorTransaction = processorsService.createProcessorTransaction(processor, entryFileName, filePath, transactionId);
        return processorTransaction.getId();
    }
    
    void archiveZipFile(String sftpWorkingDir, String sftpArchiveDir, String fileName, ChannelSftp channelSftp) throws IOException, SftpException {
    	channelSftp.rename(sftpWorkingDir + "/" + fileName, sftpArchiveDir + "/" + fileName);
    }

    void logWithCorrelationId(Exception ex, String cFileName, String cProcessorId, String cProcessorTransactionId) {
        String processor = Optional.ofNullable(correlationIds).map(o -> o.get(cProcessorId)).orElse("");
        String serverName =  Optional.ofNullable(correlationIds).map(o -> o.get(cProcessorId + "_serverName")).orElse("");
        String fileName = Optional.ofNullable(correlationIds).map(o -> o.get(cProcessorId + "_" + cFileName)).orElse("");
        String processorTransaction = Optional.ofNullable(correlationIds).map(o -> o.get(cProcessorId + "_" + cProcessorTransactionId)).orElse("");
        LOGGER.error ("runSFTPMonitor Exception processor={}, ServerName={}, fileName={}, ProcessorTransaction={}, {}:{}",Encode.forJava(processor),
                Encode.forJava(serverName), Encode.forJava(fileName), Encode.forJava(processorTransaction), ex.getClass().getSimpleName(), ex.getMessage());
        if (ex.getMessage() != null && ! ex.getMessage().contains("No such file")) {
            correlationIds.put(cProcessorId + "_exceptionMessage", cProcessorId + "_" + ExceptionUtils.getStackTrace(ex));
            LOGGER.error("runSFTPMonitor Stack {} ",
                    Encode.forJava(Optional.ofNullable(correlationIds).map(o -> o.get(cProcessorId + "_exceptionMessage")).orElse("")));
        }
    }
}
