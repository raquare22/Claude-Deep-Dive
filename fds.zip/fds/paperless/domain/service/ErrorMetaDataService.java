package com.optum.fds.paperless.domain.service;

import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.springframework.data.mongodb.core.query.Criteria;
import com.optum.fds.paperless.exception.ErrorCode;
import com.optum.fds.paperless.exception.ValidationException;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;

public interface ErrorMetaDataService {
	
	ErrorMetaData saveErrorMetaData(ErrorMetaData metadata);

	ErrorMetaData getErrorMetaData(String id);

	ErrorMetaData getErrorMetaDataByTargetId(String targetId);

	List<ErrorMetaData> getErrorListById(String id);

	List<ErrorMetaData> getErrorListByIdentifier(String identifier);

	ErrorMetaData updateErrorMetaDataStatus(String id, String status);

	ErrorMetaData updateErrorMetaData(ErrorMetaData errorMetaData);

	ErrorMetaData putErrorMetadata(ErrorMetaData metadata);

	List<ErrorMetaData> getErrorMetaData(String searchCriteriaJson, Criteria criteriaFilter) throws ValidationException;

	ErrorMetaData updateErrorMetadataFields(Map<String, Object> fieldsToUpdate, String errorId);
	
	ErrorMetaData writeToErrorCollection(String identifier, String targetId, String targetType, ErrorCode errorCode, Document metadata);
	
	ErrorMetaData writeToErrorCollection(DelegateExecution execution, String exception);

	ErrorMetaData writeToMessageServiceErrorCollection(String queue, String identifier, String targetId, Integer spaceId, Map<String, Object> variables, String errorMsg, MetaDataStatus status);
	ErrorMetaData writeToMessageServiceErrorCollection(String queue, String identifier, String targetId, Integer spaceId, String errorMsg,
			String jsonStr, MetaDataStatus status);
}
