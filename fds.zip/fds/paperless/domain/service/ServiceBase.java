package com.optum.fds.paperless.domain.service;

import java.io.IOException;
import java.net.URI;
import java.util.*;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.*;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.util.Parser;

@Service("ServiceBase")
public class ServiceBase {
	protected Integer numRetries = 2;
	protected Long timeToWaitMS = 50L;
	public static final String HEADER_ACCEPT = "Accept";

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceBase.class);
	
	private ArrayList<HttpStatus> validStatus = new ArrayList<>(Arrays.asList(HttpStatus.OK, HttpStatus.CREATED));

	@Autowired
	private HttpHeaders headers;

	@Autowired
	private RestTemplate restTemplate;


	public boolean postFDSRequest(String elgsPostUrl, Map<String, String> params)  {
	    HttpHeaders requestHeaders = new HttpHeaders();
		HttpEntity<?> requestEntity = new HttpEntity<>(requestHeaders);
		LOGGER.info("Sending request to FDS: fdsPostUrl={}, params={}", elgsPostUrl, params);
		ResponseEntity<String> responseEntity = null;

		URI uri;
		if (params == null || params.isEmpty()) {
			uri = UriComponentsBuilder.fromUriString(elgsPostUrl).build().toUri();
		} else {
			uri = UriComponentsBuilder.fromUriString(elgsPostUrl).buildAndExpand(params).toUri();
		}

		LOGGER.info("Sending POST request to FDS; uri={}, requestEntity={}", uri, requestEntity);
		try {
			responseEntity = postExchange(uri, requestEntity);
			LOGGER.info("StatusCode={}", responseEntity.getStatusCode());
			return HttpStatus.OK.equals(responseEntity.getStatusCode());
		}
		catch (Exception e) {
			LOGGER.error("Error during service call: uri={}, requestEntity={}, error={}", uri, requestEntity, ExceptionUtils.getStackTrace(e));
			return false;
		}
	}
	
	public List<String> getFDSRequest(String fdsGetUrl, Map<String, String> params)  {
		HttpHeaders requestHeaders = new HttpHeaders();
		HttpEntity<?> requestEntity = new HttpEntity<>(requestHeaders);
		ResponseEntity<String[]> responseEntity = null;
		
		URI uri;
		if ( params == null || params.isEmpty()) {
			uri = UriComponentsBuilder.fromUriString(fdsGetUrl).build().toUri();
		} else {
			uri = UriComponentsBuilder.fromUriString(fdsGetUrl).buildAndExpand(params).toUri();
		}

		LOGGER.info("Sending GET request to FDS; uri={}, requestEntity={}", uri, requestEntity);
		try {
			responseEntity = getExchange(uri, requestEntity);

			if (responseEntity == null) {
				LOGGER.warn("Get task returned null: fdsGetUrl={}, requestBody={}", fdsGetUrl, requestEntity.getBody());
				return new ArrayList<>();
			}

			if (HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				LOGGER.info("Get task successful: responseCode={}", Encode.forJava(responseEntity.getStatusCode().toString()));
				return Arrays.asList(responseEntity.getBody());
			}
			int retryCount = numRetries;
			while ((!(HttpStatus.OK.equals(responseEntity.getStatusCode()))) && (retryCount-- > 0)) {
				try {
					synchronized(this) {
						this.wait(timeToWaitMS);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = getExchange(uri, requestEntity);
				LOGGER.warn("Get task retry: requestBody={}, retryCount={}", requestEntity.getBody(), retryCount);
			}
			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				LOGGER.error("Get task failed with error code={}, requestBody={}", getStatusCode(responseEntity), requestEntity.getBody());
				return new ArrayList<>();
			}

			return Arrays.asList(responseEntity.getBody());
		}
		catch (Exception e) {
			LOGGER.error("Error during service call: uri={}, requestEntity={}, error={}", uri, requestEntity, ExceptionUtils.getStackTrace(e));
			return Collections.emptyList();
		}
	}

	protected ResponseEntity<String[]> getExchange(URI uri, HttpEntity<?> requestEntity){
		LOGGER.info("uri={}, requestEntity={}", uri, requestEntity);
		return restTemplate.exchange(uri, HttpMethod.GET, requestEntity, String[].class);
	}

	protected ResponseEntity<String> postExchange(URI uri, HttpEntity<?> requestEntity){
		LOGGER.info("uri={}, requestEntity={}", uri, requestEntity);
		return restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class);
	}
	
	protected ResponseEntity<GenericResponse> postExchangeGenericResponse(URI uri, HttpEntity<?> requestEntity){
		LOGGER.info("uri={}, requestEntity={}", uri, requestEntity);
		return restTemplate.exchange(uri, HttpMethod.POST, requestEntity, GenericResponse.class);
	}

	protected String getStatusCode(ResponseEntity<String[]> responseEntity) {
		return responseEntity != null ? responseEntity.getStatusCode().toString() : "NULL";
	}

	public ResponseEntity<GenericResponse> postRequestToSvcMultipartForm(String apiUrl, MultiValueMap<String, Object> requestMap, String pathVariable) {
		LOGGER.info("postRequestToSvcMultipartForm -- Posting document request to service layer, apiUrl={}, requestMap={}, pathVariable={}", apiUrl, requestMap, pathVariable);
		if (pathVariable != null) {
			if (! apiUrl.endsWith("/")) {
				apiUrl = apiUrl + "/";
			}
			apiUrl = apiUrl.concat(pathVariable);
			LOGGER.debug("apiUrl={}", apiUrl);
		}
		
		headers.set(HEADER_ACCEPT, "*/*");
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(requestMap, headers);

		LOGGER.info("FDSrequest={}", request);
		
		URI uri = UriComponentsBuilder.fromUriString(apiUrl).build().encode().toUri();	
		ResponseEntity<GenericResponse> responseEntity = null;
		
		try {
			responseEntity = postExchangeGenericResponse(uri, request);
			if (responseEntity == null) {
				LOGGER.warn("Post task returned null: apiUrl={}, requestBody={}", apiUrl, request.getBody());
				return new ResponseEntity<>(new GenericResponse("102", "Error during service call", "responseEntity == null"), HttpStatus.PROCESSING);
			}

			if (validStatus.contains(responseEntity.getStatusCode())) {
				LOGGER.info("Post task successful: requestBody={}", request.getBody());
				return responseEntity;
			}
			int retryCount = numRetries;
			while ((! (validStatus.contains(responseEntity.getStatusCode()))) && (retryCount --> 0)) {
				try {
					synchronized(this) {
						this.wait(timeToWaitMS);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = postExchangeGenericResponse(uri, request);
				LOGGER.warn("Post task retry: requestBody={}, retryCount={}", request.getBody(), retryCount);
			}
			if (responseEntity.getStatusCode() != HttpStatus.OK || responseEntity.getStatusCode() != HttpStatus.CREATED) {
				LOGGER.error("Post task failed with error code={}: requestBody={}", responseEntity.getStatusCode(), request.getBody());
				return responseEntity;
			}
		} catch (Exception e) {
			LOGGER.error("postExchange failed: apiUrl={}, postRequest={}; {}", apiUrl, requestMap, e.getMessage());
			return new ResponseEntity<>(new GenericResponse("400", "Error during service call", e.getMessage()), HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}

	public ResponseEntity<GenericResponse> postRequestToSvc(String apiUrl, String postRequest, String pathVariable) {
		LOGGER.info("apiUrl={}, fdsRequest={}", apiUrl, postRequest);
		apiUrl = getExpandedUrl(apiUrl, pathVariable);

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set(HEADER_ACCEPT, "*/*");
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);

		URI uri = UriComponentsBuilder.fromUriString(apiUrl).build().encode().toUri();
		HttpEntity<String> request = new HttpEntity<>(postRequest, requestHeaders);

		ResponseEntity<GenericResponse> responseEntity = null;
		try {
			responseEntity = postExchangeGenericResponse(uri, request);
			if (responseEntity == null) {
				LOGGER.warn("Post task returned null: apiUrl={}, requestBody={}", apiUrl, request.getBody());
				return new ResponseEntity<>(new GenericResponse("102", "Error during service call", "responseEntity == null"), HttpStatus.PROCESSING);
			}

			if (validStatus.contains(responseEntity.getStatusCode())) {
				LOGGER.info("Post task successful: requestBody={}", request.getBody());
				return responseEntity;
			}
			int retryCount = numRetries;
			while ((! (validStatus.contains(responseEntity.getStatusCode()))) && (retryCount-- > 0)) {
				try {
					synchronized(this) {
						this.wait(timeToWaitMS);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = postExchangeGenericResponse(uri, request);
				LOGGER.warn("Post task retry: requestBody={}, retryCount={}", request.getBody(), retryCount);
			}
			if (responseEntity.getStatusCode() != HttpStatus.OK && responseEntity.getStatusCode() != HttpStatus.CREATED) {
				LOGGER.error("Post task failed with error code={}: requestBody={}", responseEntity.getStatusCode(), request.getBody());
			}
			return responseEntity;
		} catch (Exception e) {
			LOGGER.error("postExchange failed: apiUrl={}, postRequest={}; {}", apiUrl, postRequest, e.getMessage());
			if (e.getMessage().contains(HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase()) || e.getMessage().contains("Connection refused")) {
				return new ResponseEntity<>(GenericResponse.from("503", HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase(), ": " + e.getMessage()), HttpStatus.SERVICE_UNAVAILABLE);
			}
			if (e.getMessage().contains(HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase())) {
				return new ResponseEntity<>(GenericResponse.from("504", HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase(), ": " + e.getMessage()), HttpStatus.GATEWAY_TIMEOUT);
			}
			return new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ": " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	protected String getExpandedUrl(String apiUrl, String pathVariable) {
		if (pathVariable != null) {
			if (! apiUrl.endsWith("/")) {
				apiUrl = apiUrl + "/";
			}
			apiUrl = apiUrl.concat(pathVariable);
			LOGGER.info("apiUrl={}", apiUrl);
		}
		return apiUrl;
	}


}
