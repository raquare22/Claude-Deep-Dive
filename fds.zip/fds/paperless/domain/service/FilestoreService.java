package com.optum.fds.paperless.domain.service;

public interface FilestoreService {
	
	public boolean insertFile(String location, String fileName);
	
	public byte[] downloadFile(String bucketName, String fileName);
	
	public boolean deleteFile(String bucketName, String fileName);

}
