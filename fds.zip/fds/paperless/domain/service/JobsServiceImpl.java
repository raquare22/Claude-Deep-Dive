package com.optum.fds.paperless.domain.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;


import com.optum.fds.paperless.FDSPaperlessMain;
import com.optum.fds.paperless.constants.CommonConstants;

public class JobsServiceImpl implements JobsService {

	@Override
	public List<String> getJobs(String token, String limit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getJobsRESTApi(String token, String limit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String runJob(String token, String jobId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String createCleanupJob(String token) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String resolveInProcessJobs(String token) {
		// TODO Auto-generated method stub
		return null;
	}


}
