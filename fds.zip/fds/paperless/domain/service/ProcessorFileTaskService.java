package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;

import java.util.List;
import java.util.Map;

public interface ProcessorFileTaskService {

    ProcessorFileTask getProcessorFileTaskById(String processorFileTaskId, String appIdentifier);

    ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorFileTask, Map<String, Object> resultMap, ProcessorCoreJob job);

    ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorFileTask, Map<String, Object> resultMap, RestApiJob job);

    ProcessorFileTask updateProcessorFileTask(ProcessorFileTask processorFileTask);

    ProcessorFileTask getProcessorFileTask(String id, String appIdentifier, String serverType);

    ProcessorFileTask getProcessorFileTaskForTargetId(String targetId, String targetType, String appIdentifier);

    ProcessorFileTask saveProcessorFileTask(ProcessorFileTask processorFileTask);

    List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId, String serverType);

    List<ProcessorFileTask> getProcessorFileTasksForTransactionIdByStatus(String transactionId, String status);

    List<ProcessorFileTask> getLastProcessorFileTaskForTransactionId(String transactionId, String serverType);

    List<ProcessorFileTask> getPendingProcessorFileTaskForTransactionId(String transactionId, String serverType, String status, int processorTransactionPendingTime);


    boolean areAllProcessorFileTasksCompletedForTransactionId(String transactionId);

    ProcessorFileTask updateProcessorFileTask(String id, String appId, String key, String value);

}
