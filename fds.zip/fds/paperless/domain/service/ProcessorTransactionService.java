package com.optum.fds.paperless.domain.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.query.Criteria;

import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;


public interface ProcessorTransactionService {
	
    public ProcessorTransactionMetadata updateProcessorTransactionMetaData(ProcessorTransactionMetadata processorTransactionMetadata);
    
    public ProcessorTransactionMetadata saveProcessorTransactionMetaData(ProcessorTransactionMetadata processorTransactionMetadata);

    public ProcessorTransactionMetadata findProcessorTransactionMetadataByClientCompanionFileName(String fileName, String serverType);

	public ProcessorTransactionMetadata updateProcessorExecutionRecordOfProcessorTransactionRecord(
			ProcessorTransactionMetadata processorTransactionMetadata, Map<String, Object> resultMap,
			ProcessorCoreJob job);
	
    public List<ProcessorTransactionMetadata> getProcessorTransactionMetaData(String searchCriteriaJson,Criteria filter) throws InvalidExpressionException;

	public ProcessorTransaction findProcessorTransactionByFileName(String zipFileName, Integer configSpaceId);

	public List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId, String serverType);
	
	public ProcessorTransaction getProcessTransactionInfoByTransactionId(String transactionId);

}
