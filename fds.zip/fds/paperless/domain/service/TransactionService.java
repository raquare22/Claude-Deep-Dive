/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When         Who                   Revision
 * SPT 20 2013  Sai Nagesh		    Initial version
 ****************************************************************/
////package com.optum.fs.domain.service;
package com.optum.fds.paperless.domain.service;

import java.util.List;

import com.optum.fds.paperless.mongo.ActionMetaData;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.FileMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.TransactionAttachmentInfo;
import com.optum.fds.paperless.mongo.TransactionDocumentListInfo;
import com.optum.fds.paperless.mongo.TransactionHookListInfo;
import com.optum.fds.paperless.mongo.TransactionListAttachmentsInfo;
import com.optum.fds.paperless.mongo.TransactionReportListInfo;
import com.optum.fds.paperless.mongo.VirusscanResult;

////import com.optum.fs.mongo.ActionMetaData;
////import com.optum.fs.mongo.AttachmentMetaData;
////import com.optum.fs.mongo.FileMetaData;
////import com.optum.fs.mongo.Transaction;
////import com.optum.fs.mongo.TransactionAttachmentInfo;
////import com.optum.fs.mongo.TransactionDocumentListInfo;
////import com.optum.fs.mongo.TransactionHookInfo;
////import com.optum.fs.mongo.TransactionHookListInfo;
////import com.optum.fs.mongo.TransactionListAttachmentsInfo;
////import com.optum.fs.mongo.TransactionReportListInfo;
////import com.optum.fs.mongo.VirusscanResult;


public interface TransactionService {
	/**
	 * Persist file metadata for transaction in mongo
	 * @param metadata
	 * @param totalSize 
	 * @return number of records persisted
	 */
	public void saveFileMetaData(String transactionId, List<FileMetaData> metadata, long totalSize);
	
	/**
	 * Record action performed on a transaction
	 * @param metadata
	 * @param virusScanResults 
	 * @return
	 */
	public void saveActionMetaData(String transactionId, ActionMetaData metadata, List<VirusscanResult> virusScanResults);
	
	/**
	 * Returns an existing mongo transactionMetaData or create a new one if it
	 * doesn't exist
	 * 
	 * @param transactionId
	 * @return
	 */
	public Transaction getTransactionMetaData(String transactionId);

	/**
	 * Persist transaction metadata. Always pass a new transactionMetaData object.
	 *
	 * @param transactionMetaData
	 * @return
	 */
	public Transaction insertTransactionMetaData(Transaction transactionMetaData);
	
	/**
	 * Persist transaction metadata. Always pass an updated transactionMetaData
	 * object gotten from a call to getTransactionMetaData
	 * 
	 * @param transactionMetaData
	 * @return
	 */
	public Transaction saveTransactionMetaData(Transaction transactionMetaData);
	
	/**
	 * Removes transactionMetaData from mongo db
	 * @param transactionId
	 */
	public void deleteTransactionMetaData(String transactionId);
	
	/**
	 * @param transactionId
	 * @param attInfos
	 */
	public Transaction saveTransationMetaData(String transactionId, 
			List<TransactionAttachmentInfo> attInfos);
	
	/**
	 * 
	 * @param transactionId
	 * @param amd
	 * @param attInfos
	 * @return
	 */
	public Transaction saveTransationMetaData(String transactionId,  List<TransactionAttachmentInfo> attInfos, List<AttachmentMetaData> amdList, boolean updateSpaceId);
	
	/**
	 * 
	 * @param transactionId
	 * @param listAttsInfo
	 * @param totalFileSize
	 * @param clientId
	 * @param spaceId
	 * @return
	 */
	public Transaction saveTransationMetaData(String transactionId,  TransactionListAttachmentsInfo txListAttInfos,  int clientId, String spaceId);

	public Transaction saveTransationMetaData(String transactionId,  int spaceId, int clientId, TransactionDocumentListInfo trnsctnDocInfo);
	
	public Transaction saveTransationMetaData(String transactionId,  int spaceId, int clientId, TransactionHookListInfo trnsctnDocInfo);

	public Transaction saveTransationMetaData(String transactionId,  int spaceId, int clientId, TransactionReportListInfo trnsctnDocInfo);

	
	//public Transaction saveTransationMetaData(String transactionId,
	//		TransactionListAttachmentsInfo txListAttInfos);
}
