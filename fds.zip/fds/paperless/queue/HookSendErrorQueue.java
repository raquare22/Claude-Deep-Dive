package com.optum.fds.paperless.queue;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.optum.fds.paperless.ConfigData;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HookSendErrorQueue  extends SendQueue {
	private final List<ObjectNode> retryList = new ArrayList<>();

	public HookSendErrorQueue(String path, String name) throws IOException {
		super(path, name);
	}

	protected List<ObjectNode> getRetryList() { return retryList; }
}
