package com.optum.fds.paperless.queue;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.constants.CommonConstants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

public class MetadataSendQueue extends SendQueue{
	
	@Value("${MetadataSendQueueAutoError}")
	private Boolean metadataSendQueueAutoError;
	private final List<ObjectNode> retryList = new ArrayList<>();

	public MetadataSendQueue(String path, String name) throws IOException {
		super(path, name);
	}

	protected List<ObjectNode> getRetryList() { return retryList; }

	@Override
	protected boolean addToErrorQueue(String request) {
		//return ConfigData.getOrDefaultBooleanWithActiveProfile(CommonConstants.METADATA_SEND_QUEUE_AUTO_ERROR);
		return metadataSendQueueAutoError;
	}
}
