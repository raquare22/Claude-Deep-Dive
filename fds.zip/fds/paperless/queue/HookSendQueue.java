package com.optum.fds.paperless.queue;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.constants.CommonConstants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

public class HookSendQueue extends SendQueue{
	
	@Value("${HookSendQueueAutoError}")
	private Boolean hookSendQueueAutoError;
	
	
	private final List<ObjectNode> retryList = new ArrayList<>();

	public HookSendQueue(String path, String name) throws IOException {
		super(path, name);
	}

	protected List<ObjectNode> getRetryList() { return retryList; }

	@Override
	protected boolean addToErrorQueue(String request) {
		//return ConfigData.getOrDefaultBooleanWithActiveProfile(CommonConstants.HOOK_SEND_QUEUE_AUTO_ERROR);
		return hookSendQueueAutoError;
	}
}
