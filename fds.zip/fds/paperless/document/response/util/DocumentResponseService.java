package com.optum.fds.paperless.document.response.util;

import com.optum.fds.paperless.document.util.Attachment;
import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Parser;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.ws.rs.core.Response;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class DocumentResponseService {


    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentResponseService.class);

    public DocumentResponse prepareFullDocumentResponse(DocumentMetaData documentMetaData, List<AttachmentMetaData> attmtsMetaDataList) {
        LOGGER.debug("Entering prepareFullDocumentResponse");

        DocumentResponse response = new DocumentResponse();

        if (attmtsMetaDataList != null && !attmtsMetaDataList.isEmpty()) {
        	    List<Attachment> attachmentResponseList = prepareAttachmentResponse(attmtsMetaDataList);
            response.setAttachments((attachmentResponseList.toArray(new Attachment[attachmentResponseList.size()])));
        }
                       
        response.setSpaceId(Integer.valueOf(documentMetaData.getSpaceId()));
        if(documentMetaData.getStatus() != null) {
            response.setStatus(documentMetaData.getStatus().toString());
        }
        response.setId(documentMetaData.getId());
        response.setExternalId(documentMetaData.getExternalId());
        if (documentMetaData.getMetadata() != null) {
        	Document metadataBasicObj = documentMetaData.getMetadata();
            response.setMetadata(metadataBasicObj);
        }
        if (documentMetaData.getDateCreated() != null)
            response.setDateCreated(documentMetaData.getDateCreated().toString());
        if (documentMetaData.getRevisions() != null)
            response.setRevisions(documentMetaData.getRevisions());

        LOGGER.debug("Leaving prepareFullDocumentResponse");
        return response;
    }

    public static void  logInfoWithTransactionId(Logger logger, String info, String transactionId){
        StringBuilder sb = new StringBuilder();
        sb.append(info).append(" for transaction_id:").append(transactionId);
        String transIdStr = sb.toString();
        logger.debug("for transaction_id: {}", transIdStr);
    }

    public String buildDocumentResponseInJson(DocumentMetaData documentMetaData, List<AttachmentMetaData> attmtsMetaDataList) throws IOException, ParseException {

        String transactionId = documentMetaData.getTransactionId();
        logInfoWithTransactionId(LOGGER, "Entered DocumentUtilService.buildDocumentResponseInJson", transactionId);

        DocumentResponse response = prepareFullDocumentResponse(documentMetaData, attmtsMetaDataList);

        logInfoWithTransactionId(LOGGER, "Exited DocumentUtilService.buildDocumentResponseInJson", transactionId);

        String result = Parser.toJson(response, "yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        Response.ResponseBuilder respBldr = Response.ok(result);
        String test = (String) respBldr.build().getEntity();
        System.out.println(test);
        return test;
    }

    public List<Attachment> prepareAttachmentResponse(List<AttachmentMetaData> amds) {
        LOGGER.debug("Entering prepareAttachmentResponse");
        List<Attachment> attachments = new ArrayList<>();
        int counter = 0;
        for (AttachmentMetaData amd : amds) {
            counter++;
            Attachment atmt = createAttachment(amd);
            atmt.setIndex(counter);
            attachments.add(atmt);
        }
        LOGGER.debug("Attachments Size {}", attachments.size());
        LOGGER.debug("Leaving prepareAttachmentResponse");
        return attachments;
    }

    private Attachment createAttachment(AttachmentMetaData amd) {
        LOGGER.debug("Entering createAttachment");
        Attachment atmt = new Attachment();
        atmt.setExpires(amd.getExpires());
        atmt.setFileName(amd.getFileName());
        atmt.setFileSize(amd.getFileSize());
        atmt.setId(amd.getFsId());
        atmt.setStatus(amd.getStatus().toString());
        atmt.setSpaceId(amd.getSpaceId());
        atmt.setContentType(amd.getContentType());
        atmt.setDateCreated(amd.getDateCreated());
        atmt.setExternalId(amd.getExternalId());
        LOGGER.debug("Leaving createAttachment with Id: {}", atmt.getId());
        return atmt;
    }

}
