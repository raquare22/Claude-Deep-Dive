/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who              Revision
 * Jan 26 2015  Kwasi Boateng 		Initial version
 ****************************************************************/
package com.optum.fds.paperless.document.util;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement(name = "rules")
public class Rules implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("convert_to")
    private String convertTo;

    @JsonProperty("virus_scan")
    private String virusScan;

    @JsonProperty("encrypt_scheme")
    private String encryptScheme;

    @JsonProperty("custom_rule")
    private String customRule;

    public String getCustomRule() {
        return customRule;
    }

    public void setCustomRule(String customRule) {
        this.customRule = customRule;
    }

    public String getEncryptScheme() {
        return encryptScheme;
    }

    public void setEncryptScheme(String encryptScheme) {
        this.encryptScheme = encryptScheme;
    }

    public String getVirusScan() {
        return virusScan;
    }

    public void setVirusScan(String virusScan) {
        this.virusScan = virusScan;
    }

    public String getConvertTo() {
        return convertTo;
    }

    public void setConvertTo(String convertTo) {
        this.convertTo = convertTo;
    }

}
