package com.optum.fds.paperless.model;

import java.util.List;
import java.util.Map;

public class PENRealTimeTemplateResponse {
    private String statusCode;
    
    private String statusMessage;
    
    private String responseMessage;
    

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	@Override
	public String toString() {
		return "PENRealTimeTemplateResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage
				+ ", responseMessage=" + responseMessage + "]";
	}

	

}
