package com.optum.fds.paperless.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Org {

	public String id;
    public String corpMpin;
    public String uhcProviderId;
	public String tin;
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCorpMpin() {
		return corpMpin;
	}
	public void setCorpMpin(String corpMpin) {
		this.corpMpin = corpMpin;
	}
	public String getUhcProviderId() {
		return uhcProviderId;
	}
	public void setUhcProviderId(String uhcProviderId) {
		this.uhcProviderId = uhcProviderId;
	}
	@Override
	public String toString() {
		return "Org{" +
				"id='" + id + '\'' +
				", corpMpin='" + corpMpin + '\'' +
				", uhcProviderId='" + uhcProviderId + '\'' +
				", tin='" + tin + '\'' +
				'}';
	}
	
}
