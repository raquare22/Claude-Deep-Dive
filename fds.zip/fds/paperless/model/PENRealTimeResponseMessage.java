package com.optum.fds.paperless.model;

import java.util.List;
import java.util.Map;

public class PENRealTimeResponseMessage {
    private String documentId;
    
    private String appId;
    
    private String category;
    
    private String frequency;
    
    private boolean emailSent;
    
    private List<String> providerEmailIdList;
    
    private Map<String, String> messageIdList;

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public boolean isEmailSent() {
		return emailSent;
	}

	public void setEmailSent(boolean emailSent) {
		this.emailSent = emailSent;
	}

	public List<String> getProviderEmailIdList() {
		return providerEmailIdList;
	}

	public void setProviderEmailIdList(List<String> providerEmailIdList) {
		this.providerEmailIdList = providerEmailIdList;
	}

	public Map<String, String> getMessageIdList() {
		return messageIdList;
	}

	public void setMessageIdList(Map<String, String> messageIdList) {
		this.messageIdList = messageIdList;
	}

	@Override
	public String toString() {
		return "PENRealTimeResponseMessage [documentId=" + documentId + ", appId=" + appId + ", category=" + category
				+ ", frequency=" + frequency + ", emailSent=" + emailSent + ", providerEmailIdList="
				+ providerEmailIdList + ", messageIdList=" + messageIdList + "]";
	}

    

}
