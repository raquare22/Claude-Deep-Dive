package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import com.optum.fds.paperless.util.ProcessorTaskUtil;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.service.EmailService;

@Service("TransformJsonAndGenerateFile")
public class TransformJsonAndGenerateFile extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransformJsonAndGenerateFile.class);

    private static final String FDS_COSMOSPRA = "PRA_COSMOS_FDS";

    private static final String FILE_EXTENSION = ".txt";

    private static final String DELEGATE_EXECUTION_ID= "delegateExecutionId";

    private static final String DATE_EMAIL_SENT = "dateEmailSent";

    @Autowired
    ProcessorFileTaskService processorFileTaskService;

    @Autowired
    ProcessorsService processorsService;

    @Autowired
    EmailService emailService;

    private static final String DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final String METADATA_PREFIX = "metadata.";

    private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.TEMPLATE_NAME, Workflow.OUTPUT_FILE_DIR, Workflow.JSON_FILE
    );

    public TransformJsonAndGenerateFile() {
        super(REQ_VARS);
    }

    //this function is made to reduce the complexity for the doExceute function below

	public void processDocumentMetadata(DelegateExecution execution, List<DocumentMetaData> documentList,
			List<String> documentIdsList) {
		for (DocumentMetaData document : documentList) {
			try {
				if (document.getMetadata().containsKey(DATE_EMAIL_SENT)) {
					boolean isLong = isDataFieldLong(document.getMetadata().get(DATE_EMAIL_SENT));
					boolean isDouble = isDataFieldDouble(document.getMetadata().get(DATE_EMAIL_SENT));
					if (isLong) {
						Long longDate = Long.parseLong(document.getMetadata().get(DATE_EMAIL_SENT).toString());
						document.getMetadata().append(DATE_EMAIL_SENT, dateCasting(longDate));
					} else if (isDouble) {
						Double epochDate = Double.parseDouble(document.getMetadata().get(DATE_EMAIL_SENT).toString());
						var longDate = epochDate.longValue();
						document.getMetadata().append(DATE_EMAIL_SENT, dateCasting(longDate));
					}
				}
				Boolean addOriginalZipFileName = execution.getVariable("addOriginalZipFileName", Boolean.class);
				if (addOriginalZipFileName != null && addOriginalZipFileName) {
					LOGGER.info("doExecute --> adding originalZipFileName to document metadata");
					String originalZipFileName = ProcessorTaskUtil.getFileName(document.getId(),
							document.getAppIdentifier(), processorFileTaskService, processorsService);
					document.getMetadata().put("originalZipFileName", originalZipFileName);
				}
				documentIdsList.add(document.getId());
			} catch (Exception e) {
				LOGGER.error("Error for adding originalZipFileName to document metadata {} {}", document.getId(),
						ExceptionUtils.getStackTrace(e));
			}
		}
	}

    //new method created to resolve nested try blocks in doExecute
    private String responseStringAssignment(String responseString, DelegateExecution execution, String jsonString, String templateName ) {
        try {
            responseString = TemplateFactory.getInstance(templateName).convertWithTemplate(jsonString);
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing TransformJsonAndGenerateFile task {}={} {}",
                    DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("TransformJsonAndGenerateFile-->doExecute-->Exception while executing TransformJsonFileWithTemplate task", WorkFlowUtil.getStackTrace(e));
        }
        return responseString;
    }

    @Override
    public void doExecute(DelegateExecution execution) {
        LOGGER.debug("TransformJsonAndGenerateFile-->doExecute-->ENTER");
        try {
            String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);
            String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
            String jsonString = null;
            List<DocumentMetaData> documentList = null;
            try {
                documentList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
            } catch (IOException e) {
                LOGGER.error("doExecute Unable to get DocumentMetadata {}={}, {}={} {}",
                        DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
                        "jsonFile", jsonFile,
                        ExceptionUtils.getStackTrace(e));
                addErrorMsg("TransformJsonAndGenerateFile-->doExecute-->Unable to get DocumentMetadata", WorkFlowUtil.getStackTrace(e));
                return;
            }
            
            List<String> documentUpdateList = new ArrayList<>();

            try {
                //code removed for continuation from here to doExceuteContinued
                processDocumentMetadata(execution, documentList, documentUpdateList);

                Map<String, Object> documentListJson = new HashMap<>();
                documentListJson.put(Workflow.DOCUMENTS, documentList);
                jsonString = Parser.toJson(documentListJson, false, "EEE MMM dd HH:mm:ss zzz yyyy");
            }
            catch(Exception e) {
                LOGGER.error("doExecute Unable to process JSON File {}={}, {}={} {}",
                        DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
                        "jsonFile", jsonFile,
                        ExceptionUtils.getStackTrace(e));
                addErrorMsg("TransformJsonAndGenerateFile-->doExecute-->Unable to process JSON File", WorkFlowUtil.getStackTrace(e));
                return;
            }

            String responseString = null;
            responseString = responseStringAssignment(responseString, execution, jsonString, templateName );

            String tempWorkingPath = execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class);

            String sftpFileName = execution.getVariable(Workflow.SFTP_FILENAME, String.class);

            String fileFormat = execution.getVariable(Workflow.FILE_FORMAT, String.class);

            String filePath = getFilePath(tempWorkingPath, sftpFileName, fileFormat);

            var responseFile = WorkFlowUtil.generateFileFromString(responseString, filePath);

            ArrayList<String> responseFileList = new ArrayList<>();
            responseFileList.add(responseFile.getAbsolutePath());
            execution.setTransientVariable(Workflow.SFTP_FILE_LIST, responseFileList);
            execution.setTransientVariable(Workflow.RESPONSE_FILE_NAME_MESSAGE, responseFile.getName());
            
            
            Map<String, Object> successUpdateMap = generateSuccessUpdateMap(execution);
            execution.setTransientVariable("successDocumentList", documentUpdateList);
            execution.setTransientVariable("successUpdateMap", successUpdateMap);
            execution.setTransientVariable("responseFileName", responseFile.getName());

        } catch(Exception e) {
            LOGGER.error("doExecute Unable to convert JSON File to response {}={} {}",
                    DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),

                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("TransformJsonFileWithTemplate-->doExecute-->Unable to convert JSON File to response", WorkFlowUtil.getStackTrace(e));
        }finally {
            if (newErrors() && errorMap.size() > 1) {
                DelegateUtils.sendErrorNotification(execution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
            }
        }
        LOGGER.debug("TransformJsonFileWithTemplate-->doExecute-->EXIT");

    }


    public boolean isDataFieldLong(Object dataField) {
        return dataField instanceof Long;
    }

    public boolean isDataFieldDouble(Object dataField) {
        return dataField instanceof Double;
    }

    public String dateCasting(Long longDate) {
        var date = new Date(longDate);
        var dateFormat = new SimpleDateFormat(DATE_FORMATTER);
        return dateFormat.format(date);
    }

    private String getFilePath(String tempWorkingPath, String sftpFileName,String format) {
        var now = new Date();
        var dateFormat = new SimpleDateFormat("yyyyMMdd");
        var timeFormat = new SimpleDateFormat("HHmmss");

        if (FDS_COSMOSPRA.equalsIgnoreCase(sftpFileName)) {
            return tempWorkingPath + File.separator + sftpFileName + "_" + getSecureRandomNumber() + "_"
                    + dateFormat.format(now) + "_" + timeFormat.format(now) + FILE_EXTENSION;
        } else if ("csv".equalsIgnoreCase(format)) {
            return tempWorkingPath + File.separator + sftpFileName + "_" + dateFormat.format(now) +
                    timeFormat.format(now) + ".csv";
        }else if ("json".equalsIgnoreCase(format)) {
                return tempWorkingPath + File.separator + sftpFileName + "_" + dateFormat.format(now) +
                        timeFormat.format(now) + ".json";
        } else {
            return tempWorkingPath + File.separator + sftpFileName + "_" + dateFormat.format(now) + "_"
                    + timeFormat.format(now) + FILE_EXTENSION;
        }
    }

    private String getSecureRandomNumber() {
        var random = new SecureRandom();
        return String.format("%08d", random.nextInt(1000000));
    }

    private String getDelegateExecutionId(DelegateExecution execution) {
        return execution != null ? execution.getId() : "NULL";
    }
    
    private Map<String, Object> generateSuccessUpdateMap(DelegateExecution execution) {
    	var dataFieldToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class);
        var dataFieldValueToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, Boolean.class);
    	Map<String, Object> successUpdateMap = new HashMap<>(Map.of(
    			METADATA_PREFIX + dataFieldToUpdate, dataFieldValueToUpdate
    	));
    	return successUpdateMap;
    }

}
