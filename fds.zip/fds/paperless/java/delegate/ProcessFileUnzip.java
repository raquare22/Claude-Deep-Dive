package com.optum.fds.paperless.java.delegate;

import java.util.*;

import com.optum.fds.paperless.mongo.processors.*;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.service.SendQueueService;
import com.optum.fds.paperless.domain.service.ServiceBase;
import com.optum.fds.paperless.mongo.file.metadata.ProcessFileTask;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.domain.service.TransactionService;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.exception.ProcessException;
import com.optum.fds.paperless.file.summary.ProcessSummary;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service("ProcessFileUnzip")
public class ProcessFileUnzip extends OptumJavaDelegateBase {

	private static final String PROCESSOR_TRANSACTION_ID = "processorTransactionId";
	private static final String PROCESSOR_ID = "processorId";
	private static final String APP_IDENTIFIER = "appIdentifier";
	private static final String IDENTIFIER = "ProcessFileUnzip";
	private static final String CALLBACK = "processMetadataFiles";
	private static final String QUEUE_EXCEPTION = "QUEUE: Exception sendRequestToQueue; spaceId={}, queue={}, appIdentifier={}, identifier={}, targetId={}, msg={}";
	private static final int SFTP_PORT = 22;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessFileUnzip.class);

	@Value("${ENGINE_DELIGATE_URL}")
	private String engineDelegateUrl;
	
	@Value("${fileUnzipQueuesize}")
	private Integer fileUnzipQueueSize;
	
	@Value("${serverType}")
	private String serverType;

	@Autowired
	TransactionService transactionService;
	@Autowired
	ProcessorService processorService;
	@Autowired
	ProcessorsService processorsService;
	@Autowired
	ProcessSummary processSumaryService;
	@Autowired
	ProcessorTransactionsService processorTransactionsService;
	@Autowired
	ProcessorFileTaskService processorFileTaskService;
	@Autowired
	ServiceBase serviceBase;
	@Autowired
	SendQueueService sendQueueService;
	@Autowired
	ErrorMetaDataService errorMetaDataService;
	@Autowired
    private SftpUtil sftpUtil;
	
	private DelegateExecution tempExecution;

	private static final List<String> REQ_VARS = Collections.emptyList();

	public ProcessFileUnzip() {
		super(REQ_VARS);
	}

	public ProcessFileUnzip(ProcessorsService processorsService, ProcessSummary processSumaryService,
			TransactionService transactionService, ProcessorTransactionsService processorTransactionsService,
			ProcessorFileTaskService processorFileTaskService) {
		this.processorsService = processorsService;
		this.processSumaryService = processSumaryService;
		this.transactionService = transactionService;
		this.processorTransactionsService = processorTransactionsService;
		this.processorFileTaskService = processorFileTaskService;
	}

	@Override
	public void doExecute(DelegateExecution execution) {

		long startTime = System.currentTimeMillis();
		var bAddProcessorTransactionMD = false;
		ProcessorMetaData processor = null;
		ProcessorTransaction processorTransaction = null;

		tempExecution = execution;

		var appIdentifier = execution.getVariable(APP_IDENTIFIER).toString();
		var processorId = execution.getVariable(PROCESSOR_ID).toString();
		List<String> arrProcessorTransactionId = (List<String>) execution.getVariable("processorTransactionIds");
		for (String processorTransactionId : arrProcessorTransactionId) {
			try {

			if (!processorId.isEmpty() && !appIdentifier.isEmpty()) {
				processor = processorsService.getProcessor(appIdentifier, processorId);
			}

			if (processor.getProcessConfig().get("addProcessorTransactionMetadata") != null) {
				bAddProcessorTransactionMD = (boolean) processor.getProcessConfig()
						.get("addProcessorTransactionMetadata");
			}
			if (processorTransactionId != null && !appIdentifier.isEmpty()) {
				processorTransaction = processorsService.getTransactionProcessor(appIdentifier.trim(),
						processorTransactionId.trim(), serverType);
			} else {
				LOGGER.warn("Processor Transaction is empty");
				continue;
			}

			if (processor != null && (MetaDataStatus.IN_PROCESS.equals(processor.getStatus())
					|| MetaDataStatus.ACTIVE.equals(processor.getStatus())
					|| MetaDataStatus.NEW.equals(processor.getStatus()))) {
				processorTransaction.setProcessedByHost(FileUtil.getInstance().getLocalHostName());
				processorTransaction.setStartTime();
				processorTransaction.setStatus(MetaDataStatus.IN_PROCESS);
				var zipFilePath = Paths.get(processorTransaction.getLocation(), processorTransaction.getFileName());
				var filePath = Paths.get(processorTransaction.getLocation());
				try {
					
					if (Utilities.expandFile(zipFilePath, filePath)) {
						LOGGER.warn("THE ZIP FILE EXISTS, ANOTHER UNZIP PROCESSING SKIPPED: {}, processorTransaction id: {}", filePath, processorTransaction.getId());
						continue;
	                }
					LOGGER.debug("Zip file lock does not exist, expand zip file: {}, processorTransaction id: {}", filePath,
							processorTransaction.getId());					
				} catch (IOException e) {
					LOGGER.error("execute FileUnzip IO errors for filePath and exited {} {} {}",
							processorTransaction.getId(), filePath, ExceptionUtils.getStackTrace(e));
					var processorError = new ProcessorError(ProcessorErrorCode.FILE_COULD_NOT_BE_UNZIPPED);
					processorError.setFileName(execution.getVariable("fileName").toString());
					processorTransaction.getSummary().addError(processorError);
					execution.setTransientVariable(Workflow.UNZIP_ERROR_MESSAGE, e.getMessage());
					processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
					processorsService.updateProcessorTransactionMetaData(processorTransaction);
					errorMetaDataService.writeToErrorCollection(execution,
							"ProcessFileUnzip --> doExecute: " + e.getMessage());
				}
				
				try {
					archiveAndDeleteZipFile(processor, zipFilePath);
				} catch (Exception e) {
					LOGGER.error("execute FileUnzip -- error archiving or deleting zipfile after inflation, processorTransactionId={}, filePath={}, err={}",
							processorTransaction.getId(), filePath, ExceptionUtils.getStackTrace(e));
				}
				
				processSumaryService.processSummaryFile(processorTransaction);
				if (MetaDataStatus.FATAL_ERROR.equals(processorTransaction.getStatus())) {
					var processorError = new ProcessorError(ProcessorErrorCode.FILE_COULD_NOT_BE_UNZIPPED);
					processorTransaction.getSummary().addError(processorError);
					LOGGER.error("Summary File errors and exited {} {}", processorTransaction.getId(), filePath);
					execution.setTransientVariable(Workflow.UNZIP_ERROR_MESSAGE,
							processorTransaction.getSummary().getErrorList()
									.get(processorTransaction.getSummary().getErrorList().size() - 1)
									.getErrorMessage());
					continue;
				}
				
				LOGGER.debug("ProcessFileUnzip -- doExecute -- ingest filePath {}, exists={}", filePath, Files.exists(filePath));

				// create processor file task
				long fileProcessed = 0;

				if (processor != null && (MetaDataStatus.IN_PROCESS.equals(processor.getStatus())
						|| MetaDataStatus.ACTIVE.equals(processor.getStatus())
						|| MetaDataStatus.NEW.equals(processor.getStatus()))) {
					if (processorTransaction.getFileToProcessList() != null) {
						Set<String> processorFileTaskIds = new HashSet<>();
						for (String entry : processorTransaction.getFileToProcessList()) {
							try {
								fileProcessed++;

								if (!entry.isEmpty()) {
									var processorFileTask = processorsService
											.createProcessorFileTaskEntries(processorTransaction, entry);
									LOGGER.debug("FileUnzip process execute filename for ProcessorTransaction Id on host: {} {} {}",
											entry, processorTransactionId, Encode.forJava(FileUtil.getInstance().getLocalHostName()));
									LOGGER.debug("FileUnzip created processorFileTask id={}, status={}", processorFileTask.getId(), processorFileTask.getStatus());
									if (processorFileTask != null) {
										processorFileTaskIds.add(processorFileTask.getId());
									}
								}

								if (fileProcessed < processorTransaction.getFileToProcessList().size()) {
									if (processorFileTaskIds.size() == fileUnzipQueueSize) {
										String[] arrProcessorFileTaskIds = processorFileTaskIds.toArray(String[]::new);

										trySendRequestToQueueArrProcessorFileTaskIds(processor.getConfigSpaceId(), arrProcessorFileTaskIds,
												appIdentifier, processorTransactionId);
										processorFileTaskIds.clear();
									}
								} else if (fileProcessed == processorTransaction.getFileToProcessList().size()) {
									trySendRequestToQueueProcessorFileTaskIds(processor.getConfigSpaceId(), processorFileTaskIds, appIdentifier,
											processorTransactionId);
									processorFileTaskIds.clear();
								}

							} catch (Exception e) {
								LOGGER.error("FileUnzip process failed to create processor fileTask and exited {} {}",
										entry, ExceptionUtils.getStackTrace(e));
								errorMetaDataService.writeToErrorCollection(execution,
										"ProcessFileUnzip --> doExecute, failed to create processorFileTask " + entry
												+ " : " + e.getMessage());
							}
						}
					}
				} else {
					processorTransaction.setStatus(MetaDataStatus.SHUTDOWN);
					processorsService.updateProcessorTransactionMetaData(processorTransaction);

					if (processor != null) {
						LOGGER.warn("FileUnzip process not able unzip files at the working folder for Processor Id: {}",
								processor.getId());
					}

				}
				// Set Success Response
				if (bAddProcessorTransactionMD) {
					ProcessorTransactionMetadata processorTransactionMetadata = null;
					String strFileName = Utilities.stripFileExtension(processorTransaction.getFileName());
					String companionFileName = WorkFlowUtil.convertToCompanionFileName(strFileName, ".cmp", 0, 10);
					processorTransactionMetadata = processorTransactionsService
							.getProcessorTransactionMetadataWithFileName(companionFileName);

					if (processorTransactionMetadata == null && processor != null) {
						Map<String, Object> clientHashMap = processorTransactionsService
								.createProcessorTransactionMetadataClientHashmap(false, false,
										processorTransaction.getFileName(), null);

						var pmdTransactionMetada = processorTransactionsService.createProcessorTransactionMetadata(
								clientHashMap, processor.getId(), processor.getConfigSpaceId(), companionFileName);
						LOGGER.debug("FileUnzip->execute created  ProcessorTransactionMetadata for fileName={}",
								pmdTransactionMetada.getFileName());

					} else {

						String fileName = Optional.ofNullable(processorTransactionMetadata)
								.map(ProcessorTask::getFileName).orElse("");
						LOGGER.debug("FileUnzip->execute getProcessorTransactionMetadataWithFileName {} ", fileName);

					}
				}
				execution.setTransientVariable(Workflow.UNZIP_SUCCESS_MESSAGE, "Uzip of file complete");
				LOGGER.debug("FileUnzip executed");
			} else {
				processorTransaction.setStatus(MetaDataStatus.SHUTDOWN);
				processorsService.updateProcessorTransactionMetaData(processorTransaction);
			}

			if (LOGGER.isInfoEnabled()) {
				long endTime = System.currentTimeMillis();
				long duration = (endTime - startTime);
				LOGGER.debug("FileUnzip - execute: {} ", duration);
			}
		} catch (Exception e) {
			LOGGER.error("FileUnzip-->Error to process processor transaction Id {} {}", processorTransactionId, e.getMessage());
		}
		}

	}
	
	private void archiveAndDeleteZipFile(ProcessorMetaData processor, Path zipFilePath) throws IOException, SftpException, JSchException {
		Map<String, Object> processConfig = (Map<String, Object>) processor.getProcess().get("config");
		
		String sftpHost = (String) processConfig.get(Workflow.HOST_NAME_DESTINATION);
		String sftpUSER = (String) processConfig.get(Workflow.USER_NAME_DESTINATION);
		String sftpPASS = (String) processConfig.get(Workflow.USER_CREDENTIALS_DESTINATION);
		String archiveWorkingDir = (String) processConfig.get(Workflow.FTP_ARCHIVE_DIR);
		Integer maxSftpTriesVar = (Integer) processConfig.get(Workflow.MAX_SFTP_TRIES);
		Long retryTimeSecsVar = (Long) processConfig.get(Workflow.RETRY_TIME_SECS);
		int maxSftpTries = maxSftpTriesVar != null ? maxSftpTriesVar : 10;
		long retryTimeSecs = retryTimeSecsVar != null ? retryTimeSecsVar: 360;  // 6 minutes
		LOGGER.info("ProcessFileUnzip-->archiving zip file={}", zipFilePath);
		sftpUtil.moveFileFromLocalToSFTPLocation(sftpUSER, sftpPASS, sftpHost, SFTP_PORT, archiveWorkingDir, zipFilePath.toAbsolutePath().toString(), maxSftpTries, retryTimeSecs);
		File zipFile = zipFilePath.toFile();
		if (zipFile.exists()) {
			LOGGER.info("ProcessFileUnzip-->deleting zip file from ingest folder={}", zipFilePath);
			FileUtils.forceDelete(zipFile);
		}
	}

	private void trySendRequestToQueueArrProcessorFileTaskIds(Integer spaceId, String[] arrProcessorFileTaskIds, String appIdentifier, String processorTransactionId) {
		Map<String, Object> variables = new HashMap<>();
		variables.put(APP_IDENTIFIER, appIdentifier);
		variables.put("processorFileTaskIds", arrProcessorFileTaskIds);
		variables.put(PROCESSOR_TRANSACTION_ID, processorTransactionId);
		try {
			LOGGER.info("CALLING sendRequestToQueue: spaceId={}, identifier={}, targetId={}, callback={}", spaceId, IDENTIFIER, processorTransactionId, CALLBACK);
			sendQueueService.sendRequestToQueue(spaceId, IDENTIFIER, processorTransactionId, CALLBACK, variables);
		} catch (ProcessException e) {
			String queue = sendQueueService.getPriorityQueue(spaceId);
			LOGGER.error(QUEUE_EXCEPTION, spaceId, queue, appIdentifier, IDENTIFIER, processorTransactionId, e.getMessage());
			errorMetaDataService.writeToMessageServiceErrorCollection(queue, CALLBACK, processorTransactionId, spaceId, variables, e.getMessage(), MetaDataStatus.MANUAL);
		} catch (HttpServerException e) {
			String queue = sendQueueService.getPriorityQueue(spaceId);
			LOGGER.error(QUEUE_EXCEPTION, spaceId, queue, appIdentifier, IDENTIFIER, processorTransactionId, e.getMessage());
			errorMetaDataService.writeToMessageServiceErrorCollection(queue, CALLBACK, processorTransactionId, spaceId, variables, e.getMessage(), MetaDataStatus.AUTOMATIC);
		}
	}

	private void trySendRequestToQueueProcessorFileTaskIds(Integer spaceId, Set<String> processorFileTaskIds, String appIdentifier, String processorTransactionId ) {
		String[] arrProcessorFileTaskIds = processorFileTaskIds.toArray(String[]::new);
		Map<String, Object> variables = new HashMap<>();
		variables.put(APP_IDENTIFIER, appIdentifier);
		variables.put("processorFileTaskIds", arrProcessorFileTaskIds);
		variables.put(PROCESSOR_TRANSACTION_ID, processorTransactionId);
		try {
			LOGGER.info("CALLING sendRequestToQueue: spaceId={}, identifier={}, targetId={}, callback={}", spaceId, IDENTIFIER, processorTransactionId, CALLBACK);
			sendQueueService.sendRequestToQueue(spaceId, IDENTIFIER, processorTransactionId, CALLBACK, variables);
		} catch (ProcessException e) {
			String queue = sendQueueService.getPriorityQueue(spaceId);
			LOGGER.error(QUEUE_EXCEPTION, spaceId, queue, appIdentifier, IDENTIFIER, processorTransactionId, e.getMessage());
			errorMetaDataService.writeToMessageServiceErrorCollection(queue, CALLBACK, processorTransactionId, spaceId, variables, e.getMessage(), MetaDataStatus.MANUAL);
		} catch (HttpServerException e) {
			String queue = sendQueueService.getPriorityQueue(spaceId);
			LOGGER.error(QUEUE_EXCEPTION, spaceId, queue, appIdentifier, IDENTIFIER, processorTransactionId, e.getMessage());
			errorMetaDataService.writeToMessageServiceErrorCollection(queue, CALLBACK, processorTransactionId, spaceId, variables, e.getMessage(), MetaDataStatus.AUTOMATIC);
		}
	}

	public void setProcessorService(ProcessorService processorService) {
		this.processorService = processorService;
	}

}
