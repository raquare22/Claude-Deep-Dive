package com.optum.fds.paperless.java.delegate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorError;
import com.optum.fds.paperless.mongo.processors.ProcessorErrorCode;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.template.java.impl.OptumPayNumberDocumentTemplate;
import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.util.ProcessorTaskUtil;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("ConvertFileToDocumentMetaData")
public class ConvertFileToDocumentMetaData extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConvertFileToDocumentMetaData.class);
	
	@Autowired
	DocumentMetaDataService documentMetaDataService;
	
	@Autowired
	ProcessorsService processorsService;
	
	@Autowired
	ProcessorService processorService;

	@Autowired
	private SftpUtil sftpUtil;

	@Value("${SplitPerMbSize:4}")
	protected int splitPerMbSize;

	@Value("${SplitFileMaxBytesNewLineWithin:1024}")
	protected int splitFileMaxBytesNewLineWithin;

	private static final String OUTCOME_KEY = "outcome";
    private static final String ERROR_KEY = "error";
    private static final String HOST_NAME_SOURCE = "host_name_source";
    private static final String USER_NAME_SOURCE = "username_source";
    private static final String USER_CREDENTIALS_SOURCE = "pw_source";
    private static final String FTP_ARCHIVE_DIR = "ftp_archivedir";
    private static final int SFTP_PORT = 22;
	
	private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.TEMPLATE_NAME, Workflow.FILE_PATH, Workflow.SPACE_ID, Workflow.APP_IDENTIFIER
    );
    
    public ConvertFileToDocumentMetaData() {
        super(REQ_VARS);
    }
	
	@Override
    public void doExecute(DelegateExecution execution) {
		// convert text file to documentMetaData
		LOGGER.debug("ConvertFileToDocumentMetaData-->doExecute-->ENTER");
		// filePath to AP text file in ingest
		String filePath = execution.getVariable(Workflow.FILE_PATH, String.class);
		try {
			String processorTransactionId = execution.getVariable("processorTransactionId", String.class);
			String appIdentifier = execution.getVariable("appIdentifier", String.class);
			var processorTransaction = processorsService.getTransactionProcessor(appIdentifier.trim(),
					processorTransactionId.trim(), "");
			processorTransaction.setProcessedByHost(FileUtil.getInstance().getLocalHostName());
			processorTransaction.setStartTime();
			processorTransaction.setStatus(MetaDataStatus.IN_PROCESS);
			processorsService.updateProcessorTransactionMetaData(processorTransaction);

			String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);
			String fileName = execution.getVariable(Workflow.FILE_NAME, String.class);
			Integer spaceId = execution.getVariable(Workflow.SPACE_ID, Integer.class);

			ProcessorExecutionRecord executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Converting file to documents with string template", processorTransaction);
			HashMap<String,String> message = new HashMap<>();

			boolean done = false;
			boolean logSplit = false;
			String documentMetaDataListStr = null;
			List<DocumentMetaData> insertedDocList = new ArrayList<>();
			TemplateHandler templateHandler = TemplateFactory.getInstance(templateName);
			if (templateHandler != null && templateName.equals(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate())) {
				logSplit = true;
				((OptumPayNumberDocumentTemplate) templateHandler).setSplitPerMbSize(splitPerMbSize);
				((OptumPayNumberDocumentTemplate) templateHandler).setSplitFileMaxBytesNewLineWithin(splitFileMaxBytesNewLineWithin);
			}
			while (! done) {
				try {
					if (templateHandler == null ) {
						throw new NullPointerException("templateName=" + templateName + ", templateHandler == null");
					}
					documentMetaDataListStr = templateHandler.convertWithTemplateFromFilePath(filePath);
				} catch (Exception e) {
					LOGGER.error("ConvertFileToDocumentMetaData --> unable to convert file with string template, file={}, templateName={}, e={}", 
						filePath, templateName, ExceptionUtils.getStackTrace(e));

					// update processorTransaction with error log
					message.put(OUTCOME_KEY, "Unable to convert file with string template");
					message.put(ERROR_KEY, e.toString());
					var processorError = new ProcessorError(ProcessorErrorCode.UNABLE_TO_CONVERT_WITH_STRING_TEMPLATE);
					processorError.setFileName(fileName);
					processorTransaction.getSummary().addError(processorError);
					processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
					ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord, message);
					setExitNow(execution);
					return;
				}

				// convert json string to List<DocumentMetaData>
				List<DocumentMetaData> documentMetaDataList = null;
				try {
					documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(documentMetaDataListStr);
					if (logSplit) {
						LOGGER.info("documentMetaDataList.size={}", documentMetaDataList.size());
					}
				} catch (JSONException | IOException e) {
					LOGGER.error("ConvertFileToDocumentMetaData --> unable to convert json string to documentMetaDataList, e={}", ExceptionUtils.getStackTrace(e));

					// update processorTransaction with error log
					message.put(OUTCOME_KEY, "Unable to convert json string to List<DocumentMetaData>");
					message.put(ERROR_KEY, e.toString());
					var processorError = new ProcessorError(ProcessorErrorCode.UNABLE_TO_CONVERT_WITH_STRING_TEMPLATE);
					processorError.setFileName(fileName);
					processorTransaction.getSummary().addError(processorError);
					processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
					ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord, message);
					return;
				}

				// insert List<DocumentMetaData> into mongodb and get list of documentIds
				if (CollectionUtils.isEmpty(documentMetaDataList)) {
					LOGGER.warn("ConvertFileToDocumentMetaData-->doExecute-->documentMetaDataList is null or empty");
					setExitNow(execution);
					return;
				}

				// batch insert documents into mongodb
				List<List<DocumentMetaData>> partitionedList = ListUtils.partition(documentMetaDataList, 1000);

				for (List<DocumentMetaData> subList : partitionedList) {
					insertedDocList.addAll(documentMetaDataService.insertMultiDocumentsWithSpaceId(subList, spaceId));
					LOGGER.debug("doExecute batch of documents inserted to mongodb: subList.size={}, partitionedList.size={}", subList.size(), partitionedList.size());
				}
				if (logSplit) {
					LOGGER.info("insertedDocList.size={}", insertedDocList.size());
				}

				if (templateName.equals(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate())) {
					done = ((OptumPayNumberDocumentTemplate) templateHandler).isDone();
					if (done) {
						templateHandler = null;
					}
				} else {
					done = true;
				}
			}
			documentMetaDataListStr = null;
			List<String> docIds = new ArrayList<>();
			insertedDocList.forEach(doc -> docIds.add(doc.getId()));
			execution.setTransientVariable("documentIds", docIds);
			execution.setTransientVariable("documentMetaDataList", insertedDocList);
			LOGGER.info("ConvertFileToDocumentMetaData --> file converted to documents with string template, filePath={}, # of documentIds={}", filePath, docIds.size());

			// update processorTransaction
			processorTransaction.setDocumentIds(docIds);
			message.put(OUTCOME_KEY, "File converted with string template");
			processorTransaction.setStatus(MetaDataStatus.COMPLETE);
			ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, processorTransaction, executionRecord, message);
		} catch (Exception e) {
			LOGGER.error("ConvertFileToDocumentMetaData --> doExecute error converting file e={}", ExceptionUtils.getStackTrace(e));

		} finally {
			archiveOriginalFile(execution, filePath);
		}
	}

	
	private void archiveOriginalFile(DelegateExecution execution, String filePath) {
    	try {
    		var processor = (ProcessorMetaData) execution.getVariable(Workflow.PROCESSOR_METADATA);
            var processorConfig = (Map<String, Object>) processor.getProcessConfig();

            String sftpHost = (String) processorConfig.get(HOST_NAME_SOURCE);
            String sftpUSER = (String) processorConfig.get(USER_NAME_SOURCE);
            String sftpPASS = (String) processorConfig.get(USER_CREDENTIALS_SOURCE);
            String sftpArchiveDir = (String) processorConfig.get(FTP_ARCHIVE_DIR);
            
            Integer maxSftpTriesVar = (Integer) processorConfig.get(Workflow.MAX_SFTP_TRIES);
        	Long retryTimeSecsVar = (Long) processorConfig.get(Workflow.RETRY_TIME_SECS);
        	int maxSftpTries = maxSftpTriesVar != null ? maxSftpTriesVar : 10;
        	long retryTimeSecs = retryTimeSecsVar != null ? retryTimeSecsVar: 360;  // 6 minutes
        	LOGGER.debug("ConvertFileToDocumentMetaData-->archiving file={}", filePath);
			sftpUtil.moveFileFromLocalToSFTPLocation(sftpUSER, sftpPASS, sftpHost, SFTP_PORT, sftpArchiveDir, filePath, maxSftpTries, retryTimeSecs);
		} catch (Exception e) {
			LOGGER.error("ConvertFileToDocumentMetaData --> unable to archive original file, filePath={}", filePath);
		}
	}

}
