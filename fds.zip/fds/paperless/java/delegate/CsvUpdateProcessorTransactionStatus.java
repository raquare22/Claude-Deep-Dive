
package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.jobs.CsvProcessorJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;


@Service("CsvUpdateProcessorTransactionStatus")
public class CsvUpdateProcessorTransactionStatus extends OptumJavaDelegateBase {

	CsvProcessorsService csvProcessorsService;
    @Autowired
	ProcessorService processorService;

	private static final List<String> REQ_VARS = Arrays.asList(Workflow.APP_IDENTIFIER, Workflow.JOB);
	

	public CsvUpdateProcessorTransactionStatus() {
		super(REQ_VARS);
	}

	private static final Logger log = LoggerFactory.getLogger(CsvUpdateProcessorTransactionStatus.class);

	@Override
	public void doExecute(DelegateExecution execution) {
		log.info("CsvUpdateProcessorTransactionStatus-->doExecute-->ENTER");

		var appIdentifier = (String) execution.getVariable(Workflow.APP_IDENTIFIER);
		var csvProcessorJob = (CsvProcessorJob) execution.getVariable(Workflow.JOB);

		var csvProcessorTransaction = csvProcessorsService.getCsvProcessorTransactionWithFileName(
				appIdentifier, csvProcessorJob.getProcessorId(), csvProcessorJob.getFileName(),
				csvProcessorJob.getServerType());

		if (csvProcessorTransaction != null) {
			// if csvProcessorTransaction status is Complete then don't change the status, otherwise check if the status can be made complete or not.
			checkAndUpdateCsvProcessorTransactionStatus(csvProcessorTransaction);
			 execution.setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, csvProcessorTransaction);
		} else {
			log.info("CsvUpdateProcessorTransactionStatus-->doExecute-->csvProcessorTransaction null for fileName {}",
					csvProcessorJob.getFileName());
		}

		var processorMetaData = processorService.getProcessorMetaData(csvProcessorJob.getProcessorId(),
				appIdentifier);
		if (processorMetaData == null) {
			log.error("CsvUpdateProcessorTransactionStatus-->doExecute-->processorMetaData is empty");
			return;
		}
		var processConfig = processorMetaData.getProcessConfig();

		if (processConfig == null) {
			log.error("CsvUpdateProcessorTransactionStatus-->doExecute-->processConfig is empty");
			return;
		}

		String sftpHost = (String) processConfig.get(Workflow.HOST_NAME_DESTINATION);

		String sftpUSER = (String) processConfig.get(Workflow.USER_NAME_DESTINATION);

		String sftpPASS = (String) processConfig.get(Workflow.USER_CREDENTIALS_DESTINATION);

		String ftpWorkingDir = (String) processConfig.get(Workflow.FTP_ROOT_DIR);

		String archiveWorkingDir = (String) processConfig.get(Workflow.FTP_ARCHIVE_DIR);


		 execution.setTransientVariable(Workflow.SFTP_HOSTNAME, sftpHost);
		 execution.setTransientVariable(Workflow.SFTP_USERNAME, sftpUSER);
		 execution.setTransientVariable(Workflow.SFTP_PW, sftpPASS);
		 execution.setTransientVariable(Workflow.SFTP_ROOT_DIRECTORY, ftpWorkingDir);
		 execution.setTransientVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, archiveWorkingDir);
		log.info("CsvUpdateProcessorTransactionStatus-->doExecute-->EXIT");
	}

	private void checkAndUpdateCsvProcessorTransactionStatus(CsvProcessorTransaction csvProcessorTransaction) {
		var statusBefore = csvProcessorTransaction.getStatus();

		if (statusBefore != MetaDataStatus.COMPLETE) {

			var statusNow = Boolean.TRUE.equals(csvProcessorsService.isAllCsvProcessorRowTasksWithCsvProcessorTransactionIdComplete(csvProcessorTransaction.getId())) ?
					MetaDataStatus.COMPLETE :
					MetaDataStatus.COMPLETE_WITH_ERRORS;

			log.info("statusBefore = {}, statusNow = {} before checking summary errorList", statusBefore, statusNow);
			statusNow = csvProcessorTransaction.setCompleteStatus();

			if (statusBefore != statusNow) {
				log.info("csvProcessorTransactionId = {}, set to status {}", csvProcessorTransaction.getId(), statusNow);

				csvProcessorsService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
				return;
			}
			log.info("csvProcessorTransactionId = {}, status is still {} should be {}", csvProcessorTransaction.getId(), statusNow, MetaDataStatus.COMPLETE_WITH_ERRORS);
		}
	}
}
