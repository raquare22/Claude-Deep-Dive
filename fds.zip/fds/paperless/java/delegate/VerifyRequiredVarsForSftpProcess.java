package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service("VerifyRequiredVarsForSftpProcess")
public class VerifyRequiredVarsForSftpProcess extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(VerifyRequiredVarsForSftpProcess.class);


    public VerifyRequiredVarsForSftpProcess() {
        super(REQ_VARS);
    }

    private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.DOCUMENT,

            Workflow.APP_ID,
            Workflow.APP_SECRET,
            Workflow.GRANT_TYPE,
            Workflow.OAUTH_URL,
            Workflow.CLIENT_ID,
            Workflow.CLIENT_SECRET,


            Workflow.FDS_DOCUMENT_URL,
            Workflow.FDS_ATTACHMENT_URL,
            Workflow.FDS_TRANSFORM_URL,

            Workflow.SFTP_URL,
            Workflow.SFTP_USER,
            Workflow.SFTP_PASS,
            Workflow.SFTP_ROOT,
            Workflow.EMAIL_RECEIVER,
            Workflow.EMAIL_SUBJECT
    );


    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("VerifyRequiredVarsForSftpProcess executed");
    }

}