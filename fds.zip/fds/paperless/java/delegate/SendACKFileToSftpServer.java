package com.optum.fds.paperless.java.delegate;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.StringUtils;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("SendACKFileToSftpServer")
public class SendACKFileToSftpServer extends OptumJavaDelegateBase {

	private static final Logger LOGGER = LoggerFactory.getLogger(SendACKFileToSftpServer.class);

	private static final int SFTP_PORT = 22;
	private static final String DESTINATION = "destination";
	
	@Autowired
	ProcessorService processorService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;
	
	@Autowired
    private SftpUtil sftpUtil;
	
	private DelegateExecution tempExecution = null;
		
	private static final List<String> REQ_VARS = Arrays.asList(
		Workflow.PROCESSOR_TRANSACTION, Workflow.ACK_FLAG
    );

	public SendACKFileToSftpServer() {
		super(REQ_VARS);
	}
		
	@Override
	protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("SendACKFileToSftpServer-->doExecute-->ENTER");
        tempExecution = execution;
        ProcessorTransaction processorTransaction = null;
        ProcessorExecutionRecord executionRecord = null;
        Map<String, String> message = new HashMap<>();
		try {
			processorTransaction = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);
			Boolean ackFlag = execution.getVariable(Workflow.ACK_FLAG, Boolean.class);
			if(Boolean.TRUE.equals(ackFlag)) {
				String sftpHost = execution.getVariable(Workflow.SFTP_HOSTNAME, String.class);
				String sftpUser = execution.getVariable(Workflow.SFTP_USERNAME, String.class);
				String sftpPass = execution.getVariable(Workflow.SFTP_PW, String.class);
				String sftpAckDir = execution.getVariable(Workflow.SFTP_ACK_DIRECTORY, String.class);
				String sftpArchiveDir = execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class);
				String ackFile = execution.getVariable(Workflow.ACK_FILE, String.class);

				Map<String,String> sftpMap = new HashMap<>();
				sftpMap.put("sftpHost",sftpHost);
				sftpMap.put("sftpUser",sftpUser);
				sftpMap.put("sftpPass",sftpPass);


	            Integer maxSftpTriesVar = execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class);
	            Long retryTimeSecsVar = execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class);
	            int maxSftpTries = maxSftpTriesVar != null ? maxSftpTriesVar : 10;
	            long retryTimeSecs = retryTimeSecsVar != null ? retryTimeSecsVar: 360;  // 6 minutes
				// Move zipped ack files to target ACK folder
		        executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Moving ACK file to target ACK folder");
		        message = new HashMap<>();

				boolean errors = moveFileFromLocalToSFTPLocation(message, sftpMap, sftpAckDir, ackFile, "ACK",
						maxSftpTries, retryTimeSecs);
				ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction,
						executionRecord, message);
				if (errors) {
					addErrorMsg(
							"SendACKFileToSftpServer-->doExecute-->Error while Moving ACK file to target ACK folder",
							"Error while Moving ACK file to target ACK folder");
					errorMetaDataService.writeToErrorCollection(execution, "SendACKFileToSftpServer --> doExecute: Error while moving ACK file to target ACK folder");
					return;
				}
		        // Move ack file to target Archive folder
		        if(!StringUtils.isNullOrEmpty(sftpArchiveDir)) {
		        	executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Moving ACK file to target archive folder");
			        message = new HashMap<>();
			        moveFileFromLocalToSFTPLocation(message, sftpMap, sftpArchiveDir, ackFile, "archive", maxSftpTries, retryTimeSecs);
			        ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
		        }
			} else {
				LOGGER.warn("SendACKFileToSftpServer-->doExecute-->ackWorkingDir is not defined, Suppressing sending of ACK file");
			}
	        //update processor transaction status to COMPLETE
			if (processorTransaction.getStatus() != MetaDataStatus.FATAL_ERROR) {
		        executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Updating processorTransaction status");
				message = new HashMap<>();
				processorTransaction.setCompleteStatus();
				message.put(Workflow.OUTCOME_KEY, "processorTransaction status updated");
		        ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
			}
        } catch(Exception e) {
        	LOGGER.error("doExecute Exception while executing SendACKFileToSftpServer task {}={} {}",
	        		  "processorTransactionId", processorTransaction != null ? processorTransaction.getId() : "NULL",
	        		  ExceptionUtils.getStackTrace(e));
    		addErrorMsg("SendACKFileToSftpServer-->doExecute-->Exception while executing SendACKFileToSftpServer task", e.getMessage());
			message.put(Workflow.OUTCOME_KEY, "Exception while moving ACK file target SFTP folder");
			message.put(Workflow.ERROR_KEY, e.toString());
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
			errorMetaDataService.writeToErrorCollection(execution, "SendACKFileToSftpServer --> doExecute: " + e.getMessage());

        } finally {
			execution.setTransientVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
			processorService.updateProcessorTransactionMetaData(processorTransaction);
        }
        LOGGER.debug("SendACKFileToSftpServer-->doExecute-->EXIT");
	}
	
	boolean moveFileFromLocalToSFTPLocation(Map<String, String> message, Map<String,String> sftpMap, String targetWorkingDir, String zipFileName, String destination, int maxSftpTries, long retryTimeSecs) {
		LOGGER.debug("SendACKFileToSftpServer-->moveFileFromLocalToSFTPLocation-->ENTER");
		var errors = false;
		try {
            errors = false;
            moveFileFromLocalToSFTPLocation(sftpMap, targetWorkingDir, zipFileName, maxSftpTries, retryTimeSecs);
            message.put(Workflow.OUTCOME_KEY, String.format("Ack file moved to target %s folder", destination));
        } catch (SftpException e) {
        	LOGGER.error("moveFileFromLocalToSFTPLocation Error during SFTP process for ACK file to folder {}={} {}",
	        		  DESTINATION, destination,
	        		  ExceptionUtils.getStackTrace(e));
            message.put(Workflow.OUTCOME_KEY, String.format("Error during SFTP process for ACK file to %s folder", destination));
            message.put(Workflow.ERROR_KEY, e.toString());
            errors = true;
            errorMetaDataService.writeToErrorCollection(tempExecution, "SendACKFileToSftpServer --> moveFileFromLocalToSFTPLocation: " + e.getMessage());
        } catch (JSchException e) {
        	LOGGER.error("moveFileFromLocalToSFTPLocation Error during SSH protocol for ACK file to folder {}={} {}",
	        		  DESTINATION, destination,
	        		  ExceptionUtils.getStackTrace(e));
            message.put(Workflow.OUTCOME_KEY, String.format("Error during SSH protocol for ACK file to %s folder", destination));
            message.put(Workflow.ERROR_KEY, e.toString());
            errors = true;
            errorMetaDataService.writeToErrorCollection(tempExecution, "SendACKFileToSftpServer --> moveFileFromLocalToSFTPLocation: " + e.getMessage());
        } catch (FileNotFoundException e) {
        	LOGGER.error("moveFileFromLocalToSFTPLocation Could not locate the ACK file {}={} {}",
	        		  DESTINATION, destination,
	        		  ExceptionUtils.getStackTrace(e));
            message.put(Workflow.OUTCOME_KEY, "Could not locate the ACK file");
            message.put(Workflow.ERROR_KEY, e.toString());
            errors = true;
            errorMetaDataService.writeToErrorCollection(tempExecution, "SendACKFileToSftpServer --> moveFileFromLocalToSFTPLocation: " + e.getMessage());
        } catch (IOException e) {
        	LOGGER.error("moveFileFromLocalToSFTPLocation Could not close local file {}={} {}",
	        		  DESTINATION, destination,
	        		  ExceptionUtils.getStackTrace(e));
            message.put(Workflow.OUTCOME_KEY, "Could not close local file");
            message.put(Workflow.ERROR_KEY, e.toString());
            errors = true;
            errorMetaDataService.writeToErrorCollection(tempExecution, "SendACKFileToSftpServer --> moveFileFromLocalToSFTPLocation: " + e.getMessage());
        }
		LOGGER.debug("SendACKFileToSftpServer-->moveFileFromLocalToSFTPLocation-->EXIT");
		return errors;
	}

	void moveFileFromLocalToSFTPLocation(Map<String,String> sftpMap, String targetWorkingDir,
			String zipFileName, int maxSftpTries, long retryTimeSecs) throws JSchException, SftpException, IOException {
		sftpUtil.moveFileFromLocalToSFTPLocation(sftpMap.get("sftpUser"), sftpMap.get("sftpPass"),sftpMap.get( "sftpHost"), SFTP_PORT, targetWorkingDir, zipFileName, maxSftpTries, retryTimeSecs);
	}
	
}