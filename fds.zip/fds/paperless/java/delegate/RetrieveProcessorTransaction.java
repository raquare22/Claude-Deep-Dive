package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;

import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.Parser;

import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("RetrieveProcessorTransaction")
public class RetrieveProcessorTransaction extends OptumJavaDelegateBase {
    
	private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveProcessorTransaction.class);
	private static final String QUERY_STRING = "{} query={}";
	private static final String PROCESS_KEY = "createStatusFileAndAckProcess";
	private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";
    private static final List<String> REQ_VARS = Arrays.asList(
    		Workflow.SEARCH_CRITERIA, Workflow.SEARCH_WINDOW
    );
    @Autowired
    MongoTemplate mongoTemplate;
    @Autowired
	ProcessorService processorService;
	@Autowired
    EmailService emailService;
    @Autowired
    HookService hookService;
    
    public RetrieveProcessorTransaction() {
        super(REQ_VARS);
    }
    
	@Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("RetrieveProcessorTransaction-->doExecute-->ENTER");
        
        try {
        	String searchCriteria = execution.getVariable(Workflow.SEARCH_CRITERIA, String.class);
        	String hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
        	String appIdentifier = execution.getVariable(Workflow.APP_IDENTIFIER, String.class);
        	Integer clientId = execution.getVariable(Workflow.CLIENT_ID, Integer.class);
        	Integer configSpaceId = getConfigSpaceId(searchCriteria, execution);
    		if(configSpaceId == null) {
    			LOGGER.error("RetrieveProcessorTransaction-->doExecute-->configSpaceId is null delegateExecutionId={}", execution.getId());
    			addErrorMsg("RetrieveProcessorTransaction-->doExecute-->configSpaceId is null", "configSpaceId is null");
    			return;
    		}

        	String searchWindow = execution.getVariable(Workflow.SEARCH_WINDOW, String.class);        	
        	var searchWindowCriteria = WorkFlowUtil.getSearchWindowCriteria(searchWindow);
        	if(searchWindowCriteria == null) {
    			LOGGER.error("RetrieveProcessorTransaction-->doExecute-->search_window is invalid delegateExecutionId={}", execution.getId());
    			addErrorMsg("RetrieveProcessorTransaction-->doExecute-->search_window is invalid", "search_window is invalid");
    			return;
    		}

    		List<ProcessorTransaction> processorTransactionList = getProcessorTransactions(searchCriteria, searchWindowCriteria, execution);
    		if(processorTransactionList == null || processorTransactionList.isEmpty()) {
            	LOGGER.debug("RetrieveProcessorTransaction-->doExecute-->processorTransactionList is null or empty; delegateExecutionId={}, configSpaceId={}, searchCriteria={}", execution.getId(), configSpaceId, searchCriteria);
            	String messgeKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
            	execution.setTransientVariable(messgeKey, "processorTransactionList documentList is null or empty");
            	setExitNow(execution);
            	return;
    		}
    		

			LOGGER.debug("RetrieveProcessorTransaction-->doExecute-->processor transactions are present delegateExecutionId={}", execution.getId());
			List<JSONObject> processorTransactionUpdateListJson = new ArrayList<>();
			List<String> processorTransactionIds = new ArrayList<>();
			for(ProcessorTransaction processorTransaction : processorTransactionList) {
				var processorTransactionUpdateJson = new JSONObject();
				processorTransactionUpdateJson.put(Workflow.MONGO_ID, processorTransaction.getId());
				processorTransactionUpdateJson.put(Workflow.ACK_STATUS, Workflow.ACK_STATUS_IN_PROCESS);
				processorTransactionUpdateListJson.add(processorTransactionUpdateJson);
				processorTransactionIds.add(processorTransaction.getId());
			}
			// add list of processorTransactionIds to execution bus for reconciliation error message 
			execution.setTransientVariable("processorTransactionIds", processorTransactionIds);
			execution.setTransientVariable(Workflow.PROCESSOR_TRANSACTION_IDS_MESSAGE, processorTransactionIds.toString());
    		
    		var processorTransactionsJson = new JSONObject();
			processorTransactionsJson.put(Workflow.PROCCESSOR_TRANSACTIONS, processorTransactionList);
			
			String tempWorkingPath = WorkFlowUtil.getTemporaryWorkingPath(configSpaceId);

			String filePath = tempWorkingPath + File.separator + "processorTransactions.json";
			var jsonFile = WorkFlowUtil.generateFileFromString(processorTransactionsJson.toString(), filePath);

			execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR, tempWorkingPath);
			execution.setTransientVariable(Workflow.JSON_FILE, jsonFile.getAbsolutePath());
			execution.setTransientVariable(Workflow.PROCESSOR_TRANSACTION_UPDATE, processorTransactionUpdateListJson.toString());
			DelegateUtils.updateProcessorTransactionList(execution, processorService);
			var hookExecutionMessage = new HashMap<>(Map.of(
					Workflow.PROCESSOR_TRANSACTION_IDS_MESSAGE, processorTransactionIds.toString()
            ));
			var hookExecutionRecord = new HashMap<>(Map.of(
                    Workflow.SPACE_ID, configSpaceId.toString(),
                    Workflow.HOOK_ID, hookId,
                    Workflow.APP_IDENTIFIER, appIdentifier,
                    Workflow.CLIENTID, clientId.toString()
            ));
			
			var hookExecutionRecordMetaData = HookTransactionUtil
					.getHookExecutionRecord(hookExecutionRecord, hookExecutionMessage, PROCESS_KEY);
			var hookTransactionMetaData = hookService
					.saveHookTransaction(HookTransactionUtil.createCronHookTransaction(hookExecutionRecordMetaData));
			execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA, hookTransactionMetaData);
            
        } catch(Exception e) {
        	LOGGER.error("doExecute Exception while executing Retrieve Processor Transaction task {}={} {}",
        			"delegateExecutionId", execution.getId(),
	                ExceptionUtils.getStackTrace(e));
    		addErrorMsg("RetrieveProcessorTransaction-->doExecute-->Exception while executing Retrieve Processor Transaction task", e.getMessage());
        } finally {
        	if (newErrors() && errorMap.size() > 1 ) {
        		String message = DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution);
        		LOGGER.error("Error msg: {} , process key: {}, errorMap: {} ",message, execution.getProcessInstanceBusinessKey(),errorMap.values());
    		}
        }
        LOGGER.debug("RetrieveProcessorTransaction-->doExecute-->EXIT");
    }

	@SuppressWarnings("unchecked")
	private Integer getConfigSpaceId(String searchCriteria, DelegateExecution execution) throws IOException,NullPointerException {
		Integer configSpaceId = null;
		HashMap<String, Object> criteriaMap = null;
		try {
			criteriaMap = Parser.parseJson(searchCriteria, HashMap.class);
		} catch (IOException e) {
			LOGGER.error("getConfigSpaceId Unable to parse search_criteria {}={} {}",
        			"searchCriteria", searchCriteria,
	                ExceptionUtils.getStackTrace(e));
			addErrorMsg("RetrieveProcessorTransaction-->getConfigSpaceId-->Unable to parse search_criteria", e.getMessage());
			throw new NullPointerException();
		}
		configSpaceId = (Integer) criteriaMap.get(Workflow.REST_CONFIG_SPACE_ID);
		return configSpaceId;
	}

	private List<ProcessorTransaction> getProcessorTransactions(String searchCriteria, Criteria searchWindowCriteria, DelegateExecution execution) {
    	Query query = new BasicQuery(searchCriteria);
    	query.addCriteria(Criteria.where(Workflow.PROCESSOR_RECORD_TYPE).is(ProcessorRecordTypes.processorTransaction.toString()));
		query.addCriteria(searchWindowCriteria);
		LOGGER.debug(QUERY_STRING, "getProcessorTransactions", query);
		try {
			return mongoTemplate.find(query, ProcessorTransaction.class, Workflow.PROCESSOR_TRANSACTION);
		} catch (Exception e) {
			LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorTransactions", query, ExceptionUtils.getStackTrace(e));
			throw e;

		}
	}
    
}