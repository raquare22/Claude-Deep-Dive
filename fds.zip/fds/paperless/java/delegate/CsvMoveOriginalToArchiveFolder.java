package com.optum.fds.paperless.java.delegate;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("CsvMoveOriginalToArchiveFolder")
public class CsvMoveOriginalToArchiveFolder extends OptumJavaDelegateBase {
	
	@Autowired
	CsvProcessorService csvProcessorService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;	

	@Autowired
	private WorkFlowUtil workFlowUtil;
    
    private static final Logger LOGGER = LoggerFactory.getLogger(CsvMoveOriginalToArchiveFolder.class);
    
    private static final int SFTP_PORT = 22;
    private static final String DELEGATE_EXECUTION_ID = "delegateExecutionId";
	private static final String CSV_PROCESSOR_TRANSACTION = "csvProcessorTransactionId";
	private static final String FILE_DID_NOT_ARCHIVE_MSG = "CSV File did not archived correctly: fileName";
    
    
    private static final List<String> REQ_VARS = Arrays.asList(
    		Workflow.CSV_PROCESSOR_TRANSACTION
    );
    
    public CsvMoveOriginalToArchiveFolder() {
        super(REQ_VARS);
    }
    
    @Override
    protected void doExecute(DelegateExecution execution) {
    	LOGGER.debug("CsvMoveOriginalToArchiveFolder-->doExecute-->ENTER");
    	CsvProcessorTransaction csvProcessorTransaction = null;
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
		
		try {
			csvProcessorTransaction = execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class);
			String sftpHost = execution.getVariable(Workflow.SFTP_HOSTNAME, String.class);
			String sftpUSER = execution.getVariable(Workflow.SFTP_USERNAME, String.class);
			String sftpPASS = execution.getVariable(Workflow.SFTP_PW, String.class);
			String ftpWorkingDir = execution.getVariable(Workflow.SFTP_ROOT_DIRECTORY, String.class);
			String archiveWorkingDir = execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class);
			Integer maxSftpTriesVar = execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class);
			Integer retryTimeSecsVar = execution.getVariable(Workflow.RETRY_TIME_SECS, Integer.class);
			int maxSftpTries = maxSftpTriesVar != null ? maxSftpTriesVar : 10;
			int retryTimeSecs = retryTimeSecsVar != null ? retryTimeSecsVar: 360;  // 6 minutes

			executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Cleanup CSV files", csvProcessorTransaction);
			message = new HashMap<>();
			
			try {
				workFlowUtil.moveFileFromLocalToSFTPLocation(sftpUSER, sftpPASS, sftpHost, SFTP_PORT, archiveWorkingDir, csvProcessorTransaction.getLocation() + File.separator + csvProcessorTransaction.getFileName(), maxSftpTries, retryTimeSecs);
				message.put(Workflow.OUTCOME_KEY, String.format("CSV File %s archive correctly after second try", csvProcessorTransaction.getFileName()));
			} catch (SftpException | JSchException e) {
				LOGGER.error("doExecute Error during SFTP process for Source csv to sftp {}={}, {}={} {}",
						DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
						CSV_PROCESSOR_TRANSACTION, getCsvProcessorTransactionId(csvProcessorTransaction),
						ExceptionUtils.getStackTrace(e));
				message.put(Workflow.OUTCOME_KEY, FILE_DID_NOT_ARCHIVE_MSG + getCsvFileName(csvProcessorTransaction));
				errorMetaDataService.writeToErrorCollection(execution, "CsvMoveOriginalToSFTP --> doExecute: " + e.getMessage());
				
			} catch (IOException e) {
				LOGGER.error("doExecute Could not close local file {}={}, {}={}, {}={} {}",
						DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
						CSV_PROCESSOR_TRANSACTION, getCsvProcessorTransactionId(csvProcessorTransaction),
						"fileName", getCsvFileName(csvProcessorTransaction),
						ExceptionUtils.getStackTrace(e));
				message.put(Workflow.OUTCOME_KEY, FILE_DID_NOT_ARCHIVE_MSG + getCsvFileName(csvProcessorTransaction));
				errorMetaDataService.writeToErrorCollection(execution, "CsvMoveOriginalToSFTP --> doExecute: " + e.getMessage());
			}
			
			
		} catch(Exception e) {
			LOGGER.error("doExecute Exception while executing CsvMoveOriginalToArchiveFolder task {}={}, {}={} {}",
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
					CSV_PROCESSOR_TRANSACTION, getCsvProcessorTransactionId(csvProcessorTransaction),
					ExceptionUtils.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, FILE_DID_NOT_ARCHIVE_MSG + getCsvFileName(csvProcessorTransaction));
			errorMetaDataService.writeToErrorCollection(execution, "CsvMoveOriginalToArchiveFolder --> doExecute: " + e.getMessage());
		} finally {
			
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(csvProcessorTransaction, executionRecord, message);
			 execution.setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, csvProcessorTransaction);
			csvProcessorService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
		}
		LOGGER.debug("CsvMoveOriginalToArchiveFolder-->doExecute-->EXIT");
	}

    protected String getCsvFileName(CsvProcessorTransaction csvProcessorTransaction) {
		return csvProcessorTransaction != null ? csvProcessorTransaction.getFileName() : "NULL";
    }

    protected String getDelegateExecutionId(DelegateExecution execution) {
		return execution != null ? execution.getId() : "NULL";
    }

    protected String getCsvProcessorTransactionId(CsvProcessorTransaction csvProcessorTransaction) {
		return csvProcessorTransaction != null ? csvProcessorTransaction.getId() : "NULL";
	}
}