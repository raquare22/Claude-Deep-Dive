package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.mongo.DocumentMetaData;

import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.eclipse.collections.impl.utility.LazyIterate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Service("IdentifyDocumentsFromDbUSPClaims")
public class IdentifyDocumentsFromDbUSPClaims extends OptumJavaDelegateBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(IdentifyDocumentsFromDbUSPClaims.class);

    private static final String DOCUMENTS_JSON_FILE_NAME = "Documents.json";

    private static final List<String> REQ_VARS = List.of(Workflow.SEARCH_CRITERIA, Workflow.SEARCH_WINDOW);
    String appIdentifier = "";

    @Autowired
    DocumentMetaDataService documentMetadataService;

    @Autowired
    EmailService emailService;
    
    @Autowired
    HookService hookService;

    public IdentifyDocumentsFromDbUSPClaims() {
        super(REQ_VARS);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("IdentifyDocumentsFromDb-->doExecute-->Enter");
        try {
            String documentSearchCriteria = execution.getVariable(Workflow.SEARCH_CRITERIA, String.class);
            String documentSearchWindow = execution.getVariable(Workflow.SEARCH_WINDOW, String.class);
			Integer maxDocumentsOccurs = execution.getVariable(Workflow.MAX_DOCUMENTS_OCCURS, Integer.class);
			Integer clientId = execution.getVariable(Workflow.CLIENT_ID, Integer.class);
			String hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
            String processKey = execution.getVariable(Workflow.PROCESS_KEY,String.class);
            
            Optional<Document> windowMap = validateInput(documentSearchWindow, execution);
            if (windowMap.isEmpty()) {
                addErrorMsg("IdentifyDocumentsFromDb-->doExecute-->documentSearchWindow variable is null or invalid",
                        "documentSearchWindow object is null or invalid");
                return;
            }
            var documentCriteriaFilter = WorkFlowUtil.getSearchWindowCriteria(documentSearchWindow);
            if (documentCriteriaFilter == null) {
                LOGGER.error("IdentifyDocumentsFromDb-->doExecute-->search_window is invalid");
                addErrorMsg("IdentifyDocumentsFromDb-->doExecute-->search_window is invalid", "search_window is invalid");
                return;
            }
            
            List<DocumentMetaData> documentList = null;
            
            if (maxDocumentsOccurs != null) {
            	documentList = documentMetadataService.getDocumentMetaData(documentSearchCriteria, documentCriteriaFilter, maxDocumentsOccurs);
            } else {
            	documentList = documentMetadataService.getDocumentMetaData(documentSearchCriteria, documentCriteriaFilter);
            }

            if (CollectionUtils.isEmpty(documentList)) {
                LOGGER.debug("IdentifyDocumentsFromDb-->doExecute-->documentList is null or empty; delegateExecutionId={}, documentSearchCriteria={}",
                        execution.getId(), documentSearchCriteria);
                String messgeKey = processKey + "_message";
                execution.setTransientVariable(messgeKey, "IdentifyDocumentsFromDb documentList is null or empty");
                setExitNow(execution);
                return;
            }
            
            Set<String> zipFiles=new HashSet<>();
            
            for(DocumentMetaData doc: documentList)
            {
            	String zipfilename=(String) doc.getMetadata().get("zipFileName");
            	zipFiles.add(zipfilename);
            }
            
            int spaceID = documentList.get(0).getSpaceId();
            HashMap<String, List<DocumentMetaData>> documentMapList=new HashMap<>();
            
            for (String zipFile : zipFiles) {
            	List<DocumentMetaData> documentListWithZipFiles = new ArrayList<>();
            	documentListWithZipFiles=documentMetadataService.getDocumentMetaDataByZipFileName(documentSearchCriteria, documentCriteriaFilter, zipFile, spaceID);
            	documentMapList.put(zipFile, documentListWithZipFiles);
            }


            
            execution.setTransientVariable("setofZipFile", zipFiles);
            
			// add list of documentIds to execution bus for reconciliation error message 
            List<String> docIds = new ArrayList<String>();
            documentMapList.forEach((zipFile, docList) -> {
                
            	docList.forEach(e -> docIds.add(e.getId()));
         });
            
			 execution.setTransientVariable("documentIds", docIds);
			 
			 
			 List<DocumentMetaData> zipFiledocumentList = new ArrayList<>();
			 documentMapList.forEach((zipFile, docList) -> {
				
	                
	            	docList.forEach(zipFiledocumentList::add);
	         });
			 
			 

            var adaptedList = LazyIterate.adapt(zipFiledocumentList);
            var documentIds = adaptedList.collect(DocumentMetaData::getId).toList();
            Integer spaceId = adaptedList.collect(DocumentMetaData::getSpaceId).getFirst();
            execution.setTransientVariable(Workflow.DOCUMENT_IDS_MESSAGE, documentIds.toString());
            LOGGER.debug("IdentifyDocumentsFromDb-->doExecute-->documentList has documents: documentIds={}", documentIds);

            String tempWorkingPath = WorkFlowUtil.getTemporaryWorkingPath(spaceId);
            var jsonFile = WorkFlowUtil.documentMapToFile(documentMapList, tempWorkingPath, DOCUMENTS_JSON_FILE_NAME);

            execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR, tempWorkingPath);
            execution.setTransientVariable(Workflow.JSON_FILE, jsonFile.getAbsolutePath());

            var hookExecutionMessage = new HashMap<>(Map.of(
					Workflow.IDENTIFY_DOCUMENTS_SUCCESS_MESSAGE, documentIds.toString()
            ));
			var hookExecutionRecord = new HashMap<>(Map.of(
                    Workflow.SPACE_ID, spaceId.toString(),
                    Workflow.HOOK_ID, hookId,
                    Workflow.APP_IDENTIFIER, appIdentifier,
                    Workflow.CLIENTID, clientId.toString()
            ));
			var hookExecutionRecordMetaData = HookTransactionUtil
					.getHookExecutionRecord(hookExecutionRecord, hookExecutionMessage, processKey);
			var hookTransactionMetaData = hookService
					.saveHookTransaction(HookTransactionUtil.createCronHookTransaction(hookExecutionRecordMetaData));
			 execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA, hookTransactionMetaData);
			
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing IdentifyDocumentsFromDb task {}={} {}",
                    "delegateExecutionId", execution.getId(),
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("IdentifyDocumentsFromDb-->doExecute-->Exception while executing IdentifyDocumentsFromDb task", WorkFlowUtil.getStackTrace(e));
            
        } finally {
            if (newErrors() && errorMap.size() > 1) {
                DelegateUtils.sendErrorNotification(execution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
            }
        }
        LOGGER.debug("IdentifyDocumentsFromDb-->doExecute-->Exit with var {}", execution.getVariableNames());
    }

    @SuppressWarnings("unchecked")
    private Optional<Document> validateInput(String executionBusData, DelegateExecution execution) {
        Document map = null;
        try {
            map = Document.parse(executionBusData);
        } catch (Exception e) {
            LOGGER.error("validateInput Input format is incorrect for the variable {}={} {}",
                    "executionBusData", executionBusData,
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("IdentifyDocumentsFromDb-->validateInput-->Input format is incorrect for the variable " + executionBusData, WorkFlowUtil.getStackTrace(e));
        }
        return Optional.ofNullable(map);
    }

}
