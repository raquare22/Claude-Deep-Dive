package com.optum.fds.paperless.java.delegate;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import org.springframework.data.mongodb.core.query.Criteria;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("MatchAndMerge")
public class MatchAndMerge extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MatchAndMerge.class);
	
	private static final List<String> REQ_VARS = List.of(
            Workflow.MATCH_CRITERIA,
            Workflow.SEARCH_WINDOW,
            Workflow.DOCUMENT_IDS
    );
	
	@Autowired
    DocumentMetaDataService documentMetaDataService;
    
    DelegateExecution tempExecution;
    
    public MatchAndMerge() {
        super(REQ_VARS);
    }
    
    @Override
    protected void doExecute(DelegateExecution execution) {
    	tempExecution = execution;
    	String matchCriteria = execution.getVariable(Workflow.MATCH_CRITERIA, String.class);
        String searchWindow = execution.getVariable(Workflow.SEARCH_WINDOW, String.class);
    	List<String> matchDocumentIds = execution.getVariable(Workflow.DOCUMENT_IDS, List.class);
    	
    	try {
        	List<DocumentMetaData> matchDocumentMetaDataList = documentMetaDataService.getDocumentMetaDataList(matchDocumentIds);
        	if (matchDocumentMetaDataList.isEmpty()) {
        		LOGGER.debug("MatchAndMerge matchDocumentMetaDataList is null or empty");
        		setExitNow(execution);
        		return;
        	}
        	
        	Criteria searchWindowCriteria = getSearchWindowCriteria(searchWindow);
    		if (searchWindowCriteria == null) {
    			LOGGER.debug("MatchAndMerge no search window criteria for searchWindow={}", searchWindow);
    			setExitNow(execution);
    			return;
    		}
    		
    		List<String> docLibPutDocumentIds = new ArrayList<>();
            
        	for (DocumentMetaData matchDocument : matchDocumentMetaDataList) {
        		
        		// take matchDocument, get searchCriteria
        		String searchCriteria = getSearchCriteria(matchDocument, matchCriteria);
        		if (searchCriteria == null) {
        			LOGGER.warn("MatchAndMerge no search criteria for matchDocument={}, matchDocumentId={}, matchCriteria={}", matchDocument, matchDocument.getId(), matchCriteria);
        			continue;
        		}
        		
        		// if found document, then update metadata save to list for bulk update to mongo?
        		List<DocumentMetaData> matchedDocumentList = documentMetaDataService.getDocumentMetaData(searchCriteria, searchWindowCriteria);
        		List<String> completedMergeDocumentIds = mergeDocuments(matchedDocumentList, matchDocument);
        		docLibPutDocumentIds.addAll(completedMergeDocumentIds);
        	}
        	execution.setVariable(Workflow.DOCLIB_PUT_DOCUMENT_IDS, docLibPutDocumentIds);

    	} catch (Exception e) {
    		LOGGER.error("MatchAndMerge-->doExecute-->exception={}", ExceptionUtils.getStackTrace(e));
    		addErrorMsg("Exception", e.getMessage());
    	}
    }
    
    private List<String> mergeDocuments(List<DocumentMetaData> matchedDocumentList, DocumentMetaData matchedDocument) {
    	LOGGER.info("MatchAndMerge mergeDocuments found documents to merge matchedDocument={}, matchedDocumentList={}", matchedDocument, matchedDocumentList);
    	List<String> updatedDocumentIds = new ArrayList<>();
    	for(DocumentMetaData doc : matchedDocumentList) {
    		// merge documents
    		doc.getMetadata().putAll(matchedDocument.getMetadata());
    		DocumentMetaData updatedDoc = documentMetaDataService.saveDocumentMetaData(doc);
    		updatedDocumentIds.add(updatedDoc.getId());
    	}
    	return updatedDocumentIds;
    }
    
    private Criteria getSearchWindowCriteria(String searchWindow) throws IOException, ParseException {
        if (validateJsonString(searchWindow) == null) {
            LOGGER.error("MatchAndMerge-->doExecute-->search window is invalid");
            return null;
        }

        Criteria searchWindowCriteria = WorkFlowUtil.getSearchWindowCriteria(searchWindow);
        if (searchWindowCriteria == null) {
            LOGGER.error("MatchAndMerge-->doExecute-->unable to create search window criteria");
            return null;
        }
        return searchWindowCriteria;
    }
    
    private String getSearchCriteria(DocumentMetaData matchDocument, String matchCriteria) {
        String searchCriteria;
        try {
            var documentJsonString = Parser.toJson(matchDocument, "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
            searchCriteria = WorkFlowUtil.replacePlaceHolders(matchCriteria, documentJsonString);
            if (validateJsonString(searchCriteria) == null) {
                LOGGER.error("MatchAndMerge-->doExecute-->match criteria is invalid after replacing placeholders");
                return null;
            }
        } catch (Exception e) {
            LOGGER.error("MatchAndMerge doExecute Expection while replacing placeholders in match criteria matchDocumentId={}, matchCriteria={}, e={}", matchDocument.getId(), matchCriteria, ExceptionUtils.getStackTrace(e));
            addErrorMsg("Exception: ", e.getMessage());
            return null;
        }
        return searchCriteria;
    }
    
    protected HashMap<String, Object> validateJsonString(String jsonString) {
        HashMap<String, Object> map = null;
        try {
            map = Parser.parseJson(jsonString, new TypeReference<>() {});
        } catch (IOException e) {
            LOGGER.error("validateJsonString Exception while executing MatchAndMergeDocumentsFromDB task {}={} {}", "jsonString", jsonString, ExceptionUtils.getStackTrace(e));
            addErrorMsg("MatchAndMerge-->validateJsonString-->Input format is incorrect for " + jsonString, WorkFlowUtil.getStackTrace(e));
        }
        return map;
    }

}
