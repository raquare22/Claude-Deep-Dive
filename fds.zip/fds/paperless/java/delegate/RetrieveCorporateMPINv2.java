package com.optum.fds.paperless.java.delegate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.provider.ProviderSearch;
import com.optum.fds.paperless.provider.pojo.Request;
import com.optum.fds.paperless.provider.pojo.RequestBody;
import com.optum.fds.paperless.provider.pojo.RequestHeader;
import com.optum.fds.paperless.workflow.constants.OptumProcessEnum;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("RetrieveCorporateMPINv2")
public class RetrieveCorporateMPINv2 extends OptumJavaDelegateBase {
	private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveCorporateMPINv2.class);
	private static final String PADDING_0 = "0";
	private static final List<String> REQ_VARS = List.of(
			Workflow.PROV_APP_NAME, Workflow.PROV_ATTRIBUTE_SET,
	  Workflow.PROV_COUNT, Workflow.PROV_SEARCH_URL
	 
	);
	
	@Value("${TRACKIT_SPACEID}")
    private String trackitSpaceId;

	@Value("${PRUN.EMAIL_WORKFLOW_SPACEID}")
	private List<String> emailWorkflowSpaceIds;
	
	@Value("${PRUN.TRACKIT_MNR_SPACEID}")
	private List<String> trackItAndMnrSpaceIds;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private EhCache ehcache;
	
	@Autowired
	private HookService hookService;

	@Autowired
	private DocumentMetaDataService documentMetaDataService;
	
	@Autowired
	private OauthManagerUtil oauthManagerUtil;

	@Value("${MPIN_PES_TPS:60}")
	private int mpinPesTps;

	@Value("${ALINK_SPACEID}")
    private String alinkSpaceId;

	@Value("${SSBCI_SPACEID}")
	private String ssbciSpaceId;

    @Value("${PRUN.CONSUMER_ENGINEERING_SPACEID}")
    private String pcpMemberReferralSpaceId;
	
	private static final String MISSING_OR_INVALID_DATA = "Missing or invalid data: ";
	private static final String METADATA_PREFIX = "metadata.";


	public RetrieveCorporateMPINv2() {
		super(REQ_VARS);
	}

	@Override
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("RetrieveCorporateMPINv2 delegate");
		
		String tin = StringUtils.EMPTY;
		HookTransactionMetaData hookTransactionMetaData = null;
		var hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
		var docId = execution.getVariable(Workflow.DOCID, String.class);

		
		String spaceId = execution.getVariable(Workflow.SPACE_ID).toString();
		
		List<DocumentMetaData> documentMetaDataObjectList = null;
        
        Map<String, List<String>> groupedByMetadataMap = null;
        
        if (spaceId != null && emailWorkflowSpaceIds.contains(spaceId)){
        	documentMetaDataObjectList = (List<DocumentMetaData>) execution.getVariable("uniqueFieldDocumentList");
        	groupedByMetadataMap = (Map<String, List<String>>) execution.getVariable("uniqueFieldMap");
        } else {
    		String[] docArr = docId.split(",");
    		List<String> docList = Arrays.asList(docArr);
        	documentMetaDataObjectList = documentMetaDataService.getDocumentMetaDataList(docList);
        }

		
		for (DocumentMetaData documentMetaDataObject : documentMetaDataObjectList) {
			LOGGER.info("Processing document. delegate=RetrieveCorporateMPINv2 docId={}", documentMetaDataObject.getId());
			try {
				var metadata = documentMetaDataObject.getMetadata();
				var corporateMpinMetaData = metadata.getString(Workflow.PROV_CORP_MPIN);
		    tin = metadata.getString(Workflow.TIN);
			var validateCorprateMPIN = Boolean
					.parseBoolean(String.valueOf(execution.getVariable(Workflow.VALIDATE_CORPORATE_MPIN)));

			if (StringUtils.isNotBlank(corporateMpinMetaData)) {
				execution.setTransientVariable(Workflow.PROV_CORP_MPIN, corporateMpinMetaData);
				hookTransactionMetaData = hookService.findHookTransactionByTargetIdHookId(docId, hookId);
				if(hookTransactionMetaData!=null) {
					execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, hookTransactionMetaData.getId());
				}
				continue;
			}

			if (StringUtils.isEmpty(tin)) {
				LOGGER.warn("tin is empty for docId {}", documentMetaDataObject.getId());
				Map<String, String> hookExecutionMessage = new HashMap<>();
				hookExecutionMessage.put(Workflow.TIN, tin);
				hookExecutionMessage.put(Workflow.ERROR_MESSAGE, "tin is empty");
				hookTransactionMetaData = hookService.saveHookTransaction(HookTransactionUtil
						.createHookTransactionWithHookId(documentMetaDataObject, hookExecutionMessage,
								OptumProcessEnum.RETRIEVE_CORPORATE_MPIN_V2_PROCESS.toString(), hookId));
				execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, hookTransactionMetaData.getId());
			}

			if (spaceId != null && (spaceId.equals(alinkSpaceId) || spaceId.equals(ssbciSpaceId) || spaceId.equals(pcpMemberReferralSpaceId))) {
				var corporateMpin = ehcache.getCorpMpinCache(formatTin(tin));
				if (StringUtils.isEmpty(corporateMpin)) {
						LOGGER.debug("Corporate MPIN is missing. Fetching from PES API for TIN = {}", tin);
						corporateMpin = getMpinFromSvcs(execution, tin, RateLimiter.create(mpinPesTps));
						if (StringUtils.isNotEmpty(corporateMpin)) {
							ehcache.putCorpMpinCache(tin, corporateMpin);
						} else {
							LOGGER.error("Failed to retrieve Corporate MPIN for TIN = {}", tin);
						}
				}
				verifyCorporateMpinEmptyOrNot(execution, corporateMpin, metadata, documentMetaDataObject, hookTransactionMetaData, tin, validateCorprateMPIN);
			}
			
		  else if(spaceId != null && trackItAndMnrSpaceIds.contains(spaceId)) {
	            	
	           Map<String,String> physicianInfoMap = getMpinAndProviderOrgNameFromSvcs(execution, tin, RateLimiter.create(mpinPesTps));
	           
	           String providerName = "";
	           String corporateMpin = "";
	           
	           if (physicianInfoMap != null && !physicianInfoMap.isEmpty()) {
	        	   providerName = physicianInfoMap.get("providerName");
	        	   corporateMpin = physicianInfoMap.get("corporateMpin");
	           }
	           
			  verifyCorporateMpinEmptyOrNotTrackIt(execution, corporateMpin, documentMetaDataObject, 
					  hookTransactionMetaData, tin, groupedByMetadataMap, providerName);
	
	          }
			
		 else {
				
			    var corporateMpin = ehcache.getCorpMpinCache(formatTin(tin));
			    if (StringUtils.isEmpty(corporateMpin)) {
				LOGGER.debug("Invoking Corporate MPIN retrieve service for tin= {}", tin);
				corporateMpin = getMpinFromSvcs(execution, tin, RateLimiter.create(mpinPesTps));
				ehcache.putCorpMpinCache(tin, corporateMpin);
				
			    } else {
				   LOGGER.info("Picked from the cache for tin={}", tin);
			     }
			  
			    verifyCorporateMpinEmptyOrNot(execution, corporateMpin, metadata, documentMetaDataObject, hookTransactionMetaData, tin, validateCorprateMPIN);
            
			}				
				LOGGER.info("Completed processing document. delegate=RetrieveCorporateMPINv2 docId={}", documentMetaDataObject.getId());
		} catch (Exception e) {
			setExecutionError(execution, e.getMessage());
			LOGGER.error("RetrieveCorporateMPIN Error: {} - {} - {}  ",
					Encode.forJava((String) execution.getVariable("executionErrorSourceModule")),
					Encode.forJava((String) execution.getVariable("executionErrorCode")),
					Encode.forJava((String) execution.getVariable("executionErrorMsg")), e);
			
			Map<String, String> hookExecutionMessage = new HashMap<>();
			hookExecutionMessage.put(Workflow.ERROR_MESSAGE, ExceptionUtils.getStackTrace(e));
			hookExecutionMessage.put(Workflow.TIN, tin);
			hookExecutionMessage.put(Workflow.COMMON_STATUS, "ERROR");
			
			hookTransactionMetaData = hookService.saveHookTransaction(
					HookTransactionUtil.createHookTransactionWithHookId(documentMetaDataObject, hookExecutionMessage,
							OptumProcessEnum.RETRIEVE_CORPORATE_MPIN_V2_PROCESS.toString(), hookId));
			execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA, hookTransactionMetaData);
			LOGGER.error("doExecute RetrieveCorporateMPIN terminated with an ERROR {}={} {}", "delegateExecutionId",
					execution.getId(), ExceptionUtils.getStackTrace(e));
			LOGGER.info("Corporate MPIN process completed inside catch TIN: {}, DocumentId: {}", tin, documentMetaDataObject.getId());
		}
		
		}	
	}
	
	public void updateHookTransaction(DelegateExecution execution, String tin, String corporateMpin, HookTransactionMetaData hookTransactionMetaData, DocumentMetaData documentMetaDataObject) {
		// update hookTransaction
		var hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
		Map<String, String> hookExecutionMessage = new HashMap<>();
		hookExecutionMessage.put(Workflow.TIN, tin);
		hookExecutionMessage.put("corporateMpin", corporateMpin);

		hookTransactionMetaData = hookService.saveHookTransaction(HookTransactionUtil
				.createHookTransactionWithHookId(documentMetaDataObject, hookExecutionMessage,
						OptumProcessEnum.RETRIEVE_CORPORATE_MPIN_V2_PROCESS.toString(), hookId));
		execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, hookTransactionMetaData.getId());

	}
	
	public void verifyCorporateMpinEmptyOrNot(DelegateExecution execution,String corporateMpin, Document metadata, DocumentMetaData documentMetaDataObject, 
			HookTransactionMetaData hookTransactionMetaData, String tin, boolean validateCorprateMPIN ) {
		
	    
		if (StringUtils.isNotEmpty(corporateMpin)) {
			corporateMpin = StringUtils.leftPad(corporateMpin, 9, PADDING_0);
			metadata.put(Workflow.PROV_CORP_MPIN, corporateMpin);
			documentMetaDataObject.setMetadata(metadata);
			execution.setTransientVariable(Workflow.PROV_CORP_MPIN, corporateMpin);
			documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
			
			
		} else {
			// throw severe error, return for PRAs ONLY. flag definition
			validateCorporateMpin(validateCorprateMPIN, documentMetaDataObject, execution, metadata);
			documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);

		}
		
		// update hookTransaction
		updateHookTransaction(execution, tin, corporateMpin, hookTransactionMetaData, documentMetaDataObject);
		LOGGER.info("Corporate MPIN process completed DocumentId: {}", documentMetaDataObject.getId());
	  
	}
	
	
	public void verifyCorporateMpinEmptyOrNotTrackIt(DelegateExecution execution,String corporateMpin, DocumentMetaData documentMetaDataObject, 
			HookTransactionMetaData hookTransactionMetaData, String tin, Map<String, List<String>> groupedByMetadataMap, String providerName) {
	    var hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
	    
	    org.bson.Document metadata = documentMetaDataObject.getMetadata();
	    
	    Map<String, Object> updateMap = new HashMap<>();
	    
		if (StringUtils.isNotEmpty(corporateMpin)) {
			corporateMpin = StringUtils.leftPad(corporateMpin, 9, PADDING_0);
			// multi update all documents with the same TIN
			updateMap.put(METADATA_PREFIX + Workflow.PROV_CORP_MPIN, corporateMpin);
			updateMap.put(METADATA_PREFIX + "providerName", providerName);
	    	List<String> documentIdsUpdateList = groupedByMetadataMap.get(tin);			
			documentMetaDataService.saveDocumentMetaDataMulti(documentIdsUpdateList, updateMap);
			
			execution.setTransientVariable(Workflow.PROV_CORP_MPIN, corporateMpin);
			
		} else {
			// update eDeliveryError for all documents with the same TIN			
        	String eDeliveryError = metadata.getString(Workflow.E_DELIVERY_ERROR);
            String errorMessage = MISSING_OR_INVALID_DATA + Workflow.PROV_CORP_MPIN;
            if (StringUtils.isBlank(eDeliveryError)) {
            	updateMap.put(METADATA_PREFIX + Workflow.E_DELIVERY_ERROR, errorMessage);
            } else {
                if (!eDeliveryError.contains(errorMessage)) {
                	updateMap.put(METADATA_PREFIX + Workflow.E_DELIVERY_ERROR, eDeliveryError + "|" + errorMessage);
                }
            }
            
            
            List<String> documentIdsUpdateList = groupedByMetadataMap.get(tin);
            if (!updateMap.isEmpty()) {
    			documentMetaDataService.saveDocumentMetaDataMulti(documentIdsUpdateList, updateMap);
    		}
		}
		
		// update hook transaction
		updateHookTransaction(execution, tin, corporateMpin, hookTransactionMetaData, documentMetaDataObject);
		LOGGER.info("Corporate MPIN process completed DocumentId: {}", documentMetaDataObject.getId());
	  
		
	}
	
	public void validateCorporateMpin(boolean validateCorprateMPIN, DocumentMetaData documentMetaDataObject, DelegateExecution execution, Document metadata) {
		// throw severe error, return for PRAs ONLY. flag definition
		if (validateCorprateMPIN) {
			documentMetaDataObject.setStatus(MetaDataStatus.SEVERE_ERROR);
			setExecutionError(execution, "Missing or invalid data: Provider TIN (Severe)");
		} else {
			WorkFlowUtil.updateEDeliveryError(metadata, Workflow.PROV_CORP_MPIN);
			documentMetaDataObject.setMetadata(metadata);
		}
	}

	public String getMpinFromSvcs(DelegateExecution execution, String tin, RateLimiter rateLimiter) {
		LOGGER.debug("Invoking Corporate MPIN retrieve service for tin = {}", tin);
		var request = createRequest(execution, tin);
		var ps = new ProviderSearch(execution.getVariable(Workflow.PROV_SEARCH_URL, String.class),
				restTemplate, oauthManagerUtil, ehcache);
		try {
			rateLimiter.acquire();
			return ps.getProviderCorpMpin(request.getRequestBody(), request.getRequestHeader(), execution);
		} catch (Exception e) {
			LOGGER.error("getMpinFromSvcs Error in retrieveing corporate mpin {}={}, {}={} {}", "delegateExecutionId",
					execution.getId(), "tin", tin, ExceptionUtils.getStackTrace(e));
			return null;
		}
	}
	
	public Map<String,String> getMpinAndProviderOrgNameFromSvcs(DelegateExecution execution, String tin, RateLimiter rateLimiter) {
		LOGGER.debug("Invoking provider details retrieve service for tin = {}", tin);
		var request = createRequest(execution, tin);
		var ps = new ProviderSearch(execution.getVariable(Workflow.PROV_SEARCH_URL, String.class),
				restTemplate, oauthManagerUtil, ehcache);
		try {
			rateLimiter.acquire();
			return ps.getProviderCorpMpinAndProviderOrg(request.getRequestBody(), request.getRequestHeader(), execution);
		} catch (Exception e) {
			LOGGER.error("getMpinAndProviderOrgNameFromSvcs Error in retrieveing provider data {}={}, {}={} {}", "delegateExecutionId",
					execution.getId(), "tin", tin, ExceptionUtils.getStackTrace(e));
			return null;
		}
	}
	


	private Request createRequest(DelegateExecution execution, String tin) {
		
		var pesAppId = execution.getVariable(Workflow.PES_APP_ID, String.class);
        var pesAppSecret = execution.getVariable(Workflow.PES_APP_SECRET, String.class);
        var pesUrl = execution.getVariable(Workflow.PES_OAUTH_URL, String.class);
        var pesGrantType = execution.getVariable(Workflow.PES_GRANT_TYPE, String.class);
        
        String accessToken = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId, pesAppSecret, pesGrantType, pesUrl, false, null);

		var requestHeader = new RequestHeader.RequestHeaderBuilder().setToken(accessToken).build();

		var requestBody = new RequestBody.RequestBodyBuilder()
				.setAppName(execution.getVariable(Workflow.PROV_APP_NAME, String.class))
				.setAttributeSet(execution.getVariable(Workflow.PROV_ATTRIBUTE_SET, String.class))
				.setCount(execution.getVariable(Workflow.PROV_COUNT, String.class)).setTaxIdNumber(tin).build();

		return new Request.RequestBuilder().setRequestBody(requestBody).setRequestHeader(requestHeader).build();
	}

	private void setExecutionError(DelegateExecution execution, String message) {
		execution.setTransientVariable("executionErrorSourceModule", "RetrieveCorporateMPINv2");
		execution.setTransientVariable("executionErrorCode", "RetrieveCorporateMPIN_V2 error");
		execution.setTransientVariable("executionErrorMsg", message);
	}

	public String formatTin(String tin) {
		String trimmedTin = tin.trim();
		return trimmedTin.length() == 14 ? trimmedTin.substring(0, 9) : trimmedTin;
	}
}

