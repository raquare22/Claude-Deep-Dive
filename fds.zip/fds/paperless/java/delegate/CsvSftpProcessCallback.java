package com.optum.fds.paperless.java.delegate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.model.GenericResponse;

import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;

import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("CsvSftpProcessCallback")
public class CsvSftpProcessCallback extends OptumJavaDelegateBase {
	private static final Logger LOGGER = LoggerFactory.getLogger(CsvSftpProcessCallback.class);

	@Autowired
	CsvProcessorsService csvProcessorsService;

	@Autowired
	CsvProcessorService csvProcessorService;

	@Autowired
	CsvCleanupFilesProcess csvCleanupFilesProcess;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;

	public CsvSftpProcessCallback() {
		// super(REQ_VARS);
	}

	@Override
	public void doExecute(DelegateExecution execution) {
		var genericResponse = (GenericResponse) execution.getVariable("response");
		String statusCode = genericResponse.getStatusCode();
		String statusMessage = genericResponse.getStatusMessage();
		String response = (String) genericResponse.getResponse();

		String documentId = null;
		String mongoResponse = "statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", response=" + response;
		if (statusCode.contentEquals("200")) {
			try {
				@SuppressWarnings("unchecked")
				Map<String, Object> responseDetailMap = new ObjectMapper().readValue(response, HashMap.class);
				documentId = (String) responseDetailMap.get("id");
				
				// add list of documentIds to execution bus for reconciliation error message 
				List<String> documentIds = List.of(documentId);
				 execution.setTransientVariable("documentIds", documentIds);
				
			} catch (JsonProcessingException e) {
				LOGGER.error("responseDetailMap error: {}", e.getMessage());
				statusCode = HttpStatus.PROCESSING.name();
				statusMessage = e.getMessage();
				response = statusMessage;
				
				errorMetaDataService.writeToErrorCollection(execution, "CsvSftpProcessCallback --> doExecute: " + e.getMessage());
			}
		}

		LOGGER.info("CALLBACK: documentId={}, statusCode={}, statusMessage={}, response={}", documentId, statusCode, statusMessage, response);
		LOGGER.info(
				"CALLBACK: {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}",
				Workflow.REST_JSON_FILE_NAME, execution.getVariable(Workflow.REST_JSON_FILE_NAME),
				Workflow.REST_CSV_FILE_NAME, execution.getVariable(Workflow.REST_CSV_FILE_NAME), Workflow.REST_TRX_ID,
				execution.getVariable(Workflow.REST_TRX_ID), Workflow.REST_CSV_PROCESSOR_ROW_TASK,
				execution.getVariable(Workflow.REST_CSV_PROCESSOR_ROW_TASK), Workflow.REST_LAST_RECORD,
				(Boolean) (execution.getVariable(Workflow.REST_LAST_RECORD)), Workflow.SFTP_HOSTNAME,
				execution.getVariable(Workflow.SFTP_HOSTNAME), Workflow.SFTP_USERNAME,
				execution.getVariable(Workflow.SFTP_USERNAME), Workflow.SFTP_PW,
				execution.getVariable(Workflow.SFTP_PW), Workflow.SFTP_ROOT_DIRECTORY,
				execution.getVariable(Workflow.SFTP_ROOT_DIRECTORY), Workflow.SFTP_ARCHIVE_DIRECTORY,
				execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY), Workflow.MAX_SFTP_TRIES,
				execution.getVariable(Workflow.MAX_SFTP_TRIES), Workflow.RETRY_TIME_SECS,
				execution.getVariable(Workflow.RETRY_TIME_SECS), Workflow.REST_REQUEST,
				execution.getVariable(Workflow.REST_REQUEST), Workflow.REST_RESPONSE,
				execution.getVariable(Workflow.REST_RESPONSE), Workflow.REST_STATUS,
				execution.getVariable(Workflow.REST_STATUS), Workflow.REST_TARGET_ID,
				execution.getVariable(Workflow.REST_TARGET_ID), Workflow.REST_TARGET_TYPE,
				execution.getVariable(Workflow.REST_TARGET_TYPE));

		String processorId = (String) execution.getVariable(Workflow.REST_TRX_ID);
		Integer recordNumber = (Integer) execution.getVariable(Workflow.REST_RECORD_NUMBER);
		Boolean lastRecord = (Boolean) execution.getVariable(Workflow.REST_LAST_RECORD);
		String csvFileName = (String) execution.getVariable(Workflow.REST_CSV_FILE_NAME);

		String rowTaskId = (String) execution.getVariable(Workflow.REST_CSV_PROCESSOR_ROW_TASK);
		LOGGER.debug("CALLBACK: rowTaskId={}", rowTaskId);
		var csvProcessorRowTask = csvProcessorService.getCsvProcessorRowTaskById(rowTaskId);
		if (documentId != null) {
			csvProcessorRowTask.setRestTargetId(documentId);
			csvProcessorRowTask.setIsRestApiSuccessful(true);
		} else {
			csvProcessorRowTask.setIsRestApiSuccessful(false);
		}
		csvProcessorRowTask.setResponse(mongoResponse);
		csvProcessorRowTask.setStatus(MetaDataStatus.COMPLETE);
		try {
			LOGGER.debug("CALLBACK: Calling updateCsvProcessorRowTask");
			csvProcessorsService.updateCsvProcessorRowTask(csvProcessorRowTask);
		} catch (Exception e) {
			LOGGER.error("writeCsvProcessorRowTask {}={}, {}={} {}", "delegateExecutionId", processorId,
					"csvProcessorRowTaskId", csvProcessorRowTask.getId(), ExceptionUtils.getStackTrace(e));
			addErrorMsg(Workflow.REST_ERROR_MSG, Workflow.REST_CSV_PROCESSOR_ROW_TASK_RECORD_NOT_UPDATED);
			addErrorMsg(Workflow.REST_ERROR_MSG, ExceptionUtils.getStackTrace(e));
			errorMetaDataService.writeToErrorCollection(execution, "CsvSftpProcessCallback --> doExecute: " + e.getMessage());
		}

		CsvProcessorTransaction csvProcessorTransaction = null;
		if (recordNumber.intValue() == 1 || lastRecord != null && lastRecord.booleanValue()) {
			csvProcessorTransaction = csvProcessorService.getCsvProcessorTransactionById(processorId);
			if (LOGGER.isInfoEnabled()) {
			LOGGER.debug("CALLBACK: processorId={}, csvProcessorTransaction={}", processorId,
					((csvProcessorTransaction)!= null ? csvProcessorTransaction.getId() : "NULL"));
			}
		} else if (lastRecord == null || ! lastRecord.booleanValue()) {
			LOGGER.debug("CALLBACK: NOT lastRecord; recordNumber={}", recordNumber);
			return;
		}

		if (csvProcessorTransaction != null) {
			if (recordNumber.intValue() == 1 && (lastRecord == null || ! lastRecord.booleanValue())) {
				LOGGER.debug("CALLBACK: NOT lastRecord; recordNumber={}; csvProcessorTransaction.id={}", recordNumber,
						csvProcessorTransaction.getId());
				var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord(
						"Callback delegate processing first record from queue", csvProcessorTransaction);
				ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService,
						csvProcessorTransaction, executionRecord);
				return;
			}
			LOGGER.debug("CALLBACK: Have lastRecord={}; csvProcessorTransaction.id={}", lastRecord, csvProcessorTransaction.getId());
			var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord(
					"Callback delegate processing last record from queue", csvProcessorTransaction);
			ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService, csvProcessorTransaction, executionRecord);

			 execution.setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, csvProcessorTransaction);
			LOGGER.debug("CALLBACK: CSV_CLEANUP_FILES_PROCESS");
			csvCleanupFilesProcess.doExecute(execution);
		} else {
			LOGGER.error(
					"CsvUpdateProcessorTransactionStatus-->doExecute-->csvProcessorTransaction null for fileName={}",
					csvFileName);
		}
	}
}
