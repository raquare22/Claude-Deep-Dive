package com.optum.fds.paperless.java.delegate;

import java.io.File;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

import com.newrelic.api.agent.Trace;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ScheduledSftpMonitor;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("SftpPPL")
public class SftpPPL extends OptumJavaDelegateBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(SftpPPL.class);

    @Value("${INGEST_ROOT}")
    private String ingestRoot;

    @Value("${MinFreeSpacePercentage}")
    protected Integer minFreeSpacePercentage;

    @Autowired
    ScheduledSftpMonitor scheduledSftpMonitor;
    
    @Autowired
    ErrorMetaDataService errorMetaDataService;
    
    @Autowired
    SftpUtil sftpUtil;

    private static final List<String> REQ_VARS = Collections.emptyList();

    public SftpPPL() {
        super(REQ_VARS);
    }

    public SftpPPL(ScheduledSftpMonitor scheduledSftpMonitor) {
        this.scheduledSftpMonitor = scheduledSftpMonitor;
    }

    @Override
    @Trace(dispatcher = true, metricName = "execute")
    public void doExecute(DelegateExecution execution) {
        long startTime = System.currentTimeMillis();
        var processorMetaData = (ProcessorMetaData) execution.getVariable("processorMetaData");

        Path filePath = new File(ingestRoot).toPath();
        boolean isFreeSpaceSufficient = sftpUtil.isEnoughFreeSpace(filePath, false);
        if (! isFreeSpaceSufficient) {
            LOGGER.error("FREESPACE: Not enough returning; filePath={}", filePath);
            setExitNow(execution);
            return;
        }

        try {
        	List<String> arrProcessorTransactionId = scheduledSftpMonitor.runSFTPMonitor(processorMetaData);
        	
        	if (arrProcessorTransactionId == null) {
        		setExitNow(execution);
        		return;
        	}
        	
            execution.setTransientVariable("processorMetaData", processorMetaData); 
            execution.setTransientVariable("processorTransactionIds", arrProcessorTransactionId);
			execution.setTransientVariable("Monitor_Message", "SUCCESS");
        } catch (Exception e) {
            LOGGER.error("doExecute {}={} {}",
                    "processorMetaDataId", processorMetaData != null ? processorMetaData.getTransactionId() : "NULL",
                    ExceptionUtils.getStackTrace(e));
            execution.setTransientVariable("Monitor_Message", "FAILURE");
            addErrorMsg("SftpMonitor Exception", e.getMessage());
            
            errorMetaDataService.writeToErrorCollection(execution, "Sftp --> doExecute: " + e.getMessage());
        }
        LOGGER.debug("Sftp executed");
        long endTime = System.currentTimeMillis();
        long duration = (endTime - startTime);
        LOGGER.debug("Sftp - execute: {}", duration);
    }



}