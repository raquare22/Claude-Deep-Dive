package com.optum.fds.paperless.java.delegate.oauth;

import com.optum.fds.paperless.java.delegate.OptumJavaDelegateBase;
import java.util.Arrays;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.optum.fds.paperless.workflow.constants.OptumTaskEnum;
import com.optum.fds.paperless.workflow.constants.Workflow;



@Service("Oauth")
public class Oauth extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(Oauth.class);

    @Autowired
    RestTemplate sslCheckRestTemplate;

    /*
     * Variables required to request an Oauth token.
     */
    private static final List<String> REQ_VARS = Arrays.asList (
            Workflow.CLIENT_ID,
            Workflow.CLIENT_SECRET,
            Workflow.GRANT_TYPE,
            Workflow.OAUTH_URL
    );

    public Oauth() {
        super(REQ_VARS);
    }

    @Override
    public void doExecute(DelegateExecution execution)  {
        LOGGER.debug("Entering Oauth Java Delegate");

        try {
            MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
            params.add("client_id", (String) execution.getVariable(Workflow.CLIENT_ID));
            params.add("client_secret", (String) execution.getVariable(Workflow.CLIENT_SECRET));
            params.add("grant_type", (String) execution.getVariable(Workflow.GRANT_TYPE));

            var headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params,headers);

            String url = (String) execution.getVariable(Workflow.OAUTH_URL);
            var builder = UriComponentsBuilder.fromUriString(url);

            OauthToken token = sslCheckRestTemplate.postForObject(builder.build().encode().toUri(), request, OauthToken.class);

            if (token != null) {

                //implemented this method to remove nested try blocks
                getToken(token,execution);

            }


        } catch (Exception e) {
        	 execution.setTransientVariable("executionErrorSourceModule", OptumTaskEnum.OAUTH_TASK.toString());
        	 execution.setTransientVariable("executionErrorCode", Workflow.OAUTH_ERROR_MESSAGE);
        	 execution.setTransientVariable("executionErrorMsg", e.getMessage());

            LOGGER.error("Oauth terminated with an ERROR ", e);

            addErrorMsg("executionError", e.getMessage());
        }

        LOGGER.debug("Oauth Java Delegate executed.");
    }

    private void getToken( OauthToken token, DelegateExecution execution) {
        try {
           
            execution.setTransientVariable(Workflow.OAUTH_TOKEN, token.getAccessToken());
        }
        catch (NullPointerException e) {
            LOGGER.warn("Oauth-->doExecute-->token null {}",e.getLocalizedMessage());
        }
    }

}
