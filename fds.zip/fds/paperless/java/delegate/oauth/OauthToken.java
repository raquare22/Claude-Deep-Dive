package com.optum.fds.paperless.java.delegate.oauth;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OauthToken implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty(value = "access_token") private String accessToken;
    @JsonProperty(value = "token_type") private String tokenType;
    @JsonProperty(value = "expires_in") private Integer expiresIn;
    @JsonProperty(value = "refresh_token") private String refresh_token;

    public String getAccessToken() {
        return accessToken;
    }
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
    public String getTokenType() {
        return tokenType;
    }
    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }
    public Integer getExpiresIn() {
        return expiresIn;
    }
    public void setExpiresIn(Integer expiresIn) {
        this.expiresIn = expiresIn;
    }
    public String getRefresh_token() {
        return refresh_token;
    }
    public void setRefresh_token(String refresh_token) {
        this.refresh_token = refresh_token;
    }
}
