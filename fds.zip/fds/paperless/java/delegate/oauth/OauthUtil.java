package com.optum.fds.paperless.java.delegate.oauth;

import java.nio.charset.StandardCharsets;

import org.apache.commons.codec.binary.Base64;

public class OauthUtil {

	public OauthUtil() {}
	
	public static String createAuthHeader(String username, String password){
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64( 
           auth.getBytes(StandardCharsets.US_ASCII));
        return "Basic " + new String( encodedAuth );
	}
}
