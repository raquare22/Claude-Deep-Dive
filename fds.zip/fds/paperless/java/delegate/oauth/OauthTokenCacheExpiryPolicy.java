package com.optum.fds.paperless.java.delegate.oauth;

import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import org.ehcache.expiry.ExpiryPolicy;
import java.util.function.Supplier;
import java.time.Duration;

public class OauthTokenCacheExpiryPolicy implements ExpiryPolicy<String, OauthTokenExtended> {

    @Override
    public Duration getExpiryForCreation(String key, OauthTokenExtended oauthToken) {
        long ttl = oauthToken.getExpiresIn().longValue() * 1000L;
        return ttl > 0 ? Duration.ofMillis(ttl) : Duration.ZERO;
    }

    @Override
    public Duration getExpiryForAccess(String key, Supplier<? extends OauthTokenExtended> value) {
        return null; // No change on access
    }

    @Override
    public Duration getExpiryForUpdate(String key, Supplier<? extends OauthTokenExtended> oldValue, OauthTokenExtended newValue) {
        return getExpiryForCreation(key, newValue);
    }
}

