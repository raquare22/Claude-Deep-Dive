package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service("MatchAndMergeDocumentsFromDB")
public class MatchAndMergeDocumentsFromDB extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(MatchAndMergeDocumentsFromDB.class);

    private static final String JSON_FILE_NAME = "UpdatedDocuments.json";

    private static final String TARGET_TYPE = "documents";

    private static final String DELEGATE_EXECUTION = "delegateExecutionId";
    private static final List<String> REQ_VARS = List.of(
            Workflow.JSON_FILE,
            Workflow.MATCH_CRITERIA,
            Workflow.SEARCH_WINDOW,
            Workflow.OUTPUT_FILE_DIR
    );

    @Autowired
    DocumentMetaDataService documentMetadataService;

    @Autowired
    EmailService emailService;

    @Autowired
    CsvProcessorsService csvProcessorsService;

    @Autowired
    ProcessorsService processorsService;

    @Autowired
    ProcessorService processorService;

    private DelegateExecution tempExecution;
    private List<DocumentMetaData> documentList;
    private Criteria searchWindowCriteria;

    public MatchAndMergeDocumentsFromDB() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        tempExecution = execution;
        LOGGER.debug("MatchAndMergeDocumentsFromDB-->doExecute-->ENTER");
        String matchCriteria = tempExecution.getVariable(Workflow.MATCH_CRITERIA, String.class);
        String searchWindow = tempExecution.getVariable(Workflow.SEARCH_WINDOW, String.class);
        String tempWorkingPath = tempExecution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class);
        String jsonFile = tempExecution.getVariable(Workflow.JSON_FILE, String.class);
        String templateName = tempExecution.getVariable(Workflow.TEMPLATE_NAME, String.class);

        try {
            if (getDocumentListFromJson(jsonFile) || getSearchWindowCriteria(searchWindow)) {
                return;
            }

            List<DocumentMetaData> documentUpdateList = new ArrayList<>();
            Set<String> csvProcessorTransactionFound = new HashSet<>();

			for (var document : documentList) {
				try {
					String companionFileName = getCompanionFileName(document);
					if (companionFileName.equals(StringUtils.EMPTY)) {
						continue;
					}
					String searchCriteria = getSearchCriteria(document, matchCriteria);
					if (searchCriteria == null) {
						continue;
					}
					if (checkCompanionFileIfPresent(csvProcessorTransactionFound, companionFileName, document)) {
						LOGGER.info("Found companion file={}, documentId={}", companionFileName, document.getId());
						List<DocumentMetaData> matchedDocumentList = documentMetadataService
								.getCsvDocumentMetaData(searchCriteria, searchWindowCriteria);
						if (!updateDocumentIfMatched(matchedDocumentList, document, companionFileName,
								documentUpdateList, templateName)) {
							LOGGER.info("! updateDocumentIfMatched return: companion file={}, documentId={}",
									companionFileName, document.getId());
							continue;
						}
					}
				} catch (Exception e) {
					LOGGER.error("Error to process companion record {} {}", document.getId(),
							ExceptionUtils.getStackTrace(e));
				}
			}

            if (documentUpdateList.isEmpty()) {
                LOGGER.warn("MatchAndMergeDocumentsFromDB-->doExecute-->documentUpdateList is null or empty");
                String messgeKey = tempExecution.getVariable(Workflow.PROCESS_KEY) + "_message";
                tempExecution.setTransientVariable(messgeKey, "documentUpdateList is null or empty");
                setExitNow(execution);
            } else {
                var updatedJsonFile = WorkFlowUtil.documentListToFile(documentUpdateList, tempWorkingPath, JSON_FILE_NAME);
                tempExecution.setTransientVariable(Workflow.JSON_FILE, updatedJsonFile.getAbsolutePath());
            }
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing MatchAndMergeDocumentsFromDB task {}={} {}",
                    DELEGATE_EXECUTION, tempExecution.getId(),
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("MatchAndMergeDocumentsFromDB-->doExecute-->Exception while executing MatchAndMergeDocumentsFromDB task", WorkFlowUtil.getStackTrace(e));
        } finally {
            finish();
        }
        LOGGER.debug("MatchAndMergeDocumentsFromDB-->doExecute-->EXIT: jsonFile={}, var={}", tempExecution.getVariable(Workflow.JSON_FILE), tempExecution.getVariableNames());
    }

    private void finish() {
        if (newErrors() && errorMap.size() > 1) {
            DelegateUtils.sendErrorNotification(tempExecution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(tempExecution), emailService);
        }
    }

    protected boolean updateDocumentIfMatched(List<DocumentMetaData> matchedDocumentList, DocumentMetaData document, String companionFileName,
           List<DocumentMetaData> documentUpdateList, String templateName) {
        if (CollectionUtils.isEmpty(matchedDocumentList)) {
            LOGGER.warn("Unable to find companionFileName={} for documentId={}", companionFileName, document.getId());
            return true;
        }
        LOGGER.debug("Have companionFileName={}, documentId={}", companionFileName, document.getId());

        String companionFileData = TemplateFactory.getInstance(templateName).convertWithTemplate(matchedDocumentList);
        LOGGER.debug("Converted companionFileData={}, documentId={}", companionFileData, document.getId());
        if (companionFileData == null) {
            LOGGER.error("doExecute Unable to create companion file data using matchAndMerge template {}={}, {}={}",
                    DELEGATE_EXECUTION, tempExecution.getId(), "companionFileName", companionFileName);
            addErrorMsg("MatchAndMergeDocumentsFromDB-->doExecute-->Unable to create companion file data using matchAndMerge template", "companionFileData == null");
            return false;
        }
        JSONObject companionFileDataObj = new JSONObject(companionFileData);
        try {
            List<String> recordsList = Parser.readValue(String.valueOf(companionFileDataObj.getJSONArray("originalCompanionFileRecords")), List.class);
            document.getMetadata().put(Workflow.ORIGNIAL_COMPANION_FILE_RECORDS, recordsList);
        } catch (IOException e) {
            if(LOGGER.isErrorEnabled()) {
                LOGGER.error("unable to convert JSONArray to list {}={}, {}={}, JSONArray: {} {}",
                        DELEGATE_EXECUTION, tempExecution.getId(), "companionFileName", companionFileName,
                        companionFileDataObj.getJSONArray("originalCompanionFileRecords"), WorkFlowUtil.getStackTrace(e));
            }
        }
        documentUpdateList.add(document);
        return true;
    }

    private boolean getDocumentListFromJson(String jsonFile) {
        try {
            documentList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
        } catch (IOException e) {
            LOGGER.error("doExecute Unable to read documents from JSON File {}={} {}",
                    DELEGATE_EXECUTION, tempExecution.getId(),
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("MatchAndMergeDocumentsFromDB-->doExecute-->Unable to read documents from JSON File", WorkFlowUtil.getStackTrace(e));
            return true;
        }
        return false;
    }

    private boolean getSearchWindowCriteria(String searchWindow) throws IOException, ParseException {
        if (validateJsonString(searchWindow) == null) {
            LOGGER.error("MatchAndMergeDocumentsFromDB-->doExecute-->search window is invalid");
            addErrorMsg("MatchAndMergeDocumentsFromDB-->doExecute-->search window is invalid", "search window is invalid");
            return true;
        }

        searchWindowCriteria = WorkFlowUtil.getSearchWindowCriteria(searchWindow);
        if (searchWindowCriteria == null) {
            LOGGER.error("MatchAndMergeDocumentsFromDB-->doExecute-->unable to create search window criteria");
            addErrorMsg("MatchAndMergeDocumentsFromDB-->doExecute-->unable to create search window criteria", "unable to create search window criteria");
            return true;
        }
        return false;
    }

    private String getSearchCriteria(DocumentMetaData document, String matchCriteria) {
        String searchCriteria;
        try {
            var documentJsonString = Parser.toJson(document, "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
            searchCriteria = WorkFlowUtil.replacePlaceHolders(matchCriteria, documentJsonString);
            if (validateJsonString(searchCriteria) == null) {
                LOGGER.error("MatchAndMergeDocumentsFromDB-->doExecute-->match criteria is invalid after replacing placeholders");
                addErrorMsg("MatchAndMergeDocumentsFromDB-->doExecute-->match criteria is invalid after replacing placeholders",
                        "match criteria is invalid after replacing placeholders");
                return null;
            }
        } catch (Exception e) {
            LOGGER.error("doExecute Expection while replacing placeholders in match criteria {}={} {}",
                    DELEGATE_EXECUTION, tempExecution.getId(),
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("MatchAndMergeDocumentsFromDB-->doExecute-->Expection while replacing placeholders in match criteria", WorkFlowUtil.getStackTrace(e));
            return null;
        }
        return searchCriteria;
    }

    private boolean checkCompanionFileIfPresent(Set<String> csvProcessorTransactionFound, String companionFileName, DocumentMetaData document) {

        if (StringUtils.isEmpty(companionFileName)) {
            LOGGER.warn("companion file is empty for document {}", document.getId());
            return false;
        }

        if (csvProcessorTransactionFound.contains(companionFileName)) {
            LOGGER.debug("companion file already in queue {}", companionFileName);
            return true;
        }

        try {
            var opt = Optional.ofNullable(csvProcessorsService.getCsvProcessorTransactionWithFileName(companionFileName))
                    .filter(x -> x.getStatus().equals(MetaDataStatus.COMPLETE));
            if (opt.isPresent()) {
                csvProcessorTransactionFound.add(companionFileName);
                return true;
            }
        } catch (Exception e) {
            LOGGER.error(
                    "doExecute Unable to get csvProcessor Transaction using companion Filename {}={}, {}={} {}",
                    DELEGATE_EXECUTION, tempExecution.getId(),
                    "companionFileName", companionFileName, e.getMessage());
        }
        return false;
    }

    private String getCompanionFileName(DocumentMetaData document) {
        String documentId = document.getId();
        String appIdentifier = document.getAppIdentifier();
        return Optional.ofNullable(processorService.getProcessorFileTaskForTargetId(documentId, TARGET_TYPE, appIdentifier))
                .map(ProcessorFileTask::getProcessorTransactionId)
                .map(x -> {
                    LOGGER.debug("documentId: {} appIdentifier: {} processorTransactionId: {}", documentId, appIdentifier, x);
                    return x;
                })
                .map(processorsService::getTransactionProcessorById)
                .map(ProcessorTransaction::getFileName)
                .filter(x -> x.length() >= 10)
                .map(x -> x.substring(0, 10) + ".cmp")
                .orElse(StringUtils.EMPTY);

    }

    protected HashMap<String, Object> validateJsonString(String jsonString) {
        HashMap<String, Object> map = null;
        try {
            map = Parser.parseJson(jsonString, new TypeReference<>() {
            });
        } catch (IOException e) {
            LOGGER.error("validateJsonString Exception while executing MatchAndMergeDocumentsFromDB task {}={} {}",
                    "jsonString", jsonString,
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("MatchAndMergeDocumentsFromDB-->validateJsonString-->Input format is incorrect for " + jsonString, WorkFlowUtil.getStackTrace(e));
        }
        return map;
    }
}
