package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.PdfUtil;
import com.optum.fds.paperless.util.Utilities;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.optum.fds.paperless.workflow.constants.Workflow.*;

@Service("ManipulatePdfFile")
public class ManipulatePdfFile extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(ManipulatePdfFile.class);

    private static final SecureRandom random = new SecureRandom();
    private static final List<String> REQ_VARS = List.of(
            LIST_DOCUMENT_METADATA,
            SKIP_MANIPULATE_PDF_FILE,
            ADDRESS_BLOCK_X,
            ADDRESS_BLOCK_Y,
            IDENTIFIER_FONT_SIZE,
            RECEIVER_IDENTIFIER
    );
    private static final DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");

    public ManipulatePdfFile() {
        super(REQ_VARS);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void doExecute(DelegateExecution execution) {
        LOGGER.debug("ManipulatePdfFile-->ENTER");
        Map<String, String> correlationIDs = (Map<String, String>) execution.getVariable(CORRELATION_IDS);
        String correlationIDsString = Optional.ofNullable(correlationIDs)
                .map(o -> o.values().toString()).orElse("EMPTY");
        try {
            var skipManipulatePdfFile = Boolean.parseBoolean(String.valueOf(execution.getVariable(SKIP_MANIPULATE_PDF_FILE)));
            if (skipManipulatePdfFile) {
                LOGGER.info("ManipulatePdfFile-->Manipulation of PDF files not required for CorrelationIDs {} as skipManipulatePdfFile is {}", correlationIDsString, true);
                execution.setTransientVariable(MANIPULATE_PDF_FILE_MESSAGE, String.format("Manipulation of PDF files not required for CorrelationIDs %s as skipManipulatePdfFile is %s",
                        correlationIDsString, true));
                return;
            }

            var addressBlockX = (double) execution.getVariable(ADDRESS_BLOCK_X);
            var addressBlockY = (double) execution.getVariable(ADDRESS_BLOCK_Y);
            var fontSize = (double) execution.getVariable(IDENTIFIER_FONT_SIZE);
            var receiverIdentifier = execution.getVariable(RECEIVER_IDENTIFIER, String.class);
            var pdfUtilBuilder = new PdfUtil.PdfUtilBuilder()
                    .setxCoordinate(addressBlockX)
                    .setyCoordinate(addressBlockY)
                    .setFontSize((float)fontSize)
                    .setReceiverAddressIdentifier(receiverIdentifier);

            var listDocumentMetaData = (List<DocumentMetaData>) execution.getVariable(LIST_DOCUMENT_METADATA);
            if (writeToPDF(pdfUtilBuilder, listDocumentMetaData, execution, correlationIDs, correlationIDsString)) {
                return;
            }
            execution.setTransientVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
            LOGGER.debug("ManipulatePdfFile-->PDF files manipulated for CorrelationIDs {} as skipManipulatePdfFile is {}", correlationIDsString, false);
            execution.setTransientVariable(MANIPULATE_PDF_FILE_MESSAGE, String.format(
                    "PDF files manipulated for CorrelationIDs %s as skipManipulatePdfFile is %s", correlationIDsString, false));
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing ManipulatePdfFile task {}={} {}",
                    "delegateExecutionId", execution != null ? execution.getId() : "NULL",
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("ManipulatePdfFile-->doExecute-->Exception while executing ManipulatePdfFile task", e.getMessage());
            return;
        }
        LOGGER.debug("ManipulatePdfFile-->doExecute-->END");
    }

    private boolean writeToPDF(PdfUtil.PdfUtilBuilder pdfUtilBuilder, List<DocumentMetaData> listDocumentMetaData, DelegateExecution execution, Map<String, String> correlationIDs, String correlationIDsString) {
        var writeEncryptedPDF = Boolean.parseBoolean(String.valueOf(execution.getVariable(WRITE_ENCRYPTED_PDF)));
        var receiverIdentifier = pdfUtilBuilder.getReceiverAddressIdentifier();

        for (var documentMetaData : listDocumentMetaData) {
            var metaData = documentMetaData.getMetadata();
            var targetWorkingDir = metaData.getString(DOCUMENT_ABSOLUTE_PATH);
            
            // skipping pdf manipulation for those which don't have pdf
            if (metaData.getBoolean(SKIP_MANIPULATE_PDF_FILE, false)) {
                continue;
            }
            var clone = targetWorkingDir + "new" + DEFAULT_FILE_SEPARATOR;
            var tagLine = generateTagLine();

            var pdfReceiverIdentifier = receiverIdentifier + StringUtils.SPACE + tagLine;
            var isAnyAttachmentsGood = false;
            var isException = false;

            for (var attachmentMetaData : documentMetaData.getDocumentAttachments()) {
                var fileName = attachmentMetaData.getName();
                // setting PdfBuilder for current pdf
                pdfUtilBuilder.setReceiverAddressIdentifier(pdfReceiverIdentifier)
                        .setPdfFile(targetWorkingDir + fileName)
                        .setOutputPdf(clone + fileName);
                try {
                    LOGGER.info("createDirectoryAndWriteToPDF-->Creating working directory={}, fileName={}", clone, fileName);
                    createDirectoryAndWriteToPDF(writeEncryptedPDF, pdfUtilBuilder, clone);
                    isAnyAttachmentsGood = true;
                } catch (Exception e) {
                    var documentId = documentMetaData.getId();
                    LOGGER.error("doExecute Failed to append receiver identifier on the pdf file {}={}, {}={} {}",
                            "delegateExecutionId", execution.getId(),
                            "documentId", documentId,
                            ExceptionUtils.getStackTrace(e));
                    LOGGER.error("ManipulatePdfFile-->doExecute-->Failed to append receiver identifier on the pdf file for CorrelationID {} and error:{}",
                            Optional.ofNullable(correlationIDs).map(o -> o.get(documentId)).orElse(StringUtils.EMPTY), e.getMessage());
                    addErrorMsg("ManipulatePdfFile-->doExecute-->Failed to append receiver identifier on the pdf file", e.getMessage());
                    isException = true;
                    continue;
                }
                LOGGER.debug("ManipulatePdfFile added tagLine to the DocumentMetaData list for CorrelationID {}", correlationIDsString);
            }
            if (isAnyAttachmentsGood) {
                metaData.append(TAG_LINE, tagLine)
                        .append(DOCUMENT_ABSOLUTE_PATH, clone);
            }
            if (isException) {
                return true;
            }
        }
        return false;
    }

    private void createDirectoryAndWriteToPDF(boolean writeEncryptedPDF, PdfUtil.PdfUtilBuilder pdfUtilBuilder, String clone)
            throws IOException {
        Utilities.createWorkingDirectory(clone);
        var pdfUtil = pdfUtilBuilder.build();
        if (writeEncryptedPDF) {
            pdfUtil.writeOnEncryptedPdf();
        } else {
            pdfUtil.writeOnPdf();
        }
    }

    private String generateTagLine() {
        return LocalDateTime.now().format(format) + getSecureRandomNumber();
    }

    private String getSecureRandomNumber() {
        return String.format("%06d", random.nextInt(999999));
    }
}