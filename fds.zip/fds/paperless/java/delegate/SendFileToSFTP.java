package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.eclipse.collections.api.factory.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service("SendFileToSFTP")
public class SendFileToSFTP extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(SendFileToSFTP.class);

    private static final int SFTP_PORT = 22;
    private static final List<String> REQ_VARS = List.of(
            Workflow.SFTP_HOSTNAME,
            Workflow.SFTP_USERNAME,
            Workflow.SFTP_PW,
            Workflow.SFTP_DIRECTORY,
            Workflow.SFTP_FILE_LIST
    );

    @Autowired
    private EmailService emailService;
    
    @Autowired
    private SftpUtil sftpUtil;

    public SendFileToSFTP() {
        super(REQ_VARS);
    }


    public void doExecute(DelegateExecution execution) {
        LOGGER.debug("SendFileToSFTP-->doExecute-->ENTER");
        try {

            var sftpHost =  execution.getVariable(Workflow.SFTP_HOSTNAME, String.class);
            var sftpUser =  execution.getVariable(Workflow.SFTP_USERNAME, String.class);
            var sftpPass =  execution.getVariable(Workflow.SFTP_PW, String.class);
            var sftpTargetDir =  execution.getVariable(Workflow.SFTP_DIRECTORY, String.class);
            var sftpArchiveDir =  execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class);
            var sftpUserArc =  execution.getVariable(Workflow.SFTP_USERNAME_ARC, String.class);
            var sftpPassArc =  execution.getVariable(Workflow.SFTP_PW_ARC, String.class);
            var fileList = (List<String>) execution.getVariable(Workflow.SFTP_FILE_LIST);
            int maxSftpTries = Optional.ofNullable(execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class)).orElse(10);
            long retryTimeSecs = Optional.ofNullable(execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class)).orElse(360L); // 6 minutes

            if (fileList.isEmpty()) {
                LOGGER.error("SendFileToSFTP-->doExecute-->fileList is empty fileList is empty");
                addErrorMsg("SendFileToSFTP-->doExecute-->fileList is empty", "fileList is empty");
                return;
            }

            LOGGER.info("sftpTargetDir={}, sftpArchiveDir={}, fileList={}", sftpTargetDir, sftpArchiveDir, fileList);
            var params = new Params()
                    .setSftpPass(sftpPass)
                    .setSftpUser(sftpUser)
                    .setSftpUserArc(sftpUserArc)
                    .setSftpPassArc(sftpPassArc)
                    .setSftpArchiveDir(sftpArchiveDir)
                    .setMaxSftpTries(maxSftpTries)
                    .setRetryTimeSecs(retryTimeSecs)
                    .setSftpHost(sftpHost);

            for (var file : fileList) {
                LOGGER.debug("sftpTargetDir={}, sftpArchiveDir={}, file={}", sftpTargetDir, sftpArchiveDir, file);
                sftpUtil.moveFileFromLocalToSFTPLocation(sftpUser, sftpPass, sftpHost, SFTP_PORT, sftpTargetDir, file, maxSftpTries, retryTimeSecs);
                extracted(execution, params.setFile(file));
            }
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing Send Files to SFTP task {}={} {}",
                    "delegateExecutionId", execution != null ? execution.getId() : "NULL",
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("SendFileToSFTP-->doExecute-->Exception while executing Send Files to SFTP task", e.getMessage());
        } finally {
            if (newErrors() && errorMap.size() > 1) {
                DelegateUtils.sendErrorNotification(execution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
            }
        }
        LOGGER.debug("SendFileToSFTP-->doExecute-->EXIT");
    }

    private void extracted(DelegateExecution execution, Params params) {
        try {

            if (Lists.fixedSize.of(params.getSftpArchiveDir(), params.getSftpUserArc(), params.getSftpPassArc()).allSatisfy(StringUtils::isNotEmpty)) {
                LOGGER.debug("SendFileToSFTP-->doExecute-->sending file to archive directory with Arc user and pass; {}", params);
                sftpUtil.moveFileFromLocalToSFTPLocation(params.getSftpUserArc(), params.getSftpPassArc(), params.getSftpHost(), SFTP_PORT,
                        params.getSftpArchiveDir(), params.getFile(), params.getMaxSftpTries(), params.getRetryTimeSecs());
                LOGGER.debug("SendFileToSFTP-->doExecute-->file sent to archive directory with Arc user and pass");
            } else if (StringUtils.isNotEmpty(params.getSftpArchiveDir())) {
                LOGGER.debug("SendFileToSFTP-->doExecute-->sending file to archive directory; {}", params);
                sftpUtil.moveFileFromLocalToSFTPLocation(params.getSftpUser(), params.getSftpPass(), params.getSftpHost(), SFTP_PORT,
                        params.getSftpArchiveDir(), params.getFile(), params.getMaxSftpTries(), params.getRetryTimeSecs());
                LOGGER.debug("SendFileToSFTP-->doExecute-->file sent to archive directory; {}", params);

            }
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while sending file to archive directory {}={}, {}={}, {}={} {}",
                    "delegateExecutionId", execution != null ? execution.getId() : "NULL", "file", params.getFile(),
                    "sftpArchiveDir", params.getSftpArchiveDir(), ExceptionUtils.getStackTrace(e));
        }
    }

    class Params {
        private String sftpHost;
        private String sftpUser;
        private String sftpPass;
        private String sftpArchiveDir;
        private String sftpUserArc;
        private String sftpPassArc;
        private int maxSftpTries;
        private long retryTimeSecs;
        private String file;

        public String getSftpUser() {
            return sftpUser;
        }

        public Params setSftpUser(String sftpUser) {
            this.sftpUser = sftpUser;
            return this;
        }

        public String getSftpHost() {
            return sftpHost;
        }

        public Params setSftpHost(String sftpHost) {
            this.sftpHost = sftpHost;
            return this;
        }

        public String getSftpPass() {
            return sftpPass;
        }

        public Params setSftpPass(String sftpPass) {
            this.sftpPass = sftpPass;
            return this;
        }

        public String getSftpArchiveDir() {
            return sftpArchiveDir;
        }

        public Params setSftpArchiveDir(String sftpArchiveDir) {
            this.sftpArchiveDir = sftpArchiveDir;
            return this;
        }

        public String getSftpUserArc() {
            return sftpUserArc;
        }

        public Params setSftpUserArc(String sftpUserArc) {
            this.sftpUserArc = sftpUserArc;
            return this;
        }

        public String getSftpPassArc() {
            return sftpPassArc;
        }

        public Params setSftpPassArc(String sftpPassArc) {
            this.sftpPassArc = sftpPassArc;
            return this;
        }

        public int getMaxSftpTries() {
            return maxSftpTries;
        }

        public Params setMaxSftpTries(int maxSftpTries) {
            this.maxSftpTries = maxSftpTries;
            return this;
        }

        public long getRetryTimeSecs() {
            return retryTimeSecs;
        }

        public Params setRetryTimeSecs(long retryTimeSecs) {
            this.retryTimeSecs = retryTimeSecs;
            return this;
        }

        public String getFile() {
            return file;
        }

        public Params setFile(String file) {
            this.file = file;
            return this;
        }

        @Override
        public String toString() {
            return "Params [sftpArchiveDir=" + sftpArchiveDir + ", file=" + file + "]";
        }
    }
}
