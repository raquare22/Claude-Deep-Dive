package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.jsoup.internal.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

@Service("CleanupFilesCreateACK")
public class CleanupFilesCreateACK extends OptumJavaDelegateBase {

	@Value("${serverType}")
	private String serverType;
	
	private static final Logger log = LoggerFactory.getLogger(CleanupFilesCreateACK.class);
	private static final String EXECUTION_ID = "executionId";
	
	@Autowired
	ProcessorService processorService;
	
	@Autowired
	ProcessorFileTaskService processorFileTaskService;
	
	private static final List<String> REQ_VARS = Arrays.asList(
		Workflow.PROCESSOR_TRANSACTION_ID, Workflow.APP_IDENTIFIER
	);
    
	public CleanupFilesCreateACK() {
		super(REQ_VARS);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void doExecute(DelegateExecution execution) {
		log.info("CleanupFilesCreateACK-->doExecute-->ENTER");
		ProcessorTransaction processorTransaction = null;
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
			try {
			String processorTransactionId = execution.getVariable(Workflow.PROCESSOR_TRANSACTION_ID, String.class);
			String appIdentifier = execution.getVariable(Workflow.APP_IDENTIFIER, String.class);
			
			executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Fetching process configurations");

			processorTransaction = processorService.getProcessorTransaction(processorTransactionId, appIdentifier, serverType);

			log.info("CleanupFilesCreateAck-->doExecute -- are all processorFileTasks complete for processorTransactionId={}, {}", 
					processorTransactionId, processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(processorTransactionId));
			
			if (!processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(processorTransactionId)) {
				log.error("CleanupFilesCreateACK-->doExecute-->Not all processorFileTasks are complete for processorTransactionId={}", processorTransactionId);
				return;
			}
			
			var processorMetaData = processorService.getProcessorMetaData(processorTransaction.getProcessorId(), appIdentifier);
			if(processorMetaData == null) {
				log.error("CleanupFilesCreateACK-->doExecute-->processorMetaData is empty");
				addErrorMsg("CleanupFilesCreateACK-->doExecute-->processorMetaData is empty", "processorMetaData is empty");
				message.put(Workflow.OUTCOME_KEY, "There was error while fetching processor details from MongoDB");
				message.put(Workflow.ERROR_KEY, "processorMetaData is empty");
				return;
			}
			
			Map processConfig = processorMetaData.getProcessConfig();			
			if(processConfig == null) {
				log.error("CleanupFilesCreateACK-->doExecute-->processConfig is empty");
				addErrorMsg("CleanupFilesCreateACK-->doExecute-->processConfig is empty", "processConfig is empty");
				message.put(Workflow.OUTCOME_KEY, "There was error while fetching processor configurations from processor");
				message.put(Workflow.ERROR_KEY, "processConfig is empty");
				return;
			}
			
	        String sftpHost = (String) processConfig.get(Workflow.HOST_NAME_DESTINATION);
	        if(StringUtil.isBlank(sftpHost)) {
				log.warn("CleanupFilesCreateACK-->doExecute-->sftpHost is empty {}={}", EXECUTION_ID, execution.getId());
			}
	        String sftpUSER = (String) processConfig.get(Workflow.USER_NAME_DESTINATION);
	        if(StringUtil.isBlank(sftpUSER)) {
				log.warn("CleanupFilesCreateACK-->doExecute-->sftpUSER is empty {}={}", EXECUTION_ID, execution.getId());
			}
	        String sftpPASS = (String) processConfig.get(Workflow.USER_CREDENTIALS_DESTINATION);
	        if(StringUtil.isBlank(sftpPASS)) {
				log.warn("CleanupFilesCreateACK-->doExecute-->sftpPASS is empty {}={}", EXECUTION_ID, execution.getId());
			}
	        String ftpWorkingDir = (String) processConfig.get(Workflow.FTP_ROOT_DIR);
	        if(StringUtil.isBlank(ftpWorkingDir)) {
				log.warn("CleanupFilesCreateACK-->doExecute-->ftpWorkingDir is empty {}={}", EXECUTION_ID, execution.getId());
			}
	        var ackFlag = true;
	        String ackWorkingDir = (String) processConfig.get(Workflow.FTP_ACK_DIR);
	        if(StringUtil.isBlank(ackWorkingDir)) {
				log.warn("CleanupFilesCreateACK-->doExecute-->ackWorkingDir is empty {}={}", EXECUTION_ID, execution.getId());
				ackFlag = false;
			}
	        String archiveWorkingDir = (String) processConfig.get(Workflow.FTP_ARCHIVE_DIR);
	        if(StringUtil.isBlank(archiveWorkingDir)) {
				log.warn("CleanupFilesCreateACK-->doExecute-->archiveWorkingDir is empty {}={}", EXECUTION_ID, execution.getId());
			}
	        Boolean ackWithErrorsOnly = (Boolean) processConfig.get(Workflow.ACK_WITH_ERRORS_ONLY);
	        if(!BooleanUtils.isFalse(ackWithErrorsOnly)) {
				log.warn("CleanupFilesCreateACK-->doExecute-->ackWithErrorsOnly is empty {}={}", EXECUTION_ID, execution.getId());
			}

	        Boolean generateSingleAckSummaryFile =  Optional.ofNullable((Boolean) processConfig.get(Workflow.GENERATE_SINGLE_ACK_SUMMARY_FILE_FLAG)).orElse(false);

	        message.put(Workflow.OUTCOME_KEY, "Process configurations fetched sucessfully");
	        
	        execution.setTransientVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
	        execution.setTransientVariable(Workflow.ACK_FLAG, ackFlag);
	        execution.setTransientVariable(Workflow.GENERATE_SINGLE_ACK_SUMMARY_FILE_FLAG, generateSingleAckSummaryFile);
	        execution.setTransientVariable(Workflow.ACK_WITH_ERRORS_ONLY, ackWithErrorsOnly);
	        execution.setTransientVariable(Workflow.SFTP_HOSTNAME, sftpHost);
	        execution.setTransientVariable(Workflow.SFTP_USERNAME, sftpUSER);
	        execution.setTransientVariable(Workflow.SFTP_PW, sftpPASS);
	        execution.setTransientVariable(Workflow.SFTP_ROOT_DIRECTORY, ftpWorkingDir);
	        execution.setTransientVariable(Workflow.SFTP_ACK_DIRECTORY, ackWorkingDir);
	        execution.setTransientVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, archiveWorkingDir);
		} catch(Exception e) {
			log.error("doExecute Exception while executing CleanupFilesCreateACK task {}={} {}",
	        		  "processorTransactionId", processorTransaction != null ? processorTransaction.getId() : "NULL",
	        		  ExceptionUtils.getStackTrace(e));
			addErrorMsg("CleanupFilesCreateACK-->doExecute-->Exception while executing CleanupFilesCreateACK task", e.getMessage());
			message.put(Workflow.OUTCOME_KEY, "There was Exception while executing CleanupFilesCreateACK task");
			message.put(Workflow.ERROR_KEY, e.toString());
		} finally {
			if(processorTransaction != null) {
				ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
				processorService.updateProcessorTransactionMetaData(processorTransaction);
			}
		}
		log.info("CleanupFilesCreateACK-->doExecute-->EXIT");
	}

}