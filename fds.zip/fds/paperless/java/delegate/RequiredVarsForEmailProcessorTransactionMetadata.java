package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;


@Service("RequiredVarsForEmailProcessorTransactionMetadata")
public class RequiredVarsForEmailProcessorTransactionMetadata extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequiredVarsForEmailProcessorTransactionMetadata.class);

    private static final List<String> REQ_VARS = List.of(
            Workflow.SEARCH_CRITERIA,
            Workflow.SEARCH_WINDOW,
            Workflow.TEMPLATE_ID,
            Workflow.EMAIL_SENDER,
            Workflow.EMAIL_RECEIVER,
            Workflow.EMAIL_SUBJECT,
            Workflow.ENVIRONMENT,
            Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH,
            Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE
    );

    public RequiredVarsForEmailProcessorTransactionMetadata() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("RequiredVarsForEmailProcessorTransactionMetadata-->doExecute-->Required variables are present in execution bus");
    }
}
