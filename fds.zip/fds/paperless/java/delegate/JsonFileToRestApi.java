
package com.optum.fds.paperless.java.delegate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import java.nio.file.Paths;

import java.util.HashMap;

import java.util.Map;
import java.util.Optional;


import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;


import org.springframework.stereotype.Service;


import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;

import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;

import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTargetType;
import com.optum.fds.paperless.processing.bean.Document;
import com.optum.fds.paperless.workflow.constants.Workflow;




@Service("JsonFileToRestApi")
public class JsonFileToRestApi extends OptumJavaDelegateBase {

	private static final String FDS_HTTP_METHOD = "fdsHttpMethod";
	private static final String STATUS_AVAILABLE = "AVAILABLE";
	private static final String STATUS_COMPLETE_WITH_ERRORS = "COMPLETE_WITH_ERRORS";
	private static final String STATUS_COMPLETE = "COMPLETE";
	private static final String ENDPOINT_SEPARATOR = "/";
	private static final Logger LOGGER = LoggerFactory.getLogger(JsonFileToRestApi.class);
	public static final String CSV_SRC_DIR = "/tmp/ingest/685/2804/FDSBatchInserts"; //TODO
	@Autowired
	private CsvProcessorsService csvProcessorsService;
	@Autowired
	CsvProcessorService csvProcessorService;

	@Autowired
	private ProcessorsService processorsService;



	public JsonFileToRestApi() {
		////super(REQ_VARS);
	}

	@Override
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("JsonFileToRestApi-->execute-->ENTER");


		
		var csvProcessorTransaction = execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class);
		String appIdentifier = execution.getVariable(Workflow.APP_ID_V1, String.class);


		var processorMetaData = processorsService
				.findProcessorMetaDataById(csvProcessorTransaction.getProcessorId(), appIdentifier);

		var executionRecord = ProcessorTaskUtil
				.createProcessorExecutionRecord("Loading documents records", csvProcessorTransaction);
		Map<String, String> message = new HashMap<>();
		var location = Paths.get(CSV_SRC_DIR);//csvProcessorTransaction.getLocation());
		var jsonFileToProcess = new File(location.toFile(), CommonConstants.CSV_JSON_FILENAME); ////csvProcessorTransaction.getJsonFileName());
		Integer rowsProcessed = 0;
		MetaDataStatus processedStatus = null;
		try (var br = new BufferedReader(new FileReader(jsonFileToProcess))) {
			try {

				rowsProcessed = csvFileRowToRestApiJob(execution, processorMetaData, csvProcessorTransaction, br);
				message.put(Workflow.JSONTOREST_SUCCESS_MESSAGE, "Records processed successfully.");
				 execution.setTransientVariable(Workflow.JSONTOREST_SUCCESS_MESSAGE, "Records processed successfully.");
				csvProcessorTransaction.setStatus(MetaDataStatus.IN_PROCESS);	
			} catch (Exception e) {
				LOGGER.error("JsonFileToRestApi-->execute readline error: {}", e.getMessage());
				processedStatus = MetaDataStatus.FATAL_ERROR;
				 execution.setTransientVariable(Workflow.JSONTOREST_ERROR_MESSAGE, e.getMessage());
				message.put(Workflow.JSONTOREST_ERROR_MESSAGE, ExceptionUtils.getStackTrace(e));
				csvProcessorTransaction.setStatus(processedStatus);
			}
		} catch (Exception e) {
			LOGGER.error("JsonFileToRestApi-->execute readFile error: {}", e.getMessage());
			processedStatus = MetaDataStatus.FATAL_ERROR;
			 execution.setTransientVariable(Workflow.JSONTOREST_ERROR_MESSAGE, e.getMessage());
			message.put(Workflow.JSONTOREST_ERROR_MESSAGE, ExceptionUtils.getStackTrace(e));
			csvProcessorTransaction.setStatus(processedStatus);
		} finally {
			csvProcessorTransaction.setRowCount(rowsProcessed);
			ProcessorTaskUtil.updateFileMetrics(csvProcessorTransaction, jsonFileToProcess, csvProcessorService);
			ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService, csvProcessorTransaction,
					executionRecord, message);
		}
		LOGGER.debug("JsonFileToRestApi-->execute-->EXIT");
	}


	private Integer csvFileRowToRestApiJob(DelegateExecution execution, ProcessorMetaData processorMetaData, CsvProcessorTransaction csvProcessorTransaction, BufferedReader br) throws IOException {
		String line;
		var rowCount = 0;
		while ((line = br.readLine()) != null) {
			rowCount++;
			String httpMethod = null;
			org.bson.Document metadata = org.bson.Document.parse(line);
			

			
			var csvProcessorRowTask = csvProcessorsService.createCsvProcessorRowTask(
					csvProcessorTransaction, csvProcessorTransaction.getFileName(),
					csvProcessorTransaction.getJsonFileName(), rowCount, line,
					ProcessorTargetType.documents.toString());



		}

		return rowCount;
	}


	private org.bson.Document preparePutRequest(org.bson.Document metadata, StringBuilder fdsDocumentUrl) {
		if(metadata != null){
			//String documentId = Optional.ofNullable(metadata.get(AppConst.REQUEST_PARAMETER_DOCUMENT_ID))
			String documentId = Optional.ofNullable("1234567890")
					.map(Object::toString)
					.orElse(null);

			if(!StringUtils.isEmpty(documentId)){
				fdsDocumentUrl.append(ENDPOINT_SEPARATOR).append(documentId);
			}

			String internalMetadata = Optional.ofNullable(metadata.get("internalMetadata"))
												.map(Object::toString)
												.orElse(null);
			if(!StringUtils.isEmpty(internalMetadata)){
				return org.bson.Document.parse(internalMetadata);
			}
		}
		return metadata;

	}

	private HttpEntity<Object> constructRequest(org.bson.Document metadata, String authorization, int spaceId ) throws IOException {

        var document = new Document();
        document.setStatus(STATUS_AVAILABLE);
        document.setSpaceId(spaceId);
        
        if(metadata != null) {
			document.setMetadata(metadata);
        	if (metadata.get("formData") != null) {
				org.bson.Document formdata = (org.bson.Document) metadata.get("formData");
				if (formdata.get("confirmation") != null) {
					org.bson.Document confirmation = (org.bson.Document) formdata.get("confirmation");
        			if (!StringUtils.isEmpty(String.valueOf(confirmation.get("transactionID")))) {
						document.setExternalId(String.valueOf(confirmation.get("transactionID")));
        			}
        		}
        	}
		}
        String documentsUrlEncodedJsonStr = null;

        return null;
    }

}