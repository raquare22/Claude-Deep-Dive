package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("SendEmailList")
public class SendEmailList extends OptumJavaDelegateBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(SendEmailList.class);

    private static final String PROCESSOR_TRANSACTIONS_JSON_FILE_NAME = "ProcessorTransactions.json";

    private static final List<String> REQ_VARS = List.of(Workflow.JSON_FILE,
            Workflow.OUTPUT_FILE_DIR, Workflow.EMAIL_SENDER, Workflow.EMAIL_RECEIVER, Workflow.EMAIL_SUBJECT, Workflow.ENVIRONMENT);

    @Autowired
    ProcessorTransactionsService processorTransactionsService;

    @Autowired
    EmailService emailService;

    public SendEmailList() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("SendEmailList-->doExecute-->Enter");
        ProcessorExecutionRecord executionRecord = null;
        String jsonFile = null;
        try {
            jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
            var processorTransactionMetadataList = getProcessorTransactionMetadata(execution, jsonFile);
            String tempWorkingPath = execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class);

            HashMap<String, String> message;

			for (var processorTransactionMetadata : processorTransactionMetadataList) {
				try {
					String emailMessage = (String) processorTransactionMetadata.getClient().get("emailMessage");
					message = new HashMap<>();
					var clientHashMap = processorTransactionMetadata.getClient();

					// getExecutionRecord function is implemented to reduce the complexity of the
					// parent function
					executionRecord = getExecutionRecord(clientHashMap, executionRecord, message, emailMessage);

					if (StringUtils.isEmpty(emailMessage)) {
						LOGGER.info("SendEmailList-->doExecute-->emailMessage is empty");
					} else {
						if (!emailService.sendEmail(execution, emailMessage)) {
							message.put(Workflow.ERROR_KEY, "Email Send service failed");
							addErrorMsg("SendEmailList-->doExecute-->Email Send service failed",
									"Email Send service failed");
						}

					}
					ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransactionMetadata(
							processorTransactionMetadata, executionRecord, message);
					processorTransactionsService.updateProcessorTransactionMetadata(processorTransactionMetadata);

				} catch (Exception e) {
					LOGGER.error("Error to update processorTransactionMetadata {} {}",
							processorTransactionMetadata.getId(), ExceptionUtils.getStackTrace(e));
				}
			}
            var updatedJsonFile = WorkFlowUtil.processorTransactionMetadataListToFile(processorTransactionMetadataList, tempWorkingPath, PROCESSOR_TRANSACTIONS_JSON_FILE_NAME);
            execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR, tempWorkingPath);
            execution.setTransientVariable(Workflow.JSON_FILE, updatedJsonFile.getAbsolutePath());

        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing SendEmailList task {}={}, {}={} {}",
                    "delegateExecutionId", execution != null ? execution.getId() : "NULL",
                    "jsonFile", jsonFile,
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("SendEmailList-->doExecute-->Exception while executing SendEmailList task", WorkFlowUtil.getStackTrace(e));
        } finally {
            if (newErrors() && errorMap.size() > 1) {
                DelegateUtils.sendErrorNotification(execution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
            }
        }
        LOGGER.debug("SendEmailList-->doExecute-->Exit");
    }

    private ProcessorExecutionRecord  getExecutionRecord(Map<String,Object> clientHashMap, ProcessorExecutionRecord executionRecord, HashMap<String, String> message, String emailMessage ) {
        if ((boolean) clientHashMap.get("sendCompanionFileMissingEmail")) {
            executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Sending Companion File Missing Email");
            message.put(Workflow.OUTCOME_KEY, "Companion File Missing Email Sent");
            LOGGER.warn("doExecute Companion File Missing Email Sent {}", emailMessage);
        } else if ((boolean) clientHashMap.get("sendCompanionFileUnreadableEmail")) {
            executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Sending Companion Unparseable Email");
            message.put(Workflow.OUTCOME_KEY, "Companion File Unreadable Email Sent");
            LOGGER.warn("doExecute Companion File Unreadable Email Sent {}", emailMessage);
        } else if (!(boolean) clientHashMap.get("sendCompanionFileUnreadableEmail") && !(boolean) clientHashMap.get("sendCompanionFileMissingEmail")) {
            executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Companion file processed successfully");
        }
        return executionRecord;
    }

    private List<ProcessorTransactionMetadata> getProcessorTransactionMetadata(DelegateExecution execution, String jsonFile) {
        List<ProcessorTransactionMetadata> processorTransactionMetadataList;
        try {
            processorTransactionMetadataList = WorkFlowUtil.readProcessorTransactionMetadataFromJsonFile(jsonFile);
        } catch (IOException e) {
            LOGGER.error("doExecute Unable to read processorTransactions from JSON File {}={}, {}={} {}",
                    "delegateExecutionId", execution != null ? execution.getId() : "NULL",
                    "jsonFile", jsonFile,
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("SendEmailList-->doExecute-->Unable to read processorTransactions from JSON File", WorkFlowUtil.getStackTrace(e));
            return List.of();
        }
        return processorTransactionMetadataList;
    }
}