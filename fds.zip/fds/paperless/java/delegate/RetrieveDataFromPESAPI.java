package com.optum.fds.paperless.java.delegate;

import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ServiceBase;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.provider.ProviderSearch;
import com.optum.fds.paperless.provider.pojo.*;
import com.optum.fds.paperless.util.SanitizeUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.stereotype.Service;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.ParserConfigurationException;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.optum.fds.paperless.workflow.constants.Workflow.LIST_DOCUMENT_METADATA;

@Service("RetrieveDataFromPESAPI")
public class RetrieveDataFromPESAPI extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveDataFromPESAPI.class);

    private static String AUTHORIZATION_STRING = "Authorization";
    private static String BEARER_STRING = "Bearer ";
    private static final ServiceBase serviceBase = new ServiceBase();
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private EhCache ehCache;
    @Autowired
    private OauthManagerUtil oauthManagerUtil;
    @Autowired
    private DocumentMetaDataService documentMetaDataService;
    @Value("${PES_TPS:5}")
    private int PES_TPS;


    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.info("RetrieveDataFromPESAPI-->doExecute-->ENTER");

        RateLimiter rateLimiter = RateLimiter.create(PES_TPS);
        
        String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
        String jsonString = null;
        List<DocumentMetaData> documentMetaDataList = null;
        try {
        	documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
        } catch (IOException e) {
            LOGGER.error("doExecute Unable to get DocumentMetadata {}={} err={}",
                    "jsonFile", jsonFile,
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("TransformJsonAndGenerateFile-->doExecute-->Unable to get DocumentMetadata", WorkFlowUtil.getStackTrace(e));
            return;
        }

//        List<DocumentMetaData> documentMetaDataList = (List<DocumentMetaData>) execution.getVariable(LIST_DOCUMENT_METADATA);
        List<DocumentMetaData> updatedDocumentMetadataList = new ArrayList<>();
        for (var document : documentMetaDataList) {
            LOGGER.info("Processing document. delegate=RetrieveDataFromPESAPI docId={}", document.getId());
            Document doc = document.getMetadata();
            String id = document.getId();
            String npi = doc.getString("providerNPI");
            String providerDataList = null;
            try {
                if (StringUtils.isEmpty(npi)) {
                    LOGGER.warn("NPI is empty for docId {}",id);
                    WorkFlowUtil.updateEDeliveryError(doc, "NPI");
                    documentMetaDataService.saveDocumentMetaData(document);
                } else {
                    providerDataList = getProviderDataPES(execution, document.getId(), npi, rateLimiter);
                    updatedDocumentMetadataList.add(updateDocWithProviderData(providerDataList, id, execution));
                }
            } catch (Exception e) {
                LOGGER.error("Error fetching provider data from PES API for docId={}, e={}", SanitizeUtil.sanitizeString(document.getId()), ExceptionUtils.getStackTrace(e));
            }
            LOGGER.info("Completed processing document. delegate=RetrieveDataFromPESAPI docId={}", document.getId());
        }

        execution.setTransientVariable("updatedDocumentMetadataList", updatedDocumentMetadataList);

        LOGGER.info("RetrieveDataFromPESAPI-->doExecute-->EXIT");
    }

    public String getProviderDataPES(DelegateExecution execution, String docId, String npi, RateLimiter rateLimiter) {
        var request = createRequest(execution, npi);
        var ps = new ProviderSearch(execution.getVariable(Workflow.PROV_SEARCH_URL, String.class), restTemplate, oauthManagerUtil, ehCache);
        try {
            rateLimiter.acquire();
            return ps.getProviderData(request.getRequestBodyNPI(), request.getRequestHeader(), execution);
        } catch (Exception e) {
            LOGGER.error("getProviderDataPES Error in retrieveing provider data, docId={}, e={}", SanitizeUtil.sanitizeString(docId), ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


    private RequestNPI createRequest(DelegateExecution execution, String npi) {

        var pesAppId = execution.getVariable(Workflow.PES_APP_ID, String.class);
        var pesAppSecret = execution.getVariable(Workflow.PES_APP_SECRET, String.class);
        var pesUrl = execution.getVariable(Workflow.PES_OAUTH_URL, String.class);
        var pesGrantType = execution.getVariable(Workflow.PES_GRANT_TYPE, String.class);
        String accessToken = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId,
                pesAppSecret, pesGrantType, pesUrl, false, null);

        var requestHeader = new RequestHeader.RequestHeaderBuilder().setToken(accessToken).build();//

        var requestBody = new RequestBodyNPI.RequestBodyBuilder()
                .setAppName(execution.getVariable(Workflow.PROV_APP_NAME, String.class))
                .setAttributeSet(execution.getVariable(Workflow.PROV_ATTRIBUTE_SET, String.class))
                .setstCd(execution.getVariable(Workflow.ST_CD, String.class))
                .setNPI(npi)
                .setadrTypeCD(execution.getVariable(Workflow.ADR_TYPE_CD, String.class))
                .build();

        return new RequestNPI.RequestBuilder().setRequestBodyNPI(requestBody).setRequestHeader(requestHeader).build();
    }

    private DocumentMetaData updateDocWithProviderData(String providerData, String id, DelegateExecution execution) throws IOException {
        var ps = new ProviderSearch(execution.getVariable(Workflow.PROV_SEARCH_URL, String.class), restTemplate, oauthManagerUtil, ehCache);
        Element root = ps.getRootElement(providerData);
        NodeList svcResponseList = ps.getElementFromRoot(root, "svcResponse");
        
        DocumentMetaData document = documentMetaDataService.getDocumentMetaData(id);
        Document metadata = document.getMetadata();
        List<Map<String, Object>> providerDataMap = new ArrayList<>();

        for (int i = 0; i < svcResponseList.getLength(); i++) {
            Map<String, Object> svcTemp = new HashMap<>();
            Element svc = (Element) svcResponseList.item(i);
            Element pfi = (Element) svc.getElementsByTagName("physicianFacilityInformation").item(0);

            String firstName = ps.getProviderFirstName(pfi);
            String lastName = ps.getProviderLastName(pfi);
            svcTemp.put(Workflow.PROVIDER_FIRST_NAME, firstName);
            svcTemp.put(Workflow.PROVIDER_LAST_NAME,lastName);
            svcTemp.put(Workflow.PROVIDER_FULL_NAME,firstName +" "+ lastName);
            svcTemp.put(Workflow.PROVIDER_ADDRESS_LINE_1, ps.getPostalAddress(pfi, "addressLine1"));
            svcTemp.put(Workflow.PROVIDER_ADDRESS_LINE_2, ps.getPostalAddress(pfi, "addressLine2"));
            svcTemp.put(Workflow.PROVIDER_CITY, ps.getPostalAddress(pfi, "city"));
            svcTemp.put(Workflow.PROVIDER_COUNTY, ps.getPostalAddress(pfi, "county"));
            svcTemp.put(Workflow.PROVIDER_STATE,ps.getPostalAddress(pfi, "state") );
            svcTemp.put(Workflow.PROVIDERPROVINCE, execution.getVariable(Workflow.PROVIDERPROVINCE));
            svcTemp.put(Workflow.PROVIDERCOUNTRY,execution.getVariable(Workflow.PROVIDERCOUNTRY));
            svcTemp.put(Workflow.PROVIDER_ZIP, ps.getPostalAddress(pfi, "zip"));    
            svcTemp.put(Workflow.PROVIDER_ZIP4,ps.getPostalAddress(pfi, "zip4"));
            svcTemp.put(Workflow.TIN, ps.getProviderTin(pfi));
            svcTemp.put(Workflow.PROVIDER_TYPE, ps.getProviderType(pfi));
            svcTemp.put(Workflow.GROUP_NAME, ps.getGroupName(pfi));
            
            svcTemp.put(Workflow.UNIQUE_ID,(id+i));
            providerDataMap.add(svcTemp);
        }
        metadata.put(Workflow.PROVIDER_DATA, providerDataMap);
        documentMetaDataService.updateDocMetaData(document, id);
        documentMetaDataService.saveDocumentMetaData(document);

        return document;
    }

}
