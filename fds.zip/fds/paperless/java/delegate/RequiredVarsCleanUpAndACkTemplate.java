package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service("RequiredVarsCleanUpAndACkTemplate")
public class RequiredVarsCleanUpAndACkTemplate extends OptumJavaDelegateBase {

	static final String ERROR_MSG = "json format not proper for input paramter";
	private static final Logger LOGGER = LoggerFactory.getLogger(RequiredVarsCleanUpAndACkTemplate.class);
	private static final List<String> REQ_VARS = Arrays.asList(
			Workflow.SEARCH_CRITERIA,
			Workflow.SEARCH_WINDOW,
			Workflow.TEMPLATE_ID,
			Workflow.SFTP_HOSTNAME,
			Workflow.SFTP_USERNAME,
			Workflow.SFTP_PW,
			Workflow.SFTP_DIRECTORY
    );
	
	public RequiredVarsCleanUpAndACkTemplate() {
		super(REQ_VARS);
	}

	@Override
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("Required variables are present in execution bus");
	}

	
}
