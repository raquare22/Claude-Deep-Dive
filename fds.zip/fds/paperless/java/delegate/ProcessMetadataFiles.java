package com.optum.fds.paperless.java.delegate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;

import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.file.metadata.ProcessFileTask;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.workflow.constants.Workflow;



@Service("ProcessMetadataFiles")
public class ProcessMetadataFiles extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessMetadataFiles.class);
	
	
	@Autowired
	ProcessorsService processorsService;
	
	@Autowired
	ProcessFileTask processFileTask;
	
	@Autowired
	ProcessorFileTaskService processorFileTaskService;
	
	private static final List<String> REQ_VARS = Arrays.asList(
			"appIdentifier",
			"processorTransactionId",
			"processorFileTaskIds"
	);

	public ProcessMetadataFiles() {
        super(REQ_VARS);
	}
	
	
	@Override
	@SuppressWarnings("unchecked")
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("ProcessMetadataFiles -- doExecute -- ENTER");
		
		long startTime = System.currentTimeMillis();
		
		execution.setTransientVariable(Workflow.PROCESS_KEY, ProcessKeys.PROCESS_METADATA_PROCESS_KEY);
		// get processor file task
		String appId = (String) execution.getVariable("appIdentifier");
		String processorTransactionId = (String) execution.getVariable("processorTransactionId");
		ArrayList<String> processorFileTaskIdsArrayList = (ArrayList<String>) execution.getVariable("processorFileTaskIds");
        List<String> processorFileTaskIds = Collections.unmodifiableList(processorFileTaskIdsArrayList);
        LOGGER.info("list of processorFileTaskIds to process={}", processorFileTaskIds);    
        
		for (String processorFileTaskId : processorFileTaskIds) {
			try {
				var processorFileTask = processorFileTaskService.getProcessorFileTaskById(processorFileTaskId, appId);

				if (processorFileTask == null) {
					LOGGER.error(
							"ProcessMetadataFiles -- doExecute processorFileTask NULL; delegateExecutionId={}, appIdentifier={}, processorTransactionId={}, processorFileTaskId={}",
							execution.getId(), appId, processorTransactionId, processorFileTaskId);
					continue;
				}
				
				processFileTask.processFileTaskWithRequiredFields(execution, processorFileTask);

				if (MetaDataStatus.FATAL_ERROR.equals(processorFileTask.getStatus())) {
					LOGGER.error("Error occurred processing metadata file and exited for processorFileTask id={}",
							processorFileTask.getId());

				} else {
					// COMPLETE or COMPLETE_WITH_ERRORS
					LOGGER.info("ProcessMetadataFiles executed successfully for processorFileTask id={}",
							processorFileTask.getId());
				}
			} catch (Exception e) {
				LOGGER.error("Error to process metadata file and exited for processorFileTaskId {} {}",
						processorFileTaskId, ExceptionUtils.getStackTrace(e));
			}

		}
		long endTime = System.currentTimeMillis();
		LOGGER.debug("ProcessMetadataFiles -- doExecute execution duration in ms = {}", endTime - startTime);
		
		
		
	}

}
