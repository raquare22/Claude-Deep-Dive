package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

@Service("SetProcessorTransactionMetadataForCosmosPRA")
public class SetProcessorTransactionMetadataForCosmosPRA extends OptumJavaDelegateBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(SetProcessorTransactionMetadataForCosmosPRA.class);
    private static final String DOCUMENTS_JSON_FILE_NAME = "ProcessorTransactions.json";
    private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.'000Z'";

    private static final List<String> REQ_VARS = List.of(
            Workflow.OUTPUT_FILE_DIR,
            Workflow.JSON_FILE,
            Workflow.TEMPLATE_NAME
    );

    @Autowired
    CsvProcessorsService csvProcessorsService;

    @Autowired
    ProcessorsService processorsService;

    @Autowired
    ProcessorFileTaskService processorFileTaskService;

    @Autowired
    ProcessorTransactionsService processorTransactionsService;

    String emailMessage = "";
    Integer configSpaceId = null;
    Boolean flag = false;

    public SetProcessorTransactionMetadataForCosmosPRA() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("SetProcessorTransactionMetadataForCosmosPra-->doExecute-->ENTER");
        try {
            String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
            LOGGER.debug("SetProcessorTransactionMetadataForCosmosPra-->jsonFile= {}", jsonFile);
            
            String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);

            var dateFormatter = new SimpleDateFormat(DATE_FORMAT);

            dateFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));

            List<ProcessorTransactionMetadata> processorTransactionMetadataUpdateList = new ArrayList<>();
            List<ProcessorTransactionMetadata> processorTransactionMetadataList = WorkFlowUtil.readProcessorTransactionMetadataFromJsonFile(jsonFile);

            if (CollectionUtils.isEmpty(processorTransactionMetadataList)) {
                LOGGER.warn("SetProcessorTransactionMetadataForCosmosPra-->doExecute-->processorTransactionMetadataList is null or empty");
                String messgeKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
                execution.setTransientVariable(messgeKey, "processorTransactionMetadataList is null or empty");
                setExitNow(execution);
                return;
            }

			for (var processorTransactionMetadata : processorTransactionMetadataList) {
				try {
					var csvProcessorTransaction = csvProcessorsService
							.getCsvProcessorTransactionWithFileName(processorTransactionMetadata.getFileName());
					var clientHashmap = processorTransactionMetadata.getClient();

					configSpaceId = processorTransactionMetadata.getConfigSpaceId();
					var emailMessageMap = new HashMap<String, Object>();
					var sendCompanionFileMissingEmail = "sendCompanionFileMissingEmail";
					var sendCompanionFileUnreadableEmail = "sendCompanionFileUnreadableEmail";
					var companionFileDateReceived = "companionFileDateReceived";

					if (isCreateApplicationCDC(clientHashmap, configSpaceId)) {
						clientHashmap.put(sendCompanionFileMissingEmail, false);
					} else if (csvProcessorTransaction == null) {
						clientHashmap.put(sendCompanionFileMissingEmail, true);
					} else {
						clientHashmap.put(sendCompanionFileMissingEmail, false);
						clientHashmap.put(companionFileDateReceived,
								dateFormatter.format(csvProcessorTransaction.getDateCreated()));
						clientHashmap.put(sendCompanionFileUnreadableEmail,
								csvProcessorTransaction.getStatus().equals(MetaDataStatus.FATAL_ERROR));
					}

					if ((clientHashmap.get(sendCompanionFileMissingEmail).equals(true))
							|| (clientHashmap.get(sendCompanionFileUnreadableEmail).equals(true))) {
						emailMessageMap.put("processorTransactionMetadata", processorTransactionMetadata);
						clientHashmap.put("environment", execution.getVariable(Workflow.ENVIRONMENT, String.class));
						String jsonEmailMessageMap = Parser.toJson(emailMessageMap, DATE_FORMAT);

						if (putEmailMessage(jsonEmailMessageMap, templateName, clientHashmap, execution)) {
							continue;
						}

					}

					processorTransactionMetadata.setClient(clientHashmap);
					processorTransactionMetadataUpdateList.add(processorTransactionMetadata);
				} catch (Exception e) {
					LOGGER.error("Error to process processorTransactionMetadata {} {}",
							processorTransactionMetadata.getId(), ExceptionUtils.getStackTrace(e));
				}
			}

            if (processorTransactionMetadataUpdateList.isEmpty()) {
                LOGGER.warn("SetProcessorTransactionMetadataForCosmosPra-->doExecute-->processorTransactionMetadataUpdateList is null or empty");
                String messgeKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
                execution.setTransientVariable(messgeKey, "processorTransactionMetadataUpdateList is null or empty");
                setExitNow(execution);
                return;
            } else {
                String tempWorkingPath = WorkFlowUtil.getTemporaryWorkingPath(configSpaceId);
                var updatedProcessorTransactionMetadataJsonFile = WorkFlowUtil.processorTransactionMetadataListToFile(processorTransactionMetadataUpdateList, tempWorkingPath, DOCUMENTS_JSON_FILE_NAME);
                execution.setTransientVariable(Workflow.JSON_FILE, updatedProcessorTransactionMetadataJsonFile.getAbsolutePath());
            }
        } catch (Exception e) {
            LOGGER.error("doExecute {}={} {}",
                    "delegateExecutionId", execution != null ? execution.getId() : "NULL",
                    ExceptionUtils.getStackTrace(e));
        }
        LOGGER.debug("SetProcessorTransactionMetadataForCosmosPra-->doExecute-->EXIT");
    }

    private boolean putEmailMessage(String jsonEmailMessageMap, String templateName, Map<String,Object> clientHashmap , DelegateExecution execution) {
        try {
        	emailMessage = TemplateFactory.getInstance(templateName).convertWithTemplate(jsonEmailMessageMap);
            LOGGER.debug("emailMessage = {}", emailMessage);
            clientHashmap.put("emailMessage", emailMessage);
        } catch (Exception e) {
            LOGGER.error("doExecute cannot convert with template {}={}, {}={}, {}",
                    "delegateExecutionId", execution.getId(),
                    "template", templateName,
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("SetProcessorTransactionMetadataForCosmosPra-->doExecute-->cannot convert with template", e.getMessage());
            flag = true;
        }
        return flag;
    }

    private boolean isCreateApplicationCDC(Map<String, Object> clientHashmap, Integer configSpaceId)  {
        String zipFileName = (String) clientHashmap.get("sampleZipFileName");

        var processorTransaction = processorTransactionsService.findProcessorTransactionByFileName(zipFileName, configSpaceId);
        List<ProcessorFileTask> listProcessorFileTask = processorFileTaskService.getProcessorFileTasksForTransactionId(processorTransaction.getId(), processorTransaction.getServerType());
        return listProcessorFileTask.stream().anyMatch(fileTask -> fileTask.getMetadata() != null && "CDC".equals(fileTask.getMetadata().get("createApplication")));
    }
}