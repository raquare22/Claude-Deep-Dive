package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service("GroupDocumentsByMetadata")
public class GroupDocumentsByMetadata extends OptumJavaDelegateBase {
	private static final Logger LOGGER = LoggerFactory.getLogger(GroupDocumentsByMetadata.class);
	@Autowired
	DocumentMetaDataService documentMetadataService;

	@Autowired
	EmailService emailService;

	@Autowired
	HookService hookService;

	@Override
	protected void doExecute(DelegateExecution execution) {
		List<DocumentMetaData> documentList = null;
		Map<String, List<String>> uniqueFieldMap = new HashMap<>();
		List<DocumentMetaData> uniqueFieldDocumentList = new ArrayList<>();
		String uniqueFieldForPEN = execution.getVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, String.class);
		boolean skipDocumentGrouping = Boolean
				.parseBoolean(String.valueOf(execution.getVariable(Workflow.SKIP_DOCUMENT_GROUPING, String.class)));

		String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
		try {
			documentList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		} catch (IOException e) {
			LOGGER.error("doExecute Unable to get DocumentMetadata {}={} {}", "jsonFile", jsonFile,
					ExceptionUtils.getStackTrace(e));
			addErrorMsg("TransformJsonAndGenerateFile-->doExecute-->Unable to get DocumentMetadata",
					WorkFlowUtil.getStackTrace(e));
		}

		try {
			if (documentList != null) {
				if(skipDocumentGrouping){
					//skip grouping and add all documents to uniqueFieldDocumentList
					uniqueFieldDocumentList.addAll(documentList);
				}
				else {
					for (DocumentMetaData document : documentList) {
						LOGGER.info("Processing document. delegate=GroupDocumentsByMetadata docId={}", document.getId());
						String uniqueField = document.getMetadata().getString(uniqueFieldForPEN);

						if (uniqueField != null && !uniqueField.isEmpty()) {
							uniqueFieldMap.computeIfPresent(uniqueField, (key, list) -> {
								if (!list.contains(document.getId())) {
									list.add(document.getId());
								}
								return list;
							});
							uniqueFieldMap.computeIfAbsent(uniqueField, key -> {
								List<String> newList = new ArrayList<>();
								newList.add(document.getId());
								uniqueFieldDocumentList.add(document);
								return newList;
							});
						}
						LOGGER.info("Completed processing document. delegate=GroupDocumentsByMetadata docId={}", document.getId());
					}
				}
			} else {
				LOGGER.warn("GroupDocumentsByMetadata -> empty document list");
			}

			execution.setTransientVariable("uniqueFieldMap", uniqueFieldMap);
			execution.setTransientVariable("uniqueFieldDocumentList", uniqueFieldDocumentList);

		} catch (Exception ex) {
			LOGGER.error("doExecute error while parsing documentList {}", ex.getMessage());
		}

	}
}
