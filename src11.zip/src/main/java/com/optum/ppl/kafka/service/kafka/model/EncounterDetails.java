package com.optum.ppl.kafka.service.kafka.model;

import java.util.Arrays;
import java.util.List;

public class EncounterDetails {
    String admitDate;
    String dischargeDate;
    String emergencyDate;
    String isAdmitAcknowledged;
    String isDischargeAcknowledged;
    String isEmergencyAcknowledged;
    List<String> dischargeDisposition;
    List<String> chiefComplaintList;

    public String getAdmitDate() {
        return admitDate;
    }

    public void setAdmitDate(String admitDate) {
        this.admitDate = admitDate;
    }

    public String getDischargeDate() {
        return dischargeDate;
    }

    public void setDischargeDate(String dischargeDate) {
        this.dischargeDate = dischargeDate;
    }

    public String getEmergencyDate() {
        return emergencyDate;
    }

    public void setEmergencyDate(String emergencyDate) {
        this.emergencyDate = emergencyDate;
    }

    public List<String> getDischargeDisposition() {
        return dischargeDisposition;
    }

    public void setDischargeDisposition(List<String> dischargeDisposition) {
    	
    	if (dischargeDisposition != null && !dischargeDisposition.isEmpty()) {
    		dischargeDisposition.removeAll(Arrays.asList("", null, "\"\""));
    	}
    	
        this.dischargeDisposition = dischargeDisposition;
    }
    public String getIsAdmitAcknowledged() {
        return isAdmitAcknowledged;
    }

    public void setIsAdmitAcknowledged(String isAdmitAcknowledged) {
        this.isAdmitAcknowledged = isAdmitAcknowledged;
    }

    public String getIsDischargeAcknowledged() {
        return isDischargeAcknowledged;
    }

    public void setIsDischargeAcknowledged(String isDischargeAcknowledged) {
        this.isDischargeAcknowledged = isDischargeAcknowledged;
    }

    public String getIsEmergencyAcknowledged() {
        return isEmergencyAcknowledged;
    }

    public void setIsEmergencyAcknowledged(String isEmergencyAcknowledged) {
        this.isEmergencyAcknowledged = isEmergencyAcknowledged;
    }
    public List<String> getChiefComplaintList() {
        return chiefComplaintList;
    }

    public void setChiefComplaintList(List<String> chiefComplaintList) {
        this.chiefComplaintList = chiefComplaintList;
    }

	@Override
	public String toString() {
		return "EncounterDetails [admitDate=" + admitDate + ", dischargeDate=" + dischargeDate + ", emergencyDate="
				+ emergencyDate + ", isAdmitAcknowledged=" + isAdmitAcknowledged + ", isDischargeAcknowledged="
				+ isDischargeAcknowledged + ", isEmergencyAcknowledged=" + isEmergencyAcknowledged
				+ ", dischargeDisposition=" + dischargeDisposition + ", chiefComplaintList=" + chiefComplaintList + "]";
	}
    
    
}
