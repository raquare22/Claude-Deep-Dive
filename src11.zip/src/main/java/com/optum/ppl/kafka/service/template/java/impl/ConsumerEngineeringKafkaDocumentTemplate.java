package com.optum.ppl.kafka.service.template.java.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.consumer.model.KafkaMessage;
import com.optum.ppl.kafka.service.consumer.model.MemberInfo;
import com.optum.ppl.kafka.service.consumer.model.PlanDetails;
import com.optum.ppl.kafka.service.consumer.model.ProviderDetails;
import com.optum.ppl.kafka.service.consumer.model.ReferralDetails;
import com.optum.ppl.kafka.service.consumer.model.RequestedMember;
import com.optum.ppl.kafka.service.consumer.model.RequestingMember;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;


public class ConsumerEngineeringKafkaDocumentTemplate extends TemplateHandler {
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerEngineeringKafkaDocumentTemplate.class);
	private static final String PADDING_0 = "0";

	@Override
	public String convertWithTemplate(String jsonString) {
		ObjectMapper objectMapper = new ObjectMapper();
        
        KafkaMessage msg = new KafkaMessage();
        
        try {
        	String sanitizedJsonString = objectMapper.readValue(jsonString, String.class);
        	msg = objectMapper.readValue(sanitizedJsonString, KafkaMessage.class);
        } catch(JsonProcessingException e) {
        	LOGGER.error("KafkaDocumentTemplate --> unable to convert json string to KafkaMessage, e={}", e.getMessage());
        }
        
        return convertWithTemplate(msg);
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.KAFKA_CONSUMER_ENGINEERING_DOCUMENT);
		KafkaMessage msg = (KafkaMessage) pojo;

		MemberInfo memberInfo = msg.getMemberInfo();
		PlanDetails planDetails = msg.getPlanDetails();
		ProviderDetails providerDetails = msg.getProviderDetails();

		if (providerDetails != null) {

			String primaryTin = providerDetails.getPrimaryCareProviderTin();
			String referredTin = providerDetails.getReferredToProviderTin();

			providerDetails.setPrimaryCareProviderTin(formatTin(primaryTin));
			providerDetails.setReferredToProviderTin(formatTin(referredTin));
		} else {
			LOGGER.warn("KafkaDocumentTemplate --> providerDetails is null in Kafka message.");
		}

		ReferralDetails referralDetails = msg.getReferralDetails();

		RequestingMember requestingMember = memberInfo.getRequestingMember();
		RequestedMember requestedMember = memberInfo.getRequestedMember();

		return st.add("requestingMember", requestingMember)
				.add("requestedMember", requestedMember)
				.add("planDetails", planDetails)
				.add("providerDetails", providerDetails)
				.add("referralDetails", referralDetails)
				.add("diagnosisCodeslist", referralDetails.getDiagnosisCodes())
				.render();
	}
	
	 private String formatTin(String tin) {
	    	if (tin != null && !tin.isEmpty()) {
	    		return StringUtils.leftPad(tin, 9, PADDING_0);
	    	} else {
	    		return tin;
	    	}    	
	    }
	
	

}
