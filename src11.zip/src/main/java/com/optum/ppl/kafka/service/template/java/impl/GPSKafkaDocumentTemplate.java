package com.optum.ppl.kafka.service.template.java.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.kafka.model.*;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import com.optum.ppl.kafka.service.util.Utilities;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GPSKafkaDocumentTemplate extends TemplateHandler {
    @Override
    public String convertWithTemplate(String jsonString) {
        return "";
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return "";
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.GPS_KAFKA_DOCUMENT);

        Map<String, Object> kafkaMessage = (Map<String, Object>) pojo;
        String key = (String) kafkaMessage.get("key");
        KafkaMessageGPS gpsMsg = (KafkaMessageGPS) kafkaMessage.get("kafkaMessage");
        List<ProviderGPS> providers = (gpsMsg != null) ? gpsMsg.getProviders() : null;

//        if (providers != null) {
//            for (ProviderGPS provider : providers) {
//                if (provider.getEmailAddress() != null && !provider.getEmailAddress().isEmpty()) {
//                    List<String> validEmails = provider.getEmailAddress().stream()
//                            .filter(Utilities::validateProviderEmail)
//                            .toList();
//                    provider.setEmailAddress(validEmails);
//                }
//            }
//        }

        return st.add("message", gpsMsg)
                .add("providers", providers)
                .add("transactionId", key)
                .render();
    }
}
