package com.optum.ppl.kafka.service.kafka.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberInfo {
        @JsonProperty("MemberId")
        private String memberId;

        @JsonProperty("MemberFirstName")
        private String memberFirstName;

        @JsonProperty("MemberLastName")
        private String memberLastName;

        public String getMemberId() {
                return memberId;
        }

        public void setMemberId(String memberId) {
                this.memberId = memberId;
        }

        public String getMemberFirstName() {
                return memberFirstName;
        }

        public void setMemberFirstName(String memberFirstName) {
                this.memberFirstName = memberFirstName;
        }

        public String getMemberLastName() {
                return memberLastName;
        }

        public void setMemberLastName(String memberLastName) {
                this.memberLastName = memberLastName;
        }
}
