package com.optum.ppl.kafka.service.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RecordCount {
    private int dailyReconCount;
    private int weeklyReconCount;
    private String reconFrequency;
    private String pendFrequency;
    private Boolean updated;
    private int dailyPendCount;
    private int weeklyPendCount;
    private int dailyAppealsCount;
    private int weeklyAppealsCount;
    private String providerTin;
    private String providerOrganizationName;
    private String corporateProviderMpin;
    private int dailyPaanAdditionalInfoCount;
    private int dailyPaanAppealsCount;
    private int weeklyPaanAdditionalInfoCount;
    private int weeklyPaanAppealsCount;
    private int dailySmartEditsCount;
    private int actionRequiredPendingClaimsCount;
    private int retryDocumentPendingClaimsCount;
    private int bothPendingClaimsCount;
    private int referralCreatedCount;
    private int referralAboutToExpireCount;
    private int referralBothCount;
    private int dailyDisputeCount;
    private int weeklyDisputeCount;
    private int dailySmartEditsActionRequiredCount;
    private int dailySmartEditsRetryDocCount;
    private int dailyRejectedClaimsActionRequiredCount;

    public Boolean getUpdated() {
        return updated;
    }

    public void setUpdated(Boolean updated) {
        this.updated = updated;
    }

    public String getPendFrequency() {
        return pendFrequency;
    }

    public void setPendFrequency(String pendFrequency) {
        this.pendFrequency = pendFrequency;
    }

    public String getReconFrequency() {
        return reconFrequency;
    }

    public void setReconFrequency(String reconFrequency) {
        this.reconFrequency = reconFrequency;
    }

    public int getDailyReconCount() {
        return dailyReconCount;
    }

    public void setDailyReconCount(int dailyReconCount) {
        this.dailyReconCount = dailyReconCount;
    }

    public int getWeeklyReconCount() {
        return weeklyReconCount;
    }

    public void setWeeklyReconCount(int weeklyReconCount) {
        this.weeklyReconCount = weeklyReconCount;
    }

    public int getDailyPendCount() {
        return dailyPendCount;
    }

    public void setDailyPendCount(int dailyPendCount) {
        this.dailyPendCount = dailyPendCount;
    }

    public int getWeeklyPendCount() {
        return weeklyPendCount;
    }

    public void setWeeklyPendCount(int weeklyPendCount) {
        this.weeklyPendCount = weeklyPendCount;
    }

    public int getDailyAppealsCount() {
        return dailyAppealsCount;
    }

    public void setDailyAppealsCount(int dailyAppealsCount) {
        this.dailyAppealsCount = dailyAppealsCount;
    }

    public int getWeeklyAppealsCount() {
        return weeklyAppealsCount;
    }

    public void setWeeklyAppealsCount(int weeklyAppealsCount) {
        this.weeklyAppealsCount = weeklyAppealsCount;
    }

    public String getProviderTin() {
        return providerTin;
    }

    public void setProviderTin(String providerTin) {
        this.providerTin = providerTin;
    }

    public String getProviderOrganizationName() {
        return providerOrganizationName;
    }
    
    public void setProviderOrganizationName(String providerOrganizationName) {
        this.providerOrganizationName = providerOrganizationName;
    }

    public String getCorporateProviderMpin() {
        return corporateProviderMpin;
    }

    public void setCorporateProviderMpin(String corporateProviderMpin) {
        this.corporateProviderMpin = corporateProviderMpin;
    }

    public int getDailyPaanAdditionalInfoCount() {
        return dailyPaanAdditionalInfoCount;
    }

    public void setDailyPaanAdditionalInfoCount(int dailyPaanAdditionalInfoCount) {
        this.dailyPaanAdditionalInfoCount = dailyPaanAdditionalInfoCount;
    }

    public int getDailyPaanAppealsCount() {
        return dailyPaanAppealsCount;
    }

    public void setDailyPaanAppealsCount(int dailyPaanAppealsCount) {
        this.dailyPaanAppealsCount = dailyPaanAppealsCount;
    }

    public int getWeeklyPaanAdditionalInfoCount() {
        return weeklyPaanAdditionalInfoCount;
    }

    public void setWeeklyPaanAdditionalInfoCount(int weeklyPaanAdditionalInfoCount) {
        this.weeklyPaanAdditionalInfoCount = weeklyPaanAdditionalInfoCount;
    }

    public int getWeeklyPaanAppealsCount() {
        return weeklyPaanAppealsCount;
    }

    public void setWeeklyPaanAppealsCount(int weeklyPaanAppealsCount) {
        this.weeklyPaanAppealsCount = weeklyPaanAppealsCount;
    }

    public int getDailySmartEditsCount() {
        return dailySmartEditsCount;
    }

    public void setDailySmartEditsCount(int dailySmartEditsCount) {
        this.dailySmartEditsCount = dailySmartEditsCount;
    }

    public int getActionRequiredPendingClaimsCount() {
        return actionRequiredPendingClaimsCount;
    }

    public void setActionRequiredPendingClaimsCount(int actionRequiredPendingClaimsCount) {
        this.actionRequiredPendingClaimsCount = actionRequiredPendingClaimsCount;
    }

    public int getRetryDocumentPendingClaimsCount() {
        return retryDocumentPendingClaimsCount;
    }

    public void setRetryDocumentPendingClaimsCount(int retryDocumentPendingClaimsCount) {
        this.retryDocumentPendingClaimsCount = retryDocumentPendingClaimsCount;
    }

    public int getBothPendingClaimsCount() {
        return bothPendingClaimsCount;
    }

    public void setBothPendingClaimsCount(int bothPendingClaimsCount) {
        this.bothPendingClaimsCount = bothPendingClaimsCount;
    }

    public int getReferralCreatedCount() {
        return referralCreatedCount;
    }

    public void setReferralCreatedCount(int referralCreatedCount) {
        this.referralCreatedCount = referralCreatedCount;
    }

    public int getReferralAboutToExpireCount() {
        return referralAboutToExpireCount;
    }

    public void setReferralAboutToExpireCount(int referralAboutToExpireCount) {
        this.referralAboutToExpireCount = referralAboutToExpireCount;
    }

    public int getReferralBothCount() {
        return referralBothCount;
    }

    public void setReferralBothCount(int referralBothCount) {
        this.referralBothCount = referralBothCount;
    }

    public int getDailyDisputeCount() {
        return dailyDisputeCount;
    }

    public void setDailyDisputeCount(int dailyDisputeCount) {
        this.dailyDisputeCount = dailyDisputeCount;
    }

    public int getWeeklyDisputeCount() {
        return weeklyDisputeCount;
    }

    public void setWeeklyDisputeCount(int weeklyDisputeCount) {
        this.weeklyDisputeCount = weeklyDisputeCount;
    }

    public int getDailySmartEditsActionRequiredCount() {
        return dailySmartEditsActionRequiredCount;
    }

    public void setDailySmartEditsActionRequiredCount(int dailySmartEditsActionRequiredCount) {
        this.dailySmartEditsActionRequiredCount = dailySmartEditsActionRequiredCount;
    }

    public int getDailySmartEditsRetryDocCount() {
        return dailySmartEditsRetryDocCount;
    }

    public void setDailySmartEditsRetryDocCount(int dailySmartEditsRetryDocCount) {
        this.dailySmartEditsRetryDocCount = dailySmartEditsRetryDocCount;
    }

    public int getDailyRejectedClaimsActionRequiredCount() {
        return dailyRejectedClaimsActionRequiredCount;
    }

    public void setDailyRejectedClaimsActionRequiredCount(int dailyRejectedClaimsActionRequiredCount) {
        this.dailyRejectedClaimsActionRequiredCount = dailyRejectedClaimsActionRequiredCount;
    }

}
