package com.optum.ppl.kafka.service.template.java;

import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.impl.*;
import org.eclipse.collections.impl.map.mutable.UnifiedMap;

import java.util.Map;

public final class TemplateFactory {
	private static final Map<String, TemplateHandler> TEMPLATE_HANDLERS = new UnifiedMap<>();

	/**
	 * Register your templates here. extend TemplateHandler class to override your
	 * own implementation. add that impl in the map
	 */
	static {

//		TEMPLATE_HANDLERS.put(Templates.KAFKA_RESPONSE_DOCUMENT.getTemplate(),new KafkaDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.KAFKA_MNR_DOCUMENT.getTemplate(),new MnRKafkaDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.ALINK_KAFKA_TEMPLATE.getTemplate(),new AlinkKafkaTemplate());
		TEMPLATE_HANDLERS.put(Templates.CNS_KAFKA_MESSAGE.getTemplate(),new KafkaDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.ATS_KAFKA_DOCUMENT.getTemplate(),new ATSKafkaDocumentTemplate());			
		TEMPLATE_HANDLERS.put(Templates.GPS_KAFKA_DOCUMENT.getTemplate(), new GPSKafkaDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.KAFKA_CONSUMER_ENGINEERING_DOCUMENT.getTemplate(), new ConsumerEngineeringKafkaDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.TRACKIT_KAFKA_TEMPLATE.getTemplate(), new TrackItConsumerServiceTemplate());
		
	}
		

	private TemplateFactory() {
		throw new AssertionError("Cannot instantiate");
	}

	public static TemplateHandler getInstance(String templates) {
		if (templates.equals(Templates.KAFKA_RESPONSE_DOCUMENT.getTemplate())) {
			return new KafkaDocumentTemplate();
		}
		return TEMPLATE_HANDLERS.get(templates);
	}
}
