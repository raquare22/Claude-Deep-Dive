package com.optum.ppl.kafka.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.optum.ppl.kafka.service.util.DocumentUtil;




@EnableTransactionManagement
@EnableAutoConfiguration
@SpringBootApplication
public class KafkaServiceApplication {
	
	public static void main(String[] args) {
		SpringApplication application =new SpringApplication(KafkaServiceApplication.class);
		application.run(args);
		
	}
	
	
	 @Bean
	 public DocumentUtil documentUtil() { 
	   return new DocumentUtil();
	  }
	 
	 @Bean
	 public ConfigData getConfigData() {
	    	return new ConfigData();
	    }

	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

}
