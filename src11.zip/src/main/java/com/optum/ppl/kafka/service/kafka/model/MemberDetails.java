package com.optum.ppl.kafka.service.kafka.model;

public class MemberDetails {
    String patientFirstName;
    String patientLastName;
    String patientDateOfBirth;
    String lob;
    String state;

    public String getPatientFirstName() {
        return patientFirstName;
    }

    public void setPatientFirstName(String patientFirstName) {
    	this.patientFirstName = patientFirstName;
    }

    public String getPatientLastName() {
        return patientLastName;
    }

    public void setPatientLastName(String patientLastName) {
        this.patientLastName = patientLastName;
    }

    public String getPatientDateOfBirth() {
        return patientDateOfBirth;
    }

    public void setPatientDateOfBirth(String patientDateOfBirth) {
        this.patientDateOfBirth = patientDateOfBirth;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

	@Override
	public String toString() {
		return "MemberDetails [patientFirstName=" + patientFirstName + ", patientLastName=" + patientLastName
				+ ", patientDateOfBirth=" + patientDateOfBirth + ", lob=" + lob + ", state=" + state + "]";
	}
    
    
}
