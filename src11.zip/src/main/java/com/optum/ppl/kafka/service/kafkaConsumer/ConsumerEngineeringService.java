package com.optum.ppl.kafka.service.kafkaConsumer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.optum.ppl.kafka.service.consumer.model.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ce.referrals.avro.ReferralEvent;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;


@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.engineering", havingValue = "true")
public class ConsumerEngineeringService {

	 private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerEngineeringService.class);
	   

	    @Autowired
	    DocumentMetaDataService documentMetaDataService;
	    
	    @Autowired
	    private ObjectMapper objectMapper;

	    @Value("${PRUN.CONSUMER_ENGINEERING_SPACEID}")
	    private int CONSUMER_ENGINEERING_SPACEID;
	    
	    @Value("${REFERRAL_QUERY_TIME_WINDOW}")
	    private int queryTimeWindow;
	    
	    
	    @KafkaListener(
	    		topics = "${spring.kafka.topic.trackItPCPRefferal}", 
	    		groupId = "${kafkaGroupIdtrackItPCP}",
	    	    properties = {
	    	         		   "bootstrap.servers=${trackItPCPBootstrapServers}",
	    	         		   "ssl.keystore.location=${trackItPCPconsumerKeystorePath}", 
	    	         		   "ssl.keystore.password=${trackItPCPconsumerkeystorePassword}", 
	    	         		   "ssl.truststore.location=${trackItPCPconsumertruststorelocation}", 
	    	         		   "ssl.truststore.password=${trackItPCPconsumertruststorePassword}"
	    	     			}
	    		
	    		)
	    public void consumeTrackItPCPReferral(ConsumerRecord<String, String> message) throws JsonMappingException, JsonProcessingException {
	        LOGGER.info("TrackITPCPReferral Kafka ConsumerService -->message received from trackIt kafka topic:  value={}",  Encode.forJava(message.value()));
	        processTopic(message);
	    }
	    
	    @KafkaListener(
	    		
	    		topics = "${spring.kafka.topic.consumerEngineering}", 
	    		groupId = "${kafkaGroupIdConsumerEngineering}",
	    		properties= {
	    				"bootstrap.servers=${consumerEngineeringBootstrapServers}",
						"ssl.keystore.location=${consumerEngineeringKeystorePath}",
						"ssl.keystore.password=${consumerEngineeringkeystorePassword}",
						"ssl.truststore.location=${consumerEngineeringtruststorelocation}",
						"ssl.truststore.password=${consumerEngineeringtruststorePassword}",
						"security.protocol=SSL",
						"key.deserializer=io.confluent.kafka.serializers.KafkaAvroDeserializer",
						"value.deserializer=io.confluent.kafka.serializers.KafkaAvroDeserializer",
						"schema.registry.url=${consumerEngineeringschemaRegistryUrl}",
						"schema.registry.ssl.truststore.location=${consumerEngineeringtruststorelocation}",
						"schema.registry.ssl.truststore.password=${consumerEngineeringtruststorePassword}",
						"schema.registry.ssl.keystore.location=${consumerEngineeringKeystorePath}",
						"schema.registry.ssl.keystore.password=${consumerEngineeringkeystorePassword}",
						"specific.avro.reader=true"
	    		}
	    )
	    public void consume(ConsumerRecord<String, ReferralEvent> message) {

	        List<DocumentMetaData> insertedDocList = new ArrayList<>();
	        String metadataStr = null;
	        DocumentMetaData document = null;
	        try {
	        	TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.KAFKA_CONSUMER_ENGINEERING_DOCUMENT.getTemplate());
				String jsonString = objectMapper.readValue(message.value().toString(), String.class);
				KafkaMessage kafkaMessage = objectMapper.readValue(jsonString, KafkaMessage.class);

				if(!validateMetadataFields(kafkaMessage)) {
					LOGGER.warn("ConsumerEngineeringService --> Invalid metadata received from kafka topic: value={}",  Encode.forJava(jsonString));
					return;
				}
				metadataStr = templateHandler.convertWithTemplate(kafkaMessage);
	        	org.bson.Document metadata = objectMapper.readValue(metadataStr, new TypeReference<org.bson.Document>(){});
				document = new DocumentMetaData();
				document.setMetadata(metadata);
				document.setStatus(MetaDataStatus.AVAILABLE);

				insertedDocList.add(document);
	        	
	        	
	        } catch (Exception e) {
	            LOGGER.error("ConsumerEngineeringService --> unable to convert json string to documentMetaData, message={} e={}", 
	            		 Encode.forJava(message.value().toString()), ExceptionUtils.getStackTrace(e));
	        }
	        if (CollectionUtils.isEmpty(insertedDocList)) {
	            LOGGER.warn("ConsumerEngineeringService --> Kafka Consumer-->documentMetaDataList is null or empty");
	            return;
	        }
	        documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, CONSUMER_ENGINEERING_SPACEID);
	        LOGGER.info("Kafka ConsumerEngineeringService - document inserted to mongodb");
	        
	    }
	    
	    private void processTopic(ConsumerRecord<String, String> message)  {
	    	
	      try {
	    	  String messageStr = message.value();
	    	  Map<String, Object> jsonMap = objectMapper.readValue(messageStr, new TypeReference<Map<String, Object>>() {});
	    	  Map<String, Object> recordInfo = (Map<String, Object>) jsonMap.get("recordInfo");
            
	    	  DocumentMetaData docMetadata = null;
	    	  
	    	  
	    	  String requestId = (String) recordInfo.get("recordID");
	    	  String referralStatus = (String) recordInfo.get("recordStatus");
	    	  
	    	  docMetadata = documentMetaDataService.getReferralDocumentMetaData(requestId, CONSUMER_ENGINEERING_SPACEID, "IN_PROCESS", queryTimeWindow);
	    	  
	    	  if (docMetadata == null) {
	                LOGGER.error("TrackITPCPReferral Kafka ConsumerService --> documentMetaData not found in mongo,  requestId={}",  Encode.forJava(requestId));
	                return;
	            }
	    	  
	    	  
	    	  var metadata = docMetadata.getMetadata();
	    	  
	    	  if(referralStatus.equals("Received")) {  
	    		  LOGGER.debug("TrackITPCPReferral Kafka ConsumerService -->  Event received for the ReferralId={} with status={}", requestId, referralStatus);
	    		  
	    	  } else {
	    		  metadata.put("referralStatus", referralStatus);
	    		  documentMetaDataService.updateReferralDocumentStatus(docMetadata.getId(), metadata);
	    		  LOGGER.debug("TrackITPCPReferral Kafka ConsumerService --> Event received for the ReferralId={} with status={}", requestId, referralStatus);
	    	  }
	    	  
	    	} catch(Exception e) {
	    		
	    		 LOGGER.error("TrackIt PCP Referral Kafka ConsumerService --> unable to convert json string to documentMetaData  e={}",
	                      ExceptionUtils.getStackTrace(e));
	    		
	    	}
	    }

		private boolean validateMetadataFields(KafkaMessage msg) {
			try {
				if (msg == null) {
					return false;
				}
				MemberInfo memberInfo = msg.getMemberInfo();
				PlanDetails planDetails = msg.getPlanDetails();
				ProviderDetails providerDetails = msg.getProviderDetails();
				ReferralDetails referralDetails = msg.getReferralDetails();

				if (memberInfo == null || planDetails == null || providerDetails == null || referralDetails == null) {
					return false;
				}

				RequestedMember member = memberInfo.getRequestedMember();
				if (member == null || memberInfo.getRequestingMember() == null) {
					return false;
				}

				String pcpFirstName = providerDetails.getPrimaryCareProviderFirstName();
				String pcpLastName = providerDetails.getPrimaryCareProviderLastName();
				String pcpCorpMpin = providerDetails.getPrimaryCareProviderCorpMpin();
				String pcpTin = providerDetails.getPrimaryCareProviderTin();
				String referredToProviderTin = providerDetails.getReferredToProviderTin();
				String referredToProviderFirstName = providerDetails.getReferredToProviderFirstName();
				String referredToProviderLastName = providerDetails.getReferredToProviderLastName();

				// Validate requesting member's memberId, but the other details from requested member
				String memberId = memberInfo.getRequestingMember().getMemberIdCardNbr();
				String memberFirstName = member.getFirstName();
				String memberLastName = member.getLastName();
				String memberDOB = member.getDob();
				String groupNumber = member.getGroupNumber();

				String policyId = planDetails.getPolicyId();
				String planStartDate = planDetails.getPlanStartDate();
				String planEndDate = planDetails.getPlanEndDate();

				String requestId = referralDetails.getRequestId();

                return validateStrField(pcpFirstName) &&
						validateStrField(pcpLastName) &&
						validateStrField(pcpCorpMpin) &&
						validateStrField(pcpTin) &&
						validateStrField(referredToProviderTin) &&
						validateStrField(referredToProviderFirstName) &&
						validateStrField(referredToProviderLastName) &&
						validateStrField(memberId) &&
						validateStrField(memberFirstName) &&
						validateStrField(memberLastName) &&
						validateStrField(memberDOB) &&
						validateStrField(groupNumber) &&
						validateStrField(policyId) &&
						validateStrField(planStartDate) &&
						validateStrField(planEndDate) &&
						validateStrField(requestId);

            } catch (Exception e) {
				LOGGER.error("ConsumerEngineeringService --> Exception in validateMetadataFields e={}", ExceptionUtils.getStackTrace(e));
				return false;
			}
		}


		private boolean validateStrField(String value) {
            return value != null && !value.trim().isEmpty();
        }

}
