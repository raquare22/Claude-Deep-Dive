package com.optum.ppl.kafka.service.kafka.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TrackItKafka {
    private String recordID;
    private String recordLastUpdatedDate;
    private Boolean isFromApi;
    @JsonProperty("emailAddress")
    private String providerEmailId;
    private String deliveryStatus;
    private List<RecordCount> recordsCountList;

    public Boolean getFromApi() {
        return isFromApi;
    }

    public void setFromApi(Boolean fromApi) {
        isFromApi = fromApi;
    }

    public String getRecordID() {
        return recordID;
    }

    public void setRecordID(String recordID) {
        this.recordID = recordID;
    }

    public String getRecordLastUpdatedDate() {
        return recordLastUpdatedDate;
    }

    public void setRecordLastUpdatedDate(String recordLastUpdatedDate) {
        this.recordLastUpdatedDate = recordLastUpdatedDate;
    }

    public String getProviderEmailId() {
        return providerEmailId;
    }

    public void setProviderEmailId(String providerEmailId) {
        this.providerEmailId = providerEmailId;
    }

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public List<RecordCount> getRecordsCountList() {
        return recordsCountList;
    }

    public void setRecordsCountList(List<RecordCount> recordsCountList) {
        this.recordsCountList = recordsCountList;
    }
}