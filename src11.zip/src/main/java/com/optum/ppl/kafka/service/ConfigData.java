package com.optum.ppl.kafka.service;

import java.util.Collections;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;

public class ConfigData {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigData.class);
	private Map<String, Object> allClientCredentials = new java.util.HashMap<>();


	@Value("${TRACKIT.credentials}")
	private String TRACKIT_configcredentials;

	@Value("${ADT_CNS.credentials}")
	private String ADT_CNS_configcredentials;
	
	@Value("${ATSANDALINK.credentials}")
	private String ATSAPPEALS_configcredentials;
	
	@Value("${MNR.credentials}")
	private String mnrConfigcredentials;
	
	@Value("${consumerEngineering.credentials}")
	private String consumerEngineeringConfigcredentials;

	@Value("${SSBCI.credentials}")
	private String ssbciConfigcredentials;

	@Autowired
	private ObjectMapper mapper;

	

	@SuppressWarnings({ "unchecked" })
	public Map<String, Object> getCredentials(Integer spaceId) {
		if (allClientCredentials.isEmpty()) setCredentials();

		Map<String, Object> credentials = null;
		int retryCount = 1;
		int maxRetries = 5;

		while (credentials == null && retryCount <= maxRetries) {
			credentials = (Map<String, Object>) Collections.unmodifiableMap(allClientCredentials).get(spaceId.toString());
			if (credentials == null) {
				LOGGER.warn("No credentials found for spaceId={}, retrying... (attempt {} of {})", spaceId, retryCount + 1, maxRetries);
				setCredentials();
				retryCount++;
			}
		}

		if (credentials == null) {
			LOGGER.error("No credentials found for spaceId={} after {} attempts", spaceId, maxRetries);
			return Collections.emptyMap();
		}

		return Collections.unmodifiableMap(credentials);
	}

	private void setCredentials() {
		mapper = new ObjectMapper();
		final MapType type = mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
		try {

			allClientCredentials.putAll(mapper.readValue(TRACKIT_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ADT_CNS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ATSAPPEALS_configcredentials, type));
			allClientCredentials.putAll(mapper.readValue(mnrConfigcredentials, type));
			allClientCredentials.putAll(mapper.readValue(consumerEngineeringConfigcredentials, type));
			allClientCredentials.putAll(mapper.readValue(ssbciConfigcredentials, type));
			LOGGER.info("All Credentials have been set.");
		} catch (JsonProcessingException ex) {
			LOGGER.error("Error in ConfigData-->setCredentials, {}", ex.getMessage());
		}
	}
}

