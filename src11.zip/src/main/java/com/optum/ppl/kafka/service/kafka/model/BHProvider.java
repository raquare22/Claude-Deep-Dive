package com.optum.ppl.kafka.service.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BHProvider {
	
	private String providerTin;
	private String providerNpi;
	private String providerName;
	
	
	public String getProviderTin() {
        return providerTin;
    }

    public void setProviderTin(String providerTin) {
        this.providerTin = providerTin;
    }

	public String getProviderNpi() {
		return providerNpi;
	}

	public void setProviderNpi(String providerNpi) {
		this.providerNpi = providerNpi;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	@Override
	public String toString() {
		return "BHProvider [providerTin=" + providerTin + ", providerNpi=" + providerNpi + ", providerName="
				+ providerName + "]";
	}
    
    
	

}
