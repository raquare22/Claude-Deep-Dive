package com.optum.ppl.kafka.service.mongo;

import java.io.Serializable;
import java.util.Date;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.ppl.kafka.service.mongo.processors.Revision;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorRevision extends Revision implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Date dateAttachmentUpdated;
	@JsonProperty("attachments")
	private String errorMessage;
	private String externalId;
	private transient Document metadata;

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Date getDateAttachmentUpdated() {
		return dateAttachmentUpdated == null ? null : (Date) dateAttachmentUpdated.clone();
	}

	public void setDateAttachmentUpdated(Date dateAttachmentUpdated) {
		this.dateAttachmentUpdated = dateAttachmentUpdated == null ? null : (Date) dateAttachmentUpdated.clone();
	}

	public Document getMetadata() {
		return metadata;
	}

	public void setMetadata(Document metadata) {
		this.metadata = metadata;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
