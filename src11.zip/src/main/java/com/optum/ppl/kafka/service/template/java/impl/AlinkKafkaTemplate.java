package com.optum.ppl.kafka.service.template.java.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;

import java.util.HashMap;
import java.util.Map;

public class AlinkKafkaTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        return "";
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return "";
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st=this.templateLoader.getTemplate(Templates.ALINK_KAFKA_TEMPLATE);
        Map<String,String> docMap=new HashMap<>();
        ObjectMapper objectMapper = new ObjectMapper();

        Map<String, Object> alinkResponse = (Map<String, Object>) pojo;
        String aLinkRecStr = (String) alinkResponse.get("message");
        String kafkaKey = (String) alinkResponse.get("key");

        String cleanedALinkMsgStr = aLinkRecStr.replace("\\\"", "");
        cleanedALinkMsgStr = cleanedALinkMsgStr.replace("\\\\T\\\\", "");
        cleanedALinkMsgStr = cleanedALinkMsgStr.replace("\\\\E\\\\", "");
        cleanedALinkMsgStr = cleanedALinkMsgStr.replace("\\\\", "");
        Map<String, Object> alinkJsonMap;

        try {
            alinkJsonMap = objectMapper.readValue(cleanedALinkMsgStr, Map.class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        docMap.put("key", kafkaKey);
        docMap.put("createdOn", (String) alinkJsonMap.get("attachmentOn"));
        docMap.put("corporateMpin", (String) alinkJsonMap.get("billingMpin"));
        docMap.put("tin", (String) alinkJsonMap.get("providerTin"));
        docMap.put("appealReferenceNumber", (String) alinkJsonMap.get("appealCaseNumber"));
        docMap.put("providerName", (String) alinkJsonMap.get("providerName"));
        docMap.put("appealStatus", (String) alinkJsonMap.get("appealStatus"));
        docMap.put("notificationType", (String) alinkJsonMap.get("notificationType"));
        docMap.put("numberOfUpdates", (String) alinkJsonMap.get("numberOfUpdates"));
        docMap.put("providerEmailId", (String) alinkJsonMap.get("emailAddress"));

        return st.add("documentInfo", docMap).render();
    }
}