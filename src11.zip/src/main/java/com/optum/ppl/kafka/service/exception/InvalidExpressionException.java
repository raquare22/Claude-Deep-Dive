package com.optum.ppl.kafka.service.exception;

public class InvalidExpressionException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	
	public InvalidExpressionException(String string) {
		super(string);
	}

	public InvalidExpressionException(String string, Throwable throwable) {
		super(string, throwable);
	}

	public InvalidExpressionException(Throwable throwable) {
		super(throwable);
	}
}