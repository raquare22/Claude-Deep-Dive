package com.optum.ppl.kafka.service.template.java.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.kafka.model.TrackItKafka;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;

public class TrackItConsumerServiceTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrackItConsumerServiceTemplate.class);

	@Override
	public String convertWithTemplate(String jsonString) {
        try {
            String cleanedJsonString = cleanJsonString(jsonString);
            ObjectMapper objectMapper = new ObjectMapper();
            TrackItKafka trackItKafka = objectMapper.readValue(cleanedJsonString, TrackItKafka.class);
            return renderTemplate(trackItKafka);
        } catch (JsonProcessingException e) {
            LOGGER.error("TrackItConsumerServiceTemplate --> Failed to parse JSON string: {}", e.getMessage());
            throw new IllegalArgumentException("Invalid JSON string provided", e);
        }
    }

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		return null;
	}

    @Override
    public String convertWithTemplate(Object pojo) {
        if (pojo instanceof TrackItKafka) {
            return renderTemplate((TrackItKafka) pojo);
        }
        else if (pojo instanceof String) {
            return convertWithTemplate((String) pojo);

        }else if (pojo instanceof Map) {
            Map<String, Object> kafkaResponse = (Map<String, Object>) pojo;
            String kafkaMsgStr = (String) kafkaResponse.get("kafkaResponse");
            String cleanedKafkaMsgStr = cleanJsonString(kafkaMsgStr);

            try {
                ObjectMapper objectMapper = new ObjectMapper();
                TrackItKafka trackItKafka = objectMapper.readValue(cleanedKafkaMsgStr, TrackItKafka.class);
                return renderTemplate(trackItKafka);
            } catch (JsonProcessingException e) {
                LOGGER.error("TrackItConsumerServiceTemplate --> Unable to convert JSON string to TrackItKafka, e={}", e.getMessage());
                throw new IllegalArgumentException("Invalid JSON string provided", e);
            }
        } else {
            throw new IllegalArgumentException("Unsupported object type for conversion");
        }
    }

    public String renderTemplate(TrackItKafka trackItKafka) {
    var st = this.templateLoader.getTemplate(Templates.TRACKIT_KAFKA_TEMPLATE);
    return st.add("recordID", trackItKafka.getRecordID())
             .add("recordLastUpdatedDate", trackItKafka.getRecordLastUpdatedDate())
             .add("providerEmailId", trackItKafka.getProviderEmailId())
             .add("deliveryStatus", trackItKafka.getDeliveryStatus())
             .add("recordsCountList", trackItKafka.getRecordsCountList())
             .render();
}

    private String cleanJsonString(String jsonString) {
        String cleanedJsonString = jsonString.replace("\\\"", "\"");
        cleanedJsonString = cleanedJsonString.replace("\\\\T\\\\", "");
        cleanedJsonString = cleanedJsonString.replace("\\\\E\\\\", "");
        cleanedJsonString = cleanedJsonString.replace("\\\\", "");
        return cleanedJsonString;
    }

}
