package com.optum.ppl.kafka.service.mongo.processors;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.Date;

public class Revision implements Serializable {
    private static final long serialVersionUID = 1L;

    private String appIdentifier;
    private int clientId;
    private Date dateCreated;
    private Date dateModified;
    private String name;
    private int spaceId;
    private MetaDataStatus status;
    private String transactionId;
    private String version;

    public String getAppIdentifier() {
        return appIdentifier;
    }

    public void setAppIdentifier(String appIdentifier) {
        this.appIdentifier = appIdentifier;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public Date getDateCreated() {
        return dateCreated==null?null:(Date)dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated==null?null:(Date)dateCreated.clone();
    }

    public Date getDateModified() {
    	 return dateModified==null?null:(Date)dateModified.clone();
     }

    public void setDateModified(Date dateModified) {
    	this.dateModified = dateModified==null?null:(Date)dateModified.clone();
        }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSpaceId() {
        return spaceId;
    }

    @JsonIgnore
    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    @JsonProperty("spaceId")
    public void setSpaceId(String spaceId) {
        this.spaceId = Integer.parseInt(spaceId);
    }

    public MetaDataStatus getStatus() {
        return status;
    }

    @JsonIgnore
    public void setStatus(MetaDataStatus status) {
        this.status = status;
    }

    public void setStatus(String status) {
        this.status = MetaDataStatus.valueOf(status);
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) throws NumberFormatException {
        this.version = version;
    }
}
