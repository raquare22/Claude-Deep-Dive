package com.optum.ppl.kafka.service.template;


import junit.framework.Assert;
import org.json.JSONException;
import org.junit.Test;

import com.optum.ppl.kafka.service.template.java.TemplateFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AlinkKafkaTemplateTest {
    Map<String, String> map = new HashMap<>();

    @Test
    public void testALinkKafkaDocumentTemplate() throws IOException, JSONException {

        String alinkRecord = "{\"kafkaKey\":\"AT-1447148-R\",\"corporateMpin\":\"929250072277900\",\"tin\":\"352263845\",\"appealReferenceNumber\":\"AT-1447148-R\",\"providerName\":\"Mercy Medical Center\",\"appealStatus\":\"ReSubmitAttachments\",\"notificationType\":\"\", \"numberOfUpdates\":\"1\",\"providerEmailId\":\"mercy.center@org.com\"}";

        map.put("key", "AT-1447148-R");
        map.put("message", alinkRecord);

        String output = TemplateFactory.getInstance(Templates.ALINK_KAFKA_TEMPLATE.getTemplate())
                    .convertWithTemplate(map);

        System.out.println(output);
        Assert.assertTrue(output.contains("AT-1447148-R"));

    }
}
