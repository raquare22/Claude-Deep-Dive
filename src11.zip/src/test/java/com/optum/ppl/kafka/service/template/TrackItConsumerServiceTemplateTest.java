package com.optum.ppl.kafka.service.template;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.stringtemplate.v4.ST;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.kafka.model.RecordCount;
import com.optum.ppl.kafka.service.kafka.model.TrackItKafka;
import com.optum.ppl.kafka.service.template.java.impl.TrackItConsumerServiceTemplate;

public class TrackItConsumerServiceTemplateTest {

    private TrackItConsumerServiceTemplate template;
    private ST mockSt;

    @Before
    public void setUp() throws Exception {
        template = new TrackItConsumerServiceTemplate();
        mockSt = mock(ST.class);
        TemplateLoader mockLoader = mock(TemplateLoader.class);

        when(mockLoader.getTemplate(Templates.TRACKIT_KAFKA_TEMPLATE)).thenReturn(mockSt);
        when(mockSt.add(anyString(), any())).thenReturn(mockSt);
        when(mockSt.render()).thenReturn("Rendered Output");

        Field loaderField = template.getClass().getSuperclass().getDeclaredField("templateLoader");
        loaderField.setAccessible(true);
        loaderField.set(template, mockLoader);
    }

    @Test
    public void testConvertWithTemplate_validJson() throws Exception {
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setRecordLastUpdatedDate("2024-07-16");
        kafka.setProviderEmailId("test@example.com");
        kafka.setDeliveryStatus("DELIVERED");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        rc.setWeeklyReconCount(2);
        rc.setCorporateProviderMpin("123123123");
        rc.setProviderTin("321321321");
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(kafka);

        String result = template.convertWithTemplate(json);
        System.out.println("Result: " + result);
        assertEquals("Rendered Output", result);

        verify(mockSt, times(1)).add(eq("recordID"), eq("rec-1"));
        verify(mockSt, times(1)).render();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConvertWithTemplate_invalidJson() {
        template.convertWithTemplate("invalid json");
    }

    @Test
    public void testConvertWithTemplateFromFilePath_returnsNull() {
        assertNull(template.convertWithTemplateFromFilePath("any/path"));
    }

    @Test
    public void testConvertWithTemplate_objectInput() throws Exception {
        Map<String, Object> map = new HashMap<>();
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-2");
        kafka.setRecordLastUpdatedDate("2024-07-17");
        kafka.setProviderEmailId("foo@bar.com");
        kafka.setDeliveryStatus("FAILED");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(3);
        rc.setWeeklyReconCount(4);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(kafka);

        map.put("kafkaResponse", json);

        String result = template.convertWithTemplate(map);
        assertEquals("Rendered Output", result);

        verify(mockSt, atLeastOnce()).add(anyString(), any());
        verify(mockSt, atLeastOnce()).render();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConvertWithTemplate_objectInput_invalidJson() {
        Map<String, Object> map = new HashMap<>();
        map.put("kafkaResponse", "invalid json");
        template.convertWithTemplate(map);
    }

    @Test
    public void testCleanJsonString() throws Exception {
        String dirty = "\\\"foo\\\":\\\"bar\\\" \\\\T\\\\ \\\\E\\\\ \\\\";
        Method method = TrackItConsumerServiceTemplate.class.getDeclaredMethod("cleanJsonString", String.class);
        method.setAccessible(true);
        String cleaned = (String) method.invoke(template, dirty);
        assertFalse(cleaned.contains("\\\""));
        assertFalse(cleaned.contains("\\\\T\\\\"));
        assertFalse(cleaned.contains("\\\\E\\\\"));
        assertFalse(cleaned.contains("\\\\"));
    }

}
