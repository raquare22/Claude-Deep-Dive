package com.optum.ppl.kafka.service;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class KafkaServiceApplicationTest {

    @Test
    public void contextLoads() {
       
    }
}
