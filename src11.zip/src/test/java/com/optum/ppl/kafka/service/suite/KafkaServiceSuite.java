package com.optum.ppl.kafka.service.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.optum.ppl.kafka.service.KafkaServiceApplicationTest;
import com.optum.ppl.kafka.service.template.ATSKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.AlinkKafkaTemplateTest;
import com.optum.ppl.kafka.service.template.ConsumerEngineeringKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.GPSKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.KafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.MnRKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.TrackItConsumerServiceTemplateTest;

import junit.framework.TestCase;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	
	KafkaServiceApplicationTest.class,
	AlinkKafkaTemplateTest.class,
	ATSKafkaDocumentTemplateTest.class,
	ConsumerEngineeringKafkaDocumentTemplateTest.class,
	GPSKafkaDocumentTemplateTest.class,
	KafkaDocumentTemplateTest.class,
	MnRKafkaDocumentTemplateTest.class,
	TrackItConsumerServiceTemplateTest.class
	
})

public class KafkaServiceSuite  extends TestCase {}
