package com.optum.ppl.kafka.service.template;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.junit.Test;

import com.optum.ppl.kafka.service.kafka.model.KafkaMessageGPS;
import com.optum.ppl.kafka.service.kafka.model.ProviderGPS;
import com.optum.ppl.kafka.service.template.java.impl.GPSKafkaDocumentTemplate;

import java.util.*;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class GPSKafkaDocumentTemplateTest {

    @Test
    public void test() throws JsonProcessingException {
        String messageStr = "{\"id\":\"85778AB0-24D4-4BB2-9727-C114FD8CD6C6\",\"householdId\":\"850058742385\",\"insuredPlanId\":\"146248767\",\"applicationId\":\"177064744245874\",\"type\":\"CSNP\",\"effectiveDate\":\"2026-03-01\",\"endDate\":\"2026-04-30\",\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\",\"sourceType\":\"NEW ENROLLMENT\",\"programNames\":null,\"verifiedConditions\":null,\"providers\":[{\"providerId\":\"001455298\",\"npi\":\"1205922135\",\"pcpName\":\"GONZALEZ JORGE A\",\"taxId\":\"161720069\",\"emailAddress\":[\"JAGONZALEZ57@GMAIL.COM\"]},{\"providerId\":\"001768600\",\"npi\":\"1326043761\",\"pcpName\":\"QUESENBERRY PAUL J\",\"taxId\":\"232707038\",\"emailAddress\":[\"JOLVERA@GETTYSBURGFAMILYPRACTICE.COM\"]}],\"mbi\":\"4U00TR7VY36\",\"firstName\":\"BARRETT\",\"lastName\":\"MA_CSNP_FUTURE\",\"dateOfBirth\":\"1930-01-04\",\"verifiedProviderId\":null}";

        ObjectMapper mapper = new ObjectMapper();
        KafkaMessageGPS kafkaMessageGPS = mapper.readValue(messageStr, KafkaMessageGPS.class);

        System.out.println("KafkaMessageGPS Object: " + kafkaMessageGPS);

        Map<String, Object> kafkaResponseMap = new HashMap<>();
        kafkaResponseMap.put("kafkaMessage", kafkaMessageGPS);
        kafkaResponseMap.put("key", "123456");

        TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.GPS_KAFKA_DOCUMENT.getTemplate());
        String result = templateHandler.convertWithTemplate(kafkaResponseMap);

        System.out.println(result);

    }

    @Test
    public void testConvertWithTemplate() {
        GPSKafkaDocumentTemplate template = new GPSKafkaDocumentTemplate();

        KafkaMessageGPS gpsMsg = new KafkaMessageGPS();
        gpsMsg.setId("123");
        gpsMsg.setHouseholdId("HH001");
        gpsMsg.setInsuredPlanId("PLN001");
        gpsMsg.setApplicationId("APP001");
        gpsMsg.setType("Medical");
        gpsMsg.setEffectiveDate("2025-01-01");
        gpsMsg.setEndDate("2025-12-31");
        gpsMsg.setStatus("Active");
        gpsMsg.setEventType("Referral");
        gpsMsg.setSourceType("System");
        gpsMsg.setProgramNames(Arrays.asList("ProgramA", "ProgramB"));

        ProviderGPS provider1 = new ProviderGPS();
        provider1.setProviderId("P001");
        provider1.setNpi("NPI001");
        provider1.setPcpName("Dr. Smith");
        provider1.setTaxId("TID001");
        provider1.setEmailAddress(List.of("drsmith@example.com", "drandrew@example.com"));

        ProviderGPS provider2 = new ProviderGPS();
        provider2.setProviderId("P002");
        provider2.setNpi("NPI002");
        provider2.setPcpName("Dr. Jack");
        provider2.setTaxId("TID002");
        provider2.setEmailAddress(Collections.singletonList("drjack@example.com"));

        gpsMsg.setProviders(java.util.List.of(provider1, provider2));

        Map<String, Object> kafkaMessage = new HashMap<>();
        kafkaMessage.put("key", "txn-001");
        kafkaMessage.put("kafkaMessage", gpsMsg);

        String result = template.convertWithTemplate(kafkaMessage);
        System.out.println(result);

        assertNotNull(result);
        assertTrue(result.contains("\"id\": \"123\""));
        assertTrue(result.contains("\"householdId\": \"HH001\""));
        assertTrue(result.contains("\"providerId\": \"P001\""));
        assertTrue(result.contains("\"npi\": \"NPI001\""));
        assertTrue(result.contains("\"pcpName\": \"Dr. Smith\""));
        assertTrue(result.contains("\"taxId\": \"TID001\""));
        assertTrue(result.contains("\"emailAddress\": [\"drsmith@example.com\""));
        assertTrue(result.contains("\"transactionId\" : \"txn-001\""));
    }
}
