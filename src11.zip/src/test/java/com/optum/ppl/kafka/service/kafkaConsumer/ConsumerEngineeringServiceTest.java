package com.optum.ppl.kafka.service.kafkaConsumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.optum.ce.referrals.avro.ReferralEvent;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class ConsumerEngineeringServiceTest {

    @InjectMocks
    private ConsumerEngineeringService consumerEngineeringService;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private ObjectMapper objectMapper;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(consumerEngineeringService, "CONSUMER_ENGINEERING_SPACEID", 42);
        ReflectionTestUtils.setField(consumerEngineeringService, "queryTimeWindow", 15);
    }

    @Test
    public void testConsume_SuccessfulInsert() throws Exception {
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key",getKafkaMessage());



        consumerEngineeringService.consume(record);

    }

    @Test
    public void testConsume_EmptyMetadataList() throws Exception {
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key", new ReferralEvent());
        String metadataListStr = "[]";

        consumerEngineeringService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    //    @Test
    public void testProcessTopic_DocumentFound_UpdatesStatus() throws Exception {
        Map<String, Object> jsonMap = new HashMap<>();
        Map<String, String> recordInfo = new HashMap<>();
        recordInfo.put("recordID", "req1");
        recordInfo.put("recordStatus", "APPROVED");
        jsonMap.put("recordInfo", recordInfo);
        ObjectMapper mapper = new ObjectMapper();
        String msgStr = mapper.writeValueAsString(jsonMap);

        when(objectMapper.readValue(anyString(), ArgumentMatchers.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(jsonMap);

        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "req1", msgStr);

        DocumentMetaData docMeta = new DocumentMetaData();
        docMeta.setId("docId");
        Document metadata = new Document();
        docMeta.setMetadata(metadata);

        when(documentMetaDataService.getReferralDocumentMetaData(anyString(), anyInt(), anyString(), anyInt()))
                .thenReturn(docMeta);

        // Use reflection to call private method
        java.lang.reflect.Method m = ConsumerEngineeringService.class.getDeclaredMethod("consumeTrackItPCPReferral", ConsumerRecord.class);
        m.setAccessible(true);
        m.invoke(consumerEngineeringService, record);

        assertEquals("APPROVED", metadata.get("referralStatus"));
        verify(documentMetaDataService, times(1)).updateReferralDocumentStatus(eq("docId"), eq(metadata));
    }

    //    @Test
    public void testProcessTopic_DocumentNotFound() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", "{\"recordInfo\":{\"requestId\":\"req2\",\"referralStatus\":\"DENIED\"}}");
        Map<String, Object> jsonMap = new HashMap<>();
        Map<String, String> recordInfo = new HashMap<>();
        recordInfo.put("requestId", "req2");
        recordInfo.put("referralStatus", "DENIED");
        jsonMap.put("recordInfo", recordInfo);

        when(objectMapper.readValue(anyString(), ArgumentMatchers.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(jsonMap);
        when(documentMetaDataService.getReferralDocumentMetaData(eq("req2"), eq(42), eq("IN_PROCESS"), eq(15)))
                .thenReturn(null);

        java.lang.reflect.Method m = ConsumerEngineeringService.class.getDeclaredMethod("consumeTrackItPCPReferral", ConsumerRecord.class);
        m.setAccessible(true);
        m.invoke(consumerEngineeringService, record);

        verify(documentMetaDataService, never()).updateReferralDocumentStatus(anyString(), any());
    }

    @Test
    public void testProcessTopic_Exception() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", "bad_json");
        when(objectMapper.readValue(anyString(), ArgumentMatchers.<TypeReference<Map<String, Object>>>any()))
                .thenThrow(new RuntimeException("parse error"));

        java.lang.reflect.Method m = ConsumerEngineeringService.class.getDeclaredMethod("consumeTrackItPCPReferral", ConsumerRecord.class);
        m.setAccessible(true);
        m.invoke(consumerEngineeringService, record);

        verify(documentMetaDataService, never()).updateReferralDocumentStatus(anyString(), any());
    }


    private ReferralEvent getKafkaMessage() throws JsonMappingException, JsonProcessingException {

        ObjectMapper object = new ObjectMapper();

        String message =   """ 
                {
                "memberInfo": {
            "requestingMember": {
                "memberIdCardNbr": "162080645",
                        "firstName": "FNGVSLMDSRJM",
                        "lastName": "LNTWOEADGL",
                        "dob": "2000-05-19",
                        "groupNumber": "0021311",
                        "dependentSeqNbr": "01"
            },
            "requestedMember": {
                "memberIdCardNbr": "162080645",
                        "firstName": "FNGVSLMDSRJM",
                        "lastName": "LNTWOEADGL",
                        "groupNumber": "0021311",
                        "dob": "2000-05-19"
            }
        },
        "planDetails": {
            "insuranceType": "M",
                    "planEndDate": "2025-12-31",
                    "planStartDate": "2025-01-01",
                    "policyId": "092019",
                    "policyType": "Medical"
        },
        "providerDetails": {
            "primaryCareProviderFirstName": "FNGALILEO ",
                    "primaryCareProviderLastName": "LNHEALTH ",
                    "primaryCareProviderCorpMpin": "1831",
                    "primaryCareProviderTin": "9812391",
                    "referredToProviderFirstName": "FNKENDRA ",
                    "referredToProviderLastName": "LNMULHOLAND ",
                    "referredToProviderTin": "76231",
                    "referredToProviderCorpMpin": "981923",
                    "referredToProviderId": "005222521014"
        },
        "referralDetails": {
                   "requestId": "RF_64c11a80-0d9d-48a3-a100-bd80004dc7e7",
                    "specialty": "Dermatologist ",
                    "comments": "Requesting referrals for dermatologist",
                    "diagnosisCodes": [
            "A0100",
                    "A0101"
        ]
        }
  }

        """;

        ReferralEvent event = new ReferralEvent();

        event = object.readValue( message, new TypeReference<ReferralEvent>(){});

        return event;
    }


}