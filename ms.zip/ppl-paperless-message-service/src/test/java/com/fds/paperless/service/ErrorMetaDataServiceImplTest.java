package com.fds.paperless.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.fds.paperless.mongo.ErrorMetaData;
import com.fds.paperless.mongo.MetaDataErrorCode;
import com.fds.paperless.mongo.MetaDataStatus;
import org.springframework.data.mongodb.core.query.Query;

@RunWith(MockitoJUnitRunner.class)

public class ErrorMetaDataServiceImplTest {
	@InjectMocks
	private ErrorMetaDataServiceImpl errorMetaDataServiceImpl;

	@Mock
	MongoTemplate mongoTemplate;
	@Test
	public void setMongoQueryMaxMillisTest() {
		String mongoQueryMaxMillis="3";
		errorMetaDataServiceImpl.setMongoQueryMaxMillis(mongoQueryMaxMillis);
		assertNotNull(mongoQueryMaxMillis);
	}
	@Test
	public void getErrorMetaDataTest() {
		String str="sample";
		when(mongoTemplate.findOne(any(), eq(ErrorMetaData.class))).thenReturn(new ErrorMetaData());
		ErrorMetaData metaData=errorMetaDataServiceImpl.getErrorMetaData(str);
		assertNotNull(metaData);
	}
	@Test
	public void getErrorListTest() {
		ErrorMetaData e=new ErrorMetaData();
		e.setCompleteStatus();
		List<ErrorMetaData> errorMetaData = new ArrayList<>();
		errorMetaData.add(e);
		when(mongoTemplate.find(any(), eq(ErrorMetaData.class))).thenReturn(errorMetaData);
		List<ErrorMetaData> metaData=errorMetaDataServiceImpl.getErrorList(MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.MANUAL, "1", 0);
		assertNotNull(metaData);
	}
	@Test
	public void getErrorListQueueTest() {
		ErrorMetaData e=new ErrorMetaData();
		e.setCompleteStatus();
		List<ErrorMetaData> errorMetaData = new ArrayList<>();
		errorMetaData.add(e);
		when(mongoTemplate.find(any(), eq(ErrorMetaData.class))).thenReturn(errorMetaData);
		List<ErrorMetaData> metaData=errorMetaDataServiceImpl.getErrorList(MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.MANUAL, "queue", 0);
		assertNotNull(metaData);
	}
	@Test
	public void getErrorListByIdentifierTest() {
		ErrorMetaData e=new ErrorMetaData();
		e.setCompleteStatus();
		List<ErrorMetaData> errorMetaData = new ArrayList<>();
		errorMetaData.add(e);
		when(mongoTemplate.find(any(), eq(ErrorMetaData.class))).thenReturn(errorMetaData);
		List<ErrorMetaData> metaData=errorMetaDataServiceImpl.getErrorListByIdentifier("identifier");
		assertNotNull(metaData);
	}
	@Test
	public void getErrorListByTargetIdTest() {
		ErrorMetaData e=new ErrorMetaData();
		e.setCompleteStatus();
		List<ErrorMetaData> errorMetaData = new ArrayList<>();
		errorMetaData.add(e);
		when(mongoTemplate.find(any(), eq(ErrorMetaData.class))).thenReturn(errorMetaData);
		List<ErrorMetaData> metaData=errorMetaDataServiceImpl.getErrorListByTargetId("target");
		assertNotNull(metaData);
	}
	@Test
	public void getErrorMetaDataByIndentifierTargetIdTest() {
		when(mongoTemplate.findOne(any(), eq(ErrorMetaData.class))).thenReturn(new ErrorMetaData());
		ErrorMetaData metaData=errorMetaDataServiceImpl.getErrorMetaDataByIndentifierTargetId("identifier", "target");
		assertNotNull(metaData);
	}
	@Test
	public void updateErrorMetaDataStatusTest() {
		when(mongoTemplate.findOne(any(), eq(ErrorMetaData.class))).thenReturn(new ErrorMetaData());
		ErrorMetaData metaData=errorMetaDataServiceImpl.updateErrorMetaDataStatus("test", MetaDataStatus.MANUAL);
		assertNotNull(metaData);
	}
	@Test
	public void updateErrorMetaDataSubjectStatusTest() {
		when(mongoTemplate.findOne(any(), eq(ErrorMetaData.class))).thenReturn(new ErrorMetaData());
		ErrorMetaData metaData=errorMetaDataServiceImpl.updateErrorMetaDataSubjectStatus("identifier", "target", MetaDataStatus.MANUAL);
		assertNotNull(metaData);
	}
	@Test
	public void convertISOStringToDateTest() {
		Date date=errorMetaDataServiceImpl.convertISOStringToDate("2020-07-10 15:00:00.000");
		System.out.print(date);
		assertNotNull(date);
	}
	@Test
	public void saveErrorMetaDataTest() {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		ErrorMetaData metaData = errorMetaDataServiceImpl.saveErrorMetaData(errorMetaData);
		assertNull(metaData);
	}
	@Test
	public void saveErrorMetaDataExistsTest() {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setId("1234");
		ErrorMetaData metaData = errorMetaDataServiceImpl.saveErrorMetaData(errorMetaData);
		assertNull(metaData);
	}
	@Test
	public void getTest() {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setId("1234");
		errorMetaData.setDateCreated(new Date());
		errorMetaData.getDateCreated();
		errorMetaData.getDateModified();
		errorMetaData.setName("name");
		errorMetaData.getName();
		errorMetaData.setStatus("AUTOMATIC");
		errorMetaData.getStatus();
		errorMetaData.getVersion();
		errorMetaData.toString();
		assertNotNull(errorMetaData);
	}

	@Test
	public void getErrorMetaDataByMessageIdTest() {
		String messageId = "testMessageId";
		ErrorMetaData errorMetaData = new ErrorMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(ErrorMetaData.class))).thenReturn(errorMetaData);

		ErrorMetaData result = errorMetaDataServiceImpl.getErrorMetaDataByMessageId(messageId);

		assertNotNull(result);
		verify(mongoTemplate, times(1)).findOne(any(Query.class), eq(ErrorMetaData.class));
	}

	@Test
	public void getErrorListWithQueueTest() {
		List<ErrorMetaData> errorMetaDataList = Collections.singletonList(new ErrorMetaData());
		when(mongoTemplate.find(any(Query.class), eq(ErrorMetaData.class))).thenReturn(errorMetaDataList);

		List<ErrorMetaData> result = errorMetaDataServiceImpl.getErrorList(MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.MANUAL, "replyIndex", "queueName", 10);

		assertNotNull(result);
		assertEquals(1, result.size());
		verify(mongoTemplate, times(1)).find(any(Query.class), eq(ErrorMetaData.class));
	}

	@Test
	public void updateErrorMetaDataMessageIdSubjectStatusTest() {
		String id = "testId";
		String messageId = "testMessageId";
		String subject = "testSubject";
		MetaDataStatus status = MetaDataStatus.MANUAL;
		ErrorMetaData errorMetaData = new ErrorMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(ErrorMetaData.class))).thenReturn(errorMetaData);
		when(mongoTemplate.save(any(ErrorMetaData.class))).thenReturn(errorMetaData);

		ErrorMetaData result = errorMetaDataServiceImpl.updateErrorMetaDataMessageIdSubject(id, messageId, subject, status);

		assertNotNull(result);
		assertEquals(messageId, errorMetaData.getMessageId());
		assertEquals(subject, errorMetaData.getSubject());
		assertEquals(status, errorMetaData.getStatus());
		verify(mongoTemplate, times(1)).findOne(any(Query.class), eq(ErrorMetaData.class));
		verify(mongoTemplate, times(1)).save(any(ErrorMetaData.class));
	}

	@Test
	public void convertISOStringToDate_validDateTest() throws ParseException {
		String isoDate = "2024-01-01T12:00:00.000Z";
		Date expectedDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse(isoDate);

		Date actualDate = errorMetaDataServiceImpl.convertISOStringToDate(isoDate);

		assertEquals(expectedDate, actualDate);
	}

	@Test
	public void convertISOStringToDate_invalidDateTest() {
		String invalidIsoDate = "invalid-date-format";

		Date actualDate = errorMetaDataServiceImpl.convertISOStringToDate(invalidIsoDate);

		assertNull(actualDate);
	}

//	@Test
//	public void saveErrorMetaData_newDocumentTest() {
//		ErrorMetaData errorMetaData = new ErrorMetaData();
//		errorMetaData.setId("newId");
//		when(mongoTemplate.findById(eq("newId"), eq(ErrorMetaData.class))).thenReturn(null);
//		when(mongoTemplate.insert(any(ErrorMetaData.class), eq("error_meta_data"))).thenReturn(errorMetaData);
//
//		ErrorMetaData result = errorMetaDataServiceImpl.saveErrorMetaData(errorMetaData);
//
//		assertNotNull(result);
//		assertEquals(errorMetaData, result);
//		verify(mongoTemplate, times(1)).findById(eq("newId"), eq(ErrorMetaData.class));
//		verify(mongoTemplate, times(1)).insert(any(ErrorMetaData.class), eq("error_meta_data"));
//	}
//
//	@Test
//	public void saveErrorMetaData_existingDocumentTest() {
//		ErrorMetaData errorMetaData = new ErrorMetaData();
//		errorMetaData.setId("existingId");
//		ErrorMetaData existingDocument = new ErrorMetaData();
//		existingDocument.setDateCreated(new Date());
//		when(mongoTemplate.findById(eq("existingId"), eq(ErrorMetaData.class))).thenReturn(existingDocument);
//		when(mongoTemplate.save(any(ErrorMetaData.class), eq("error_meta_data"))).thenReturn(errorMetaData);
//
//		ErrorMetaData result = errorMetaDataServiceImpl.saveErrorMetaData(errorMetaData);
//
//		assertNotNull(result);
//		assertEquals(errorMetaData, result);
//		verify(mongoTemplate, times(1)).findById(eq("existingId"), eq(ErrorMetaData.class));
//		verify(mongoTemplate, times(1)).save(any(ErrorMetaData.class), eq("error_meta_data"));
//	}
}
