package com.fds.paperless.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import static org.mockito.ArgumentMatchers.eq;
import java.net.ConnectException;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.Test;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.junit.RallyTestCase;
import com.fds.paperless.junit.UserStory;
import com.fds.paperless.model.GenericResponse;
import com.fds.paperless.msgsvc.MessageServiceMgr.AsyncServiceCallback;
import com.fds.paperless.msgsvc.ReceiveAsyncResponse;

public class AsyncServiceTest {
	@InjectMocks
	private AsyncService asyncService;

	@SuppressWarnings("rawtypes")
	@Mock
	HttpResponse httpResponse;

	@Mock
	private ErrorMetaDataService errorMetaDataService;

	@Mock
	private AsyncServiceCallback asyncServiceCallback;

	@Mock
	private ReceiveAsyncResponse receiveAsyncResponse;

	@Mock
	private CompletionException completionException;

	@Mock
	private ConnectException connectException;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		asyncService.objectMapper = new ObjectMapper();
//		ReflectionTestUtils.setField(asyncService, "INTERNAL_SERVER_ERROR", "INTERNAL_SERVER_ERROR");
		when(asyncServiceCallback.getReceiveAsyncResponse()).thenReturn(receiveAsyncResponse);
		Mockito.doNothing().when(receiveAsyncResponse).processAsyncSuccess(Mockito.any());
		Mockito.doNothing().when(receiveAsyncResponse).processAsyncFailure(Mockito.any(), Mockito.any());
	}

	@SuppressWarnings("unchecked")
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void applyResponseOKTest() {
		when(httpResponse.statusCode()).thenReturn(200);
		asyncService.applyResponse(httpResponse, asyncServiceCallback);
		assertNotNull(asyncService);
	}

	@SuppressWarnings("unchecked")
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void applyResponseNotOKTest() {
		when(httpResponse.statusCode()).thenReturn(400);
		when(httpResponse.body()).thenReturn("{\"statusMessage\":\"statusMessage\",\"response\":\"response\"}");
		asyncService.applyResponse(httpResponse, asyncServiceCallback);
		assertNotNull(asyncService);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void whenCompleteOnNonCompletionExceptionTest() {
		asyncService.whenCompleteOnException(connectException, asyncServiceCallback);
		assertNotNull(asyncService);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void whenCompleteOnExceptionTest() {
		asyncService.whenCompleteOnException(completionException, asyncServiceCallback);
		assertNotNull(asyncService);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void whenCompleteOnConnectExceptionTest() {
		when(completionException.getCause()).thenReturn(new ConnectException("error"));
		asyncService.whenCompleteOnException(completionException, asyncServiceCallback);
		assertNotNull(asyncService);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void whenCompleteOnHttpConnectTimeoutExceptionTest() {
		when(completionException.getCause()).thenReturn(new HttpConnectTimeoutException("error"));
		asyncService.whenCompleteOnException(completionException, asyncServiceCallback);
		assertNotNull(asyncService);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void whenCompleteOnHttpTimeoutExceptionTest() {
		when(completionException.getCause()).thenReturn(new HttpTimeoutException("error"));
		asyncService.whenCompleteOnException(completionException, asyncServiceCallback);
		assertNotNull(asyncService);
	}

	@SuppressWarnings("unchecked")
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void getResponseEntityTest() {
		when(httpResponse.statusCode()).thenReturn(503);
		when(httpResponse.body()).thenReturn("{\"statusMessage\":null,\"response\":null}");
		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity(httpResponse, asyncServiceCallback);
		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, genericResponse.getStatusCode());
		assertEquals(AsyncService.SERVICE_UNAVAILABLE, genericResponse.getBody().getResponse());
		assertEquals(AsyncService.SERVICE_UNAVAILABLE, genericResponse.getBody().getStatusMessage());
	}

//	@Test
//	public void getResponseEntity_504Test() throws JsonProcessingException {
//		when(httpResponse.statusCode()).thenReturn(504);
//		Map<String, Object> responseMap = new HashMap<>();
//		responseMap.put("statusMessage", "statusMessage");
//		responseMap.put("response", "response");
//
//		when(asyncService.objectMapper.readValue(anyString(), eq(HashMap.class))).thenReturn((HashMap) responseMap);
//		when(httpResponse.body()).thenReturn("{\"statusMessage\":\"statusMessage\",\"response\":\"response\"}");
//
//		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity(httpResponse, asyncServiceCallback);
//		assertEquals(HttpStatus.GATEWAY_TIMEOUT, genericResponse.getStatusCode());
//	}


//	@Test
//	public void getResponseEntity_defaultTest() throws JsonProcessingException {
//		when(httpResponse.statusCode()).thenReturn(400);
//		Map<String, Object> responseMap = new HashMap<>();
//		responseMap.put("statusMessage", "statusMessage");
//		responseMap.put("response", "response");
//
//		when(asyncService.objectMapper.readValue(anyString(), eq(HashMap.class))).thenReturn((HashMap) responseMap);
//		when(httpResponse.body()).thenReturn("{\"statusMessage\":\"statusMessage\",\"response\":\"response\"}");
//
//		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity(httpResponse, asyncServiceCallback);
//		assertEquals(HttpStatus.BAD_REQUEST, genericResponse.getStatusCode());
//	}


	@Test
	public void getResponseEntity_nullHttpResponseTest() {
		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity((HttpResponse<String>) null, asyncServiceCallback);

		assertEquals(HttpStatus.PROCESSING, genericResponse.getStatusCode());
		assertEquals("Error during service call", genericResponse.getBody().getStatusMessage());
	}


	@Test
	public void getResponseEntity_CompletionException_ConnectExceptionTest() {
		CompletionException completionException = Mockito.mock(CompletionException.class);
		ConnectException connectException = new ConnectException("connect error");

		when(completionException.getCause()).thenReturn(connectException);
		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity(completionException, asyncServiceCallback);

		assertEquals(HttpStatus.GATEWAY_TIMEOUT, genericResponse.getStatusCode());
		assertEquals(AsyncService.GATEWAY_TIMEOUT, genericResponse.getBody().getStatusMessage());
	}


	@Test
	public void getResponseEntity_CompletionException_HttpConnectTimeoutExceptionTest() {
		CompletionException completionException = Mockito.mock(CompletionException.class);
		HttpConnectTimeoutException httpConnectTimeoutException = new HttpConnectTimeoutException("connect timeout error");

		when(completionException.getCause()).thenReturn(httpConnectTimeoutException);
		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity(completionException, asyncServiceCallback);

		assertEquals(HttpStatus.GATEWAY_TIMEOUT, genericResponse.getStatusCode());
		assertEquals(AsyncService.GATEWAY_TIMEOUT, genericResponse.getBody().getStatusMessage());
	}


	@Test
	public void getResponseEntity_CompletionException_HttpTimeoutExceptionTest() {
		CompletionException completionException = Mockito.mock(CompletionException.class);
		HttpTimeoutException httpTimeoutException = new HttpTimeoutException("timeout error");

		when(completionException.getCause()).thenReturn(httpTimeoutException);
		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity(completionException, asyncServiceCallback);

		assertEquals(HttpStatus.REQUEST_TIMEOUT, genericResponse.getStatusCode());
		assertEquals(AsyncService.REQUEST_TIMEOUT, genericResponse.getBody().getStatusMessage());
	}


	@Test
	public void getResponseEntity_ThrowableTest() {
		Throwable throwable = new Throwable("generic error");

		ResponseEntity<GenericResponse> genericResponse = asyncService.getResponseEntity(throwable, asyncServiceCallback);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, genericResponse.getStatusCode());

//		assertEquals(AsyncService.INTERNAL_SERVER_ERROR, genericResponse.getBody().getStatusMessage());
	}
}