package com.fds.paperless.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.constants.QueueEnum;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fds.paperless.exception.ProcessException;
import com.fds.paperless.junit.RallyTestCase;
import com.fds.paperless.junit.UserStory;
import com.fds.paperless.model.GenericResponse;
import com.fds.paperless.msgsvc.MessageServiceMgr;
import org.springframework.test.util.ReflectionTestUtils;

public class MessageServiceControllerTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageServiceControllerTest.class);

	String queue = null;
	@InjectMocks
	private MessageServiceController messageServiceController;

	@Mock
	private MessageServiceMgr messageServiceMgr;

	@Mock
	private ObjectMapper objectMapper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		queue = QueueEnum.LOW_PRIORITY_QUEUE.getQueueName();
		Mockito.doNothing().when(messageServiceMgr).sendAsyncMessage(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyString());
		ReflectionTestUtils.setField(messageServiceController, "objectMapper", objectMapper);

	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendQueueReplyToTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.sendQueueReplyTo(queue, "replyTo", "identifier", "targetId", "jsonStr");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendQueueReplyToBadQueueTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.sendQueueReplyTo("badQueue", "replyTo", "identifier", "targetId", "jsonStr");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendQueueReplyToExceptionTest() {
		try {
			Mockito.doThrow(new ProcessException("MessageService is shutting down")).when(messageServiceMgr).sendAsyncMessage(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyString());
		} catch (ProcessException e) {
			LOGGER.error("{}", e.getMessage());
		}
		
		ResponseEntity<GenericResponse> response = messageServiceController.sendQueueReplyTo(queue, "replyTo", "identifier", "targetId", "jsonStr");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendQueueReplyToExceptionTest2() {
		try {
			Mockito.doThrow(new ProcessException("java.net.UnknownHostException")).when(messageServiceMgr).sendAsyncMessage(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyString());
		} catch (ProcessException e) {
			LOGGER.error("{}", e.getMessage());
		}
		
		ResponseEntity<GenericResponse> response = messageServiceController.sendQueueReplyTo(queue, "replyTo", "identifier", "targetId", "jsonStr");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendQueueReplyToExceptionTest3() {
		try {
			Mockito.doThrow(new ProcessException("Exception")).when(messageServiceMgr).sendAsyncMessage(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyString());
		} catch (ProcessException e) {
			LOGGER.error("{}", e.getMessage());
		}
		
		ResponseEntity<GenericResponse> response = messageServiceController.sendQueueReplyTo(queue, "replyTo", "identifier", "targetId", "jsonStr");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	@UserStory(references = {"US33488"})
	@RallyTestCase(references = {"TC33042"})
	public void peekTest(){
		ResponseEntity<GenericResponse> response = messageServiceController.peek(queue, false, true);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());

		response = messageServiceController.peek(queue,"identifier", "targetId", null, "messageId", false, true);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());

		response = messageServiceController.peek(queue, "null", "null", null, "null", false, true);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());

		response = messageServiceController.flushInMemoryToDisk(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());

		response = messageServiceController.flush(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());

		response = messageServiceController.flush(queue, "identifier", "targetId", null, "messageId");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());

		response = messageServiceController.flush(queue, "null", "null", null, "null");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());

		try {
			Mockito.doThrow(new ProcessException("MessageService is shutting down")).when(messageServiceMgr).peekOrFlush(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.any(),Mockito.anyString(), Mockito.any(), Mockito.anyBoolean(), Mockito.anyBoolean());
		} catch (ProcessException e) {
			LOGGER.error("{}", e.getMessage());
		}
		response = messageServiceController.peek(queue,"identifier", "targetId", null, "messageId", false,true);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());

		try {
			Mockito.doThrow(new Exception("Exception")).when(messageServiceMgr).peekOrFlush(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.any(), Mockito.anyString(), Mockito.any(), Mockito.anyBoolean(), Mockito.anyBoolean());
		} catch (Exception e) {
			LOGGER.error("{}", e.getMessage());
		}
		response = messageServiceController.peek(queue,"identifier", "targetId", null, "messageId", false, true);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void flushTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.flush(queue, "identifier", "targetId", 1, "messageId");
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void hardFlushTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.hardFlush(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void flushInMemoryToDiskTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.flushInMemoryToDisk(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void suspendDequeueTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.suspendDequeue(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void reactivateDequeueTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.enableDequeue(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void logStatisticsTest() {
		ResponseEntity<GenericResponse> response = messageServiceController.logStatistics();
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void removeOutstandingPayloadRequestsTest() throws ProcessException {
		Mockito.when(messageServiceMgr.removeOutstandingPayloadRequests(queue)).thenReturn(5);
		ResponseEntity<GenericResponse> response = messageServiceController.removeOutstandingPayloadRequests(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void removeOutstandingPayloadRequestsExceptionTest() {
		try {
			Mockito.doThrow(new ProcessException("Error")).when(messageServiceMgr).removeOutstandingPayloadRequests(queue);
		} catch (ProcessException e) {
			LOGGER.error("{}", e.getMessage());
		}
		ResponseEntity<GenericResponse> response = messageServiceController.removeOutstandingPayloadRequests(queue);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

//	@Test
//	public void responseToRequestTest() throws Exception {
//		String jsonStr = "{\"statusCode\":\"200\",\"statusMessage\":\"OK\",\"response\":\"Success\"}";
//		GenericResponse mockResponse = new GenericResponse();
//		mockResponse.setStatusCode("200");
//		mockResponse.setStatusMessage("OK");
//		mockResponse.setResponse("Success");
//
//		when(objectMapper.readValue(Mockito.eq(jsonStr), Mockito.any(TypeReference.class))).thenReturn(mockResponse);
//
//		ResponseEntity<GenericResponse> response = messageServiceController.responseToRequest(jsonStr);
//		assertNotNull(response);
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//	}

//	@Test
//	public void responseToRequestInvalidJsonTest() throws Exception {
//		String invalidJsonStr = "invalidJson";
//
//		when(objectMapper.readValue(Mockito.eq(invalidJsonStr), Mockito.any(TypeReference.class)))
//				.thenThrow(new RuntimeException("Invalid JSON"));
//
//		ResponseEntity<GenericResponse> response = messageServiceController.responseToRequest(invalidJsonStr);
//		assertNotNull(response);
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//	}
}