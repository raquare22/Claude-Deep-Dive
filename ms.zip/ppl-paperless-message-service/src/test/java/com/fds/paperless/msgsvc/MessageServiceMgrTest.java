package com.fds.paperless.msgsvc;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.constants.QueueEnum;
import com.fds.paperless.exception.ProcessException;
import com.fds.paperless.junit.RallyTestCase;
import com.fds.paperless.junit.UserStory;
import com.fds.paperless.model.GenericResponse;
import com.fds.paperless.model.Message;
import com.fds.paperless.mongo.ErrorMetaData;
import com.fds.paperless.mongo.MetaDataErrorCode;
import com.fds.paperless.mongo.MetaDataStatus;
import com.fds.paperless.msgsvc.BigQueueService.FLUSH;
import com.fds.paperless.msgsvc.BigQueueService.PeekedAndFlushedData;
import com.fds.paperless.msgsvc.MessageServiceMgr.AsyncServiceCallback;
import com.fds.paperless.msgsvc.MessageServiceMgr.BackPressureInfo;
import com.fds.paperless.service.AsyncService;

public class MessageServiceMgrTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageServiceMgrTest.class);

	public static final String LOW_QUEUE = "LOW_PRIORITY_QUEUE";

	private String queue = QueueEnum.LOW_PRIORITY_QUEUE.getQueue();
	private String queueName = "LOW_PRIORITY_QUEUE";

	Message message = new Message(queue, "MessageServiceMgr:8099", "replyToIndex", "identifier", "targetId", 9889, "body");

	@InjectMocks
	private MessageServiceMgr messageServiceMgr = new MessageServiceMgr(5,10,15,20,60,45,30,15,900,900,900,900,60,60,60,60,32);

	@Mock
	ErrorCollection errorCollection;

	@Mock
	private AsyncService asyncService;

	@Mock
	private BigQueueService bigQueueService;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		messageServiceMgr.objectMapper = new ObjectMapper();
		messageServiceMgr.restApiTimeoutMs = 1L;
		messageServiceMgr.maxRetryRestApiCnt = 5;
		messageServiceMgr.calculateResponseTime = false;
		messageServiceMgr.supportedDelegates = "EngineDelegateUrl=http://127.0.0.1:8081/api/services/run/delegate=8081,EngineDelegateJunkUrl=http://127.0.0.1:8081/api/services/run/delegate";
		messageServiceMgr.supportedDelegatesIndex ="DummyDelegateUrl=1000";

		MessageServiceMgr.outstandingPayloadRequestsPerQueue.put(QueueEnum.HIGH_PRIORITY_QUEUE.getQueue(),0);
		MessageServiceMgr.outstandingPayloadRequestsPerQueue.put(QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueue(),0);
		MessageServiceMgr.outstandingPayloadRequestsPerQueue.put(QueueEnum.LOW_PRIORITY_QUEUE.getQueue(),0);

		when(errorCollection.writeToErrorCollection(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
		when(errorCollection.updateErrorMetaDataSubjectStatus(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
		Mockito.doNothing().when(asyncService).postRequestToSvc(Mockito.any(), Mockito.any());
		when(bigQueueService.enqueueMessage(Mockito.any())).thenReturn(true);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendAsyncMessageTest() {
		
		boolean exceptionCaught = false;
		try {
			MessageServiceMgr.shutdown = false;
			messageServiceMgr.sendAsyncMessage(queueName, "replyTo", "identifier", "targetId", 3007, "body");
		} catch (ProcessException e) {
			e.printStackTrace();
			exceptionCaught = true;
		}
		assertFalse(exceptionCaught);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendAsyncMessageShutdownTest() {
		boolean exceptionCaught = false;
		try {
			MessageServiceMgr.shutdown = true;
			messageServiceMgr.sendAsyncMessage(queueName, "replyTo", "identifier", "targetId", 3007, "body");
		} catch (ProcessException e) {
			e.printStackTrace();
			exceptionCaught = true;
		}
		assertTrue(exceptionCaught);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendAsyncMessageMsgTest() {
		boolean exceptionCaught = false;
		try {
			MessageServiceMgr.shutdown = false;
			messageServiceMgr.delegateMap.put("MessageServiceMgr", "http://127.0.0.1:8081/api/services/run/delegate");
			messageServiceMgr.sendAsyncMessage(message);
		} catch (Exception e) {
			exceptionCaught = true;
			LOGGER.error("Caught exception {}", ExceptionUtils.getStackTrace(e));
		}
		assertFalse(exceptionCaught);
	}
	
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendAsyncMessageMsgUrlNotFoundTest() {
		boolean exceptionCaught = false;
		try {
			MessageServiceMgr.shutdown = false;
			messageServiceMgr.delegateMap.put("MessageServiceMgr", "http://127.0.0.1:8081/api/services/run/delegate");
			messageServiceMgr.sendAsyncMessage(message);
		} catch (Exception e) {
			exceptionCaught = true;
			LOGGER.error("Caught exception {}", ExceptionUtils.getStackTrace(e));
		}
		assertFalse(exceptionCaught);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void shutdownFirstTest() {
		MessageServiceMgr.outstandingPayloadRequestMap.clear();
		MessageServiceMgr.shutdown = false;
		boolean exceptionCaught = false;
		MessageServiceMgr.shutdown();
		assertFalse(exceptionCaught);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void shutdownSecondTest() {
		MessageServiceMgr.outstandingPayloadRequestMap.clear();
		MessageServiceMgr.shutdown = true;
		boolean exceptionCaught = false;
		MessageServiceMgr.shutdown();
		assertFalse(exceptionCaught);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void processAsyncSuccessTest() {
		AsyncServiceCallback asyncServiceCallback = messageServiceMgr.new AsyncServiceCallback(messageServiceMgr,message);
		messageServiceMgr.processAsyncSuccess(asyncServiceCallback.getMessage());
		assertNotNull(messageServiceMgr);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void processAsyncSuccessErrorCollectionTest() {
		message.setMetadataId("1234");
		AsyncServiceCallback asyncServiceCallback = messageServiceMgr.new AsyncServiceCallback(messageServiceMgr,message);
		messageServiceMgr.processAsyncSuccess(asyncServiceCallback.getMessage());
		assertNotNull(messageServiceMgr);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void processAsyncFailureTest() {
		ResponseEntity responseEntity = new ResponseEntity<>(new GenericResponse("102", "Error during service call", "responseEntity == null"), HttpStatus.PROCESSING);
		AsyncServiceCallback asyncServiceCallback = messageServiceMgr.new AsyncServiceCallback(messageServiceMgr,message);
		messageServiceMgr.processAsyncFailure(asyncServiceCallback.getMessage(), responseEntity);
		asyncServiceCallback.toStringVerbose();
		assertNotNull(messageServiceMgr);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void processAsyncFailure408Test() {
		ResponseEntity responseEntity = new ResponseEntity<>(new GenericResponse("408", "Error during service call", "responseEntity == null"), HttpStatus.REQUEST_TIMEOUT);
		AsyncServiceCallback asyncServiceCallback = messageServiceMgr.new AsyncServiceCallback(messageServiceMgr,message);
		messageServiceMgr.processAsyncFailure(asyncServiceCallback.getMessage(), responseEntity);
		asyncServiceCallback.toStringVerbose();
		assertNotNull(messageServiceMgr);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void processAsyncFailureConnectionRefusedTest() {
		message.setMetadataId("1234");
		message.setRetryCount(4);
		ResponseEntity responseEntity = new ResponseEntity<>(new GenericResponse("102", "Error during service call", "Connection refused"), HttpStatus.PROCESSING);
		AsyncServiceCallback asyncServiceCallback = messageServiceMgr.new AsyncServiceCallback(messageServiceMgr,message);
		messageServiceMgr.processAsyncFailure(asyncServiceCallback.getMessage(), responseEntity);
		assertNotNull(messageServiceMgr);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void processAsyncFailureConnectionRefusedExceedsTest() {
		messageServiceMgr.calculateResponseTime = true;
		MessageServiceMgr.outstandingPayloadRequestMap.put(message.getMessageId(), messageServiceMgr.new BackPressureInfo(message));
		message.setMetadataId("1234");
		message.setRetryCount(5);
		ResponseEntity responseEntity = new ResponseEntity<>(new GenericResponse("102", "Error during service call", "Connection refused"), HttpStatus.PROCESSING);
		AsyncServiceCallback asyncServiceCallback = messageServiceMgr.new AsyncServiceCallback(messageServiceMgr,message);
		assertNotNull(asyncServiceCallback.getReceiveAsyncResponse());
		messageServiceMgr.processAsyncFailure(asyncServiceCallback.getMessage(), responseEntity);
		assertNotNull(messageServiceMgr);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void sendErrorCollectionMsgTest() {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":1}");
		errorMetaData.setRetryCount(4);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		ArrayList<ErrorMetaData> errorMetaDataList = new ArrayList<>();
		errorMetaDataList.add(errorMetaData);
		messageServiceMgr.resendExecutors.enqueueErrorCollectionMsg(errorMetaDataList);
		errorMetaData.setSubject(null);
		messageServiceMgr.resendExecutors.enqueueErrorCollectionMsg(errorMetaDataList);
		assertNotNull(messageServiceMgr);
	}

	@Test
	@UserStory(references = {"US33134"})
	@RallyTestCase(references = {"TC32999"})
	public void isValidPriorityQueueTest() {
		assertTrue(MessageServiceMgr.isValidPriorityQueue(QueueEnum.PREMIUM_PRIORITY_QUEUE.getQueueName()));
		assertTrue(MessageServiceMgr.isValidPriorityQueue(QueueEnum.HIGH_PRIORITY_QUEUE.getQueueName()));
		assertTrue(MessageServiceMgr.isValidPriorityQueue(QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueueName()));
		assertTrue(MessageServiceMgr.isValidPriorityQueue(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName()));
		assertFalse(MessageServiceMgr.isValidPriorityQueue("JUNK"));
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void peekOrFlushTest() {
		boolean writeToAppError = false;
		boolean verbose = false;
		PeekedAndFlushedData peekedAndFlushedData = bigQueueService.new PeekedAndFlushedData();
		try {
			when(bigQueueService.peekOrFlush(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyBoolean())).thenReturn(peekedAndFlushedData);
		} catch (ProcessException e) {
			LOGGER.info("{}", e.getMessage());
		}
		boolean exceptionCaught = false;
		try {
			messageServiceMgr.peekOrFlush(queueName, "identifier", "targetId", null, "messageId", FLUSH.KEYED, writeToAppError, verbose);
		} catch (ProcessException e) {
			exceptionCaught = true;
			LOGGER.info("{}", e.getMessage());
		}
		assertFalse(exceptionCaught);

		writeToAppError  = true;
		try {
			messageServiceMgr.peekOrFlush(queueName, "identifier", "targetId", null, "messageId", FLUSH.NONE, writeToAppError, verbose);
		} catch (ProcessException e) {
			exceptionCaught = true;
			LOGGER.info("{}", e.getMessage());
		}
		assertFalse(exceptionCaught);

		writeToAppError  = false;
		try {
			messageServiceMgr.peekOrFlush(queueName, "identifier", "targetId", null, "messageId", FLUSH.NONE, writeToAppError, verbose);
		} catch (ProcessException e) {
			exceptionCaught = true;
			LOGGER.info("{}", e.getMessage());
		}
		assertFalse(exceptionCaught);

		try {
			Mockito.when(bigQueueService.peekOrFlush(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyBoolean())).thenThrow(new ProcessException("peekOrFlushActive not allowed"));
		} catch (ProcessException e) {
			LOGGER.error("{}", e.getMessage());
		}
		try {
			messageServiceMgr.peekOrFlush(queueName, "identifier", "targetId", null, "messageId", FLUSH.NONE, writeToAppError, verbose);
		} catch (ProcessException e) {
			exceptionCaught = true;
			LOGGER.info("{}", e.getMessage());
		}
		assertFalse(exceptionCaught);
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void writePeekToAppErrorTest() {
		messageServiceMgr.writePeekToAppError(message);

		when(errorCollection.getErrorMetaDataByMessageId(Mockito.any())).thenReturn(new ErrorMetaData());
		messageServiceMgr.writePeekToAppError(message);
		assertNotNull(messageServiceMgr);
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void resendExecutorsTest() {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setQueue(queue);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":1}");
		errorMetaData.setRetryCount(4);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		List<ErrorMetaData> errorMetaDataList = new ArrayList<>();
		errorMetaDataList.add(errorMetaData);
		messageServiceMgr.resendExecutors.enqueueErrorCollectionMsg(errorMetaDataList);
		assertNotNull(messageServiceMgr);
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void ageOffBackPressureExecutorsTest() {
		messageServiceMgr.ageOffSeconds = 1L;
		BackPressureInfo backPressureInfo = messageServiceMgr.new BackPressureInfo(message);
		Instant now = Instant.now().plusSeconds(10L);
		messageServiceMgr.ageOffBackPressureExecutors.ageOffBackPressure(backPressureInfo, now);
		assertTrue(MessageServiceMgr.ageOffCount.get(3) > 0);

		messageServiceMgr.ageOffSeconds = 10L;
		now = Instant.now().plusSeconds(1L);
		messageServiceMgr.ageOffBackPressureExecutors.ageOffBackPressure(backPressureInfo, now);
		assertTrue(MessageServiceMgr.ageOffCount.get(3) > 0);
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void premiumSingleThreadScheduledExecutoTest() {
		messageServiceMgr.queueExecutors.dequeueAndSendAsyncMessage(queue, 10);
		assertNotNull(messageServiceMgr);
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void postRequestToSvcTest() {
		messageServiceMgr.ageOffSeconds = 1L;
		try {
			messageServiceMgr.postRequestToSvc(message);
			assertEquals(1,MessageServiceMgr.outstandingPayloadRequestMap.size());
		} catch (ProcessException e) {
			LOGGER.info("{}", e.getMessage());
		}
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void processAsyncResponseTest() {
		ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(new GenericResponse("200","OK","low-priority-queues:2e72ec02-dd28-44d7-9f4b-6de2826689a5:processMetadataFiles:620a61a6dbb91110e75137c0"), HttpStatus.OK);
		messageServiceMgr.processAsyncResponse(responseEntity);
		assertNull(MessageServiceMgr.outstandingPayloadRequestMap.get("2e72ec02-dd28-44d7-9f4b-6de2826689a5"));

		MessageServiceMgr.outstandingPayloadRequestMap.put("2e72ec02-dd28-44d7-9f4b-6de2826689a5", messageServiceMgr.new BackPressureInfo(message));
		messageServiceMgr.processAsyncResponse(responseEntity);
		assertNull(MessageServiceMgr.outstandingPayloadRequestMap.get("2e72ec02-dd28-44d7-9f4b-6de2826689a5"));

		responseEntity = new ResponseEntity<>(new GenericResponse("500","OK","low-priority-queues:2e72ec02-dd28-44d7-9f4b-6de2826689a5:processMetadataFiles:620a61a6dbb91110e75137c0"), HttpStatus.OK);
		MessageServiceMgr.outstandingPayloadRequestMap.put("2e72ec02-dd28-44d7-9f4b-6de2826689a5", messageServiceMgr.new BackPressureInfo(message));
		messageServiceMgr.processAsyncResponse(responseEntity);
		assertNull(MessageServiceMgr.outstandingPayloadRequestMap.get("2e72ec02-dd28-44d7-9f4b-6de2826689a5"));
		
		responseEntity = new ResponseEntity<>(new GenericResponse("200","OK","low-priority-queues:2e72ec02-dd28-44d7-9f4b-6de2826689a5:processMetadataFiles"), HttpStatus.OK);
		messageServiceMgr.processAsyncResponse(responseEntity);
		assertNull(MessageServiceMgr.outstandingPayloadRequestMap.get("2e72ec02-dd28-44d7-9f4b-6de2826689a5"));
	}

	@Test
	@UserStory(references = {"US33567"})
	@RallyTestCase(references = {"TC33057"})
	public void checkForAppErrorTest() {
		messageServiceMgr.checkForAppError(message);
		assertNotNull(messageServiceMgr);
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void checkRestApiErrorNullTest() {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setQueue(queue);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":4}");
		errorMetaData.setRetryCount(4);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		Message message = new Message(errorMetaData);
		int rc = messageServiceMgr.checkRestApiError(message, null);
		assertEquals (MetaDataStatus.MANUAL.ordinal(), rc);
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void checkRestApiErrorRetryCountNotExceededTest() {
		messageServiceMgr.maxRetryRestApiCnt = 5;
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setQueue(queue);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":4}");
		errorMetaData.setRetryCount(4);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		Message message = new Message(errorMetaData);
		GenericResponse responseEntity = new GenericResponse("503", "Error during service call", "responseEntity == null");
		int rc = messageServiceMgr.checkRestApiError(message, responseEntity);
		assertEquals (MetaDataStatus.AUTOMATIC.ordinal(), rc);
		responseEntity = new GenericResponse("504", "Error during service call", "responseEntity == null");
		rc = messageServiceMgr.checkRestApiError(message, responseEntity);
		assertEquals (MetaDataStatus.AUTOMATIC.ordinal(), rc);
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void checkRestApiErrorRetryCountExceededTest() {
		messageServiceMgr.maxRetryRestApiCnt = 5;
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setQueue(queue);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":6}");
		errorMetaData.setRetryCount(6);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		Message message = new Message(errorMetaData);
		GenericResponse responseEntity = new GenericResponse("504", "Error during service call", "responseEntity == null");
		int rc = messageServiceMgr.checkRestApiError(message, responseEntity);
		assertEquals (10, rc);
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void checkRestApiErrorStatusCode500AutomaticTest() {
		messageServiceMgr.maxRetryRestApiCnt = 5;
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setQueue(queue);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":0}");
		errorMetaData.setRetryCount(0);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		Message message = new Message(errorMetaData);
		GenericResponse responseEntity = new GenericResponse("500",HttpStatus.INTERNAL_SERVER_ERROR.name(),
			"high-priority-queues:78cdd92e-0d19-48a7-a61b-48883ad935df:ProcessFileUnzip:63f9e3d383d1c36321a45efe:Could not open JPA EntityManager for transaction; nested exception is org.hibernate.exception.JDBCConnectionException: Unable to acquire JDBC Connection");
		messageServiceMgr.restApiErrorProcessAutomaticArray = new String[]{"XYZ1234567890", "JDBC","NoMatch","JUNK"};
		int rc = messageServiceMgr.checkRestApiError(message, responseEntity);
		assertEquals (MetaDataStatus.AUTOMATIC.ordinal(), rc);
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void checkRestApiErrorStatusCode500ManualTest() {
		messageServiceMgr.maxRetryRestApiCnt = 5;
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setQueue(queue);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":0}");
		errorMetaData.setRetryCount(0);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		Message message = new Message(errorMetaData);
		GenericResponse responseEntity = new GenericResponse("500",HttpStatus.INTERNAL_SERVER_ERROR.name(),
			"high-priority-queues:78cdd92e-0d19-48a7-a61b-48883ad935df:ProcessFileUnzip:63f9e3d383d1c36321a45efe:Could not open JPA EntityManager for transaction; nested exception is org.hibernate.exception.JDBCConnectionException: Unable to acquire JDBC Connection");
		messageServiceMgr.restApiErrorProcessAutomaticArray = new String[]{"XYZ1234567890","NoMatch","JUNK"};
		int rc = messageServiceMgr.checkRestApiError(message, responseEntity);
		assertEquals (MetaDataStatus.MANUAL.ordinal(), rc);
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void checkRestApiErrorStatusExceptionTest() {
		messageServiceMgr.maxRetryRestApiCnt = 5;
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setErrorCode(MetaDataErrorCode.REST_API_ERROR);
		errorMetaData.setQueue(queue);
		errorMetaData.setSubject("{\"identifier\":\"LOAD_TEST\", \"targetId\":\"czap0c8og52ssfyovj8gdgzt\", \"retryRestCnt\":0}");
		errorMetaData.setRetryCount(0);
		errorMetaData.setMetadata(new Document().append("tag","value"));
		GenericResponse responseEntity = new GenericResponse("500",HttpStatus.INTERNAL_SERVER_ERROR.name(),
			"high-priority-queues:78cdd92e-0d19-48a7-a61b-48883ad935df:ProcessFileUnzip:63f9e3d383d1c36321a45efe:Could not open JPA EntityManager for transaction; nested exception is org.hibernate.exception.JDBCConnectionException: Unable to acquire JDBC Connection");
		messageServiceMgr.restApiErrorProcessAutomaticArray = new String[]{"XYZ1234567890","NoMatch","JUNK"};
		int rc = messageServiceMgr.checkRestApiError(null, responseEntity);
		assertEquals (-1, rc);
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void isMatchingSubstringTest() {
		when(errorCollection.writeToErrorCollection(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());

		messageServiceMgr.restApiErrorProcessAutomaticArray = new String[]{"XYZ1234567890","NoMatch","JUNK"};
		String response = "high-priority-queues:78cdd92e-0d19-48a7-a61b-48883ad935df:ProcessFileUnzip:63f9e3d383d1c36321a45efe:Could not open JPA EntityManager for transaction; nested exception is org.hibernate.exception.JDBCConnectionException: Unable to acquire JDBC Connection";
		int responseIsAutomatic = messageServiceMgr.isMatchingSubstring(response);
		assertEquals(-1,responseIsAutomatic);

		messageServiceMgr.restApiErrorProcessAutomaticArray = new String[]{"XYZ1234567890", "JDBC","NoMatch","JUNK"};
		response = "high-priority-queues:78cdd92e-0d19-48a7-a61b-48883ad935df:ProcessFileUnzip:63f9e3d383d1c36321a45efe:Could not open JPA EntityManager for transaction; nested exception is org.hibernate.exception.JDBCConnectionException: Unable to acquire JDBC Connection";
		responseIsAutomatic = messageServiceMgr.isMatchingSubstring(response);
		assertEquals(194,responseIsAutomatic);

		messageServiceMgr.restApiErrorProcessAutomaticArray = new String[]{""};
		response = "zzabyycdxx";
		responseIsAutomatic = messageServiceMgr.isMatchingSubstring(response);
		assertEquals(0,responseIsAutomatic);
		response = "";
		responseIsAutomatic = messageServiceMgr.isMatchingSubstring(response);
		assertEquals(0,responseIsAutomatic);
		messageServiceMgr.restApiErrorProcessAutomaticArray = null;
		responseIsAutomatic = messageServiceMgr.isMatchingSubstring(response);
		assertEquals(-1,responseIsAutomatic);
	}

//	@Test
//	@UserStory(references = {"US5480409"})
//	@RallyTestCase(references = {"TC3408060"})
//	public void shutdownWhileOutstandingRequestsExist() {
//		MessageServiceMgr.outstandingPayloadRequestMap.put("messageId1", messageServiceMgr.new BackPressureInfo(message));
//		MessageServiceMgr.outstandingPayloadRequestMap.put("messageId2", messageServiceMgr.new BackPressureInfo(message));
//		MessageServiceMgr.shutdown();
//		assertTrue(MessageServiceMgr.shutdown);
//		assertTrue(MessageServiceMgr.outstandingPayloadRequestMap.isEmpty());
//	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void shutdownWithoutOutstandingRequests() {
		MessageServiceMgr.outstandingPayloadRequestMap.clear();
		MessageServiceMgr.shutdown();
		assertTrue(MessageServiceMgr.shutdown);
		assertTrue(MessageServiceMgr.outstandingPayloadRequestMap.isEmpty());
	}

//	@Test
//	@UserStory(references = {"US5480409"})
//	@RallyTestCase(references = {"TC3408060"})
//	public void processAsyncResponseWithNullBody() {
//		ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(null, HttpStatus.OK);
//		messageServiceMgr.processAsyncResponse(responseEntity);
//		assertTrue(MessageServiceMgr.outstandingPayloadRequestMap.isEmpty());
//	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void processAsyncResponseWithInvalidQueue() {
		ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(new GenericResponse("200", "OK", "invalid-queue:messageId:identifier:targetId"), HttpStatus.OK);
		messageServiceMgr.processAsyncResponse(responseEntity);
		assertTrue(MessageServiceMgr.outstandingPayloadRequestMap.isEmpty());
	}

	@Test
	@UserStory(references = {"US5480409"})
	@RallyTestCase(references = {"TC3408060"})
	public void removeOutstandingPayloadRequestWithNonExistentMessageId() {
		BackPressureInfo result = messageServiceMgr.removeOutstandingPayloadRequest(queue, "nonExistentMessageId", null);
		assertNull(result);
	}

//	@Test
//	@UserStory(references = {"US5480409"})
//	@RallyTestCase(references = {"TC3408060"})
//	public void removeOutstandingPayloadRequestWithValidMessageId() {
//		MessageServiceMgr.outstandingPayloadRequestMap.put("validMessageId", messageServiceMgr.new BackPressureInfo(message));
//		BackPressureInfo result = messageServiceMgr.removeOutstandingPayloadRequest(queue, "validMessageId", null);
//		assertNotNull(result);
//		assertTrue(MessageServiceMgr.outstandingPayloadRequestMap.isEmpty());
//	}
}