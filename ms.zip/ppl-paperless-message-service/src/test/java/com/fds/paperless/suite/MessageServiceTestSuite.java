package com.fds.paperless.suite;

import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.fds.paperless.SanitizeUtilTest;
import com.fds.paperless.controller.MessageServiceControllerTest;
import com.fds.paperless.exception.ProcessExceptionTest;
import com.fds.paperless.exception.ValidationExceptionTest;
import com.fds.paperless.msgsvc.ErrorCollectionTest;
import com.fds.paperless.msgsvc.MessageServiceMgrTest;
import com.fds.paperless.service.AsyncServiceTest;
import com.fds.paperless.service.ErrorMetaDataServiceImplTest;
import com.fds.paperless.msgsvc.BigQueueServiceTest;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	ProcessExceptionTest.class,
	ValidationExceptionTest.class,
	ErrorMetaDataServiceImplTest.class,
	AsyncServiceTest.class,
	ErrorCollectionTest.class,
	MessageServiceControllerTest.class,
	MessageServiceMgrTest.class,
	BigQueueServiceTest.class,
	SanitizeUtilTest.class
})

public class MessageServiceTestSuite extends TestCase {}