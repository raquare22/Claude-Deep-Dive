package com.fds.paperless.msgsvc;

import static org.junit.Assert.assertNotNull;

import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.model.Message;
import com.fds.paperless.mongo.ErrorMetaData;
import com.fds.paperless.mongo.MetaDataErrorCode;
import com.fds.paperless.mongo.MetaDataStatus;
import com.fds.paperless.service.ErrorMetaDataService;

public class ErrorCollectionTest {
	@InjectMocks
	private ErrorCollection errorCollection;

	@Mock
	private ErrorMetaDataService errorMetaDataService;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		errorCollection.objectMapper = new ObjectMapper();
	}

	@Test
	public void writeToErrorCollectionTest() {
		
		when(errorMetaDataService.saveErrorMetaData(Mockito.any())).thenReturn(new ErrorMetaData());
		Message message = new Message("queue", "replyTo", "replyToIndex", "identifier", "targetId", 3007, "{\"response\":\"response\",\"statusCode\":\"200\",\"statusMessage\":\"OK\",\"responseMsg\":\"Message received\"}");
		ErrorMetaData errorMetaData = errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.AUTOMATIC, " errorMsg");
		assertNotNull(errorMetaData);
	}
}
