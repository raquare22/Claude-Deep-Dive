package com.fds.paperless.util;

import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.function.Function;

public class UtilityTest {

    private MockedStatic<System> systemMock;
    private Function<String, String> originalEnvFunction;

    @Before
    public void setUp() {
        originalEnvFunction = Utility.envFunction;
    }

    @After
    public void tearDown() {
        if (systemMock != null) {
            systemMock.close();
        }

        // Restore original environment function
        try {
            java.lang.reflect.Field field = Utility.class.getDeclaredField("envFunction");
            field.setAccessible(true);
            field.set(null, originalEnvFunction);
        } catch (Exception e) {
            // Handle exception
        }
    }

//    @Test
//    public void getEnvironmentReturnsConfiguredEnvironment() {
//        // Mock the environment function
//        Function<String, String> mockEnvFunction = key -> "dev";
//        setMockEnvFunction(mockEnvFunction);
//
//        Assert.assertEquals("dev", Utility.getEnvironment());
//    }
//
//    @Test
//    public void getEnvironmentReturnsLocalWhenEnvironmentIsNull() {
//        // Mock the environment function to return null
//        Function<String, String> mockEnvFunction = key -> null;
//        setMockEnvFunction(mockEnvFunction);
//
//        Assert.assertEquals("local", Utility.getEnvironment());
//    }
//
//    @Test
//    public void getEnvironmentReturnsLocalWhenEnvironmentIsInvalid() {
//        // Mock the environment function to return an invalid environment
//        Function<String, String> mockEnvFunction = key -> "invalid-environment";
//        setMockEnvFunction(mockEnvFunction);
//
//        Assert.assertEquals("local", Utility.getEnvironment());
//    }

    @Test
    public void sleepBlocksForSpecifiedTime() {
        long startTime = System.currentTimeMillis();
        Utility.sleep(100, "Test sleep");
        long elapsedTime = System.currentTimeMillis() - startTime;

        Assert.assertTrue("Sleep should take at least the specified time", elapsedTime >= 100);
    }

    @Test
    public void sleepHandlesInterruptedException() {
        Thread currentThread = Thread.currentThread();
        Thread interrupter = new Thread(() -> {
            try {
                Thread.sleep(50);
                currentThread.interrupt();
            } catch (InterruptedException e) {
                // Ignore
            }
        });

        interrupter.start();
        Utility.sleep(500, "Test interrupt");

        Assert.assertTrue("Thread should be in interrupted state", Thread.interrupted());
    }

    private void setMockEnvFunction(Function<String, String> mockFunction) {
        try {
            java.lang.reflect.Field field = Utility.class.getDeclaredField("envFunction");
            field.setAccessible(true);
            field.set(null, mockFunction);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set mock environment function", e);
        }
    }
}