package com.fds.paperless;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class SanitizeUtilTest {
    @Test
    public void testSanitizeToString() {
        String input = "[Prior Auth]";
        Assert.assertEquals(input, SanitizeUtil.sanitizeToString(input));
    }
    
    @Test
    public void testSanitizeToString2() {
        String input = "[abcdABCDR1209!@#$%^&()<>?{}|]";
        Assert.assertEquals(input, SanitizeUtil.sanitizeToString(input));
    }

    @Test
    public void testSanitizeQueueName() {
        String input = "PremiumPriorityQueue";
        Assert.assertEquals(input, SanitizeUtil.sanitizeQueueName(input));
    }

    @Test
    public void testSanitizeIntegerString() {
        String input = "0123459876543";
        Assert.assertEquals(input, SanitizeUtil.sanitizeIntegerString(input));
    }

    @Test
    public void testSanitizeIntegerStringFailure() {
        String input = "JUNK";
        Assert.assertEquals(SanitizeUtil.REPLACEMENT_CHARACTER +SanitizeUtil.REPLACEMENT_CHARACTER + SanitizeUtil.REPLACEMENT_CHARACTER + SanitizeUtil.REPLACEMENT_CHARACTER , SanitizeUtil.sanitizeIntegerString(input));
    }

    @Test
    public void testSanitizeAlphaString() {
    	String input = "abcytrHHRCaa";
        Assert.assertEquals(input, SanitizeUtil.sanitizeAlphaString(input));
    }

    @Test
    public void testSanitizeAlphaStringFailure() {
    	String input = "abcytrHHRCaa123";
        Assert.assertEquals("abcytrHHRCaa" + SanitizeUtil.REPLACEMENT_CHARACTER +SanitizeUtil.REPLACEMENT_CHARACTER + SanitizeUtil.REPLACEMENT_CHARACTER, SanitizeUtil.sanitizeAlphaString(input));
    }

    @Test
    public void testSanitizeAlphaNumericString() {
        String input = "012345abcytrHHRCaa987654";
        Assert.assertEquals(input, SanitizeUtil.sanitizeAlphaNumericString(input));
    }

    @Test
    public void testSanitizeAlphaNumericStringFailure() {
        String input = "012345abcytrHHRCaa987654#";
        Assert.assertEquals("012345abcytrHHRCaa987654" + SanitizeUtil.REPLACEMENT_CHARACTER, SanitizeUtil.sanitizeAlphaNumericString(input));
    }

    @Test
    public  void testSanitizeAlphaNumericStringWithHyphen() {
        String input = "012345-abcytrHHRCaa-987654";
        Assert.assertEquals(input, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(input));
    }

    @Test
    public  void testSanitizeAlphaNumericStringWithHyphenFailure() {
        String input = "012345-abcytrHHRCaa-%987654";
        Assert.assertEquals("012345-abcytrHHRCaa-" + SanitizeUtil.REPLACEMENT_CHARACTER + "987654", SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(input));
    }
    @Test
    public  void testSanitizeRequestMap(){
        Map<String, Object> validMap = new HashMap<>();
        validMap.put("name", "kaleab");
        validMap.put("age", 25);

        String result = SanitizeUtil.sanitizeRequestMap(validMap);
        String expectedJson = "{\"name\":\"kaleab\",\"age\":25}";
        Assert.assertEquals(expectedJson, result);

        Assert.assertNull(SanitizeUtil.sanitizeRequestMap(null));
    }

    @Test
    public void testSanitizeJsonString() {
        String validJson = "{\"name\":\"John\",\"age\":30}";
        Assert.assertEquals(validJson, SanitizeUtil.sanitizeJsonString(validJson));
    }

    @Test
    public void testSanitizeJsonStringWithInvalidJson() {
        String invalidJson = "{name:John,age:30";
        Assert.assertEquals("Sanitize Failure", SanitizeUtil.sanitizeJsonString(invalidJson));
    }

    @Test
    public void testSanitizeJsonStringWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeJsonString(null));
    }

    @Test
    public void testSanitizeResponseEntityBody() {
        ResponseEntity<String> response = ResponseEntity.ok("{\"status\":\"success\"}");
        String sanitizedBody = SanitizeUtil.sanitizeResponseEntityBody(response);
        Assert.assertEquals("{\"status\":\"success\"}", sanitizedBody);
    }

    @Test
    public void testSanitizeResponseEntityBodyWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeResponseEntityBody(null));
    }

    @Test
    public void testSanitizeToStringWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeToString(null));
    }

    @Test
    public void testSanitizeToStringWithVerticalWhitespace() {
        String input = "Line1\nLine2\rLine3\fLine4";
        Assert.assertEquals("Line1Line2Line3Line4", SanitizeUtil.sanitizeToString(input));
    }

    @Test
    public void testSanitizeQueueNameWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeQueueName(null));
    }

    @Test
    public void testSanitizeIntegerStringWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeIntegerString(null));
    }

    @Test
    public void testSanitizeIntegerStringWithMixedContent() {
        String input = "123abc456";
        Assert.assertEquals("123$$$456", SanitizeUtil.sanitizeIntegerString(input));
    }

    @Test
    public void testSanitizeAlphaStringWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeAlphaString(null));
    }

    @Test
    public void testSanitizeAlphaNumericStringWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeAlphaNumericString(null));
    }

    @Test
    public void testSanitizeAlphaNumericStringWithHyphenWithNull() {
        Assert.assertNull(SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(null));
    }
    
    @Test
    public void testSanitizeRequestMapWithComplexObject() {
        Map<String, Object> map = new HashMap<>();
        map.put("string", "value");
        map.put("number", 123);
        map.put("boolean", true);

        Map<String, Object> nestedMap = new HashMap<>();
        nestedMap.put("nestedKey", "nestedValue");
        map.put("nested", nestedMap);

        String result = SanitizeUtil.sanitizeRequestMap(map);
        Assert.assertTrue(result.contains("\"string\":\"value\""));
        Assert.assertTrue(result.contains("\"number\":123"));
        Assert.assertTrue(result.contains("\"boolean\":true"));
        Assert.assertTrue(result.contains("\"nested\":{\"nestedKey\":\"nestedValue\"}"));
    }

    }