package com.fds.paperless.msgsvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fds.paperless.constants.QueueEnum;
import com.fds.paperless.exception.ProcessException;
import com.fds.paperless.junit.RallyTestCase;
import com.fds.paperless.junit.UserStory;
import com.fds.paperless.model.Message;
import com.fds.paperless.msgsvc.BigQueueService.ActiveEnum;
import com.fds.paperless.msgsvc.BigQueueService.FLUSH;
import com.fds.paperless.msgsvc.BigQueueService.PeekedAndFlushedData;
import com.leansoft.bigqueue.BigQueueImpl;
import com.leansoft.bigqueue.IBigQueue;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicIntegerArray;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.springframework.test.util.ReflectionTestUtils;

public class BigQueueServiceTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(BigQueueServiceTest.class);

    @InjectMocks
    private BigQueueService bigQueueService = getBigQueueService();

    private Message highMessage = new Message(QueueEnum.HIGH_PRIORITY_QUEUE.getQueue(), "replyTo", "replyToIndex", "identifier", "targetId", 9889, "body");
    private Message mediumMessage = new Message(QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueue(), "replyTo", "replyToIndex", "identifier", "targetId", 9889, "body");
    private Message lowMessage = new Message(QueueEnum.LOW_PRIORITY_QUEUE.getQueue(), "replyTo", "replyToIndex", "identifier", "targetId", 9889, "body");

    @Before
   public void setUp() {
       MockitoAnnotations.openMocks(this);
    }

    protected BigQueueService getBigQueueService() {
    	try {
			return new  BigQueueService("/prun-pv/msg_srv/bigQ");
		} catch (ProcessException e) {
			e.printStackTrace();
			return null;
		}
    }

    @Test
    @UserStory(references = {"US33337"})
    @RallyTestCase(references = {"TA69747"})
    public void highPriorityQueueTest() throws ProcessException {
        boolean result = bigQueueService.enqueueMessage(highMessage);
        assertEquals(true, result);
        List<Message> messageList = bigQueueService.dequeueMessage(highMessage.getQueue(), 1, 0);
        assertNotNull(messageList);
        assertEquals(1, messageList.size());
        assertEquals(QueueEnum.HIGH_PRIORITY_QUEUE.getQueue(), messageList.get(0).getQueue());
    }

    @Test
    @UserStory(references = {"US33337"})
    @RallyTestCase(references = {"TA69747"})
    public void mediumPriorityQueueTest() throws ProcessException {
        boolean result = bigQueueService.enqueueMessage(mediumMessage);
        assertEquals(true, result);
        List<Message> messageList = bigQueueService.dequeueMessage(mediumMessage.getQueue(), 1, 0);
        assertNotNull(messageList);
        assertEquals(1, messageList.size());
        assertEquals(QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueue(), messageList.get(0).getQueue());
    }

    @Test
    @UserStory(references = {"US33337"})
    @RallyTestCase(references = {"TA69747"})
    public void lowPriorityQueueTest() throws ProcessException {
        boolean result = bigQueueService.enqueueMessage(lowMessage);
        assertEquals(true, result);
        List<Message> messageList = bigQueueService.dequeueMessage(lowMessage.getQueue(), 1, 0);
        assertNotNull(messageList);
        assertEquals(1, messageList.size());
        assertEquals(QueueEnum.LOW_PRIORITY_QUEUE.getQueue(), messageList.get(0).getQueue());
    }

    @Test
    @UserStory(references = {"US33337"})
    @RallyTestCase(references = {"TA69747"})
    public void enqueueFailureTest() throws IOException, ProcessException {
        IBigQueue highPriorityQueue = Mockito.spy(new BigQueueImpl(System.getProperty("user.home"), QueueEnum.HIGH_PRIORITY_QUEUE.getQueueName()));
        bigQueueService.queueMap.put(QueueEnum.HIGH_PRIORITY_QUEUE.getQueue(), highPriorityQueue);
        ObjectMapper objectMapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
        Mockito.doThrow(new IOException()).when(highPriorityQueue).enqueue(objectMapper.writeValueAsBytes(highMessage));
        boolean result = bigQueueService.enqueueMessage(highMessage);
        assertEquals(false, result);
    }

    @Test
    @UserStory(references = {"US33337"})
    @RallyTestCase(references = {"TA69747"})
    public void dequeueFailureTest() throws IOException, ProcessException {
        IBigQueue highPriorityQueue = Mockito.spy(new BigQueueImpl(System.getProperty("user.home"), QueueEnum.HIGH_PRIORITY_QUEUE.getQueueName()));
        bigQueueService.queueMap.put(QueueEnum.HIGH_PRIORITY_QUEUE.getQueue(), highPriorityQueue);
        Mockito.when(highPriorityQueue.dequeue()).thenThrow(new IOException());
        boolean result = bigQueueService.enqueueMessage(highMessage);
        assertEquals(true, result);
        List<Message> messageList = bigQueueService.dequeueMessage(highMessage.getQueue(), 1, 0);
        assertNotNull(messageList);
        assertEquals(0, messageList.size());
        Mockito.doCallRealMethod().when(highPriorityQueue).dequeue();
        bigQueueService.dequeueMessage(highMessage.getQueue(), 1, 0);
    }

    @Test
    @UserStory(references = {"US33488"})
    @RallyTestCase(references = {"TC33042"})
    public void peekOrFlushTest() throws IOException, ProcessException {
        bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), null, null, null, null, FLUSH.KEYED, false);

        // Nothing in queue all isEmpty
        PeekedAndFlushedData result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier", "targetId", null, "messageId", FLUSH.NONE, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());

        // Peek match on the one element
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());

        // InMemory flush
        bigQueueService.enqueueMessage(lowMessage);
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), null, null, null, null, FLUSH.IN_MEMORY, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());

        // Peek no match on XmessageIdX both lists empty
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier", "targetId", null, "XmessageIdX", FLUSH.NONE, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());

        // Peek match peekList ! empty
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier", "targetId", null, null, FLUSH.NONE, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertFalse(result.getPeekList().isEmpty());

        // Flush match flushList ! empty, peekList empty
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier", "targetId", null, null, FLUSH.KEYED, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertFalse(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());

        // Flush match on message2; peek match on message
        Message lowMessage2 = new Message(QueueEnum.LOW_PRIORITY_QUEUE.getQueue(), "replyTo", "replyToIndex", "identifier2", "targetId", 9889, "body");
        bigQueueService.enqueueMessage(lowMessage);
        bigQueueService.enqueueMessage(lowMessage2);
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier2", "targetId", null, null, FLUSH.KEYED, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertFalse(result.getFlushedList().isEmpty());
        assertFalse(result.getPeekList().isEmpty());

        // Flush match on message2; no peek
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), null, null, null, null, FLUSH.KEYED, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertFalse(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());

        // All above non covered conditions on continueAction
        AtomicIntegerArray activeArray = new AtomicIntegerArray(1);
        activeArray.set(0, 0);
        bigQueueService.peekOrFlushActive.set(2,1);
        boolean actionContinue = bigQueueService.continueAction(2, activeArray, ActiveEnum.DEQUEUE_ACTIVE, false);
        assertFalse(actionContinue);
        actionContinue = bigQueueService.continueAction(2, activeArray, ActiveEnum.PEAK_OR_FLUSH_ACTIVE, false);
        assertFalse(actionContinue);
        bigQueueService.peekOrFlushActive.set(2,0);
        bigQueueService.dequeueActive.set(2,1);
        actionContinue = bigQueueService.continueAction(2, activeArray, ActiveEnum.PEAK_OR_FLUSH_ACTIVE, false);
        assertFalse(actionContinue);
        bigQueueService.dequeueActive.set(2,0);
        bigQueueService.enqueueActive.set(2,1);
        actionContinue = bigQueueService.continueAction(2, activeArray, ActiveEnum.PEAK_OR_FLUSH_ACTIVE, false);
        assertFalse(actionContinue);

        PeekedAndFlushedData peekedAndFlushedData = bigQueueService.new PeekedAndFlushedData();
        assertEquals(-1L, peekedAndFlushedData.getPreQueueSize());
        assertEquals(0L, peekedAndFlushedData.getPostQueueSize());
    }

    @Test
    @UserStory(references = {"US33337"})
    @RallyTestCase(references = {"TA69747"})
    public void closeTest() throws IOException {
        IBigQueue highPriorityQueue = Mockito.spy(new BigQueueImpl(System.getProperty("user.home"), QueueEnum.HIGH_PRIORITY_QUEUE.getQueueName()));
        Mockito.doThrow(new IOException()).when(highPriorityQueue).gc();
        bigQueueService.close(highPriorityQueue);
        assertNotNull(bigQueueService);
    }

    @Test
    @UserStory(references = {"US5480414"})
    @RallyTestCase(references = {"TC3414752"})
    public void peekOrFlushSpaceIdTest() throws IOException, ProcessException {
        bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), null, null, null, null, FLUSH.KEYED, false);

        // Nothing in queue all isEmpty
        PeekedAndFlushedData result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier", "targetId", null, "messageId", FLUSH.NONE, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());
        LOGGER.info("logQueueDetails:");
        BigQueueService.logQueueDetails();

        // Add two elements; No flush match on message2 spaceId=1000 no match; peek match on message
        Message lowMessage2 = new Message(QueueEnum.LOW_PRIORITY_QUEUE.getQueue(), "replyTo", "replyToIndex", "identifier2", "targetId", 9999, "body");
        bigQueueService.enqueueMessage(lowMessage);  //identifier, 9889
        bigQueueService.enqueueMessage(lowMessage2); //identifier2, 9999
        LOGGER.info("logQueueDetails:");
        BigQueueService.logQueueDetails();
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier2", "targetId", 1000, null, FLUSH.KEYED, false);
        LOGGER.info("No match on spaceId=1000; result={}", result);
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertFalse(result.getPeekList().isEmpty());

        // Flush match on lowMessage2; peek match on message
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), "identifier2", "targetId", 9999, null, FLUSH.KEYED, false);
        LOGGER.info("Match on identifier2, spaceId=9999; result={}", result);
        assertNotNull(result);
        assertFalse(result.getFlushedList().isEmpty());
        assertFalse(result.getPeekList().isEmpty());

        // Flush match on lowMessage; no peek
        result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), null, null, 9889, null, FLUSH.KEYED, false);
        LOGGER.info("result={}", result);
        assertNotNull(result);
        assertFalse(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());
    }
//    @Test
//    public void testEnqueueMessageWithInvalidInput() {
//        Message invalidMessage = null;
//        Exception exception = assertThrows(ProcessException.class, () -> {
//            bigQueueService.enqueueMessage(invalidMessage);
//        });
//        assertEquals("Message cannot be null", exception.getMessage());
//    }

    @Test
    public void testDequeueMessageWithEmptyQueue() throws ProcessException {
        List<Message> messages = bigQueueService.dequeueMessage(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), 10, 0);
        assertNotNull(messages);
        assertTrue(messages.isEmpty());
    }

    @Test
    public void testPeekOrFlushWithHardFlush() throws ProcessException {
        Message message = new Message(QueueEnum.LOW_PRIORITY_QUEUE.getQueue(), "replyTo", "replyToIndex", "identifier", "targetId", 1234, "body");
        bigQueueService.enqueueMessage(message);

        PeekedAndFlushedData result = bigQueueService.peekOrFlush(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName(), null, null, null, null, BigQueueService.FLUSH.HARD, false);
        assertNotNull(result);
        assertTrue(result.getFlushedList().isEmpty());
        assertTrue(result.getPeekList().isEmpty());
        assertEquals(0, result.getPostQueueSize());
    }

//    @Test
//    public void testContinueActionWithInvalidConditions() {
//        AtomicIntegerArray activeArray = new AtomicIntegerArray(1);
//        activeArray.set(0, 1);
//
//        boolean result = bigQueueService.continueAction(0, activeArray, BigQueueService.ActiveEnum.ENQUEUE_ACTIVE, false);
//        assertFalse(result);
//    }

    @Test
    public void testShutdown() {
        ReflectionTestUtils.invokeMethod(bigQueueService, "shutdown");
        assertNotNull(bigQueueService);
    }
}