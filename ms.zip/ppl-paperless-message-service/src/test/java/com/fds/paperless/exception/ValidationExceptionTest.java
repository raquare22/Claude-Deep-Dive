package com.fds.paperless.exception;

import org.junit.Test;
import com.fds.paperless.junit.RallyTestCase;
import com.fds.paperless.junit.UserStory;

import static org.junit.Assert.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ValidationExceptionTest {

	private static final Logger log = LogManager.getLogger(ValidationExceptionTest.class);

	@UserStory(references = "US29310")
	@RallyTestCase(references = "TC31570")
	@Test
	public void wrapExceptionTest(){
		try {
			throw new NullPointerException("NPE has been thrown");
		} catch(Exception e) {
			try {
				throw new ValidationException("NPE caught and rethrown as a ValidationException", e);
			} catch (ValidationException e2) {
				log.error("wrapExceptionTest Log1: message={}", e2.toString());
				assertTrue(e2.toString().contains("1: A validation error has occurred"));
				//log.error("wrapExceptionTest Log2: message={}", e2.getMessage(), e2);
				assertTrue(e2.toString().contains("NPE caught and rethrown as a ValidationException"));
				//e2.getCause() is the original NPE stack
				//log.error("wrapExceptionTest Log3: message={}", e2.getMessage(), e2.getCause());
			}
		}
	}

	@UserStory(references = "US29310")
	@RallyTestCase(references = "TC31570")
	@Test
	public void throwExceptionNoThrowableTest(){
		try {
			throw new NullPointerException("NPE has been thrown");
		} catch(Exception e) {
			try {
				throw new ValidationException("NPE caught and rethrown as a ValidationException");
			} catch (ValidationException e2) {
				log.error("wrapExceptionTest Log1: message={}", e2.toString());
				assertTrue(e2.toString().contains("1: A validation error has occurred"));
			}
		}
	}

	@UserStory(references = "US29310")
	@RallyTestCase(references = "TC31570")
	@Test
	public void throwExceptionThrowableTest(){
		try {
			throw new NullPointerException("NPE has been thrown");
		} catch(Exception e) {
			try {
				throw new ValidationException(e);
			} catch (ValidationException e2) {
				log.error("wrapExceptionTest Log1: message={}", e2.toString());
				assertTrue(e2.toString().contains("1: A validation error has occurred"));
			}
		}
	}
}
