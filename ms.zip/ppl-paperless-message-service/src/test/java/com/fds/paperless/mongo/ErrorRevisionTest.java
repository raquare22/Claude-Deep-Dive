package com.fds.paperless.mongo;

import org.bson.Document;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class ErrorRevisionTest {

    @Test
    public void setDateAttachmentUpdated_setsCorrectValue() {
        ErrorRevision errorRevision = new ErrorRevision();
        Date originalDate = new Date();
        errorRevision.setDateAttachmentUpdated(originalDate);

        Date returnedDate = errorRevision.getDateAttachmentUpdated();
        assertNotSame(originalDate, returnedDate);
        assertEquals(originalDate, returnedDate);
    }

    @Test
    public void getDateAttachmentUpdated_returnsNullWhenDateIsNull() {
        ErrorRevision errorRevision = new ErrorRevision();
        errorRevision.setDateAttachmentUpdated(null);

        assertNull(errorRevision.getDateAttachmentUpdated());
    }

    @Test
    public void setErrorMessage_setsCorrectValue() {
        ErrorRevision errorRevision = new ErrorRevision();
        errorRevision.setErrorMessage("Error occurred");

        assertEquals("Error occurred", errorRevision.getErrorMessage());
    }

    @Test
    public void setExternalId_setsCorrectValue() {
        ErrorRevision errorRevision = new ErrorRevision();
        errorRevision.setExternalId("EXT123");

        assertEquals("EXT123", errorRevision.getExternalId());
    }

    @Test
    public void setMetadata_setsCorrectValue() {
        ErrorRevision errorRevision = new ErrorRevision();
        Document metadata = new Document("key", "value");
        errorRevision.setMetadata(metadata);

        assertEquals(metadata, errorRevision.getMetadata());
    }

    @Test
    public void getMetadata_returnsNullWhenMetadataIsNull() {
        ErrorRevision errorRevision = new ErrorRevision();
        errorRevision.setMetadata(null);

        assertNull(errorRevision.getMetadata());
    }
}