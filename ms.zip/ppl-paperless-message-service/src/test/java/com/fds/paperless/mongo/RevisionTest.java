package com.fds.paperless.mongo;

import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class RevisionTest {

    @Test
    public void getDateCreated_returnsClonedDate() {
        Date originalDate = new Date();
        Revision revision = new Revision();
        revision.setDateCreated(originalDate);

        Date returnedDate = revision.getDateCreated();
        assertNotSame(originalDate, returnedDate);
        assertEquals(originalDate, returnedDate);
    }

    @Test
    public void getDateCreated_returnsNullWhenDateCreatedIsNull() {
        Revision revision = new Revision();
        revision.setDateCreated(null);

        assertNull(revision.getDateCreated());
    }

    @Test
    public void setSpaceId_withString_setsCorrectValue() {
        Revision revision = new Revision();
        revision.setSpaceId("123");

        assertEquals(123, revision.getSpaceId());
    }

    @Test
    public void setSpaceId_withInvalidString_throwsNumberFormatException() {
        Revision revision = new Revision();

        try {
            revision.setSpaceId("invalid");
            fail("Expected NumberFormatException to be thrown");
        } catch (NumberFormatException e) {
            // Test passes
        }
    }

    @Test
    public void setStatus_withString_setsCorrectEnumValue() {
        Revision revision = new Revision();
        revision.setStatus("AUTOMATIC");

        assertEquals(MetaDataStatus.AUTOMATIC, revision.getStatus());
    }

    @Test
    public void setStatus_withInvalidString_throwsIllegalArgumentException() {
        Revision revision = new Revision();

        try {
            revision.setStatus("INVALID");
            fail("Expected IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            // Test passes
        }
    }

    @Test
    public void getDateModified_returnsClonedDate() {
        Date originalDate = new Date();
        Revision revision = new Revision();
        revision.setDateModified(originalDate);

        Date returnedDate = revision.getDateModified();
        assertNotSame(originalDate, returnedDate);
        assertEquals(originalDate, returnedDate);
    }

    @Test
    public void getDateModified_returnsNullWhenDateModifiedIsNull() {
        Revision revision = new Revision();
        revision.setDateModified(null);

        assertNull(revision.getDateModified());
    }
    @Test
    public void setAppIdentifier_setsCorrectValue() {
        Revision revision = new Revision();
        revision.setAppIdentifier("App123");

        assertEquals("App123", revision.getAppIdentifier());
    }

    @Test
    public void setClientId_setsCorrectValue() {
        Revision revision = new Revision();
        revision.setClientId(456);

        assertEquals(456, revision.getClientId());
    }

    @Test
    public void setTransactionId_setsCorrectValue() {
        Revision revision = new Revision();
        revision.setTransactionId("TXN789");

        assertEquals("TXN789", revision.getTransactionId());
    }

    @Test
    public void setVersion_setsCorrectValue() {
        Revision revision = new Revision();
        revision.setVersion("1.0");

        assertEquals("1.0", revision.getVersion());
    }

    @Test
    public void setName_setsCorrectValue() {
        Revision revision = new Revision();
        revision.setName("TestName");

        assertEquals("TestName", revision.getName());
    }
}