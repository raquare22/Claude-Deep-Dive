package com.fds.paperless.msgsvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fds.paperless.SanitizeUtil;
import com.fds.paperless.constants.CommonConstants;
import com.fds.paperless.constants.QueueEnum;
import com.fds.paperless.exception.ProcessException;
import com.fds.paperless.model.Message;
import com.leansoft.bigqueue.BigQueueImpl;
import com.leansoft.bigqueue.IBigQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.stream.Collectors;

@Service
public class BigQueueService {
	private static final Logger LOGGER = LoggerFactory.getLogger(BigQueueService.class);
	private static final ObjectMapper objectMapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
	public static final int QUEUE_SUPPORTED_SIZE = 4;

	protected String bigQueuePath;

	private final IBigQueue premiumPriorityQueue;
	private final IBigQueue highPriorityQueue;
	private final IBigQueue mediumPriorityQueue;
	private final IBigQueue lowPriorityQueue;
	protected static Map<String, IBigQueue> queueMap = new HashMap<>();
	private static boolean shutdown = false;

	protected final AtomicIntegerArray enqueueActive = new AtomicIntegerArray(QUEUE_SUPPORTED_SIZE);
	protected final AtomicIntegerArray dequeueActive = new AtomicIntegerArray(QUEUE_SUPPORTED_SIZE);
	protected final AtomicIntegerArray peekOrFlushActive = new AtomicIntegerArray(QUEUE_SUPPORTED_SIZE);

	private static final String DEQUEUE_ACTIVE = ", dequeueActive=";
	private static final String PEEK_OR_FLUSH_ACTIVE = ", peekOrFlushActive=";

	public enum FLUSH {
		HARD, KEYED, IN_MEMORY, NONE
	}

	public enum ActiveEnum {
		ENQUEUE_ACTIVE, DEQUEUE_ACTIVE, PEAK_OR_FLUSH_ACTIVE
	}

	@SuppressWarnings("unchecked")
	protected final ArrayDeque<Message>[] priorityQueueEntries = new ArrayDeque[QUEUE_SUPPORTED_SIZE];

	public BigQueueService(@Value("${bigQueue.path}") String bigQueuePath) throws ProcessException {
		this.bigQueuePath = bigQueuePath;
		for (int i = 0; i < QUEUE_SUPPORTED_SIZE; i++) {
			enqueueActive.set(i, 0);
			dequeueActive.set(i, 0);
			peekOrFlushActive.set(i, 0);
			priorityQueueEntries[i] = new ArrayDeque<>();
		}

		premiumPriorityQueue = initializeQueue(QueueEnum.PREMIUM_PRIORITY_QUEUE.getQueueName());
		highPriorityQueue = initializeQueue(QueueEnum.HIGH_PRIORITY_QUEUE.getQueueName());
		mediumPriorityQueue = initializeQueue(QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueueName());
		lowPriorityQueue = initializeQueue(QueueEnum.LOW_PRIORITY_QUEUE.getQueueName());
		queueMap.put(QueueEnum.PREMIUM_PRIORITY_QUEUE.getQueue(), premiumPriorityQueue);
		queueMap.put(QueueEnum.HIGH_PRIORITY_QUEUE.getQueue(), highPriorityQueue);
		queueMap.put(QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueue(), mediumPriorityQueue);
		queueMap.put(QueueEnum.LOW_PRIORITY_QUEUE.getQueue(), lowPriorityQueue);
		logQueueDetails();
	}

	private IBigQueue initializeQueue(String queueName) throws ProcessException {
		File directory = new File(bigQueuePath);
		LOGGER.warn("queueName={}: bigQueuePath={}", queueName, bigQueuePath);
		if (! directory.exists()) {
			LOGGER.error("BigQueue directory doesn't exist: Creating directory={}", directory);
			if (directory.mkdirs()) {
				LOGGER.warn("BigQueue directory created successfully; directory={}", directory);
			} else {
				bigQueuePath = System.getProperty("user.home");
				LOGGER.error("Using user.home={}", bigQueuePath);
			}
		}
		try {
			return new BigQueueImpl(bigQueuePath, queueName);
		} catch (IOException e) {
			throw new ProcessException("queue=" + queueName + ": " + e.getMessage());
		}
	}

	public static synchronized void shutdown() {
		if (shutdown) {
			return;
		}
		shutdown = true;
		logQueueDetails();
	}

	public static void logQueueDetails() {
		try {
			IBigQueue currentQueue;
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < QUEUE_SUPPORTED_SIZE; i++) {
				currentQueue = queueMap.get(QueueEnum.getQueueAtIndex(i));
				if (currentQueue == null) {
					continue;
				}
				sb.append(QueueEnum.getQueueShortNameAtIndex(i) + ": queueSize=" + currentQueue.size());
				if (i < QUEUE_SUPPORTED_SIZE - 1) {
					sb.append(", ");
				}
			}
			if (LOGGER.isWarnEnabled()) {
				LOGGER.warn(sb.toString());
			}
		} catch (Exception e) {
			LOGGER.error("SHUTDOWN: {}", e.getMessage());
		}
	}

	public boolean enqueueMessage(Message message) throws ProcessException {
		return enqueueMessage(message, false);
	}

	protected boolean enqueueMessage(Message message, boolean skipCheck) throws ProcessException {
		String queue = message.getQueue();
		QueueEnum queueEnum = QueueEnum.getQueueEnum(queue);
		int priority = queueEnum.ordinal();
		LOGGER.debug("queue={}, priority={}, skipCheck={}, enqueueActive={}, {}", queue, priority, skipCheck, enqueueActive.get(priority), message);
		if (! continueAction(priority, enqueueActive, ActiveEnum.ENQUEUE_ACTIVE, skipCheck)) {
			throw new ProcessException("enqueueMessage not allowed during peekOrFlushActive: enqueueActive="
				+ enqueueActive.get(priority) + DEQUEUE_ACTIVE + dequeueActive.get(priority) + PEEK_OR_FLUSH_ACTIVE + peekOrFlushActive.get(priority));
		}
		boolean addedToQueue = false;
		IBigQueue currentQueue = queueMap.get(message.getQueue());
		try {
			if (currentQueue == null) {
				return addedToQueue;
			}
			currentQueue.enqueue(objectMapper.writeValueAsBytes(message));
			LOGGER.info("{}, queueSize={}, enqueueActive={}", message, currentQueue.size(), enqueueActive.get(priority));
			addedToQueue = true;
		} catch (IOException e) {
			LOGGER.error(CommonConstants.SOMETHING_WENT_WRONG, e.getLocalizedMessage());
			close(currentQueue);
		} finally {
			if (! skipCheck) {
				enqueueActive.decrementAndGet(priority);
			}
			LOGGER.debug("queue={}, priority={}, skipCheck={}, enqueueActive={}", queue, priority, skipCheck, enqueueActive.get(priority));
		}
		return addedToQueue;
	}

	public List<Message> dequeueMessage(String queue, int dequeueLimit, int outstandingRequestsCount)
			throws ProcessException {
		QueueEnum queueEnum = QueueEnum.getQueueEnum(queue);
		int priority = queueEnum.ordinal();
		LOGGER.debug("queue={}, priority={}", queue, priority);
		if (!continueAction(priority, dequeueActive, ActiveEnum.DEQUEUE_ACTIVE, false)) {
			throw new ProcessException("dequeueMessage not allowed during peekOrFlushActive: enqueueActive="
				+ enqueueActive.get(priority) + DEQUEUE_ACTIVE + dequeueActive.get(priority) + PEEK_OR_FLUSH_ACTIVE + peekOrFlushActive.get(priority));
		}
		List<Message> messageList = new ArrayList<>();
		IBigQueue currentQueue = queueMap.get(queue);
		try {
			if (currentQueue == null) {
				return messageList;
			}
			int currentCount = 0;
			int allowedLimit = dequeueLimit - outstandingRequestsCount;
			boolean dequeueFlag = false;
			if (LOGGER.isInfoEnabled() && !currentQueue.isEmpty()) {
				LOGGER.info("Before dequeue: queue={}, queueSize={}, dequeueLimit={}, outstandingRequestsCount={}, dequeueActive={}",
					queue, currentQueue.size(), dequeueLimit, outstandingRequestsCount, dequeueActive.get(priority));
			}
			while (! currentQueue.isEmpty() && ++currentCount <= allowedLimit) {
				Message message = objectMapper.readValue(currentQueue.dequeue(), Message.class);
				messageList.add(message);
				dequeueFlag = true;
			}
			if (LOGGER.isInfoEnabled() && dequeueFlag) {
				LOGGER.info("After dequeue: queue={}, queueSize={}, outstandingRequestsCount={}, dequeueActive={}",
					queue, currentQueue.size(), outstandingRequestsCount, dequeueActive.get(priority));
			}
			if (dequeueFlag) {
				currentQueue.gc();
			}
		} catch (IOException e) {
			LOGGER.error(CommonConstants.SOMETHING_WENT_WRONG, e.getLocalizedMessage());
			close(currentQueue);
		} finally {
			dequeueActive.decrementAndGet(priority);
		}
		return messageList;
	}

	public PeekedAndFlushedData peekOrFlush(String queueName, String identifier, String targetId, Integer spaceId, String messageId,
			FLUSH flush, boolean verbose) throws ProcessException {
		LOGGER.warn("queueName={}, identifier={}, targetId={}, messageId={}, flush={}, verbose={}", SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeAlphaNumericString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), flush, verbose);
		QueueEnum queueEnum = QueueEnum.getQueueNameEnum(queueName);
		String queue = queueEnum.getQueue();
		int priority = queueEnum.ordinal();
		if (!continueAction(priority, peekOrFlushActive, ActiveEnum.PEAK_OR_FLUSH_ACTIVE, false)) {
			throw new ProcessException("peekOrFlushActive not allowed; enqueueActive=" + enqueueActive.get(priority) + DEQUEUE_ACTIVE
				+ dequeueActive.get(priority) + PEEK_OR_FLUSH_ACTIVE + peekOrFlushActive.get(priority));
		}
		List<Message> peekList = new ArrayList<>();
		List<Message> flushList = new ArrayList<>();
		IBigQueue currentQueue = queueMap.get(queue);
		long preQueueSize = currentQueue.size();
		long postQueueSize = -1L;
		try {
			PeekedAndFlushedData peekedAndFlushedData = nonLoopConditions(currentQueue, flush, preQueueSize);
			if (peekedAndFlushedData != null) {
				return peekedAndFlushedData;
			}
			boolean dequeueFlag = false;
			LOGGER.info("Before dequeue: queue={}, queueSize={}, peekOrFlushActive({})={}", queue, preQueueSize, priority, peekOrFlushActive.get(priority));
			while (! currentQueue.isEmpty()) {
				Message message = objectMapper.readValue(currentQueue.dequeue(), Message.class);
				boolean match = isMatch(identifier, targetId, spaceId, messageId, message);
				if (flush == FLUSH.NONE) {
					priorityQueueEntries[priority].add(message);
					LOGGER.debug("Added priorityQueueEntries[{}]: {}", priority, message);
					if (match) {
						peekList.add(message);
						LOGGER.debug("Added peekList: {}", message);
					}
				}
				else // flush
				if (match) {
					flushList.add(message);
					LOGGER.debug("Added flushList: {}", message);
				} else {
					peekList.add(message);
					LOGGER.debug("Added peekList: {}", message);
					priorityQueueEntries[priority].add(message);
					LOGGER.debug("Added priorityQueueEntries[{}]: {}", priority, message);
				}
				dequeueFlag = true;
			}
			if (dequeueFlag) {
				LOGGER.info("After dequeue: queue={}, queueSize={}, peekOrFlushActive({})={}", queue, currentQueue.size(), priority, peekOrFlushActive.get(priority));
				requeue(priority);
				LOGGER.info("After requeue: queue={}, queueSize={}, peekOrFlushActive({})={}", queue, currentQueue.size(), priority, peekOrFlushActive.get(priority));
				currentQueue.gc();
			}
			postQueueSize = currentQueue.size();
		} catch (IOException e) {
			LOGGER.error(CommonConstants.SOMETHING_WENT_WRONG, e.getLocalizedMessage());
			close(currentQueue);
		} finally {
			peekOrFlushActive.decrementAndGet(priority);
			if (peekOrFlushActive.get(priority) != 0) {
				LOGGER.warn("Finally peekOrFlushActive({})={} != 0; Reset to 0", priority, peekOrFlushActive.get(priority));
				peekOrFlushActive.set(priority, 0);
			}
		}
		return new PeekedAndFlushedData(preQueueSize, postQueueSize, verbose, peekList, flushList);
	}

	protected PeekedAndFlushedData nonLoopConditions(IBigQueue currentQueue, FLUSH flush, long preQueueSize) throws ProcessException {
		if (currentQueue == null) {
			return new PeekedAndFlushedData();
		}
		if (currentQueue.isEmpty()) {
			return new PeekedAndFlushedData(true, flush, 0);
		}
		if (flush == FLUSH.HARD) {
			try {
				currentQueue.removeAll();
				currentQueue.gc();
				return new PeekedAndFlushedData(false, flush, preQueueSize);
			} catch (IOException e) {
				throw new ProcessException("Hard flush failure: " + e.getMessage());
			}
		}
		if (flush == FLUSH.IN_MEMORY) {
			currentQueue.flush();
			return new PeekedAndFlushedData(false, flush, currentQueue.size());
		}
		return null;
	}

	protected synchronized boolean continueAction(int priority, AtomicIntegerArray activeArray, ActiveEnum activeEnum, boolean skipCheck) {
		if (skipCheck) {
			// Only called from peekOrFlush don't increment since peekOrFlushActive=1
			return true;
		}
		if (activeEnum == ActiveEnum.DEQUEUE_ACTIVE || activeEnum == ActiveEnum.ENQUEUE_ACTIVE) {
			if (peekOrFlushActive.get(priority) > 0) {
				LOGGER.warn("NOT performed activeEnum={}: enqueueActive({})={}, dequeueActive({})={}, peekOrFlushActive({})={}",
					activeEnum, priority, enqueueActive.get(priority), priority, dequeueActive.get(priority), priority, peekOrFlushActive.get(priority));
				return false;
			}
			activeArray.incrementAndGet(priority);
			return true;
		}
		if (enqueueActive.get(priority) > 0 || dequeueActive.get(priority) > 0 || peekOrFlushActive.get(priority) > 0) {
			LOGGER.warn("NOT performed activeEnum={}: enqueueActive({})={}, dequeueActive({})={}, peekOrFlushActive({})={}",
				activeEnum, priority, enqueueActive.get(priority), priority, dequeueActive.get(priority), priority, peekOrFlushActive.get(priority));
			return false;
		}
		activeArray.incrementAndGet(priority);
		return true;
	}

	protected void requeue(int priority) throws ProcessException {
		LOGGER.warn("REQUEUE: priorityQueueEntries[{}].size={}", priority, priorityQueueEntries[priority].size());
		while (! priorityQueueEntries[priority].isEmpty()) {
			if (! enqueueMessage(priorityQueueEntries[priority].poll(), true)) {
				LOGGER.error("REQUEUE: priorityQueueEntries failure");
			}
		}
	}

	protected boolean isMatch(String identifier, String targetId, Integer spaceId, String messageId, Message message) {
		boolean isMatch = ((identifier == null || message.getIdentifier().equals(identifier))
			&& (targetId == null || message.getTargetId().equals(targetId))
			&& (spaceId == null || spaceId.compareTo(message.getSpaceId()) == 0)
			&& (messageId == null || message.getMessageId().equals(messageId)));
		LOGGER.debug("isMatch={}: identifier={}, targetId={}, messageId={}; {}", isMatch, SanitizeUtil.sanitizeAlphaNumericString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), message);
		return isMatch;
	}

	protected void close(IBigQueue queue) {
		LOGGER.info("Closing BigQueue");
		try {
			if (queue != null) {
				queue.close();
				queue.gc();
			}
		} catch (IOException e) {
			LOGGER.error("{}", e.getLocalizedMessage());
		}
	}

	public class PeekedAndFlushedData {
		private long preQueueSize;
		private long postQueueSize;
		private boolean verbose;
		private boolean isEmpty;
		private FLUSH flush;
		private List<Message> peekList = null;
		private List<Message> flushedList = null;
		private Comparator<Message> compareByIdentifierTargetId = Comparator.comparing(Message::getIdentifier).thenComparing(Message::getTargetId);

		PeekedAndFlushedData() {
			preQueueSize = -1L;
			preQueueSize = -1L;
			verbose = false;
			isEmpty = false;
			flush = FLUSH.NONE;
			this.peekList = new ArrayList<>();
			this.flushedList = new ArrayList<>();
		}

		PeekedAndFlushedData(boolean isEmpty, FLUSH flush, long preQueueSize) {
			this.preQueueSize = preQueueSize;
			preQueueSize = 0L;
			verbose = false;
			this.isEmpty = isEmpty;
			this.flush = flush;
			this.peekList = new ArrayList<>();
			this.flushedList = new ArrayList<>();
		}

		PeekedAndFlushedData(long preQueueSize, long postQueueSize, boolean verbose, List<Message> peekList,
				List<Message> flushedList) {
			this.preQueueSize = preQueueSize;
			this.postQueueSize = postQueueSize;
			this.verbose = verbose;
			this.peekList = peekList;
			this.flushedList = flushedList;
			isEmpty = false;
		}

		public long getPreQueueSize() {
			return preQueueSize;
		}

		public long getPostQueueSize() {
			return postQueueSize;
		}

		public List<Message> getPeekList() {
			return peekList;
		}

		public List<Message> getFlushedList() {
			return flushedList;
		}

		public String toStringList(String identifier, boolean verbose, List<Message> messageList) {
			List<Message> sortedList = messageList.stream().sorted(compareByIdentifierTargetId)
					.collect(Collectors.toList());
			StringBuilder sb = new StringBuilder(identifier);
			sortedList.forEach(x -> toStringAppend(sb, verbose ? x.toStringVerbose() : x.toString()));
			return sb.toString();
		}

		protected void toStringAppend(StringBuilder sb, String x) {
			sb.append(x + '\n');
		}

		@Override
		public String toString() {
			if (isEmpty) {
				return "Queue is empty\n";
			}
			if (flush == FLUSH.HARD) {
				return "Hard flush completed on queueSize=" + preQueueSize + ". Records associated with the hard flush in appError will still exist if they existed before the flush\n";
			}
			if (flush == FLUSH.IN_MEMORY) {
				return "In memory flush to disk has been performed on queueSize=" + preQueueSize + "\n";
			}
			String prePostQueueSize = "preQueueSize=" + preQueueSize + ", postQueueSize=" + postQueueSize;
			String flushedListStr = toStringList("\nFlushedList:\n", verbose, flushedList);
			String peekedListStr = toStringList("\nPeekedList:\n", verbose, peekList);
			return prePostQueueSize + '\n' + flushedListStr + '\n' + peekedListStr;
		}
	}
}