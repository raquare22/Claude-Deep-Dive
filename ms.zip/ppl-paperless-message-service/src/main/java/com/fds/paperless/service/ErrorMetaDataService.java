package com.fds.paperless.service;

import com.fds.paperless.mongo.ErrorMetaData;
import com.fds.paperless.mongo.MetaDataErrorCode;
import com.fds.paperless.mongo.MetaDataStatus;

import java.util.List;

public interface ErrorMetaDataService {
	ErrorMetaData saveErrorMetaData(ErrorMetaData metadata);

	public ErrorMetaData getErrorMetaData(String id);
	public List<ErrorMetaData> getErrorList(MetaDataErrorCode errorCode, MetaDataStatus status, String replyToIndex, int limit);
	public List<ErrorMetaData> getErrorList(MetaDataErrorCode errorCode, MetaDataStatus status, String replyToIndex, String queue, int limit);
	public List<ErrorMetaData> getErrorListByIdentifier(String identifier);
	public List<ErrorMetaData> getErrorListByTargetId(String targetId);
	public ErrorMetaData getErrorMetaDataByIndentifierTargetId(String identifier, String targetId);

	public ErrorMetaData updateErrorMetaDataStatus(String id, MetaDataStatus status);
	public ErrorMetaData updateErrorMetaDataStatus(String id, MetaDataStatus status, String errorMessage);
	public ErrorMetaData updateErrorMetaDataSubjectStatus(String id, String subject, MetaDataStatus status);
	public ErrorMetaData getErrorMetaDataByMessageId(String messageId);
	public ErrorMetaData updateErrorMetaDataMessageIdSubject(String id, String messageId, String subject, MetaDataStatus status);
}