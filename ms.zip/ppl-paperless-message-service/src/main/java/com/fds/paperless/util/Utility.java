package com.fds.paperless.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;

public final class Utility {
	private static final Logger LOGGER = LogManager.getLogger(Utility.class);
	public static final Function<String, String> envFunction = System::getenv;

	private Utility() {}

	public static String getEnvironment() {
		String env = envFunction.apply("spring.profiles.active");
		String local = "local";
		if(env == null) {
			return local;
		}
		for(Environments envs : Environments.values()) {
			if(envs.getEnv().equals(env)) {
				return env;
			}
		}
		return local;
	}

	public static void sleep(long milliseconds, String description) {
		try {
			LOGGER.warn("sleeping {} ms: {}", milliseconds, description);
			TimeUnit.MILLISECONDS.sleep(milliseconds);
		} catch (InterruptedException e) {
			LOGGER.error("SLEEP: INTERRUPT; threadId={}", Thread.currentThread().getId());
			Thread.currentThread().interrupt();
		}
	}
}
