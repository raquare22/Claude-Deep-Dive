package com.fds.paperless.mongo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Document(collection = "appError")
public class ErrorMetaData extends MetaData implements Serializable {
	private static final long serialVersionUID = 1L;

	private String subject;
	private String identifier;
	private String targetId;
	private Integer spaceId;
	private String queue;
	private String connectionType;
	private Long sequenceNumber;
	private String correlationId;
	private String messageId;
	private String replyTo;
	private String replyToIndex;
	private Long deliveryCount;
	private Integer retryCount;

	private String errorMessage;

	@JsonProperty("errorCode")
	MetaDataErrorCode errorCode;

	private transient org.bson.Document metadata;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

	public Integer getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(Integer spaceId) {
		this.spaceId = spaceId;
	}

	public String getQueue() {
		return queue;
	}

	public void setQueue(String queue) {
		this.queue = queue;
	}

	public String getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}

	public Long getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Long sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getReplyTo() {
		return replyTo;
	}

	public void setReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}

	public String getReplyToIndex() {
		return replyToIndex;
	}

	public void setReplyToIndex(String replyToIndex) {
		this.replyToIndex = replyToIndex;
	}

	public Long getDeliveryCount() {
		return deliveryCount;
	}

	public void setDeliveryCount(Long deliveryCount) {
		this.deliveryCount = deliveryCount;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getMetadataAsJsonString() {
		return metadata.toJson();
	}

	public org.bson.Document getMetadata() {
		return metadata;
	}

	public void setMetadata(org.bson.Document metadata) {
		this.metadata = metadata;
	}

	public MetaDataErrorCode getErrorCode() {
		return errorCode;
	}

	@JsonIgnore
	public void setErrorCode(MetaDataErrorCode errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = MetaDataErrorCode.valueOf(errorCode);
	}

	public void setErrorCodeAndDefaultErrorStatus(MetaDataErrorCode errorCode, MetaDataStatus status) {
		this.errorCode = errorCode;
		setStatus(status);
	}

	public MetaDataStatus setCompleteStatus() {
		MetaDataStatus status = MetaDataStatus.COMPLETE;
		setStatus(status);
		return status;
	}

	@Override
	public List<ErrorRevision> getRevisions() {
		return revisions;
	}

	@Override
	public String toString() {
		return "ErrorMetaData [identifier=" + identifier + ", targetId=" + targetId + ", spaceId=" + spaceId
				+ ", queue=" + queue + ", connectionType=" + connectionType
				+ ", sequenceNumber=" + sequenceNumber + ", correlationId=" + correlationId + ", messageId=" + messageId
				+ ", replyTo=" + replyTo + ", deliveryCount=" + deliveryCount + ", retryCount=" + retryCount
				+ ", errorMessage=" + errorMessage + ", errorCode=" + errorCode + "]";
	}
}