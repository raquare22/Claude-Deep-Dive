package com.fds.paperless.msgsvc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fds.paperless.SanitizeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.constants.CommonConstants;
import com.fds.paperless.model.Message;
import com.fds.paperless.mongo.ErrorMetaData;
import com.fds.paperless.mongo.MetaDataErrorCode;
import com.fds.paperless.mongo.MetaDataStatus;
import com.fds.paperless.service.ErrorMetaDataService;

@Service("ErrorCollection")
public class ErrorCollection {
	@Autowired
	private ErrorMetaDataService errorMetaDataService;

	@Autowired
	protected ObjectMapper objectMapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorCollection.class);

	public ErrorMetaData writeToErrorCollection(Message message, MetaDataErrorCode errorCode, MetaDataStatus status, String errorMsg) {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setId(message.getMetadataId());
		errorMetaData.setSpaceId(message.getSpaceId());
		errorMetaData.setQueue(message.getQueue());
		errorMetaData.setErrorCodeAndDefaultErrorStatus(errorCode, status);
		errorMetaData.setRetryCount(message.getRetryCount());
		errorMetaData.setReplyTo(message.getReplyTo());
		errorMetaData.setReplyToIndex(message.getReplyToIndex());
		errorMetaData.setErrorMessage(errorMsg);
		errorMetaData.setSubject(message.getSubject());
		setMetadataIdentifiers(message, errorMetaData);
		errorMetaData.setMessageId(message.getMessageId());
		errorMetaData.setMetadata(org.bson.Document.parse(message.getBody()));
		errorMetaData.setDeliveryCount(message.getDeliveryCount());
		writeToErrorCollection(errorMetaData);
		return errorMetaData;
	}

	protected void setMetadataIdentifiers(Message message, ErrorMetaData errorMetaData) {
		String subject = message.getSubject();
		setMetadataIdentifiers(subject, errorMetaData);
	}

	@SuppressWarnings("unchecked")
	protected void setMetadataIdentifiers(String subject, ErrorMetaData errorMetaData) {
		Map<String, Object> subjectMap;
		try {
			subjectMap = objectMapper.readValue(subject, HashMap.class);
			String identifier = (String) subjectMap.get(CommonConstants.ID);
			String targetId = (String) subjectMap.get(CommonConstants.TARGET_ID);
			errorMetaData.setSubject(subject);
			if (identifier != null) {
				errorMetaData.setIdentifier(identifier);
				errorMetaData.setTargetId(targetId);
			} else {
				LOGGER.info("subjectMap: identifier == null");
			}
		} catch (JsonProcessingException e) {
			LOGGER.error("subjectMap Failure: {}", e.getMessage());
		}
	}

	public ErrorMetaData getErrorMetaDataByMessageId(String messageId) {
		return errorMetaDataService.getErrorMetaDataByMessageId(messageId);
	}

	public void writeToErrorCollection(ErrorMetaData errorMetaData) {
		ErrorMetaData savedErrorMetaData = errorMetaDataService.saveErrorMetaData(errorMetaData);
		LOGGER.error("MONGO: Saved mongo error; savedErrorMetaData={}", savedErrorMetaData);
	}

	public List<ErrorMetaData> getErrorList(MetaDataErrorCode errorCode, MetaDataStatus status, String replyToIndex, int limit) {
		return errorMetaDataService.getErrorList(errorCode, status, replyToIndex, limit);
	}

	public List<ErrorMetaData> getErrorList(MetaDataErrorCode errorCode, MetaDataStatus status, String replyToIndex, String queue, int limit) {
		return errorMetaDataService.getErrorList(errorCode, status, replyToIndex, queue, limit);
	}

	public ErrorMetaData updateErrorMetaDataStatus(String id, MetaDataStatus status) {
		return errorMetaDataService.updateErrorMetaDataStatus(id, status);
	}

	public ErrorMetaData updateErrorMetaDataSubjectStatus(String id, String subject, MetaDataStatus status) {
		return errorMetaDataService.updateErrorMetaDataSubjectStatus(id, subject, status);
	}
	
	public ErrorMetaData updateErrorMetaDataMessageIdSubject(String id, String messageId, String subject, MetaDataStatus status) {
		return errorMetaDataService.updateErrorMetaDataMessageIdSubject(id, messageId, subject, status);
	}
}
