package com.fds.paperless.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fds.paperless.constants.CommonConstants;
import com.fds.paperless.mongo.ErrorMetaData;

@JsonInclude(Include.NON_NULL)
public class Message {
	private static final String MESSAGE_QUEUE = "Message [queue=";
	private static final String IDENTIFIER_LOG = ", identifier=";
	private static final String TARGET_ID = ", targetId=";
	private static final String SPACE_ID = ", spaceId=";
	private static final String MESSAGE_ID = ", messageId=";
	private static final String REPLY_TO_INDEX = ", replyToIndex=";

	private String queue;
	private String replyTo;
	private String replyToIndex;
	private String identifier;
	private String targetId;
	private Integer spaceId;
	private String body;
	private String subject;
	private Integer retryCount;
	private String messageId;
	private Long deliveryCount;
	private String metadataId;

	@JsonCreator
	public Message(@JsonProperty("queue")String queue, @JsonProperty("replyTo") String replyTo, @JsonProperty("replyToIndex") String replyToIndex,
			@JsonProperty("identifier") String identifier, @JsonProperty("targetId") String targetId, @JsonProperty("spaceId") Integer spaceId, @JsonProperty("body") String body) {
		this.queue = queue;
		this.replyTo = replyTo;
		this.replyToIndex = replyToIndex;
		this.identifier = identifier;
		this.targetId = targetId;
		this.spaceId = spaceId == null ? -1 : spaceId;
		this.body = body;
		this.subject = "{\"" + CommonConstants.ID + CommonConstants.ENCLOSED_COLON + identifier
				+ CommonConstants.QUOTE_COMMA_QUOTE + CommonConstants.TARGET_ID
				+ CommonConstants.ENCLOSED_COLON + targetId + "\"}";
		retryCount = 0;
		messageId = UUID.randomUUID().toString();
		deliveryCount = 0L;
		metadataId = null;
	}

	public Message(ErrorMetaData errorMetaData) {
		queue = errorMetaData.getQueue();
		replyTo = errorMetaData.getReplyTo();
		replyToIndex = errorMetaData.getReplyToIndex();
		identifier = errorMetaData.getIdentifier();
		targetId = errorMetaData.getTargetId();
		spaceId = errorMetaData.getSpaceId() == null ? -1 : errorMetaData.getSpaceId();
		body = errorMetaData.getMetadataAsJsonString();
		subject = errorMetaData.getSubject();
		retryCount = errorMetaData.getRetryCount();
		messageId = errorMetaData.getMessageId();
		deliveryCount = errorMetaData.getDeliveryCount();
		metadataId = errorMetaData.getId();
	}

	public String getQueue() {
		return queue;
	}

	public void setQueue(String queue) {
		this.queue = queue;
	}

	public String getReplyTo() {
		return replyTo;
	}

	public void setReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}

	public String getReplyToIndex() {
		return replyToIndex;
	}

	public void setReplyToIndex(String replyToIndex) {
		this.replyToIndex = replyToIndex;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

	public Integer getSpaceId() {
		return spaceId;
	}

	public void setTargetId(Integer spaceId) {
		this.spaceId = spaceId;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	public String getMessageId() {
		return messageId;
	}

	public Long getDeliveryCount() {
		return deliveryCount;
	}

	public void setDeliveryCount(Long deliveryCount) {
		this.deliveryCount = deliveryCount;
	}

	public void setMetadataId(String metadataId) {
		this.metadataId = metadataId;
	}

	public String getMetadataId() {
		return metadataId;
	}

	@Override
	public String toString() {
		return MESSAGE_QUEUE + queue + IDENTIFIER_LOG + identifier + TARGET_ID + targetId + SPACE_ID + spaceId + MESSAGE_ID + messageId + REPLY_TO_INDEX + replyToIndex + ", metadataId=" + metadataId + "]";
	}

	public String toStringVerbose() {
		return MESSAGE_QUEUE + queue + IDENTIFIER_LOG + identifier + TARGET_ID + targetId + SPACE_ID + spaceId + MESSAGE_ID + messageId + REPLY_TO_INDEX + replyToIndex
			+ ", metadataId=" + metadataId + ", body=" + body + "]";
	}

	public String toStringCompositeKey() {
		return MESSAGE_QUEUE + queue + IDENTIFIER_LOG + identifier + TARGET_ID + targetId + SPACE_ID + spaceId + MESSAGE_ID + messageId + REPLY_TO_INDEX + replyToIndex + "]";
	}

	public String toStringCompositeKeyVerbose() {
		return MESSAGE_QUEUE + queue + IDENTIFIER_LOG + identifier + TARGET_ID + targetId + SPACE_ID + spaceId + MESSAGE_ID + messageId + REPLY_TO_INDEX + replyToIndex + ", body=" + body + "]";
	}
}
