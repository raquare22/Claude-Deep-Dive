package com.fds.paperless.constants;

public final class CommonConstants {
	public static final String ID = "identifier";
	public static final String TARGET_ID = "targetId";
	public static final String SOMETHING_WENT_WRONG = "SOMETHING WENT WRONG ERROR={}";
	public static final String PREMIUM_DEQUEUE_INITIAL_DELAY_SECONDS = "PremiumDequeueInitialDelaySeconds";
	public static final String HIGH_DEQUEUE_INITIAL_DELAY_SECONDS = "HighDequeueInitialDelaySeconds";
	public static final String MEDIUM_DEQUEUE_INITIAL_DELAY_SECONDS = "MediumDequeueInitialDelaySeconds";
	public static final String LOW_DEQUEUE_INITIAL_DELAY_SECONDS = "LowDequeueInitialDelaySeconds";
	public static final String AGE_OFF_BACK_PRESSURE_OUTSTANDING_INITIAL_DELAY_SECONDS = "AgeOffBackPressureOutstandingInitialDelaySeconds";
	public static final String AGE_OFF_BACK_PRESSURE_OUTSTANDING_SUBSEQUENT_DELAY_SECONDS = "AgeOffBackPressureOutstandingSubsequentDelaySeconds";
	public static final String BIG_QUEUE_PATH ="bigQueuePath";
	public static final String STATS ="Stats";
	public static final String QUOTE_COMMA_QUOTE = "\", \"";
	public static final String ENCLOSED_COLON = "\":\"";
	public static final String REST_API_THREAD_DEFAULT = "20";

	private CommonConstants(){}
}