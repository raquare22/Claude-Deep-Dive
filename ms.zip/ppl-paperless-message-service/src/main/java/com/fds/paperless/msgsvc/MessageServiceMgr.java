package com.fds.paperless.msgsvc;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.SanitizeUtil;
import com.fds.paperless.constants.CommonConstants;
import com.fds.paperless.constants.QueueEnum;
import com.fds.paperless.exception.ProcessException;
import com.fds.paperless.model.GenericResponse;
import com.fds.paperless.model.Message;
import com.fds.paperless.mongo.ErrorMetaData;
import com.fds.paperless.mongo.MetaDataErrorCode;
import com.fds.paperless.mongo.MetaDataStatus;
import com.fds.paperless.msgsvc.BigQueueService.FLUSH;
import com.fds.paperless.msgsvc.BigQueueService.PeekedAndFlushedData;
import com.fds.paperless.service.AsyncService;
import com.fds.paperless.util.Utility;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class MessageServiceMgr implements ReceiveAsyncResponse {
	@Value("${RestApiTimeoutMs:9000}")
	protected Long restApiTimeoutMs;
	@Value("${AgeOffBackPressureOutstandingSeconds:900}")
	protected Long ageOffSeconds;
	@Value("${MaxRetryRestApiCnt:5}")
	protected Integer maxRetryRestApiCnt;
	@Value("${CalculateResponseTime:true}")
	protected Boolean calculateResponseTime;
	@Value("${SupportedDelegates}")
	protected String supportedDelegates;
	@Value("${SupportedDelegatesIndex}")
	protected String supportedDelegatesIndex;
	@Value("${RestApiErrorProcessAutomaticArray:}#{{''}}")
	protected String[] restApiErrorProcessAutomaticArray;
	@Value("${AppErrorQueryLimit:0}")
	protected int appErrorQueryLimit;

	// Allow 5 seconds in shutdown for connection error, bad payload response and pre shutdown payload timeout processing to finish
	private static Long maxShutdownLoop = 100L;

	@Autowired
	protected AsyncService asyncService;

	@Autowired
	protected ErrorCollection errorCollection;

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	BigQueueService bigQueueService;

	private static final String RETRY_CNT = "retryRestCnt";
	private static final String RETRY_CNT_ONE = "{\"retryRestCnt\":1}";
	private static final String SET_LABEL_POST_LOG = "setSubject[]: POST subject={}";
	public static final String DELIMITER = ":";


	private static final Logger LOGGER = LoggerFactory.getLogger(MessageServiceMgr.class);

	private static final String REPLYTO_NOT_VALID_ERROR_COLLECTION = "ReplyTo not valid";
	private static final String SHUTTING_DOWN = "MessageService is shutting down";
	private static final String SHUTDOWN_SKIPPING_SEND = "ASYNC_REQUEST: SHUTDOWN; Skipping send";

	private static final String FAILURE_LOG = "Failure: {}";

	protected static boolean shutdown = false;
	protected static boolean startup = true;

	protected static int recordStatistics;

	protected ResendExecutors resendExecutors;
	protected AgeOffBackPressureExecutors ageOffBackPressureExecutors;
	protected QueueExecutors queueExecutors;

	// <MessageId, BackPressureInfo>
	protected static Map<String, BackPressureInfo> outstandingPayloadRequestMap = new ConcurrentHashMap<>();
	// <QueueEnum, outstanding count>
	protected static Map<String, Integer> outstandingPayloadRequestsPerQueue = new ConcurrentHashMap<>(Map.of(
		QueueEnum.PREMIUM_PRIORITY_QUEUE.getQueue(),0, QueueEnum.HIGH_PRIORITY_QUEUE.getQueue(),0, QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueue(), 0, QueueEnum.LOW_PRIORITY_QUEUE.getQueue(), 0));

	protected Map<String, String> delegateMap = new HashMap<>();
	protected List<String> delegateList = new ArrayList<>();

	// Used to only allow the ResendExecutors to process resends associated with the proper environment.
	// The search criteria will include replyToIndex to accomplish this for the replyTo could change if an environment is no longer supported
	//"replyTo" : "http://fds-paperless-activiti-prod-pra.hcck8s-ctc.optum.com/api/services/run/delegate",
	//"replyToIndex" : "1",
	protected Map<String, String> delegateIndexMap = new HashMap<>();

	protected static final AtomicInteger maxOutstandingPayloadConcurrentRequests = new AtomicInteger(0);
	protected static final AtomicIntegerArray maxOutstandingPayloadConcurrentRequestsPerQueue = new AtomicIntegerArray(BigQueueService.QUEUE_SUPPORTED_SIZE);
	protected static final AtomicIntegerArray payloadSuccess = new AtomicIntegerArray(BigQueueService.QUEUE_SUPPORTED_SIZE);
	protected static final AtomicIntegerArray payloadFailure = new AtomicIntegerArray(BigQueueService.QUEUE_SUPPORTED_SIZE);
	protected static final AtomicIntegerArray payloadRetries = new AtomicIntegerArray(BigQueueService.QUEUE_SUPPORTED_SIZE);
	protected static final AtomicIntegerArray ageOffCount = new AtomicIntegerArray(BigQueueService.QUEUE_SUPPORTED_SIZE);
	protected static final AtomicIntegerArray suspendDequeue = new AtomicIntegerArray(BigQueueService.QUEUE_SUPPORTED_SIZE);

	protected int lowDequeueLimit;
	protected int mediumDequeueLimit;
	protected int highDequeueLimit;
	protected int premiumDequeueLimit;
	protected int lowDequeueSubsequentDelay;
	protected int mediumDequeueSubsequentDelay;
	protected int highDequeueSubsequentDelay;
	protected int premiumDequeueSubsequentDelay;

	protected int resendRestApiInitialDelaySeconds;
	protected int resendRestApiSubsequentDelaySeconds;
	protected int ageOffBackPressureOutstandingInitialDelaySeconds;
	protected int ageOffBackPressureOutstandingSubsequentDelaySeconds;
	protected int premiumDequeueInitialDelaySeconds;
	protected int highDequeueInitialDelaySeconds;
	protected int mediumDequeueInitialDelaySeconds;
	protected int lowDequeueInitialDelaySeconds;

	public MessageServiceMgr(
		@Value("${LowDequeueLimit:5}") int lowDequeueLimit,  @Value("${MediumDequeueLimit:10}") int mediumDequeueLimit, @Value("${HighDequeueLimit:15}") int highDequeueLimit, @Value("${PremiumDequeueLimit:20}") int premiumDequeueLimit,
		@Value("${LowDequeueSubsequentDelay:60}") int lowDequeueSubsequentDelay, @Value("${MediumDequeueSubsequentDelay:45}") int mediumDequeueSubsequentDelay, @Value("${HighDequeueSubsequentDelay:30}") int highDequeueSubsequentDelay, @Value("${PremiumDequeueSubsequentDelay:15}") int premiumDequeueSubsequentDelay,
		@Value("${ResendRestApiInitialDelaySeconds:900}") int resendRestApiInitialDelaySeconds, @Value("${ResendRestApiSubsequentDelaySeconds:900}") int resendRestApiSubsequentDelaySeconds,
		@Value("${AgeOffBackPressureOutstandingInitialDelaySeconds:900}") int ageOffBackPressureOutstandingInitialDelaySeconds, @Value("${AgeOffBackPressureOutstandingSubsequentDelaySeconds:900}") int ageOffBackPressureOutstandingSubsequentDelaySeconds,
		@Value("${PremiumDequeueInitialDelaySeconds:60}") int premiumDequeueInitialDelaySeconds, @Value("${HighDequeueInitialDelaySeconds:60}") int highDequeueInitialDelaySeconds,
		@Value("${MediumDequeueInitialDelaySeconds:60}") int mediumDequeueInitialDelaySeconds, @Value("${LowDequeueInitialDelaySeconds:60}") int lowDequeueInitialDelaySeconds,
		@Value("${RecordStatistics:32}") int recordStatistics
		) {

		this.lowDequeueLimit = lowDequeueLimit;
		this.mediumDequeueLimit = mediumDequeueLimit;
		this.highDequeueLimit = highDequeueLimit;
		this.premiumDequeueLimit = premiumDequeueLimit;
		this.lowDequeueSubsequentDelay = lowDequeueSubsequentDelay;
		this.mediumDequeueSubsequentDelay = mediumDequeueSubsequentDelay;
		this.highDequeueSubsequentDelay = highDequeueSubsequentDelay;
		this.premiumDequeueSubsequentDelay = premiumDequeueSubsequentDelay;

		this.resendRestApiInitialDelaySeconds = resendRestApiInitialDelaySeconds;
		this.resendRestApiSubsequentDelaySeconds = resendRestApiSubsequentDelaySeconds;
		this.ageOffBackPressureOutstandingInitialDelaySeconds = ageOffBackPressureOutstandingInitialDelaySeconds;
		this.ageOffBackPressureOutstandingSubsequentDelaySeconds = ageOffBackPressureOutstandingSubsequentDelaySeconds;
		this.premiumDequeueInitialDelaySeconds = premiumDequeueInitialDelaySeconds;
		this.highDequeueInitialDelaySeconds = highDequeueInitialDelaySeconds;
		this.mediumDequeueInitialDelaySeconds = mediumDequeueInitialDelaySeconds;
		this.lowDequeueInitialDelaySeconds = lowDequeueInitialDelaySeconds;
		setRecordStatistics(recordStatistics);

		instantiateExecutors();
	}

	protected static void setRecordStatistics(int recordStatistics) {
		MessageServiceMgr.recordStatistics = recordStatistics;
		LOGGER.warn("recordStatistics={}", recordStatistics);
	}

	protected synchronized void instantiateExecutors() {
		LOGGER.warn("Executors: resendRestApiInitialDelaySeconds={}, resendRestApiSubsequentDelaySeconds={}, ageOffBackPressureOutstandingInitialDelaySeconds={}, ageOffBackPressureOutstandingSubsequentDelaySeconds={}",
			resendRestApiInitialDelaySeconds, resendRestApiSubsequentDelaySeconds, ageOffBackPressureOutstandingInitialDelaySeconds, ageOffBackPressureOutstandingSubsequentDelaySeconds);
		fetchAndConfigureQueue();
		resendExecutors = new ResendExecutors();
		resendExecutors.newSingleThreadScheduledExecutor(resendRestApiInitialDelaySeconds, resendRestApiSubsequentDelaySeconds);
		ageOffBackPressureExecutors = new AgeOffBackPressureExecutors();
		ageOffBackPressureExecutors.newSingleThreadScheduledExecutor(ageOffBackPressureOutstandingInitialDelaySeconds, ageOffBackPressureOutstandingSubsequentDelaySeconds);
	}

	private void fetchAndConfigureQueue() {
		queueExecutors = new QueueExecutors();
		LOGGER.warn("Premium QueueExecutors: premiumDequeueInitialDelaySeconds={}, premiumDequeueSubsequentDelay={}", premiumDequeueInitialDelaySeconds, premiumDequeueSubsequentDelay);
		queueExecutors.newPremiumSingleThreadScheduledExecutor(premiumDequeueInitialDelaySeconds, premiumDequeueSubsequentDelay);

		LOGGER.warn("High QueueExecutors: highDequeueInitialDelaySeconds={}, highDequeueSubsequentDelay={}", highDequeueInitialDelaySeconds, highDequeueSubsequentDelay);
		queueExecutors.newHighSingleThreadScheduledExecutor(highDequeueInitialDelaySeconds, highDequeueSubsequentDelay);

		LOGGER.warn("Medium QueueExecutors: mediumDequeueInitialDelaySeconds={}, mediumDequeueSubsequentDelay={}", mediumDequeueInitialDelaySeconds, mediumDequeueSubsequentDelay);
		queueExecutors.newMediumSingleThreadScheduledExecutor(mediumDequeueInitialDelaySeconds, mediumDequeueSubsequentDelay);

		LOGGER.warn("Low QueueExecutors: lowDequeueInitialDelaySeconds={}, lowDequeueSubsequentDelay={}", lowDequeueInitialDelaySeconds, lowDequeueSubsequentDelay);
		queueExecutors.newLowSingleThreadScheduledExecutor(lowDequeueInitialDelaySeconds, lowDequeueSubsequentDelay);

		LOGGER.warn("QueueExecutors: premiumDequeueLimit={}, highDequeueLimit={}, mediumDequeueLimit={}, lowDequeueLimit={}", premiumDequeueLimit, highDequeueLimit, mediumDequeueLimit, lowDequeueLimit);
	}

	protected synchronized void setup() {
		if (! startup) {
			return;
		}
		startup = false;

		//SupportedDelegatesIndex=EngineDelegateUrl=1
		//SupportedDelegatesIndex=EngineDelegateUrl=1,ServiceDelegateUrl=2
		List<String> supportedDelegatesIndexList = Arrays.asList(supportedDelegatesIndex.split("\\s*,\\s*"));
		LOGGER.warn("supportedDelegatesIndexList={}", supportedDelegatesIndexList);
		for (String delegateIndex : supportedDelegatesIndexList) {
			String[] keyValue = delegateIndex.split("\\s*=\\s*");
			if (LOGGER.isWarnEnabled()) {
				LOGGER.warn("supportedDelegatesIndexList; keyValue={}", Arrays.toString(keyValue));
			}
			delegateIndexMap.put(keyValue[0], keyValue[1]);
		}

		//SupportedDelegates=EngineDelegateUrl=http://127.0.0.1:8081/api/services/run/delegate
		//SupportedDelegates=EngineDelegateUrl=http://127.0.0.1:8081/api/services/run/delegate,ServiceDelegateUrl=http://127.0.0.1:8082/api/services/run/delegate
		List<String> supportedDelegatesList = Arrays.asList(supportedDelegates.split("\\s*,\\s*"));
		LOGGER.warn("supportedDelegatesList={}", supportedDelegatesList);
		for (String delegate : supportedDelegatesList) {
			String[] keyValue = delegate.split("\\s*=\\s*");
			if (LOGGER.isWarnEnabled()) {
				LOGGER.warn("supportedDelegatesList; keyValue={}", Arrays.toString(keyValue));
			}
			delegateList.add(keyValue[0]);
			delegateMap.put(keyValue[0], keyValue[1]);
			// Needed for resends since already expanded
			delegateMap.put(keyValue[1], keyValue[1]);
			if (delegateIndexMap.get(keyValue[0]) != null) {
				delegateIndexMap.put(keyValue[1], delegateIndexMap.get(keyValue[0]));
			}
		}
		LOGGER.warn("SETUP: maxShutdownLoop={}, restApiTimeoutMs={}, maxRetryRestApiCnt={}, calculateResponseTime={}, appErrorQueryLimit={}",
			maxShutdownLoop, restApiTimeoutMs, maxRetryRestApiCnt, calculateResponseTime, appErrorQueryLimit);
		LOGGER.warn("SETUP: delegateList={}", delegateList);
		LOGGER.warn("SETUP: delegateIndexMap={}", delegateIndexMap);
		LOGGER.warn("SETUP: delegateMap={}", delegateMap);
		if (LOGGER.isWarnEnabled()) {
			LOGGER.warn("SETUP: restApiErrorProcessAutomaticArray={}", Arrays.toString(restApiErrorProcessAutomaticArray));
		}
	}

	public static synchronized void shutdown() {
		LOGGER.warn("SHUTDOWN: shutdown={}, maxShutdownLoop={}, outstandingPayloadRequestMap.size={}", shutdown, maxShutdownLoop, outstandingPayloadRequestMap.size());
		if (shutdown) {
			LOGGER.warn("SHUTDOWN: COMPLETE; Already performed; shutdown={}, outstandingPayloadRequestMap.size={}", shutdown, outstandingPayloadRequestMap.size());
			return;
		}

		try {
			shutdown = true;
			for (String s : outstandingPayloadRequestMap.keySet()) {
				LOGGER.warn("SHUTDOWN: outstandingPayloadRequestMapElement={}", s);
			}

			logStatistics();

			long i = 0;
			while (! outstandingPayloadRequestMap.isEmpty() && ++i <= maxShutdownLoop) {
				Utility.sleep(50, "SHUTDOWN: outstandingPayloadRequestMap.size=" + outstandingPayloadRequestMap.size());
			}

			LOGGER.warn("SHUTDOWN: COMPLETE; shutdown={}, outstandingPayloadRequestMap.size={}", shutdown, outstandingPayloadRequestMap.size());
			for (String s : outstandingPayloadRequestMap.keySet()) {
				LOGGER.warn("outstandingPayloadRequestMapElement={}", s);
			}
		} catch (Exception e) {
			LOGGER.error("SHUTDOWN: {}", ExceptionUtils.getStackTrace(e));
		}
	}

	public static boolean isValidPriorityQueue(String queueName) {
		return QueueEnum.PREMIUM_PRIORITY_QUEUE.getQueueName().equals(queueName)
			|| QueueEnum.HIGH_PRIORITY_QUEUE.getQueueName().equals(queueName)
			|| QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueueName().equals(queueName)
			|| QueueEnum.LOW_PRIORITY_QUEUE.getQueueName().equals(queueName);
	}

	public void sendAsyncMessage(String queueName, String replyTo, String identifier, String targetId, Integer spaceId, String body) throws ProcessException {
		sendAsyncMessage(queueName, replyTo, null, identifier, targetId, spaceId, body);
	}

	public void sendAsyncMessage(String queueName, String replyTo, String replyToIndex, String identifier, String targetId, Integer spaceId, String body) throws ProcessException {
		if (shutdown) {
			throw new ProcessException(SHUTTING_DOWN);
		}

		QueueEnum queueEnum = QueueEnum.getQueueNameEnum(queueName);
		String queue = queueEnum.getQueue();
		int priority = queueEnum.ordinal();
		Message message = new Message(queue, replyTo, replyToIndex, identifier, targetId, spaceId, body);
		try {
			bigQueueService.enqueueMessage(message);
		} catch (ProcessException e) {
			LOGGER.error("peekOrFlush[{}] active: writeToErrorCollection; {}; msg={}", priority, message, e.getMessage());
			errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.AUTOMATIC, "peekOrFlush was active");
		}
	}

	public void suspendDequeue(String queueName) {
		QueueEnum queueEnum = QueueEnum.getQueueNameEnum(queueName);
		String queue = queueEnum.getQueue();
		int priority = queueEnum.ordinal();
		suspendDequeue.set(priority, 1);
		LOGGER.warn("Suspended dequeue on queueName={}, queue={}, suspendDequeue[{}]={}", SanitizeUtil.sanitizeQueueName(queueName), queue, priority, suspendDequeue.get(priority));
	}

	public void reactivateDequeue(String queueName) {
		QueueEnum queueEnum = QueueEnum.getQueueNameEnum(queueName);
		String queue = queueEnum.getQueue();
		int priority = queueEnum.ordinal();
		suspendDequeue.set(priority, 0);
		LOGGER.warn("Reactivated dequeue on queueName={}, queue={}, suspendDequeue[{}]={}", SanitizeUtil.sanitizeQueueName(queueName), queue, priority, suspendDequeue.get(priority));
	}

	public void peekOrFlush(String queueName, String identifier, String targetId, Integer spaceId, String messageId, FLUSH flush,
			boolean writeToAppError, boolean verbose) throws ProcessException {
		LOGGER.warn("queueName={}, identifier={}, targetId={}, spaceId={}, messageId={}, flush={}, writeToAppError={}, verbose={}",
				SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeAlphaString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), spaceId, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), flush, writeToAppError, verbose);
		try {
			PeekedAndFlushedData peekedAndFlushedData = bigQueueService.peekOrFlush(queueName, identifier, targetId, spaceId, messageId, flush, verbose);
			LOGGER.warn("Search Criteria: flush={}, queueName={}, identifier={}, targetId={}, spaceId={}, messageId={}\n{}",
				flush, SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeAlphaString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), spaceId, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), peekedAndFlushedData);
			if (flush == FLUSH.NONE && writeToAppError) {
				List<Message> flushedList = peekedAndFlushedData.getPeekList();
				LOGGER.warn("PEEKED: Writing records to appError if they don't already exist; Change PEEKED errorCode to REST_API_ERROR to activate, flushedList.size={}",
						flushedList.size());
				flushedList.stream().forEach(MessageServiceMgr.this::writePeekToAppError);
				return;
			}
			if (flush == FLUSH.KEYED) {
				LOGGER.warn("FLUSHED: Checking for appError records to mark as COMPLETE");
				List<Message> flushedList = peekedAndFlushedData.getFlushedList();
				flushedList.stream().forEach(MessageServiceMgr.this::checkForAppError);
			}
		} catch (ProcessException e) {
			LOGGER.error("FAILURE; queueName={}, identifier={}, targetId={}, messageId={}: {}",
				SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeAlphaString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), e.getMessage());
		} catch (Exception e) {
			LOGGER.error("FAILURE; queueName={}, identifier={}, targetId={}, messageId={}: {}",
					SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeAlphaString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), ExceptionUtils.getStackTrace(e));
		}
	}

	protected void writePeekToAppError(Message message) {
		try {
			ErrorMetaData errorMetaData = errorCollection.getErrorMetaDataByMessageId(message.getMessageId());
			if (errorMetaData == null) {
				LOGGER.warn("PEEKED message: Writing to errorCollection; {}", message);
				errorCollection.writeToErrorCollection(message, MetaDataErrorCode.PEEKED, MetaDataStatus.AUTOMATIC, "PEEKED writeToAppError request");
			}
			else {
				LOGGER.warn("PEEKED message: Already in appError skipping writeToAppError; id={}; {}", errorMetaData.getId(), message);
			}
		} catch (Exception e) {
			LOGGER.error(FAILURE_LOG, ExceptionUtils.getStackTrace(e));
		}
	}

	// Check if flushed records are in appError and mark COMPLETE
	protected void checkForAppError(Message message) {
		try {
			if (message.getMetadataId() != null) {
				LOGGER.warn("FLUSHED message: Updating errorCollection to COMPLETE; {}", message);
				errorCollection.updateErrorMetaDataSubjectStatus(message.getMetadataId(), message.getSubject(), MetaDataStatus.COMPLETE);
			}
		} catch (Exception e) {
			LOGGER.error(FAILURE_LOG, ExceptionUtils.getStackTrace(e));
		}
	}

	// Message is dequeued failures go to error collection
	protected void sendAsyncMessage(Message message) {
		if (startup) {
			LOGGER.warn("Calling setup");
			setup();
		}
		String replyToUrl = getExpandedUrl(message);
		if (replyToUrl != null) {
			message.setReplyTo(replyToUrl);
		}
		String replyToIndex = getReplyToIndex(message);
		if (replyToUrl == null || replyToIndex == null) {
			if (LOGGER.isErrorEnabled()) {
				LOGGER.error("replyToUrl == null || replyToIndex == null: replyToUrl={}, replyToIndex={}, delegateMap={}, delegateIndexMap={}; {}",
					replyToUrl, replyToIndex, delegateMap, delegateIndexMap, message.toStringVerbose());
			}
			try {
				errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.MANUAL, REPLYTO_NOT_VALID_ERROR_COLLECTION);
			} catch (Exception e) {
				LOGGER.error("Failure: {}; {}", message.toStringVerbose(), ExceptionUtils.getStackTrace(e));
			}
			return;
		}

		try {
			message.setReplyToIndex(replyToIndex);
			postRequestToSvc(message);
		} catch (ProcessException e) {
			LOGGER.error("PROCESSED: SENT postRequestToSvc FAILURE; {} {}", message, e.getMessage());
			errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.AUTOMATIC, e.getMessage());
		} catch (Exception e) {
			LOGGER.error("PROCESSED: SENT postRequestToSvc FAILURE; {} {}", message, ExceptionUtils.getStackTrace(e));
			errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.MANUAL, ExceptionUtils.getStackTrace(e));
		}
	}

	protected String addOKResponse(Message message) {
		String body = message.getBody();
		String backPressureInfo = message.getQueue() + ":" + message.getMessageId() + ":" + message.getIdentifier() + ":" + message.getTargetId();
		GenericResponse response = new GenericResponse("200", "OK", "SVC_MSG; Message received:" + backPressureInfo);
		StringBuilder jsonStrBuilder = new StringBuilder(body);
		jsonStrBuilder.insert(1, "\"response\":{" + "\"statusCode\":" + "\"" + response.getStatusCode() + "\"" + ", \"statusMessage\":"
				+ "\"" + response.getStatusMessage() + "\"" + ", \"responseMsg\":" + "\"" + response.getResponse() + "\"},");
		return jsonStrBuilder.toString();
	}

	protected void postRequestToSvc(Message message) throws ProcessException {
		if (shutdown) {
			throw new ProcessException(SHUTTING_DOWN);
		}

		String body = addOKResponse(message);
		message.setBody(body);

		addOutstandingPayloadRequest(message);
		maxStatistics(message);

		AsyncServiceCallback asyncServiceCallback = new AsyncServiceCallback(this, message);
		LOGGER.info("CALLING asyncService.postRequestToSvc: {}, outstandingPayloadRequestMap.size={}", asyncServiceCallback, outstandingPayloadRequestMap.size());
		asyncService.postRequestToSvc(asyncServiceCallback, restApiTimeoutMs);
		LOGGER.info("SENT postRequestToSvc: {}", asyncServiceCallback);
	}

	public void processAsyncResponse(ResponseEntity<GenericResponse> responseEntity) {
		LOGGER.info("SENT responseEntity: responseEntity={}", responseEntity);
		try {
			GenericResponse genericResponse = responseEntity.getBody();
			if (genericResponse == null) {
				return;
			}
			String statusMessage = genericResponse.getStatusMessage();
			String statusCode = genericResponse.getStatusCode();
			String response = (String) genericResponse.getResponse();
			LOGGER.info("SENT responseEntity: statusMessage={}, statusCode={}, response={}", statusMessage,statusCode, response);
			String[] responseArray = response.split(":");
			if (responseArray.length >= 4) {
				String queue = responseArray[0];
				String messageId = responseArray[1];
				BackPressureInfo backPressureInfo = removeOutstandingPayloadRequest(queue, messageId, responseEntity);
				if (backPressureInfo == null) {
					LOGGER.warn("SENT responseEntity: backPressureInfo == null returning; responseEntity={}", responseEntity);
					return;
				}
				if (statusCode.equals("200")) {
					processAsyncSuccess(backPressureInfo.getMessage(), false);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception: {}", ExceptionUtils.getStackTrace(e));
		}
	}

	public void processAsyncSuccess(Message message) {
		processAsyncSuccess(message, true);
	}

	public void processAsyncSuccess(Message message, boolean invokeRemoveOutstandingPayloadRequest) {
		if (invokeRemoveOutstandingPayloadRequest) {
			BackPressureInfo backPressureInfo = removeOutstandingPayloadRequest(message.getQueue(), message.getMessageId(), null);
			if (backPressureInfo == null) {
				LOGGER.warn("SENT responseEntity: backPressureInfo == null returning; {}", message);
				return;
			}
		}
		LOGGER.info("SENT postRequestToSvc: SUCCESS: {}", message);
		payloadSuccess.incrementAndGet(QueueEnum.getQueueEnum(message.getQueue()).ordinal());
	}

	public void processAsyncFailure(Message message, ResponseEntity<GenericResponse> responseEntity) {
		processAsyncFailure(message, responseEntity, true);
	}

	public void processAsyncFailure(Message message, ResponseEntity<GenericResponse> responseEntity, boolean invokeRemoveOutstandingPayloadRequest) {
		try {
			GenericResponse genericResponse = responseEntity.getBody();
			if (responseEntity.getStatusCode().value() == 408) {
				LOGGER.debug("SENT postRequestToSvc application timeout drop response: genericResponse={}, {}", genericResponse, message);
				return;
			}
			LOGGER.info("SENT failure: {}", message);
			if (invokeRemoveOutstandingPayloadRequest) {
				BackPressureInfo backPressureInfo = removeOutstandingPayloadRequest(message.getQueue(), message.getMessageId(), responseEntity);
				if (backPressureInfo == null) {
					LOGGER.warn("SENT responseEntity: backPressureInfo == null returning; queue={}, messageId={}, responseEntity={}",
						message.getQueue(), message.getMessageId(), responseEntity);
					return;
				}
			}
			payloadFailure.incrementAndGet(QueueEnum.getQueueEnum(message.getQueue()).ordinal());
		} catch (Exception e) {
			LOGGER.error("Exception: {}", ExceptionUtils.getStackTrace(e));
		}
	}

	protected void addOutstandingPayloadRequest(Message message) {
		String queueName = message.getQueue();
		outstandingPayloadRequestMap.put(message.getMessageId(), new BackPressureInfo(message));
		outstandingPayloadRequestsPerQueue.put(queueName, outstandingPayloadRequestsPerQueue.getOrDefault(queueName, 0) + 1);
	}

	public int removeOutstandingPayloadRequests(String queueName) throws ProcessException {
		LOGGER.warn("queueName={}", SanitizeUtil.sanitizeQueueName(queueName));
		int matchCnt = 0;
		try {
			QueueEnum queueEnum = QueueEnum.getQueueNameEnum(queueName);
			String queue = queueEnum.getQueue();
			BackPressureInfo backPressureInfo;
			Message message;
			String messageId;
			Iterator<Map.Entry<String, BackPressureInfo>> iter = outstandingPayloadRequestMap.entrySet().iterator();
			LOGGER.warn("outstandingPayloadRequestMap.size={}", outstandingPayloadRequestMap.size());
			while (iter.hasNext()) {
				Map.Entry<String, BackPressureInfo> entry = iter.next();
				backPressureInfo = entry.getValue();
				message = backPressureInfo.getMessage();
				messageId = message.getMessageId();
				if (queue.equals(message.getQueue())) {
					removeOutstandingPayloadRequest(queue, messageId, null);
					matchCnt++;
				}
			}
			LOGGER.warn("REMOVED: queue={}, matchCnt={}", queue, matchCnt);
			return matchCnt;
		} catch(Exception e) {
			throw new ProcessException("queue=" + queueName + ": " + e.getMessage());
		}
	}

	protected synchronized BackPressureInfo removeOutstandingPayloadRequest(String queueName, String messageId, ResponseEntity<GenericResponse> responseEntity) {
		// The receiver can send back both a responseToRequest and a AsyncService response
		// This must handle all appError processing before outstandingPayloadRequestMap.remove. Can have a resend while this is processing and
		// resend checks outstandingPayloadRequestMap is already outstanding and skips
		BackPressureInfo backPressureInfo = outstandingPayloadRequestMap.get(messageId);
		if (backPressureInfo == null) {
			LOGGER.info("ALREADY REMOVED: queue={}, messageId={}, outstandingPayloadRequestMap.size={}", queueName, messageId, outstandingPayloadRequestMap.size());
			return null;
		}
		try {
			Message message = backPressureInfo.getMessage();
			String metadataId = message.getMetadataId();
			if (responseEntity != null && (responseEntity.getBody() == null || ! responseEntity.getBody().getStatusCode().equals("200"))) {
				checkRestApiError(message, responseEntity.getBody());
			}
			else
			if (metadataId != null) {
				// OK response: The request was an outstanding appError mark it as complete since any failure in processing is the receiver's reconciliation
				LOGGER.warn("Updating errorCollection to COMPLETE; {}", message);
				errorCollection.updateErrorMetaDataSubjectStatus(metadataId, message.getSubject(), MetaDataStatus.COMPLETE);
			}
			outstandingPayloadRequestMap.remove(messageId);
			Integer prevBackPressureCnt = outstandingPayloadRequestsPerQueue.put(queueName, outstandingPayloadRequestsPerQueue.get(queueName) - 1);
			LOGGER.warn("REMOVED: queue={}, messageId={}, identifier={}, targetId={}, createInstant={}, prevBackPressureCnt={}, outstandingPayloadRequestMap.size={}",
				queueName, messageId, message.getIdentifier(), message.getTargetId(), backPressureInfo.getCreateInstant(), prevBackPressureCnt, outstandingPayloadRequestMap.size());
			return backPressureInfo;
		} catch(Exception e) {
			LOGGER.error("FAILURE; backPressureInfo={}; {}", backPressureInfo, ExceptionUtils.getStackTrace(e));
			return backPressureInfo;
		}
	}

	protected int checkRestApiError(Message message, GenericResponse responseEntity) {
		int rc = -1;
		try {
			LOGGER.info("SENT postRequestToSvc: {}, responseEntity={}", message, responseEntity);
			Integer retryRestCnt = message.getRetryCount();
			String response = responseEntity != null ? (String) responseEntity.getResponse() : null;
			String statusCode = responseEntity == null ? "status code null" : responseEntity.getStatusCode();

			LOGGER.error("SENT postRequestToSvc FAILURE: Have {}; {}, response={}", statusCode, message, response);
			if (retryRestCnt >= maxRetryRestApiCnt) {
				LOGGER.error("SENT postRequestToSvc FAILURE: MAX_RETRY_REST_API_CNT={} exceeded; Change to {} in appError; {}, response={}",
					retryRestCnt, MetaDataStatus.MANUAL, message, response);
				errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.MANUAL, statusCode + ": " + response);
				return 10;
			}

			if (response == null || ! (statusCode.equals("503") || statusCode.equals("504"))) {
				int index = isMatchingSubstring(response);
				MetaDataStatus metaDataStatus = index > 0 ? MetaDataStatus.AUTOMATIC : MetaDataStatus.MANUAL;
				LOGGER.error("SENT postRequestToSvc FAILURE: NON 503 or 504; index={}, write {} in appError; {}, httpResponseAsync={}", index, metaDataStatus, message, responseEntity);
				errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, metaDataStatus, statusCode + ": " + response);
				return metaDataStatus.ordinal();
			}

			LOGGER.error("SENT postRequestToSvc FAILURE: MAX_RETRY_REST_CNT Not Exceeded write appError {}; retryRestCnt={}, {}, response={}",
				MetaDataStatus.AUTOMATIC, retryRestCnt, message, response);
			errorCollection.writeToErrorCollection(message, MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.AUTOMATIC, statusCode + ": " + response);
			return MetaDataStatus.AUTOMATIC.ordinal();
		} catch (Exception e) {
			LOGGER.error("Failure: {}; {}", message != null ? message.toStringVerbose() : "NULL", ExceptionUtils.getStackTrace(e));
		}
		return rc;
	}

	protected int isMatchingSubstring(String str) {
		LOGGER.debug("str={}, restApiErrorProcessAutomaticArray={}", str, restApiErrorProcessAutomaticArray);
		return StringUtils.indexOfAny(str, restApiErrorProcessAutomaticArray);
	}

	protected String getExpandedUrl(Message message) {
		String replyToUrl;
		if ((replyToUrl = message.getReplyTo()) == null) {
			return null;
		}
		return delegateMap.get(replyToUrl);
	}

	protected String getReplyToIndex(Message message) {
		if (message.getReplyTo() == null) {
			LOGGER.error("Failure: message.getReplyTo() == null");
			return null;
		}
		return delegateIndexMap.get(message.getReplyTo());
	}

	@SuppressWarnings("unchecked")
	protected Integer getRetryCnt(String subject) {
		LOGGER.info("subject={}", subject);
		Map<String, Object> subjectMap;
		try {
			subjectMap = objectMapper.readValue(subject, HashMap.class);
			return (Integer) subjectMap.get(RETRY_CNT);
		} catch (JsonProcessingException e) {
			LOGGER.info("RETRY Failure: {}", e.getMessage());
			return null;
		}
	}

	protected static void maxStatistics(Message message) {
		if (recordStatistics <= 0) {
			return;
		}
		if (outstandingPayloadRequestMap.size() > maxOutstandingPayloadConcurrentRequests.get()) {
			maxOutstandingPayloadConcurrentRequests.incrementAndGet();
		}
		int priority = QueueEnum.getQueueEnum(message.getQueue()).ordinal();
		if (outstandingPayloadRequestsPerQueue.get(message.getQueue()) > maxOutstandingPayloadConcurrentRequestsPerQueue.get(priority)) {
			maxOutstandingPayloadConcurrentRequestsPerQueue.incrementAndGet(priority);
		}
	}

	protected static void retryStatistics(String queue) {
		if (recordStatistics <= 0) {
			return;
		}
		payloadRetries.incrementAndGet(QueueEnum.getQueueEnum(queue).ordinal());
	}

	protected static void ageOffStatistics(String queue) {
		if (recordStatistics <= 0) {
			return;
		}
		ageOffCount.incrementAndGet(QueueEnum.getQueueEnum(queue).ordinal());
	}

	public static void logStatistics() {
		if (recordStatistics <= 0) {
			return;
		}
		int payloadSuccessTotal = 0;
		int payloadFailureTotal = 0;
		int payloadRetriesTotal = 0;
		int ageOffCountTotal = 0;
		LOGGER.warn("STATS: maxOutstandingConcurrentRequests={}", maxOutstandingPayloadConcurrentRequests);
		for (int i = 0; i < BigQueueService.QUEUE_SUPPORTED_SIZE; i++) {
			payloadSuccessTotal += payloadSuccess.get(i);
			payloadFailureTotal += payloadFailure.get(i);
			payloadRetriesTotal += payloadRetries.get(i);
			ageOffCountTotal += ageOffCount.get(i);
			LOGGER.warn("STATS[{}]: payloadSuccess={}, payloadFailure={}, payloadRetries={}, ageOffCount={}, maxOutstandingConcurrentRequestsPerQueue={}, suspendDequeue={}",
				QueueEnum.getQueueShortNameAtIndex(i), payloadSuccess.get(i), payloadFailure.get(i), payloadRetries.get(i), ageOffCount.get(i),
				maxOutstandingPayloadConcurrentRequestsPerQueue.get(i), suspendDequeue.get(i));
		}
		LOGGER.warn("STATS[{}]: payloadSuccessTotal={}, payloadFailureTotal={}, payloadRetriesTotal={}, ageOffCountTotal={}",
			"Totals", payloadSuccessTotal, payloadFailureTotal, payloadRetriesTotal, ageOffCountTotal);
	}

	public class AsyncServiceCallback {
		private ReceiveAsyncResponse receiveAsyncResponse;
		private Message message;

		AsyncServiceCallback(ReceiveAsyncResponse receiveAsyncResponse, Message message) {
			this.receiveAsyncResponse = receiveAsyncResponse;
			this.message = message;
		}

		public ReceiveAsyncResponse getReceiveAsyncResponse() {
			return receiveAsyncResponse;
		}

		public Message getMessage() {
			return message;
		}

		@Override
		public String toString() {
			return "AsyncServiceCallback [" + message + "]";
		}

		public String toStringVerbose() {
			return "AsyncServiceCallback [" + message.toStringVerbose() + "]";
		}
	}

	public class BackPressureInfo {
		private Instant createInstant = Instant.now();
		private Message message = null;

		BackPressureInfo(Message message) {
			createInstant = Instant.now();
			this.message = message;
		}

		public Instant getCreateInstant() {
			return createInstant;
		}

		public Message getMessage() {
			return message;
		}

		@Override
		public String toString() {
			return "BackPressureInfo [createInstant=" + createInstant + ", message=" + message + "]";
		}

		public String toStringVerbose() {
			return "BackPressureInfo [createInstant=" + createInstant + ", message=" + message.toStringVerbose() + "]";
		}
	}

	protected class QueueExecutors {
		protected void newPremiumSingleThreadScheduledExecutor(int initialDelay, int subsequentDelay) {
			final String queue = QueueEnum.PREMIUM_PRIORITY_QUEUE.getQueue();
			ScheduledExecutorService scheduledQueueExecutorService = Executors.newSingleThreadScheduledExecutor();
			Runnable asyncRequest = () -> dequeueAndSendAsyncMessage(queue, premiumDequeueLimit);
			scheduledQueueExecutorService.scheduleAtFixedRate(asyncRequest, initialDelay, subsequentDelay, TimeUnit.SECONDS);
		}

		protected void newHighSingleThreadScheduledExecutor(int initialDelay, int subsequentDelay) {
			final String queue = QueueEnum.HIGH_PRIORITY_QUEUE.getQueue();
			ScheduledExecutorService scheduledQueueExecutorService = Executors.newSingleThreadScheduledExecutor();
			Runnable asyncRequest = () -> dequeueAndSendAsyncMessage(queue, highDequeueLimit);
			scheduledQueueExecutorService.scheduleAtFixedRate(asyncRequest, initialDelay, subsequentDelay, TimeUnit.SECONDS);
		}

		protected void newMediumSingleThreadScheduledExecutor(int initialDelay, int subsequentDelay) {
			final String queue = QueueEnum.MEDIUM_PRIORITY_QUEUE.getQueue();
			ScheduledExecutorService scheduledQueueExecutorService = Executors.newSingleThreadScheduledExecutor();
			Runnable asyncRequest = () -> dequeueAndSendAsyncMessage(queue, mediumDequeueLimit);
			scheduledQueueExecutorService.scheduleAtFixedRate(asyncRequest, initialDelay, subsequentDelay, TimeUnit.SECONDS);
		}

		protected void newLowSingleThreadScheduledExecutor(int initialDelay, int subsequentDelay) {
			final String queue = QueueEnum.LOW_PRIORITY_QUEUE.getQueue();
			ScheduledExecutorService scheduledQueueExecutorService = Executors.newSingleThreadScheduledExecutor();
			Runnable asyncRequest = () -> dequeueAndSendAsyncMessage(queue, lowDequeueLimit);
			scheduledQueueExecutorService.scheduleAtFixedRate(asyncRequest, initialDelay, subsequentDelay, TimeUnit.SECONDS);
		}

		protected void dequeueAndSendAsyncMessage(String queue, int dequeueLimit) {
			try {
				if (shutdown) {
					LOGGER.warn(SHUTDOWN_SKIPPING_SEND);
					return;
				}
				int priority = QueueEnum.getQueueEnum(queue).ordinal();
				if (suspendDequeue.get(priority) == 1) {
					LOGGER.warn("Queue currently in suspended dequeue mode: {}", queue);
					return;
				}
				List<Message> messages = bigQueueService.dequeueMessage(queue, dequeueLimit, outstandingPayloadRequestsPerQueue.get(queue));
				if (LOGGER.isInfoEnabled() && ! messages.isEmpty()) {
					LOGGER.info("Executor: {}; send message size={}", queue, messages.size());
				}
				messages.stream().forEach(MessageServiceMgr.this::sendAsyncMessage);
			} catch(ProcessException e) {
				// peekOrFlush Outstanding
				LOGGER.error(FAILURE_LOG, e.getMessage());
			} catch(Exception e) {
				LOGGER.error(FAILURE_LOG, ExceptionUtils.getStackTrace(e));
			}
		}
	}

	protected class ResendExecutors {
		protected void newSingleThreadScheduledExecutor(int initialDelay, int subsequentDelay) {
			LOGGER.warn("RESEND: initialDelay={}, subsequentDelay={}", initialDelay, subsequentDelay);
			ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
			Runnable runResend = () -> {
				if (shutdown) {
					LOGGER.warn("RESEND: SHUTDOWN; Skipping resend");
					return;
				}
				if (startup) {
					LOGGER.warn("Calling setup");
					setup();
				}
				String replyToIndex;
				LOGGER.debug("delegateList={}", delegateList);
				for (String replyTo : delegateList) {
					replyToIndex = delegateIndexMap.get(replyTo);
					LOGGER.info("replyTo={}, replyToIndex={}", replyTo, replyToIndex);
					try {
						List<ErrorMetaData> errorMetaDataList = errorCollection.getErrorList(MetaDataErrorCode.REST_API_ERROR, MetaDataStatus.AUTOMATIC, replyToIndex, appErrorQueryLimit);
						if (! errorMetaDataList.isEmpty()) {
							LOGGER.warn("RESEND: replyTo={}, replyToIndex={}, errorMetaDataList.size={}, appErrorQueryLimit={}", replyTo, replyToIndex, errorMetaDataList.size(), appErrorQueryLimit);
							enqueueErrorCollectionMsg(errorMetaDataList);
						} else {
							LOGGER.info("RESEND: No work to do; replyTo={}, replyToIndex={}, errorMetaDataList.size={}", replyTo, replyToIndex, errorMetaDataList.size());
						}
					} catch (Exception e) {
						LOGGER.error(FAILURE_LOG, ExceptionUtils.getStackTrace(e));
					}
				}
			};
			scheduledExecutorService.scheduleAtFixedRate(runResend, initialDelay, subsequentDelay, TimeUnit.SECONDS);
			LOGGER.debug("RESEND PROCESSING: Finished; initialDelay={}, subsequentDelay={}", initialDelay, subsequentDelay);
		}

		protected void enqueueErrorCollectionMsg(List<ErrorMetaData> errorMetaDataList) {
			boolean httpServerException;
			for (ErrorMetaData errorMetaData : errorMetaDataList) {
				try {
					httpServerException = false;
					MetaDataErrorCode errorCode = errorMetaData.getErrorCode();
					if (errorMetaData.getMessageId() == null) {
						// Engine HttpServerException to messageService
						httpServerException = true;
						QueueEnum queueEnum = QueueEnum.getQueueNameEnum(errorMetaData.getQueue());
						String queue = queueEnum.getQueue();
						errorMetaData.setQueue(queue);
						String messageId = UUID.randomUUID().toString();
						String subject = "{\"" + CommonConstants.ID + CommonConstants.ENCLOSED_COLON + errorMetaData.getIdentifier()
							+ CommonConstants.QUOTE_COMMA_QUOTE + CommonConstants.TARGET_ID
							+ CommonConstants.ENCLOSED_COLON + errorMetaData.getTargetId() + "\"}";
						errorMetaData.setMessageId(messageId);
						errorMetaData.setSubject(subject);
						errorMetaData.setDeliveryCount(0L);
						LOGGER.warn("RESEND: Have Engine HttpServerException: id={}, identifier={}, targetId={}, messageId={}",
							errorMetaData.getId(), errorMetaData.getIdentifier(), errorMetaData.getTargetId(), errorMetaData.getMessageId());
					}
					String subject = errorMetaData.getSubject();
					int retryCount = errorMetaData.getRetryCount();
					subject = setSubjectRetryCnt(subject);
					Message message = new Message(errorMetaData);
					String queue = message.getQueue();
					QueueEnum queueEnum = QueueEnum.getQueueEnum(queue);
					int priority = queueEnum.ordinal();
					if (outstandingPayloadRequestMap.containsKey(message.getMessageId())) {
						LOGGER.warn("RESEND: Skipping message is still outstanding; errorCode={}, {}", errorCode, message);
						continue;
					}
					message.setSubject(subject);
					message.setRetryCount(++retryCount);
					retryStatistics(queue);
					LOGGER.warn("RESEND: errorCode={}, {}", errorCode, message);
					enqueueMessage(priority, message, httpServerException);
				} catch (Exception e) {
					LOGGER.error("RESEND FAILURE; errorMetaData={}; {}", errorMetaData, ExceptionUtils.getStackTrace(e));
				}
			}
		}

		protected void enqueueMessage(int priority, Message message, boolean httpServerException) {
			try {
				bigQueueService.enqueueMessage(message);
				// Change status to QUEUED. If this fires again before its dequeued don't enqueue again
				LOGGER.info("RESEND: Changing state to {}; {}", MetaDataStatus.QUEUED, message);
				if (httpServerException) {
					errorCollection.updateErrorMetaDataMessageIdSubject(message.getMetadataId(), message.getMessageId(), message.getSubject(), MetaDataStatus.QUEUED);
				} else {
					errorCollection.updateErrorMetaDataStatus(message.getMetadataId(), MetaDataStatus.QUEUED);
				}
			} catch (ProcessException e) {
				LOGGER.error("RESEND: Skipping Message; priority={}, {}; msg={}", priority, message, e.getMessage());
			}
		}

		protected String setSubjectRetryCnt(String subject) {
			try {
				LOGGER.info("subject={}", subject);
				if (subject != null) {
					Integer retryCnt = getRetryCnt(subject);
					if (retryCnt == null) {
						retryCnt = 0;
					}
					subject = setRetryCnt(subject, retryCnt + 1);
					LOGGER.info(SET_LABEL_POST_LOG, subject);
				} else {
					LOGGER.warn("Subject: null");
					subject = RETRY_CNT_ONE;
					LOGGER.info(SET_LABEL_POST_LOG, subject);
				}
			} catch (Exception e) {
				LOGGER.error("Subject: failure; {}", e.getMessage());
				subject = setRetryCnt(subject, 1);
				LOGGER.error(SET_LABEL_POST_LOG, subject);
			}
			return subject;
		}

		@SuppressWarnings("unchecked")
		protected String setRetryCnt(String subject, Integer retryCnt) {
			LOGGER.debug("setRetryCnt: subject={}, retryCnt={}", subject, retryCnt);
			Map<String, Object> subjectMap;
			try {
				subjectMap = objectMapper.readValue(subject, HashMap.class);
				subjectMap.put(RETRY_CNT, retryCnt);
				subject = objectMapper.writeValueAsString(subjectMap);
			} catch (JsonProcessingException e) {
				LOGGER.error("RETRY Failure: {}", e.getMessage());
				return null;
			}
			LOGGER.info("setRetryCnt: return subject={}", subject);
			return subject;
		}
	}

	protected class AgeOffBackPressureExecutors {
		int executionCnt = 0;
		protected void newSingleThreadScheduledExecutor(int initialDelay, int subsequentDelay) {
			LOGGER.debug("AGE_OFF: initialDelay={}, subsequentDelay={}", initialDelay, subsequentDelay);
			ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
			Runnable ageOff = () -> {
				try {
					if (shutdown) {
						LOGGER.warn("AGE_OFF: SHUTDOWN; Skipping ageOffBackPressure");
						return;
					}
					if (recordStatistics > 0 && ++executionCnt >= recordStatistics) {
						logStatistics();
						executionCnt = 0;
					}
					LOGGER.info("AGE_OFF: ageOffSeconds={}", ageOffSeconds);
					Instant now = Instant.now();
					outstandingPayloadRequestMap.forEach((k, v) -> ageOffBackPressure(v, now));
				} catch (Exception e) {
					LOGGER.error(FAILURE_LOG, ExceptionUtils.getStackTrace(e));
				}
			};
			scheduledExecutorService.scheduleAtFixedRate(ageOff, initialDelay, subsequentDelay, TimeUnit.SECONDS);
			LOGGER.debug("RESEND PROCESSING: Finished; initialDelay={}, subsequentDelay={}", initialDelay, subsequentDelay);
		}

		protected void ageOffBackPressure(BackPressureInfo v, Instant now) {
			try {
				Message message = v.getMessage();
				String queue = message.getQueue();
				String messageId = message.getMessageId();
				String metadataId = message.getMetadataId();
				LOGGER.info("AGE_OFF: queue={}, messageId={}, metadataId={}, ageOffSeconds={}", queue, messageId, metadataId, ageOffSeconds);
				Duration d = Duration.between(v.getCreateInstant(), now);
				long secondsElapsed = d.getSeconds();
				if (secondsElapsed > ageOffSeconds.longValue()) {
					LOGGER.warn("AGE_OFF: queue={}, messageId={}, secondsElapsed={}, metadataId={}, ageOffSeconds={}",
						queue, messageId, secondsElapsed, metadataId, ageOffSeconds);
					removeOutstandingPayloadRequest(queue, messageId, null);
					ageOffStatistics(queue);
				}
			} catch (Exception e) {
				LOGGER.error(FAILURE_LOG, ExceptionUtils.getStackTrace(e));
			}
		}
	}
}
