package com.fds.paperless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessageServiceApplication {
	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(MessageServiceApplication.class);
		application.addListeners(new MessageServiceApplicationListener());
		application.run(args);
	}
}
