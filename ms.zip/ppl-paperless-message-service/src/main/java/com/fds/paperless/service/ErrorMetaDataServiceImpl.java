package com.fds.paperless.service;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.fds.paperless.mongo.ErrorMetaData;
import com.fds.paperless.mongo.MetaDataErrorCode;
import com.fds.paperless.mongo.MetaDataStatus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Calendar;

@Service
public class ErrorMetaDataServiceImpl implements ErrorMetaDataService {
	private static final Logger logger = LoggerFactory.getLogger(ErrorMetaDataServiceImpl.class);

	private static final String ID = "id";
	private static final String IDENTIFIER = "identifier";
	private static final String TARGET_ID = "targetId";
	private static final String REPLY_TO_INDEX = "replyToIndex";
	private static final String MESSAGE_ID = "messageId";
	private static final String ERROR_CODE = "errorCode";
	private static final String STATUS = "status";
	private static final String QUEUE = "queue";
	private static final String DOCUMENT_COLLECTION = "appError";
	private static final String ERROR_METADATA_LOG = "errorMetaData={}";
	private static final String DATE_CREATED = "dateCreated";

	@Autowired
	MongoTemplate mongoTemplate;

	@Value("${MONGO_QUERY_MAX_MILLIS:90000}")
	String mongoQueryMaxMillis;

	public synchronized void setMongoQueryMaxMillis(String mongoQueryMaxMillis) {
		this.mongoQueryMaxMillis = mongoQueryMaxMillis;
	}

	public Date dateThreeDaysAgo() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_YEAR, -3);
		return cal.getTime();
	}

	@Override
	public ErrorMetaData saveErrorMetaData(ErrorMetaData errorMetaData) {
		logger.info(ERROR_METADATA_LOG, errorMetaData);
		MongoOperations op = mongoTemplate;
		ErrorMetaData updatedDoc = null;
		String id = errorMetaData.getId();
		if (id == null || id.isEmpty()) {
			logger.info("Document doesn't exist id == null || id.isEmpty(); Insert");
			// document doesn't exist, insert
			updatedDoc = op.insert(errorMetaData);
			return updatedDoc;
		} else {
			// check document already exists in collection
			logger.info("Document exists; id={}", id);
			Query query = new Query();
			query.addCriteria(Criteria.where(ID).is(id));
			ErrorMetaData document = op.findOne(query, ErrorMetaData.class);
			if (document != null) {
				errorMetaData.setDateCreated(document.getDateCreated());
				mongoTemplate.save(errorMetaData, DOCUMENT_COLLECTION);
				return errorMetaData;
			} else {
				updatedDoc = op.insert(errorMetaData, DOCUMENT_COLLECTION);
				return updatedDoc;
			}
		}
	}

	@Override
	public ErrorMetaData getErrorMetaData(String id) {
		logger.info("id={}", id);
		Query query = new Query();
		query.addCriteria(Criteria.where(ID).is(id));
		MongoOperations op = mongoTemplate;
		return op.findOne(query, ErrorMetaData.class);
	}

	@Override
	public ErrorMetaData getErrorMetaDataByMessageId(String messageId) {
		logger.info(messageId);
		Query query = new Query();
		query.addCriteria(Criteria.where(MESSAGE_ID).is(messageId).and(DATE_CREATED).gte(dateThreeDaysAgo().toInstant()));
		MongoOperations op = mongoTemplate;
		return op.findOne(query, ErrorMetaData.class);
	}

	@Override
	public List<ErrorMetaData> getErrorList(MetaDataErrorCode errorCode, MetaDataStatus status, String replyToIndex, int limit) {
		logger.info("errorCode={}, status={}, replyToIndex={}", errorCode, status, replyToIndex);
		Query query = new Query();
		if (limit > 0) {
			query.limit(limit);
		}
		query.addCriteria(Criteria.where(ERROR_CODE).is(errorCode).and(STATUS).is(status).and(REPLY_TO_INDEX).is(replyToIndex).and(DATE_CREATED).gte(dateThreeDaysAgo().toInstant()));
		return mongoTemplate.find(query, ErrorMetaData.class);
	}

	@Override
	public List<ErrorMetaData> getErrorList(MetaDataErrorCode errorCode, MetaDataStatus status, String replyToIndex, String queue, int limit) {
		logger.info("errorCode={}, status={}, replyToIndex={}, queue={}", errorCode, status, replyToIndex, queue);
		Query query = new Query();
		if (limit > 0) {
			query.limit(limit);
		}
		query.addCriteria(Criteria.where(ERROR_CODE).is(errorCode).and(STATUS).is(status).and(REPLY_TO_INDEX).is(replyToIndex).and(QUEUE).is(queue).and(DATE_CREATED).gte(dateThreeDaysAgo().toInstant()));
		List<ErrorMetaData> errorList =  mongoTemplate.find(query, ErrorMetaData.class);
		logger.info("query={}, errorList.size={}", query, errorList.size());
		return errorList;
	}

	@Override
	public List<ErrorMetaData> getErrorListByIdentifier(String identifier) {
		logger.info("identifier={}", identifier);
		Query query = new Query();
		query.addCriteria(Criteria.where(IDENTIFIER).is(identifier).and(DATE_CREATED).gte(dateThreeDaysAgo().toInstant()));
		return mongoTemplate.find(query, ErrorMetaData.class);
	}

	@Override
	public List<ErrorMetaData> getErrorListByTargetId(String targetId) {
		logger.info("targetId={}", targetId);
		Query query = new Query();
		query.addCriteria(Criteria.where(TARGET_ID).is(targetId).and(DATE_CREATED).gte(dateThreeDaysAgo().toInstant()));
		return mongoTemplate.find(query, ErrorMetaData.class);
	}

	@Override
	public ErrorMetaData getErrorMetaDataByIndentifierTargetId(String indentifier, String targetId) {
		logger.info("indentifier={}, targetId={}", indentifier, targetId);
		Query query = new Query();
		query.addCriteria(Criteria.where(IDENTIFIER).is(indentifier).and(TARGET_ID).is(targetId).and(DATE_CREATED).gte(dateThreeDaysAgo().toInstant()));
		MongoOperations op = mongoTemplate;
		return op.findOne(query, ErrorMetaData.class);
	}

	// Used to set mongoTemplate in JUnit test
	public synchronized void setMongoTemplate(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}

	@Override
	public ErrorMetaData updateErrorMetaDataStatus(String id, MetaDataStatus status) {
		return updateErrorMetaDataStatus(id, status, null);
	}

	@Override
	public ErrorMetaData updateErrorMetaDataStatus(String id, MetaDataStatus status, String errorMessage) {
		logger.info("id={}, status={}, errorMessage={}", id, status, errorMessage);
		if (StringUtils.isEmpty(id)) {
			return null;
		}
		var query = new Query();
		query.addCriteria(Criteria.where(ID).is(id));
		MongoOperations op = mongoTemplate;
		ErrorMetaData errorMetaData = op.findOne(query, ErrorMetaData.class);
		if (errorMetaData == null) {
			return errorMetaData;
		}
		errorMetaData.setStatus(status);
		if (errorMessage != null) {
			errorMetaData.setErrorMessage(errorMessage);
		}
		errorMetaData.setDateModified(new java.util.Date());
		op.save(errorMetaData);
		logger.info(ERROR_METADATA_LOG, errorMetaData);
		return errorMetaData;
	}

	@Override
	public ErrorMetaData updateErrorMetaDataSubjectStatus(String id, String subject, MetaDataStatus status) {
		logger.info("id={}, subject={}, status={}", id, subject, status);
		if (StringUtils.isEmpty(id)) {
			return null;
		}
		var query = new Query();
		query.addCriteria(Criteria.where(ID).is(id));
		MongoOperations op = mongoTemplate;
		ErrorMetaData errorMetaData = op.findOne(query, ErrorMetaData.class);
		if (errorMetaData == null) {
			return errorMetaData;
		}

		errorMetaData.setSubject(subject);
		errorMetaData.setStatus(status);

		errorMetaData.setDateModified(new java.util.Date());
		op.save(errorMetaData);
		logger.info(ERROR_METADATA_LOG, errorMetaData);
		return errorMetaData;
	}

	@Override
	public ErrorMetaData updateErrorMetaDataMessageIdSubject(String id, String messageId, String subject, MetaDataStatus status) {
		logger.info("id={}, messageId={}, subject={}, status={}", id, messageId, subject, status);
		if (StringUtils.isEmpty(id)) {
			return null;
		}
		var query = new Query();
		query.addCriteria(Criteria.where(ID).is(id));
		MongoOperations op = mongoTemplate;
		ErrorMetaData errorMetaData = op.findOne(query, ErrorMetaData.class);
		if (errorMetaData == null) {
			return errorMetaData;
		}

		errorMetaData.setMessageId(messageId);
		errorMetaData.setSubject(subject);
		errorMetaData.setStatus(status);

		errorMetaData.setDateModified(new java.util.Date());
		op.save(errorMetaData);
		logger.info(ERROR_METADATA_LOG, errorMetaData);
		return errorMetaData;
	}

	private static final List<SimpleDateFormat> dateFormatList = List.of(
			new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
			new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'"),
			new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS"),
			new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
	);

	public Date convertISOStringToDate(String isoDate) {
		if (StringUtils.isNotEmpty(isoDate)) {
			var itr = dateFormatList.iterator();
			while (itr.hasNext()) {
				var format = itr.next();
				try {
					return format.parse(isoDate);
				} catch (ParseException e) {
					logger.error("Failure isoDate={}: {}", isoDate, e.getMessage());
				}
			}
		}
		return null;
	}
}