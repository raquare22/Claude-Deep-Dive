package com.fds.paperless.service;

import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.model.GenericResponse;
import com.fds.paperless.msgsvc.MessageServiceMgr.AsyncServiceCallback;

import javax.annotation.Nullable;

import static com.fds.paperless.constants.CommonConstants.REST_API_THREAD_DEFAULT;

@Service
public class AsyncService {
	@Autowired
	protected ObjectMapper objectMapper;

	protected static final String GATEWAY_TIMEOUT = "GATEWAY_TIMEOUT";
	protected static final String SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE";
	protected static final String REST_API_CONNECTION_REFUSED = "Connection refused";
	protected static final String REQUEST_TIMEOUT = "REQUEST_TIMEOUT";
	private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
	private static final String HEADER_ACCEPT = "Accept";
    private final HttpClient client;
	private static final Logger LOGGER = LoggerFactory.getLogger(AsyncService.class);

	AsyncService(@Value("${RestApiThreads}") @Nullable String restApiThreads) {
		String threads = ObjectUtils.isEmpty(restApiThreads) ? REST_API_THREAD_DEFAULT : restApiThreads;
        ExecutorService executorService = Executors.newFixedThreadPool(Integer.parseInt(threads));
		client = HttpClient.newBuilder().executor(executorService).build();
		LOGGER.info("INSTANTIATE: restApiThreads={}", threads);
	}

	public void postRequestToSvc(AsyncServiceCallback asyncServiceCallback, Long restApiTimeoutMs) {
		String replyToUrl = asyncServiceCallback.getMessage().getReplyTo();
		HttpRequest request = HttpRequest.newBuilder()
			.version(HttpClient.Version.HTTP_2)
			.uri(UriComponentsBuilder.fromUriString(replyToUrl).build().encode().toUri())
			.timeout(Duration.ofMillis(restApiTimeoutMs))
			.POST(HttpRequest.BodyPublishers.ofString(asyncServiceCallback.getMessage().getBody()))
			.headers("Content-Type", MediaType.APPLICATION_JSON_VALUE, HEADER_ACCEPT, "*/*")
			.build();
		LOGGER.info("SENDING: {}; restApiTimeoutMs={}", asyncServiceCallback, restApiTimeoutMs);
		client.sendAsync(request, BodyHandlers.ofString())
			.thenApply(response -> {
				applyResponse(response, asyncServiceCallback);
				return response;
		})
		.whenComplete((response, x) -> whenCompleteOnException(x, asyncServiceCallback))
		.thenApply(HttpResponse::body)
		.thenAccept(response -> LOGGER.info("Accept: response={}, {}", response, asyncServiceCallback)
		);
	}

	protected void applyResponse(HttpResponse<String> response, AsyncServiceCallback asyncServiceCallback) {
		LOGGER.info("Received response: response={}, {}", response.statusCode(), asyncServiceCallback);
		if (response.statusCode() == 200) {
			asyncServiceCallback.getReceiveAsyncResponse().processAsyncSuccess(asyncServiceCallback.getMessage());
		} else {
			ResponseEntity<GenericResponse> responseEntity = getResponseEntity(response, asyncServiceCallback);
			LOGGER.info("FAILURE: Calling processAsyncFailure; responseEntity={}, {}", responseEntity, asyncServiceCallback);
			asyncServiceCallback.getReceiveAsyncResponse().processAsyncFailure(asyncServiceCallback.getMessage(), responseEntity);
		}
	}

	protected void whenCompleteOnException(Throwable x, AsyncServiceCallback asyncServiceCallback) {
		ResponseEntity<GenericResponse> responseEntity = getResponseEntity(x, asyncServiceCallback);
		if (LOGGER.isInfoEnabled() && responseEntity.getStatusCode() != HttpStatus.REQUEST_TIMEOUT) {
			LOGGER.info("Calling processAsyncFailure; responseEntity={}, {}", responseEntity, asyncServiceCallback);
		}
		asyncServiceCallback.getReceiveAsyncResponse().processAsyncFailure(asyncServiceCallback.getMessage(), responseEntity);
	}

	protected ResponseEntity<GenericResponse> getResponseEntity(HttpResponse<String> httpResponse, AsyncServiceCallback asyncServiceCallback) {
		if (httpResponse == null ) {
			LOGGER.error("Failure: httpResponse == null {}", asyncServiceCallback);
			return new ResponseEntity<>(new GenericResponse("102", "Error during service call", "responseEntity == null"), HttpStatus.PROCESSING);
		}
		int statusCode = httpResponse.statusCode();
		String statusMessage = "Unknown";
		String response = "Unknown";
		HttpStatus httpStatus = statusCode == 200 ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
		if (statusCode == 503) {
			// openshift statusMessage and response can be null avoid JsonProcessingException
			httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
			statusMessage = SERVICE_UNAVAILABLE;
			response = SERVICE_UNAVAILABLE;
		}
		else {
			if (statusCode == 504) {
				httpStatus = HttpStatus.GATEWAY_TIMEOUT;
			}
			try {
				@SuppressWarnings("unchecked")
				Map<String, Object> httpResponseMap = objectMapper.readValue(httpResponse.body(), HashMap.class);
				statusMessage = (String) httpResponseMap.get("statusMessage");
				response = (String) httpResponseMap.get("response");
			} catch (JsonProcessingException e) {
				LOGGER.warn("httpResponseMap Failure: {}; {}", asyncServiceCallback, e.getMessage());
			}
		}
		LOGGER.info("Received response: statusCode={}, statusMessage={}, response={}, {}", statusCode, statusMessage, response, asyncServiceCallback);
		return new ResponseEntity<>(new GenericResponse(Integer.toString(statusCode), statusMessage, response), httpStatus);
	}

	protected ResponseEntity<GenericResponse> getResponseEntity(Throwable throwable, AsyncServiceCallback asyncServiceCallback) {
		// CompletableFuture: Request timed out or connection failures
		// x.getCause() instance of java.net.ConnectException || x.getCause() instance of HttpConnectTimeoutException
		//   ConnectException: Test no Engine (Exception thrown right away if a connection can't be established)
		//   HttpConnectionTimeoutException if the connection is not connected at the time the timeout is raised or
		//   if the connect timeout is raised before the connection has finished connecting.
		//   Test: RestApiTimeoutMs=1
		// x.getCause() instance of java.net.http.HttpTimeoutException
		//   Application timeout occurred
		//   Test: Introduce sleep at engine /run/delegate > RestApiTimeoutMs
		if (throwable instanceof CompletionException) {
			if (throwable.getCause() instanceof java.net.ConnectException || throwable.getCause() instanceof HttpConnectTimeoutException) {
				LOGGER.error("FAILURE: ConnectException occurred; {}; {}", asyncServiceCallback, throwable.getMessage());
				return new ResponseEntity<>(GenericResponse.from("504", GATEWAY_TIMEOUT, throwable.getClass().getSimpleName() + ":" +  throwable.getMessage()), HttpStatus.GATEWAY_TIMEOUT);
			}
			if (throwable.getCause() instanceof java.net.http.HttpTimeoutException) {
				LOGGER.info("Application timeout occurred: {}", asyncServiceCallback);
				return new ResponseEntity<>(GenericResponse.from("408", REQUEST_TIMEOUT,
					throwable.getClass().getSimpleName() + ":" +  throwable.getMessage() + ":Application timeout occurred"),
					HttpStatus.REQUEST_TIMEOUT);
			}
		}
		LOGGER.error("FAILURE: Unexpected exception occurred; {}; {}", asyncServiceCallback, throwable.getMessage());
		return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, throwable.getClass().getSimpleName() + ":" +  throwable.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}