package com.fds.paperless.constants;

public enum QueueEnum {
	PREMIUM_PRIORITY_QUEUE("PremiumPriorityQueue", "premium-priority-queues"),
	HIGH_PRIORITY_QUEUE("HighPriorityQueue", "high-priority-queues"),
	MEDIUM_PRIORITY_QUEUE("MediumPriorityQueue", "medium-priority-queues"),
	LOW_PRIORITY_QUEUE("LowPriorityQueue", "low-priority-queues");

	private final String queueName;
	private final String queue;

	QueueEnum(String queueName, String queue) {
		this.queueName = queueName;
		this.queue = queue;
	}

	// RestApiName
	public String getQueueName() {
		return queueName;
	}

	// BigQueueName
	public String getQueue() {
		return queue;
	}

	public static QueueEnum getQueueNameEnum(String queue) {
		if (queue.equals("PremiumPriorityQueue")) {
			return PREMIUM_PRIORITY_QUEUE;
		}
		if (queue.equals("HighPriorityQueue")) {
			return HIGH_PRIORITY_QUEUE;
		}
		if (queue.equals("MediumPriorityQueue")) {
			return MEDIUM_PRIORITY_QUEUE;
		}
		return LOW_PRIORITY_QUEUE;
	}

	public static QueueEnum getQueueEnum(String queue) {
		if (queue.equals("premium-priority-queues")) {
			return PREMIUM_PRIORITY_QUEUE;
		}
		if (queue.equals("high-priority-queues")) {
			return HIGH_PRIORITY_QUEUE;
		}
		if (queue.equals("medium-priority-queues")) {
			return MEDIUM_PRIORITY_QUEUE;
		}
		return LOW_PRIORITY_QUEUE;
	}

	public static String getQueueAtIndex(int index) {
		if (index == 0) {
			return "premium-priority-queues";
		}
		if (index == 1) {
			return "high-priority-queues";
		}
		if (index == 2) {
			return "medium-priority-queues";
		}
		return "low-priority-queues";
	}

	public static String getQueueShortNameAtIndex(int index) {
		if (index == 0) {
			return "Premium";
		}
		if (index == 1) {
			return "High";
		}
		if (index == 2) {
			return "Medium";
		}
		return "Low";
	}
}
