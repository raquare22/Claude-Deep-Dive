package com.fds.paperless;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

import com.fds.paperless.msgsvc.BigQueueService;
import com.fds.paperless.msgsvc.MessageServiceMgr;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MessageServiceApplicationListener implements ApplicationListener<ContextClosedEvent>{
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageServiceApplicationListener.class);

	@Override
	public void onApplicationEvent(ContextClosedEvent event) {
		LOGGER.warn("SHUTDOWN: event.getSource={}; Calling MessageServiceMgr.shutdown", event.getSource());
		BigQueueService.shutdown();
		MessageServiceMgr.shutdown();
		LOGGER.warn("SHUTDOWN: complete");
	}
}
