package com.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class MetaData implements Serializable {
	private static final long serialVersionUID = 1L;

	protected transient List<ErrorRevision> revisions;

    @Id
    String id;

    Date dateCreated;

    Date dateModified;

    @JsonIgnore
    Date dateCreatedIso;

    @JsonIgnore
    Date dateModifiedIso;

    @JsonProperty("status")
    MetaDataStatus status;

    String version;

    private String name;

    public MetaData() {
        dateCreated = new Date();
        dateModified = new Date();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ErrorRevision> getRevisions() {
        return revisions;
    }

    public void setRevisions(List<ErrorRevision> revisions) {
        this.revisions = revisions;
    }

    public MetaDataStatus getStatus() {
        return status;
    }

    @JsonIgnore
    public void setStatus(MetaDataStatus status) {
        this.status = status;
    }

    public void setStatus(String status) {
        this.status = MetaDataStatus.valueOf(status);
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) throws NumberFormatException {
        String versionString = StringUtils.isEmpty(version) ? "1" : version;

        if (Integer.parseInt(versionString) > 0) {
            this.version = versionString;
        }
    }

    public void incrementVersion() {
        version = String.valueOf(Integer.parseInt(version) + 1);
    }

	@Override
	public String toString() {
		return "MetaData [id=" + id + ", dateCreated=" + dateCreated + ", dateModified=" + dateModified
				+ ", dateCreatedIso=" + dateCreatedIso + ", dateModifiedIso=" + dateModifiedIso + ", status=" + status
				+ ", version=" + version + ", name=" + name + "]";
	}
}
