package com.fds.paperless.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fds.paperless.SanitizeUtil;
import com.fds.paperless.exception.ProcessException;
import com.fds.paperless.model.GenericResponse;
import com.fds.paperless.msgsvc.BigQueueService;
import com.fds.paperless.msgsvc.BigQueueService.FLUSH;
import com.fds.paperless.msgsvc.MessageServiceMgr;
import org.owasp.encoder.Encode;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/fds/api/azure/queue")
@Configuration
public class MessageServiceController {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageServiceController.class);

	public static final String PROD = "prod";
	private static final String INVALID_REQUEST = "Invalid request";
	private static final String PAYLOAD_SUCCESSFULLY_RECEIVED = "Payload successfully received for ";
	private static final String VALID_QUEUES = "queueName is not valid; Must be HighPriorityQueue, MediumPriorityQueue or LowPriorityQueue";
	private static final String ENTERING_QUEUE_REPLY_ID_TARGET_JSON_LOG = "Entering: queueName={}, replyTo={}, identifier={}, targetId={}";
	private static final String ENTERING_QUEUE_REPLY_ID_TARGET_SPACEID_JSON_LOG = "Entering: queueName={}, replyTo={}, identifier={}, targetId={}, spaceId={}";
	private static final String ENTERING_QUEUE_ID_TARGET_REPLY_LOG = "Entering: queueName={}, identifier={}, targetId={}, replyTo={}";
	private static final String ENTERING_QUEUE_ID_TARGET_SPACEID_REPLY_LOG = "Entering: queueName={}, identifier={}, targetId={}, spaceId={}, replyTo={}";
	private static final String QUEUE_NAME = "queueName={}";

	@Autowired
	MessageServiceMgr messageServiceMgr;

	@Autowired
	private ObjectMapper objectMapper;

	@Value("${server.port}")
	private String port;

	@PostMapping("/sendQueueWithIdentifiers/{queueName}/{replyTo}/{identifier}/{targetId}")
	public ResponseEntity<GenericResponse> sendQueueReplyTo(@PathVariable String queueName,
			@PathVariable String replyTo, @PathVariable String identifier, @PathVariable String targetId, @RequestBody String jsonStr) {
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace(ENTERING_QUEUE_REPLY_ID_TARGET_JSON_LOG,  Encode.forJava(queueName), Encode.forJava(replyTo), 
					Encode.forJava(identifier),  Encode.forJava(targetId));
		} else {
			LOGGER.debug(ENTERING_QUEUE_ID_TARGET_REPLY_LOG,  Encode.forJava(queueName),  Encode.forJava(identifier), 
					 Encode.forJava(targetId),  Encode.forJava(replyTo));
		}
		return sendQueueReplyTo(queueName, replyTo, identifier, targetId, -1, jsonStr);
	}

	@PostMapping("/sendQueueWithIdentifiers/{queueName}/{replyTo}/{identifier}/{targetId}/{spaceId}")
	public ResponseEntity<GenericResponse> sendQueueReplyTo(@PathVariable String queueName,
			@PathVariable String replyTo, @PathVariable String identifier, @PathVariable String targetId, @PathVariable Integer spaceId, @RequestBody String jsonStr) {
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace(ENTERING_QUEUE_REPLY_ID_TARGET_SPACEID_JSON_LOG,  Encode.forJava(queueName),  Encode.forJava(replyTo), 
					Encode.forJava(identifier),  Encode.forJava(targetId), spaceId);
		} else {
			LOGGER.debug(ENTERING_QUEUE_ID_TARGET_SPACEID_REPLY_LOG,  Encode.forJava(queueName),  Encode.forJava(identifier), 
					Encode.forJava(targetId), spaceId,  Encode.forJava(replyTo));
		}
		if (! MessageServiceMgr.isValidPriorityQueue(queueName)) {
			return new ResponseEntity<>(new GenericResponse("400", INVALID_REQUEST, VALID_QUEUES), HttpStatus.BAD_REQUEST);
		}
		try {
			messageServiceMgr.sendAsyncMessage(queueName, replyTo, identifier, targetId, spaceId, jsonStr);
		} catch (ProcessException e) {
			LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/sendQueueWithIdentifiers/{}/{}/{}/{}/{}, queueName={}, error={}", 
					HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(queueName), Encode.forJava(replyTo),
					Encode.forJava(identifier), Encode.forJava(targetId), spaceId, Encode.forJava(queueName), ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/sendQueueWithIdentifiers/{}/{}/{}/{}/{}, queueName={}, error={}", 
					HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(queueName), Encode.forJava(replyTo),
					Encode.forJava(identifier), Encode.forJava(targetId), spaceId, Encode.forJava(queueName), ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		String response = PAYLOAD_SUCCESSFULLY_RECEIVED + queueName;
		return new ResponseEntity<>(new GenericResponse("200", "OK", response), HttpStatus.OK);
	}

	@PostMapping("/peek/{queueName}/{writeToAppError}/{verbose}")
	public ResponseEntity<GenericResponse> peek(@PathVariable String queueName, @PathVariable Boolean writeToAppError, @PathVariable Boolean verbose) {
		LOGGER.warn("queueName={}, writeToAppError={}, verbose={}", Encode.forJava(queueName), writeToAppError, verbose);
		return peekOrFlush(queueName, null, null, null, null, FLUSH.NONE, writeToAppError, verbose);
	}

	@PostMapping("/peek/{queueName}/{identifier}/{targetId}/{spaceId}/{messageId}/{writeToAppError}/{verbose}")
	public ResponseEntity<GenericResponse> peek(@PathVariable String queueName, @PathVariable String identifier, @PathVariable String targetId,
			@PathVariable Integer spaceId, @PathVariable String messageId, @PathVariable Boolean writeToAppError, @PathVariable Boolean verbose) {
		LOGGER.warn("queueName={}, identifier={}, targetId={}, spaceId={}, messageId={}, writeToAppError={}, verbose={}",
				Encode.forJava(queueName), SanitizeUtil.sanitizeAlphaNumericString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), spaceId, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), writeToAppError, verbose);
		if (identifier.equals("null")) {
			identifier = null;
		}
		if (targetId.equals("null")) {
			targetId = null;
		}
		if (messageId.equals("null")) {
			messageId = null;
		}
		return peekOrFlush(queueName, identifier, targetId, spaceId, messageId, FLUSH.NONE, writeToAppError, verbose);
	}

	@PostMapping("/flush/{queueName}")
	public ResponseEntity<GenericResponse> flush(@PathVariable String queueName) {
		LOGGER.warn(QUEUE_NAME, Encode.forJava(queueName));
		return peekOrFlush(queueName, null, null, null, null, FLUSH.KEYED, false, false);
	}

	@PostMapping("/flush/{queueName}/{identifier}/{targetId}/{spaceId}/{messageId}")
	public ResponseEntity<GenericResponse> flush(@PathVariable String queueName, @PathVariable String identifier, @PathVariable String targetId,
			@PathVariable Integer spaceId, @PathVariable String messageId) {
		LOGGER.warn("queueName={}, identifier={}, targetId={}, spaceId={}, messageId={}", SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeAlphaNumericString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), spaceId, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId));
		if (identifier.equals("null")) {
			identifier = null;
		}
		if (targetId.equals("null")) {
			targetId = null;
		}
		if (messageId.equals("null")) {
			messageId = null;
		}
		return peekOrFlush(queueName, identifier, targetId, spaceId, messageId, FLUSH.KEYED, false, false);
	}

	@PostMapping("/hardFlush/{queueName}")
	public ResponseEntity<GenericResponse> hardFlush(@PathVariable String queueName) {
		LOGGER.warn(QUEUE_NAME, SanitizeUtil.sanitizeQueueName(queueName));
		return peekOrFlush(queueName, null, null, null, null, FLUSH.HARD, false, false);
	}

	@PostMapping("/flushInMemoryToDisk/{queueName}")
	public ResponseEntity<GenericResponse> flushInMemoryToDisk(@PathVariable String queueName) {
		LOGGER.warn(QUEUE_NAME, SanitizeUtil.sanitizeQueueName(queueName));
		return peekOrFlush(queueName, null, null, null, null, FLUSH.IN_MEMORY, false, false);
	}

	@PostMapping("/suspendDequeue/{queueName}")
	public ResponseEntity<GenericResponse> suspendDequeue(@PathVariable String queueName) {
		LOGGER.warn(QUEUE_NAME, SanitizeUtil.sanitizeQueueName(queueName));
		messageServiceMgr.suspendDequeue(queueName);
		return new ResponseEntity<>(new GenericResponse("200", "OK", "suspendDequeue success on " + queueName), HttpStatus.OK);
	}

	@PostMapping("/reactivateDequeue/{queueName}")
	public ResponseEntity<GenericResponse> enableDequeue(@PathVariable String queueName) {
		LOGGER.warn(QUEUE_NAME, SanitizeUtil.sanitizeQueueName(queueName));
		messageServiceMgr.reactivateDequeue(queueName);
		return new ResponseEntity<>(new GenericResponse("200", "OK", "reactivateDequeue success on " + queueName), HttpStatus.OK);
	}

	@PostMapping("/logStatistics")
	public ResponseEntity<GenericResponse> logStatistics() {
		try {
			MessageServiceMgr.logStatistics();
			BigQueueService.logQueueDetails();
		} catch (Exception e) {
			LOGGER.error("logStatistics error: {}", e.getMessage());
		}
		return new ResponseEntity<>(new GenericResponse("200", "OK", "logStatistics successful"), HttpStatus.OK);
	}

	protected ResponseEntity<GenericResponse> peekOrFlush(String queueName, String identifier, String targetId, Integer spaceId, String messageId,
			FLUSH flush, Boolean writeToAppError, Boolean verbose) {
		    LOGGER.warn("queueName={}, identifier={}, targetId={}, spaceId={}, messageId={}, writeToAppError={}, verbose={}",
			SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeAlphaNumericString(identifier), SanitizeUtil.sanitizeAlphaNumericString(targetId), spaceId, SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(messageId), writeToAppError, verbose);
		if (! MessageServiceMgr.isValidPriorityQueue(queueName)) {
			return new ResponseEntity<>(new GenericResponse("400", INVALID_REQUEST, VALID_QUEUES), HttpStatus.BAD_REQUEST);
		}
		try {
			messageServiceMgr.peekOrFlush(queueName, identifier, targetId, spaceId, messageId, flush, writeToAppError, verbose);
		} catch (ProcessException e) {
			LOGGER.error("Error in peekorFlush, HTTPStatus={}, queue={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, SanitizeUtil.sanitizeQueueName(queueName), e.getMessage());   
			return new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			LOGGER.error("Error in peekorFlush, HTTPStatus={}, queue={}, error={}", HttpStatus.INTERNAL_SERVER_ERROR, SanitizeUtil.sanitizeQueueName(queueName), ExceptionUtils.getStackTrace(e));   
			return new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		String response = "PeekOrFlush successful: queueName=" + queueName;
		return new ResponseEntity<>(new GenericResponse("200", "OK", response), HttpStatus.OK);
	}

	@PostMapping("/removeOutstandingPayloadRequests/{queueName}")
	public ResponseEntity<GenericResponse> removeOutstandingPayloadRequests(@PathVariable String queueName) {
		LOGGER.warn(QUEUE_NAME, SanitizeUtil.sanitizeQueueName(queueName));
		if (! MessageServiceMgr.isValidPriorityQueue(queueName)) {
			return new ResponseEntity<>(new GenericResponse("400", INVALID_REQUEST, VALID_QUEUES), HttpStatus.BAD_REQUEST);
		}
		int matchCnt = 0;
		try {
			matchCnt = messageServiceMgr.removeOutstandingPayloadRequests(queueName);
		} catch (ProcessException e) {
			LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/removeOutstandingPayloadRequests/{}, queueName={}, error={}",
					HttpStatus.INTERNAL_SERVER_ERROR, SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeQueueName(queueName), e.getMessage());
			return new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			LOGGER.error("Error to process workflow, HTTPStatus={}, apiPath=/removeOutstandingPayloadRequests/{}, queueName={}, error={}",
					HttpStatus.INTERNAL_SERVER_ERROR, SanitizeUtil.sanitizeQueueName(queueName), SanitizeUtil.sanitizeQueueName(queueName), e.getMessage());
			return new ResponseEntity<>(GenericResponse.from("500", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), ":" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		String response = "RemoveOutstandingPayloadRequests successful: queueName=" + queueName + ", matchCnt=" + matchCnt;
		return new ResponseEntity<>(new GenericResponse("200", "OK", response), HttpStatus.OK);
	}

	@PostMapping("/responseToRequest")
	public ResponseEntity<GenericResponse> responseToRequest(@RequestBody String jsonStr) {
		Map<String, Object> requestMap;
		try {
			requestMap = objectMapper.readValue(jsonStr, new TypeReference<>() {});
			String statusCodeStr = (String) requestMap.get("statusCode");
			HttpStatus statusCode = HttpStatus.valueOf(Integer.parseInt(statusCodeStr));
			String statusMessage = (String) requestMap.get("statusMessage");
			String response = (String) requestMap.get("response");
			ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(GenericResponse.from(statusCodeStr, statusMessage, response), statusCode);
			LOGGER.info("PRE: responseEntity={}", responseEntity);
			messageServiceMgr.processAsyncResponse(responseEntity);
			LOGGER.info("POST: responseEntity={}", responseEntity);
		} catch (JsonProcessingException e) {
			LOGGER.error("responseDetailMap error: {}", e.getMessage());
		}
		String response = "Response message processed";
		return new ResponseEntity<>(new GenericResponse("200", "OK", response), HttpStatus.OK);
	}
}
