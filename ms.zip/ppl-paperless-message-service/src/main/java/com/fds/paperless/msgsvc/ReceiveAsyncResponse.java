package com.fds.paperless.msgsvc;

import org.springframework.http.ResponseEntity;
import com.fds.paperless.model.GenericResponse;
import com.fds.paperless.model.Message;

public interface ReceiveAsyncResponse {
	public void processAsyncSuccess(Message message);
	public void processAsyncFailure(Message message, ResponseEntity<GenericResponse> responseEntity);
}
