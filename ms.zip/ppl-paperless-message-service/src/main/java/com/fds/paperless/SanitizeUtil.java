package com.fds.paperless;

import com.fds.paperless.constants.QueueEnum;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import org.bson.json.JsonObject;
import org.slf4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.util.Map;
import java.util.logging.Level;

public final class SanitizeUtil {
	protected static final String REGEX_REPLACEMENT_CHARACTER = "\\$";
	public static final String REPLACEMENT_CHARACTER = "$";

    private static final String AUTHORIZATION = "Authorization";

    private SanitizeUtil() {}

    public static String sanitizeJsonString(String input){
        try {
            return input == null ? null : JsonParser.parseString(input).toString();
        } catch (JsonSyntaxException e) {
            return "Sanitize Failure";
        }
    }

    public static HttpEntity<?> sanitizeHttpEntityHeaderRmAuth(HttpEntity<?> requestEntity) {
        requestEntity = new HttpEntity<>(requestEntity.getHeaders());
        HttpHeaders httpHeaders = requestEntity.getHeaders();
        httpHeaders.remove(AUTHORIZATION);
        if (requestEntity.getHeaders().getContentType() != null) {
            httpHeaders.setContentType(new MediaType(sanitizeJsonString(requestEntity.getHeaders().getContentType().toString())));
        }
        return requestEntity;
    }

    public static String sanitizeResponseEntityBody(ResponseEntity<?> response) {
        return response != null && response.getBody() != null ? sanitizeJsonString(response.getBody().toString()) : null;
    }

    public static String sanitizeQueueName(String str){
        return str == null ? null : QueueEnum.getQueueNameEnum(str).getQueueName();
    }

    public static String sanitizeToString(String str){
        return str == null ? null : str.replaceAll("\\v", "");
    }

    public static String sanitizeIntegerString(String str) {
        return str == null ? null : str.replaceAll("[^0-9]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaString(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaNumericString(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z0-9]", REGEX_REPLACEMENT_CHARACTER);
    }

    public static String sanitizeAlphaNumericStringWithHyphen(String str){
        return str == null ? null : str.replaceAll("[^a-zA-Z0-9-]", REGEX_REPLACEMENT_CHARACTER);
    }
    public static String sanitizeRequestMap(Map<String, Object> inputMap){
        if (inputMap == null){
            return null;
        }
        try{
            String jsonStr = new Gson().toJson(inputMap);
            String sanitizedJsonStr = JsonParser.parseString(jsonStr).toString();
            return sanitizedJsonStr;
        } catch (JsonSyntaxException e) {
            return "Sanitize Failure: " + e.getMessage();

        }

    }

}
