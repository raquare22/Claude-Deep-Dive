package com.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum MetaDataErrorCode {
	NONE,
	REST_API_ERROR,
	PEEKED;
}
