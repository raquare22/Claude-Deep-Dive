package com.fds.paperless.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Ping {

    private String buildNumber;

    private String timeStamp;

    public Ping(String buildNumber, String timeStamp) {
        this.buildNumber = buildNumber;
        this.timeStamp = timeStamp;
    }

    public String getBuildNumber() {
        return buildNumber;
    }

    public void setBuildNumber(String buildNumber) {
        this.buildNumber = buildNumber;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    @Override
    public String toString() {
        return "buildNumber: " + this.buildNumber + ", timeStamp: " + this.timeStamp;
    }


}
