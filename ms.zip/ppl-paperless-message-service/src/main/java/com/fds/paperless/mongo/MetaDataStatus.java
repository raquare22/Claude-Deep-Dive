package com.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum MetaDataStatus {
	AUTOMATIC,
	MANUAL,
	AVAILABLE,
	COMPLETE,
	DELETED,
	QUEUED;
}