package com.fds.paperless;

public interface NotifyOnConfigEvent {
	boolean configChange();
}