package com.optum.fds.paperless.provider;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.JsonSyntaxException;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.provider.pojo.PhysicianFacility;
import com.optum.fds.paperless.provider.pojo.PhysicianFacilityInformation;
import com.optum.fds.paperless.provider.pojo.ProviderSearchResults;
import com.optum.fds.paperless.provider.pojo.Records;
import com.optum.fds.paperless.provider.pojo.RequestBody;
import com.optum.fds.paperless.provider.pojo.RequestBodyNPI;
import com.optum.fds.paperless.provider.pojo.RequestHeader;
import com.optum.fds.paperless.provider.pojo.Rosterdata;
import com.optum.fds.paperless.provider.pojo.SvcResponse;
import com.optum.fds.paperless.provider.pojo.TaxId;
import com.optum.fds.paperless.provider.pojo.TaxIdType;
import com.optum.fds.paperless.util.HttpUtils;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.SanitizeUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class ProviderSearch {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProviderSearch.class);
	
    protected OauthManagerUtil oauthManagerUtil;

	private String searchUrl;
	private RestTemplate restTemplate;
	private EhCache ehCache;



	public ProviderSearch() {
		super();
	}

	public ProviderSearch(String searchUrl, RestTemplate restTemplate, OauthManagerUtil oauthManagerUtil, EhCache ehCache) {
		this.searchUrl = searchUrl;
		this.restTemplate = restTemplate;
		this.oauthManagerUtil = oauthManagerUtil;
		this.ehCache = ehCache;
	}

	public final Object searchProvider(RequestBody requestBody, RequestHeader requestHeader, DelegateExecution execution) throws Exception {
		Object providerInfo = null;

		var searchParams = new LinkedMultiValueMap<String, String>();
		searchParams.add("tax-id-nbr", requestBody.getTaxIdNumber());
		searchParams.add("app-nm", requestBody.getAppName());
		searchParams.add("attribute-set", requestBody.getAttributeSet());
		searchParams.add("count", requestBody.getCount());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.set("Accept", "application/xml");
		headers.set("authorization", "Bearer " + requestHeader.getToken());
		headers.set("timestamp", requestHeader.getTimeStamp());
		headers.set("scope", requestHeader.getScope());
		headers.set("actor", requestHeader.getActor());
		headers.set("correlation_id", requestHeader.getCorrelationId());
		try {

			ResponseEntity<String> response = HttpUtils.postExchange(headers, searchParams, searchUrl, String.class,
					restTemplate);

			if (HttpUtils.validateStatusCode(response.getStatusCode())) {
				return retrySearchProvider(headers, searchParams, execution);
			}
			String responseBody = Optional.of(response).map(ResponseEntity::getBody)
					.orElseThrow(() -> new RestClientException("Message"));

			MediaType mediaType = Optional.of(response).map(ResponseEntity::getHeaders).map(HttpHeaders::getContentType)
					.orElseThrow(() -> new RestClientException("Message"));

			return parseResponseBody(responseBody, mediaType);

		} catch (RestClientException e) {
			LOGGER.error("searchProvider Invoking Retry Mechanism error={}", ExceptionUtils.getStackTrace(e));
			providerInfo = retrySearchProvider(headers, searchParams, execution);

		} catch (IOException | JsonSyntaxException | NullPointerException e) {
			LOGGER.error("searchProvider Syntax exception {}", ExceptionUtils.getStackTrace(e));

			return null;

		} catch (Exception e) {
			LOGGER.error("searchProvider Error while Provider Search {}", ExceptionUtils.getStackTrace(e));

			throw e;
		}
		return providerInfo;
	}

	public final String searchProviderFromNPI(RequestBodyNPI requestBody, RequestHeader requestHeader, DelegateExecution execution) throws Exception {
		String providerInfoStr = null;

		var searchParams = new LinkedMultiValueMap<String, String>();
		searchParams.add("npi-id", requestBody.getNPI());
		searchParams.add("app-nm", requestBody.getAppName());
		searchParams.add("attribute-set", requestBody.getAttributeSet());
		searchParams.add("adr-typ-cd", requestBody.getadrTypeCD());
		searchParams.add("st-cd",requestBody.getstCd());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set("authorization", "Bearer " + requestHeader.getToken());
        headers.set("Accept", "application/xml");
		headers.set("timestamp", requestHeader.getTimeStamp());
		headers.set("scope", requestHeader.getScope());
		headers.set("actor", requestHeader.getActor());
		headers.set("correlation_id", requestHeader.getCorrelationId());
		LOGGER.info("retrieve providerData PES request body{}, searchUrl:{}", searchParams, searchUrl );
		try {
			ResponseEntity<String> response = HttpUtils.postExchange(headers, searchParams, searchUrl, String.class,
					null);
			LOGGER.info("retrieve providerData PES response:{}", Encode.forJava(response.getBody()) );

			if (HttpUtils.validateStatusCode(response.getStatusCode())) {
				return retrySearchProviderNPI(headers, searchParams, execution);
			}
			providerInfoStr = Optional.of(response).map(ResponseEntity::getBody)
					.orElseThrow(() -> new RestClientException("Message"));

			return providerInfoStr;

		} catch (RestClientException e) {
			LOGGER.error("searchProviderFromNPI Invoking Retry Mechanism , error={}", SanitizeUtil.sanitizeString(ExceptionUtils.getStackTrace(e)));

			providerInfoStr = retrySearchProviderNPI(headers, searchParams, execution);

		} catch (IOException | JsonSyntaxException | NullPointerException e) {
			LOGGER.error("searchProviderFromNPI Syntax exception {}", SanitizeUtil.sanitizeString(ExceptionUtils.getStackTrace(e)));

			return null;

		} catch (Exception e) {
			LOGGER.error("searchProviderFromNPI Error while Provider Search {}", SanitizeUtil.sanitizeString(ExceptionUtils.getStackTrace(e)));
			throw e;
		}
		return providerInfoStr;
	}


	public String getProviderCorpMpin(RequestBody requestBody, RequestHeader requestHeader, DelegateExecution execution) throws Exception {

		Object providerInfo = searchProvider(requestBody, requestHeader, execution);

		return (providerInfo instanceof ProviderSearchResults)
				? getProviderCorpMpin((ProviderSearchResults) providerInfo)
				: getProviderCorpMpin((PhysicianFacility) providerInfo);
	}

	public String getProviderCorpMpin(PhysicianFacility providerInfo) {
        return Optional.ofNullable(providerInfo).map(PhysicianFacility::getSvcResponse)
				.map(SvcResponse::getPhysicianFacilityInformation)
				.map(PhysicianFacilityInformation::getTaxId).flatMap(x -> x.stream().findFirst())
				.map(TaxIdType::getcorpMPIN).orElse(null);

	}

	public String getProviderCorpMpin(ProviderSearchResults providerInfo) {
        return Optional.ofNullable(providerInfo).map(ProviderSearchResults::getRecords)
				.filter(CollectionUtils::isNotEmpty).flatMap(x -> x.stream().findFirst()).map(Records::getRosterdata)
				.map(Rosterdata::getTaxId).filter(CollectionUtils::isNotEmpty).flatMap(x -> x.stream().findFirst())
				.flatMap(x -> x.stream().findFirst()).map(TaxId::getCorpOwnrProvId).orElse(null);
	}

	public String getProviderData(RequestBodyNPI requestBody, RequestHeader requestHeader, DelegateExecution execution) throws Exception {
		return searchProviderFromNPI(requestBody, requestHeader, execution);
	}
	
	public Map<String,String> getProviderCorpMpinAndProviderOrg(RequestBody requestBody, RequestHeader requestHeader, DelegateExecution execution) throws Exception {

		Object providerInfo = searchProvider(requestBody, requestHeader, execution);
		
		PhysicianFacility physicianFacilityInfo = (PhysicianFacility) providerInfo;
		Map<String,String> physicianInfoMap = new HashMap<>();
		
		String providerName = "";
		
		if(physicianFacilityInfo != null && physicianFacilityInfo.getSvcResponse() != null){
			
		  String firstName = physicianFacilityInfo.getSvcResponse().getPhysicianFacilityInformation().getFirstName();
		  String middleName = physicianFacilityInfo.getSvcResponse().getPhysicianFacilityInformation().getMiddleName();
		  String lastName = physicianFacilityInfo.getSvcResponse().getPhysicianFacilityInformation().getLastName(); 
		
		  String providerOrgName = firstName.trim() + middleName.trim() + lastName.trim();
		
		  
		  physicianInfoMap.put("corporateMpin", getProviderCorpMpin(physicianFacilityInfo));
		
		  if(StringUtils.isNotEmpty(providerOrgName)) {
			 providerName = firstName + " " + middleName + " " + lastName;
		  } else {
			providerName = physicianFacilityInfo.getSvcResponse().getPhysicianFacilityInformation().getFacilityName();
		  }
		  
		  // remove special characters
		  providerName = !providerName.isEmpty() ? providerName.replaceAll("[-\"\'+.^:,]", "") : providerName;

		  physicianInfoMap.put("providerName", providerName);

		 }else {
			LOGGER.warn("ProviderSearch-->getProviderCorpMpinAndProviderOrg-->physicianFacilityInfo or svcResponse is null for tin: {}", requestBody.getTaxIdNumber());
		}
		
	   return physicianInfoMap;
	}

	public Element getRootElement(String providerInfo) throws IOException {
		Element rootElement = null;
		ObjectOutputStream objectStream = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			InputStream stream = new ByteArrayInputStream(providerInfo.getBytes(StandardCharsets.UTF_8));

			Document document = builder.parse(stream);
			document.getDocumentElement().normalize();

			rootElement = document.getDocumentElement();
		} catch (Exception e) {
			LOGGER.error("Error converting provider response, {}", ExceptionUtils.getStackTrace(e));
		} finally {
			if (objectStream != null) {
				objectStream.flush();
			    objectStream.close();
			}
		}
		
		return rootElement;
	}

	public NodeList getElementFromRoot(Element rootElement, String tagName) {
		return rootElement.getElementsByTagName(tagName);
	}
	
	public String getProviderType(Element pfi) {
		Element providerType = (Element) pfi.getElementsByTagName("providerType").item(0);
		return providerType.getTextContent() != null ? providerType.getTextContent() : "";
	}
	
	public String getProviderTin(Element pfi){
		Element taxId = (Element) pfi.getElementsByTagName("taxId").item(0);
		return (taxId.getElementsByTagName("taxId").item(0).getTextContent() != null)
				? taxId.getElementsByTagName("taxId").item(0).getTextContent()
				: "";
	}

	public String getPostalAddress(Element pfi, String tag) {
		Element address = (Element) pfi.getElementsByTagName("address").item(0);
		Element postalAddress = (Element) address.getElementsByTagName("postalAddress").item(0);
		return (postalAddress.getElementsByTagName(tag).item(0).getTextContent() != null)
				? postalAddress.getElementsByTagName(tag).item(0).getTextContent()
				: "";
	}

	public String getProviderFirstName(Element pfi) {
		Element firstName = (Element) pfi.getElementsByTagName("firstName").item(0);
		return (firstName.getTextContent() != null) ? firstName.getTextContent() : "";
	}

	public String getProviderLastName(Element pfi) {
		Element lastName = (Element) pfi.getElementsByTagName("lastName").item(0);
		return (lastName.getTextContent() != null) ? lastName.getTextContent() : "";
	}

	public String getGroupName(Element pfi) {
		Element taxId = (Element) pfi.getElementsByTagName("taxId").item(0);
		String fName = (taxId.getElementsByTagName("payeeFirstName").item(0).getTextContent() != null) ? taxId.getElementsByTagName("payeeFirstName").item(0).getTextContent() : "";
		String mName = (taxId.getElementsByTagName("payeeMiddleName").item(0).getTextContent() != null) ? taxId.getElementsByTagName("payeeMiddleName").item(0).getTextContent() : "";
		String lName = (taxId.getElementsByTagName("payeeLastName").item(0).getTextContent() != null) ? taxId.getElementsByTagName("payeeLastName").item(0).getTextContent() : "";

		return (fName.equals("")? "": fName + " ") + (mName.equals("")? "": mName + " ") + lName;
	}

	public String getResponseCount(Element pfi) {
		Element taxId = (Element) pfi.getElementsByTagName("taxId").item(0);
		String fName = (taxId.getElementsByTagName("payeeFirstName").item(0).getTextContent() != null) ? taxId.getElementsByTagName("payeeFirstName").item(0).getTextContent() : "";
		String mName = (taxId.getElementsByTagName("payeeMiddleName").item(0).getTextContent() != null) ? taxId.getElementsByTagName("payeeMiddleName").item(0).getTextContent() : "";
		String lName = (taxId.getElementsByTagName("payeeLastName").item(0).getTextContent() != null) ? taxId.getElementsByTagName("payeeLastName").item(0).getTextContent() : "";

		return (fName.equals("")? "": fName + " ") + (mName.equals("")? "": mName + " ") + lName;
	}

	public final String retrySearchProviderNPI(HttpHeaders headers, MultiValueMap<?, ?> searchParams, DelegateExecution execution) throws Exception {
		int count = 0;
		int retrieveCorpMPINCallRetryInterval = 1000;
		int retryCount = 3;

		var pesAppId = execution.getVariable(Workflow.PES_APP_ID, String.class);
		var pesAppSecret = execution.getVariable(Workflow.PES_APP_SECRET, String.class);
		var pesUrl = execution.getVariable(Workflow.PES_OAUTH_URL, String.class);
		var pesGrantType = execution.getVariable(Workflow.PES_GRANT_TYPE, String.class);

		// get new token for retry
		String newToken = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId,
				pesAppSecret, pesGrantType, pesUrl, true, null);
		headers.set("authorization", "Bearer " + newToken); 

		
		LOGGER.info("retrieveProviderData PES retry request searchParams:{}, searchUrl:{}, interval:{}, retryCount:{} ", searchParams, searchUrl
				,retrieveCorpMPINCallRetryInterval, retryCount );

		while (count < retryCount) {
			try {
				synchronized (this) {
					this.wait(retrieveCorpMPINCallRetryInterval);
				}
				ResponseEntity<String> response = HttpUtils.postExchange(headers, searchParams, searchUrl, String.class,
						restTemplate);

				String responseBody = Optional.of(response).map(ResponseEntity::getBody).orElse(null);

				return responseBody;

			} catch (HttpServerErrorException e) {
				if (HttpUtils.validateStatusCode(e.getStatusCode())) {
					LOGGER.error("retrySearchProvider Provider Search - Invoking Retry Mechanism Again: {} ", count);
					if (count == (retryCount - 1)) {
						LOGGER.error("retrySearchProvider HTTP 5xx Error after {} retries - Provider Search", count);
						LOGGER.error("retrySearchProvider for error={}", ExceptionUtils.getStackTrace(e));
						throw e;
					}
				} else {
					throw e;
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw e;
			} catch (Exception e) {
				LOGGER.error("retrySearchProvider Error while Provider Search error={}", ExceptionUtils.getStackTrace(e));
				throw e;
			} finally {
				count++;
			}
		}
		return null;
	}


	public final Object retrySearchProvider(HttpHeaders headers, MultiValueMap<?, ?> searchParams, DelegateExecution execution) throws Exception {
		int count = 0;
		int retrieveCorpMPINCallRetryInterval = 1000;
		int retryCount = 3;
		
		// get new token for retry
		var pesAppId = execution.getVariable(Workflow.PES_APP_ID, String.class);
		var pesAppSecret = execution.getVariable(Workflow.PES_APP_SECRET, String.class);
		var pesUrl = execution.getVariable(Workflow.PES_OAUTH_URL, String.class);
		var pesGrantType = execution.getVariable(Workflow.PES_GRANT_TYPE, String.class);

		// get new token for retry
		String newToken = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId,
				pesAppSecret, pesGrantType, pesUrl, true, null);
		headers.set("authorization", "Bearer " + newToken); 

		
		LOGGER.info("retrievecorpMPIN PES retry request interval:{}, retryCount:{} ", retrieveCorpMPINCallRetryInterval, retryCount );

		while (count < retryCount) {
			try {
				synchronized (this) {
					this.wait(retrieveCorpMPINCallRetryInterval);
				}
				ResponseEntity<String> response = HttpUtils.postExchange(headers, searchParams, searchUrl, String.class,
						restTemplate);

				String responseBody = Optional.of(response).map(ResponseEntity::getBody).orElse(null);
				MediaType mediaType = Optional.of(response).map(ResponseEntity::getHeaders)
						.map(HttpHeaders::getContentType).orElse(null);

				return parseResponseBody(responseBody, mediaType);

			} catch (HttpServerErrorException e) {
				if (HttpUtils.validateStatusCode(e.getStatusCode())) {
					LOGGER.error("retrySearchProvider Provider Search - Invoking Retry Mechanism Again: {} ", count);
					if (count == (retryCount - 1)) {
						LOGGER.error("retrySearchProvider HTTP 5xx Error after {} retries - Provider Search", count);
						LOGGER.error("retrySearchProvider error={}", ExceptionUtils.getStackTrace(e));
						throw e;
					}
				} else {
					throw e;
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw e;
			} catch (Exception e) {
				LOGGER.error("retrySearchProvider Error while Provider Search error={}", ExceptionUtils.getStackTrace(e));
				throw e;
			} finally {
				count++;
			}
		}
		return null;
	}

	public Object parseResponseBody(String responseBody, MediaType mediaType) throws IOException {
        if (responseBody != null && mediaType != null) {
			if (mediaType.equals(MediaType.APPLICATION_XML)) {
				LOGGER.info("xml -> PhysicianFacility, response body: {}, mediaType: {}", Encode.forJava(responseBody), mediaType);
				return Parser.parseXML(responseBody, PhysicianFacility.class);
			} else {
				LOGGER.info("json -> ProviderSearchResults, response body: {}, mediaType: {}", Encode.forJava(responseBody), mediaType);
				return Parser.parseJson(responseBody, ProviderSearchResults.class, false);
			}
		}
		return null;
	}

}