package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "addressType", propOrder = {
        "addressId",
        "addressTypeDescription",
        "postalAddress"
})

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class AddressType implements Serializable {

    protected String addressId;
    protected String addressTypeDescription;
    protected PostalAddressType postalAddress;

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getAddressTypeDescription() {
        return addressTypeDescription;
    }

    public void setAddressTypeDescription(String addressTypeDescription) {
        this.addressTypeDescription = addressTypeDescription;
    }

    public PostalAddressType getPostalAddress() {
        return postalAddress;
    }

    public void setPostalAddress(PostalAddressType postalAddress) {
        this.postalAddress = postalAddress;
    }
}
