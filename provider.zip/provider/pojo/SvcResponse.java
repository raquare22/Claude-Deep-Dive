package com.optum.fds.paperless.provider.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class SvcResponse implements Serializable {
    private PhysicianFacilityInformation physicianFacilityInformation;

    public PhysicianFacilityInformation getPhysicianFacilityInformation() {
        return physicianFacilityInformation;
    }

    public void setPhysicianFacilityInformation(PhysicianFacilityInformation physicianFacilityInformation) {
        this.physicianFacilityInformation = physicianFacilityInformation;
    }
}
