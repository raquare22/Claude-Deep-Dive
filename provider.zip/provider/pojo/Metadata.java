package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Metadata {
    private int offset;
    private int psize;
    private int total;
    @JsonProperty("elapsedTime")
    private String elapsedtime;
    @JsonProperty("elasticTime")
    private String elastictime;
    public void setOffset(int offset) {
        this.offset = offset;
    }
    public int getOffset() {
        return offset;
    }

    public void setPsize(int psize) {
        this.psize = psize;
    }
    public int getPsize() {
        return psize;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    public int getTotal() {
        return total;
    }

    public void setElapsedtime(String elapsedtime) {
        this.elapsedtime = elapsedtime;
    }
    public String getElapsedtime() {
        return elapsedtime;
    }

    public void setElastictime(String elastictime) {
        this.elastictime = elastictime;
    }
    public String getElastictime() {
        return elastictime;
    }
}
