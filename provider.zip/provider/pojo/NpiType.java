package com.optum.fds.paperless.provider.pojo;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for npiType complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="npiType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="npi" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="npiLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "npiType", propOrder = {
        "npi",
        "npiLevelCode"
})

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class NpiType implements Serializable {

    protected String npi;
    protected String npiLevelCode;

    /**
     * Gets the value of the npi property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNpi() {
        return npi;
    }

    /**
     * Sets the value of the npi property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNpi(String value) {
        this.npi = value;
    }

    /**
     * Gets the value of the npiLevelCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNpiLevelCode() {
        return npiLevelCode;
    }

    /**
     * Sets the value of the npiLevelCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNpiLevelCode(String value) {
        this.npiLevelCode = value;
    }

}
