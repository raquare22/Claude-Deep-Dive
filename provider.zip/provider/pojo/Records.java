package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Records {

    @JsonProperty("rosterData")
    private Rosterdata rosterdata;

    public void setRosterdata(Rosterdata rosterdata) {
        this.rosterdata = rosterdata;
    }
    public Rosterdata getRosterdata() {
        return rosterdata;
    }

}