package com.optum.fds.paperless.provider.pojo;

public class RequestBody {
    private final String taxIdNumber;
    private final String appName;
    private final String attributeSet;
    private final String count;

    private RequestBody(RequestBodyBuilder requestBodyBuilder) {
       taxIdNumber = requestBodyBuilder.taxIdNumber;
       appName = requestBodyBuilder.appName;
       attributeSet = requestBodyBuilder.attributeSet;
       count = requestBodyBuilder.count;
    }

    public static class RequestBodyBuilder {
        private String taxIdNumber;
        private String appName;
        private String attributeSet;
        private String count;

        public RequestBodyBuilder setCount(String count) {
            this.count = count;
            return this;
        }

        public RequestBodyBuilder setTaxIdNumber(String taxIdNumber) {
            this.taxIdNumber = taxIdNumber;
            return this;
        }

        public RequestBodyBuilder setAppName(String appName) {
            this.appName = appName;
            return this;
        }

        public RequestBodyBuilder setAttributeSet(String attributeSet) {
            this.attributeSet = attributeSet;
            return this;
        }

        public RequestBody build() {
            return new RequestBody(this);
        }
    }


    public String getTaxIdNumber() {
        return taxIdNumber;
    }

    public String getAppName() {
        return appName;
    }

    public String getAttributeSet() {
        return attributeSet;
    }

    public String getCount() {
        return count;
    }

	@Override
	public String toString() {
		return "RequestBody [taxIdNumber=" + taxIdNumber + ", appName=" + appName + ", attributeSet=" + attributeSet
				+ ", count=" + count + "]";
	}
    
    

}
