package com.optum.fds.paperless.provider.pojo;

public class RequestBodyNPI {
    private final String npi;
    private final String appName;
    private final String attributeSet;
    private final String adrTypeCd;
    private final String stCd;


    private RequestBodyNPI(RequestBodyNPI.RequestBodyBuilder requestBodyBuilder) {
        npi = requestBodyBuilder.npi;
        appName = requestBodyBuilder.appName;
        attributeSet = requestBodyBuilder.attributeSet;
        adrTypeCd = requestBodyBuilder.adrTypeCD;
        stCd = requestBodyBuilder.stCd;
    }

    public static class RequestBodyBuilder {
        private String npi;
        private String appName;
        private String attributeSet;
        private String adrTypeCD;
        private String stCd;

        public RequestBodyNPI.RequestBodyBuilder setadrTypeCD(String adrTypeCD) {
            this.adrTypeCD = adrTypeCD;
            return this;
        }

        public RequestBodyNPI.RequestBodyBuilder setNPI(String npi) {
            this.npi = npi;
            return this;
        }

        public RequestBodyNPI.RequestBodyBuilder setAppName(String appName) {
            this.appName = appName;
            return this;
        }

        public RequestBodyNPI.RequestBodyBuilder setAttributeSet(String attributeSet) {
            this.attributeSet = attributeSet;
            return this;
        }
        public RequestBodyNPI.RequestBodyBuilder setstCd(String stCd) {
            this.stCd = stCd;
            return this;
        }

        public RequestBodyNPI build() {
            return new RequestBodyNPI(this);
        }
    }


    public String getNPI() {
        return npi;
    }

    public String getAppName() {
        return appName;
    }

    public String getAttributeSet() {
        return attributeSet;
    }

    public String getadrTypeCD() {
        return adrTypeCd;
    }
    public String getstCd() {
        return stCd;
    }

    @Override
    public String toString() {
        return "RequestBodyNPI [npi=" + npi + ", appName=" + appName + ", attributeSet=" + attributeSet
                + ", adrTypeCD=" + adrTypeCd + ", stCd=" + stCd +"]";

    }


}
