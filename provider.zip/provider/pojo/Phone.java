package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Phone {

    @JsonProperty("tel_actv_cd")
    private String telActvCd;
    @JsonProperty("tel_pri_cd")
    private String telPriCd;
    @JsonProperty("tel_ext_nbr")
    private String telExtNbr;
    @JsonProperty("tel_use_typ_cd")
    private String telUseTypCd;
    @JsonProperty("tel_use_typ_desc")
    private String telUseTypDesc;
    @JsonProperty("area_cd")
    private String areaCd;
    @JsonProperty("tel_nbr")
    private String telNbr;
    public void setTelActvCd(String telActvCd) {
        this.telActvCd = telActvCd;
    }
    public String getTelActvCd() {
        return telActvCd;
    }

    public void setTelPriCd(String telPriCd) {
        this.telPriCd = telPriCd;
    }
    public String getTelPriCd() {
        return telPriCd;
    }

    public void setTelExtNbr(String telExtNbr) {
        this.telExtNbr = telExtNbr;
    }
    public String getTelExtNbr() {
        return telExtNbr;
    }

    public void setTelUseTypCd(String telUseTypCd) {
        this.telUseTypCd = telUseTypCd;
    }
    public String getTelUseTypCd() {
        return telUseTypCd;
    }

    public void setTelUseTypDesc(String telUseTypDesc) {
        this.telUseTypDesc = telUseTypDesc;
    }
    public String getTelUseTypDesc() {
        return telUseTypDesc;
    }

    public void setAreaCd(String areaCd) {
        this.areaCd = areaCd;
    }
    public String getAreaCd() {
        return areaCd;
    }

    public void setTelNbr(String telNbr) {
        this.telNbr = telNbr;
    }
    public String getTelNbr() {
        return telNbr;
    }

}