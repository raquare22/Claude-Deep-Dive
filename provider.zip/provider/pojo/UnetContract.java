package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class UnetContract {

    @JsonProperty("acpt_ptnt_cd")
    private String acptPtntCd;
    @JsonProperty("prov_contr_role_cd")
    private String provContrRoleCd;

    public void setAcptPtntCd(String acptPtntCd) {
        this.acptPtntCd = acptPtntCd;
    }
    public String getAcptPtntCd() {
        return acptPtntCd;
    }

    public void setProvContrRoleCd(String provContrRoleCd) {
        this.provContrRoleCd = provContrRoleCd;
    }
    public String getProvContrRoleCd() {
        return provContrRoleCd;
    }

}