package com.optum.fds.paperless.provider.pojo;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for uhpdType complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="uhpdType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="efficiency" type="{}efficiencyType" minOccurs="0"/>
 *         &lt;element name="focusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="focusDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="qeDesignationTierNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="qeDesignationPriority" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="quality" type="{}qualityType" minOccurs="0"/>
 *         &lt;element name="uhpdDateRange" type="{}uhpdDateRangeType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "uhpdType", propOrder = {
        "efficiency",
        "focusCode",
        "focusDescription",
        "qeDesignationTierNumber",
        "qeDesignationPriority",
        "quality",
        "uhpdDateRange"
})

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class UhpdType implements Serializable {

    protected EfficiencyType efficiency;
    protected String focusCode;
    protected String focusDescription;
    protected String qeDesignationTierNumber;
    protected String qeDesignationPriority;
    protected QualityType quality;
    protected UhpdDateRangeType uhpdDateRange;

    /**
     * Gets the value of the efficiency property.
     *
     * @return
     *     possible object is
     *     {@link EfficiencyType }
     *
     */
    public EfficiencyType getEfficiency() {
        return efficiency;
    }

    /**
     * Sets the value of the efficiency property.
     *
     * @param value
     *     allowed object is
     *     {@link EfficiencyType }
     *
     */
    public void setEfficiency(EfficiencyType value) {
        this.efficiency = value;
    }

    /**
     * Gets the value of the focusCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFocusCode() {
        return focusCode;
    }

    /**
     * Sets the value of the focusCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFocusCode(String value) {
        this.focusCode = value;
    }

    /**
     * Gets the value of the focusDescription property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFocusDescription() {
        return focusDescription;
    }

    /**
     * Sets the value of the focusDescription property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFocusDescription(String value) {
        this.focusDescription = value;
    }

    /**
     * Gets the value of the qeDesignationTierNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getQeDesignationTierNumber() {
        return qeDesignationTierNumber;
    }

    /**
     * Sets the value of the qeDesignationTierNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setQeDesignationTierNumber(String value) {
        this.qeDesignationTierNumber = value;
    }

    /**
     * Gets the value of the qeDesignationPriority property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getQeDesignationPriority() {
        return qeDesignationPriority;
    }

    /**
     * Sets the value of the qeDesignationPriority property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setQeDesignationPriority(String value) {
        this.qeDesignationPriority = value;
    }

    /**
     * Gets the value of the quality property.
     *
     * @return
     *     possible object is
     *     {@link QualityType }
     *
     */
    public QualityType getQuality() {
        return quality;
    }

    /**
     * Sets the value of the quality property.
     *
     * @param value
     *     allowed object is
     *     {@link QualityType }
     *
     */
    public void setQuality(QualityType value) {
        this.quality = value;
    }

    /**
     * Gets the value of the uhpdDateRange property.
     *
     * @return
     *     possible object is
     *     {@link UhpdDateRangeType }
     *
     */
    public UhpdDateRangeType getUhpdDateRange() {
        return uhpdDateRange;
    }

    /**
     * Sets the value of the uhpdDateRange property.
     *
     * @param value
     *     allowed object is
     *     {@link UhpdDateRangeType }
     *
     */
    public void setUhpdDateRange(UhpdDateRangeType value) {
        this.uhpdDateRange = value;
    }

}
