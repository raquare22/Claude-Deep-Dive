package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Degree {

    @JsonProperty("deg_cd")
    private String degCd;
    @JsonProperty("deg_pri_cd")
    private String degPriCd;
    @JsonProperty("deg_desc")
    private String degDesc;
    public void setDegCd(String degCd) {
        this.degCd = degCd;
    }
    public String getDegCd() {
        return degCd;
    }

    public void setDegPriCd(String degPriCd) {
        this.degPriCd = degPriCd;
    }
    public String getDegPriCd() {
        return degPriCd;
    }

    public void setDegDesc(String degDesc) {
        this.degDesc = degDesc;
    }
    public String getDegDesc() {
        return degDesc;
    }


}
